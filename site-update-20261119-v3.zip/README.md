# NEO Before / After — 20261119-v3

Independent bilingual NEO design guide. Open questions appear beneath each Solution. NEO-029 After includes the interactive calculation progress, ready reminder and saved result.
