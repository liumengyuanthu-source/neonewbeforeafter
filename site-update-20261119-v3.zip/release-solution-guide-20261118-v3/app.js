'use strict';
const C=window.MUST_CATALOG, B=window.BEFORE_MAP, E=window.MUST_EN;
const OLD='../must-design-guide-20261115-v1/';
const $=s=>document.querySelector(s), esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const KEY='neo-release-review-v2-'+C.sourceSha256.slice(0,12);
let notes={};try{notes=JSON.parse(localStorage.getItem(KEY)||'{}');}catch{}
const params=()=>new URLSearchParams(location.hash.split('?')[1]||'');
const t=(zh,en)=>lang==='zh'?zh:en;
const groups=['p1','p2','cr','non-system','all','baseline'];
const priorities=['Must_Urgent','Must','Should','Could','Not Now','N/A - Non System requirement.'];
let lang='zh',side='after',release='p1',priority='all',tab='page',current='NEO-001';
const title=r=>lang==='en'?(E[r.id]?.title||r.title):r.title;
const status=id=>['seen','feedback'].includes(notes[id]?.status)?notes[id].status:'unread';
const statusLabels=()=>({unread:t('未看','Not reviewed'),seen:t('已看','Reviewed'),feedback:t('有意见','Feedback')});
const groupLabel=g=>({p1:t('一期 · 1月21日','Phase 1 · 21 Jan'),p2:t('二期 · 4月26日','Phase 2 · 26 Apr'),cr:t('CR · 暂不排期','CR · Not scheduled'),'non-system':t('非系统事项','Non-system'),all:t('全部','All'),baseline:t('AS-IS 基线','AS-IS baseline')})[g];
const priorityLabel=p=>p==='Must_Urgent'?'Must Urgent':p.startsWith('N/A')?t('非系统','Non-system'):p;
const inRelease=r=>release==='all'||r.releaseGroup===release;
const baseRows=()=>C.rows.filter(inRelease).sort((a,b)=>a.priorityRank-b.priorityRank||a.id.localeCompare(b.id));
function filtered(){
 const q=$('#search').value.trim().toLowerCase();
 return baseRows().filter(r=>(priority==='all'||r.jointPriority===priority)&&($('#category').value==='all'||r.solutionCategory===$('#category').value)&&($('#assessment').value==='all'||r.deliveryAssessment===$('#assessment').value)&&($('#reviewFilter').value==='all'||status(r.id)===$('#reviewFilter').value)&&(!q||[r.id,r.title,E[r.id]?.title,r.currentSolution,r.solutionReview?.summary.zh,r.solutionReview?.summary.en,r.solutionCategory,r.v2Source['Requirement Statement']].join(' ').toLowerCase().includes(q)));
}
function readHash(){
 const id=decodeURIComponent(location.hash.slice(1).split('?')[0]),p=params(),r=C.rows.find(x=>x.id===id);
 current=r?.id||'NEO-001'; lang=p.get('lang')==='en'?'en':'zh'; side=p.get('view')==='before'?'before':'after';
 release=groups.includes(p.get('release'))?p.get('release'):r?.releaseGroup||'p1';
 priority=priorities.includes(p.get('priority'))?p.get('priority'):'all';
 tab=['page','process','guide','questions','screens','sources'].includes(p.get('tab'))?p.get('tab'):'page';
}
function urlState(){
 const p=new URLSearchParams({lang,view:side,release});if(priority!=='all')p.set('priority',priority);if(tab!=='page')p.set('tab',tab);
 history.replaceState(null,'','#'+encodeURIComponent(current||'')+'?'+p);
}
function options(id,values,label){const el=$(id),v=el.value;el.innerHTML=[['all',label],...values.map(x=>[x,x])].map(([v,l])=>`<option value="${esc(v)}">${esc(l)}</option>`).join('');el.value=[...el.options].some(x=>x.value===v)?v:'all';}
function statics(){
 document.documentElement.lang=lang==='en'?'en':'zh-CN';document.title=t('NEO · 分期方案导览','NEO · Release solution review');
 $('#title').textContent=t('分期方案导览','Release solution review');
 $('#baseline').textContent=groupLabel('baseline')+' · '+C.counts.baseline;
 $('#baseline').setAttribute('aria-pressed',release==='baseline');
 $('#filtersLabel').textContent=t('筛选','Filters');
 $('#search').placeholder=t('搜索编号、名称或方案','Search ID, title or solution');$('#search').setAttribute('aria-label',$('#search').placeholder);
 options('#category',[...new Set(C.rows.map(r=>r.solutionCategory))].filter(Boolean).sort(),t('全部改动类型','All solution categories'));
 options('#assessment',[...new Set(C.rows.map(r=>r.deliveryAssessment))].filter(Boolean).sort(),t('全部实施评估','All delivery assessments'));
 const rf=$('#reviewFilter').value;$('#reviewFilter').innerHTML=[['all',t('全部评审状态','All review states')],...Object.entries(statusLabels())].map(([v,l])=>`<option value="${v}">${l}</option>`).join('');$('#reviewFilter').value=rf||'all';
 $('#resetFilters').textContent=t('重置筛选','Reset filters');
 document.querySelectorAll('[data-lang]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.lang===lang));
}
function renderNavigation(){
 $('#releases').innerHTML=['p1','p2','cr','non-system','all'].map(g=>`<button class="epic" data-release="${g}" aria-pressed="${release===g}">${groupLabel(g)}<span>${g==='all'?C.rows.length:C.counts[g]}</span></button>`).join('');
 $('#releases').querySelectorAll('button').forEach(b=>b.onclick=()=>selectRelease(b.dataset.release));
 $('#baseline').setAttribute('aria-pressed',release==='baseline');
 const rows=baseRows();
 $('#priorities').innerHTML=['all',...priorities.filter(p=>rows.some(r=>r.jointPriority===p))].map(p=>`<button data-priority="${esc(p)}" aria-pressed="${priority===p}">${p==='all'?t('全部优先级','All priorities'):priorityLabel(p)}<small>${rows.filter(r=>p==='all'||r.jointPriority===p).length}</small></button>`).join('');
 $('#priorities').querySelectorAll('button').forEach(b=>b.onclick=()=>{priority=b.dataset.priority;renderNavigation();refilter();});
}
function clearFilters(){priority='all';$('#search').value='';for(const id of ['category','assessment','reviewFilter'])$('#'+id).value='all';}
function selectRelease(g){release=g;clearFilters();renderNavigation();current=baseRows()[0]?.id||null;refilter();}
function refilter(){const rows=filtered();if(!rows.some(r=>r.id===current))current=rows[0]?.id||null;urlState();renderList();renderDetail();}
function renderList(){
 const rows=filtered();$('#listCount').textContent=rows.length+t(' 条',' items');$('#doneCount').textContent=baseRows().filter(r=>status(r.id)!=='unread').length+'/'+baseRows().length+' '+t('已看','reviewed');
 $('#items').innerHTML=rows.length?rows.map(r=>`<button class="item" data-id="${r.id}" aria-current="${r.id===current}"><span class="item-id"><span>${esc(r.id)}</span><span>${status(r.id)==='seen'?'✓':status(r.id)==='feedback'?'●':''}</span></span><span class="item-title">${esc(title(r))}</span><span class="item-priority">${priorityLabel(r.jointPriority)}${release==='all'?' · '+groupLabel(r.releaseGroup):''}</span></button>`).join(''):`<div class="empty">${t('没有匹配的需求','No matching requirements')}</div>`;
 $('#items').querySelectorAll('button').forEach(b=>b.onclick=()=>choose(b.dataset.id));
}
function choose(id){current=id;urlState();renderList();renderDetail();if(innerWidth<=900){$('#items').classList.add('collapsed');$('#detail').scrollIntoView({block:'start',behavior:'smooth'});}}
function inline(s){return esc(s).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>');}
function markdown(s){if(!s)return '';const lines=s.split('\n');let out='',i=0;while(i<lines.length){const l=lines[i];if(!l.trim()||/^!\[/.test(l)||/^---+$/.test(l)){i++;continue;}if(l.trim().startsWith('|')){out+='<div class="table-wrap" tabindex="0"><table>';let n=0;while(i<lines.length&&lines[i].trim().startsWith('|')){let x=lines[i++];if(/^\|[\s:|\-]+\|\s*$/.test(x.trim()))continue;let tag=n++?'td':'th';out+='<tr>'+x.trim().replace(/^\||\|$/g,'').split('|').map(c=>'<'+tag+'>'+inline(c.trim())+'</'+tag+'>').join('')+'</tr>';}out+='</table></div>';continue;}const h=l.match(/^(#{1,6})\s+(.*)/);out+=h?'<h3>'+inline(h[2])+'</h3>':'<p>'+inline(l.replace(/^[-*]\s/,'• '))+'</p>';i++;}return out;}
const original=(label,text)=>text?`<details><summary>${label}</summary>${markdown(text)}</details>`:'';
const state=r=>B.states[B.rows[r.id].key];
const beforeLink=r=>r.comparison?OLD+'comparison.html?id='+r.id+'&view=before':OLD+'before-launch.html?state='+encodeURIComponent(B.rows[r.id].key)+'&lang='+lang;
const afterLink=r=>r.page||r.assessment;
const guard=r=>r.scopeGuard?`<div class="warning">${esc(r.scopeGuard[lang==='en'?1:0])}</div>`:'';
const exact=v=>`<p class="exact-text">${esc(v||t('原表未填写。','Not entered in the source workbook.'))}</p>`;
function solutionText(r){
 if(r.solutionReview)return r.solutionReview.summary[lang];
 if(isBulkUpload(r))return r.bulkUploadReview[lang];
 if(r.surfaceReview&&r.surfaceReview.mode!=='none')return r.surfaceReview[lang];
 const summaries=window.REVIEW_SUMMARIES;
 if(lang==='zh'&&summaries?.sourceSha256===C.sourceSha256&&summaries.solutionsZh[r.id])return summaries.solutionsZh[r.id];
 if(r.id==='AS-IS Baseline')return 'Retain the existing AS-IS functionality, requirements and configuration. Requested changes are listed separately against this baseline.';
 if(r.id==='NEO-065')return 'Clarify the purpose of Gross Claim Value first. Automatic calculation differs from the field-guidance scope and requires agreement on the formula, precision and scope.';
 return r.currentSolution.split('\n').map(line=>line.replace(/^NTT assessment:\s*/,'').trim()).filter(line=>line&&!/^(?:Functionality|Report|Integration|Functionality\s*\+\s*(?:report|Performance|validation|Integration))$/i.test(line)).join(' ');
}
let highlightChanges=true;
const canHighlight=r=>r.releaseGroup!=='baseline'&&r.releaseGroup!=='non-system';
function reviewQuestions(r,showReference=false){
 if(r.releaseGroup==='baseline')return '';
 const source=r.v2Source.Questions?.trim();
 const summaries=window.REVIEW_SUMMARIES;
 const questions=source
  ?source.split(/\r?\n(?=\s*\d+[.)])/).map(line=>line.replace(/^\s*\d+[.)]\s*/,'').trim())
  :summaries?.sourceSha256===C.sourceSha256?summaries.reviewQuestions?.[r.id]?.[lang]:null;
 if(!questions?.length)return '';
 const owner=source&&r.v2Source['To Whom']?.trim();
 const label=t('待确认问题','Open questions');
 const reference=source&&showReference?'<button class="summary-reference" data-citation="AB" aria-label="'+t('查看问题原文','View original questions')+' AB'+r.sourceRow+'">AB'+r.sourceRow+'</button>':'';
 return `<section class="summary-questions" aria-label="${label}" data-question-source="${source?'workbook':'review'}"><div class="summary-heading"><h4>${label}</h4>${reference}</div><ol${source?' lang="en"':''}>${questions.map(question=>`<li>${esc(question)}</li>`).join('')}</ol>${owner?`<p class="question-owner">${t('请确认','Ask')} · ${esc(owner)}</p>`:''}</section>`;
}
function summaryStrip(r){
 const requirement=r.v2Source['Requirement Statement']||'',solution=solutionText(r);
 const sourceTitle=column=>column==='UC18'?r.solutionReview.reference:`${C.sourcePath.split('/').pop()} · ${C.sourceSheet}!${column}${r.sourceRow}`;
 const card=(kind,label,text,column,quote)=>`<section class="summary-column" data-summary="${kind}"><div class="summary-heading"><h3>${label}</h3><button class="summary-reference" data-citation="${column}" title="${esc(sourceTitle(column))}" aria-label="${t('查看原表引用','View source reference')} ${column==='UC18'?'POC UC18':column+r.sourceRow}">${column==='UC18'?'POC UC18':column+r.sourceRow}</button></div><${quote?'blockquote':'p'} id="${kind}Summary" class="summary-copy${quote?' original-quote':''}"${quote?' lang="en"':''}>${!quote&&side==='after'&&highlightChanges&&canHighlight(r)?`<mark class="after-change-summary">${esc(text)}</mark>`:esc(text)}</${quote?'blockquote':'p'}><button class="summary-expand" data-expand="${kind}Summary" aria-expanded="false" aria-controls="${kind}Summary" hidden>${t('展开','Read more')}</button>${kind==='solution'?reviewQuestions(r,true):''}</section>`;
 return `<div class="requirement-solution" aria-label="${t('需求与方案','Requirement and solution')}">${card('requirement',t('Requirement · 原文引用','Requirement · Original wording'),requirement,'M',true)}${card('solution','Solution',solution,r.solutionReview?.captures?'UC18':r.currentSolution?'V':'M',false)}</div>`;
}
function fitSummaries(){
 $('#detail').querySelectorAll('[data-expand]').forEach(button=>{const text=document.getElementById(button.dataset.expand);button.hidden=text.scrollHeight<=text.clientHeight+1;});
}
let citationTrigger=null;
function openCitation(r,column,trigger){
 citationTrigger=trigger;
 if(column==='UC18'){
  $('#assetTitle').textContent=r.id+' · POC UC18';
  $('#closeAsset').textContent=t('关闭','Close');
  $('#assetContent').innerHTML=`<div class="reading">${solutionReview(r)}</div>`;
  $('#assetDialog').showModal();
  $('#assetContent').scrollTop=0;
  return;
 }
 const sources={M:[
  ['M','Requirement Statement'],['N','Finance Desired Outcome (As a user I would need...)'],['O','Procurement Desired Outcome (As a user I would need...)']
 ],V:[['V','Solution Summary and NTT Assessment']],AB:[['AB','Questions'],['AC','To Whom']]};
 const fields=sources[column];
 $('#assetTitle').textContent=r.id+' · '+t('原表引用','Source reference');$('#closeAsset').textContent=t('关闭','Close');
 $('#assetContent').innerHTML=`<div class="reading source-quotation"><p class="source-filename">${esc(C.sourcePath.split('/').pop())}</p>${fields.filter(([,key])=>r.v2Source[key]).map(([col,key])=>`<section><h3>${esc(C.sourceSheet)} · ${col}${r.sourceRow}</h3><p class="meta">${esc(key)}</p>${exact(r.v2Source[key])}</section>`).join('')}</div>`;
 if(!$('#assetDialog').open)$('#assetDialog').showModal();$('#assetContent').scrollTop=0;
}
function assessment(r,open=false){return `<details class="current-assessment" ${open?'open':''}><summary>${t('V2 方案与 NTT 评估原文','V2 solution and NTT assessment — original wording')}</summary>${exact(r.currentSolution)}<p class="meta">${esc(C.sourceSheet)} · V${r.sourceRow}</p></details>`;}
function syncAlignedSide(r) {
 if(current!==r.id)return;
 const detail=$('#detail');
 detail.dataset.compareSide=side;
 detail.querySelectorAll('[data-side]').forEach(button=>button.setAttribute('aria-pressed',button.dataset.side===side));
 const summary=$('#solutionSummary');
 summary.innerHTML=side==='after'&&highlightChanges&&canHighlight(r)
  ? `<mark class="after-change-summary">${esc(solutionText(r))}</mark>`
  : esc(solutionText(r));
 const canvas=$('#content > iframe');
 if(canvas){
  canvas.title=r.id+' · '+(side==='after'?'After':'Before');
  canvas.contentWindow?.setReviewSide?.(side);
  canvas.contentWindow?.setReviewHighlight?.(side==='after'&&highlightChanges);
 }
 syncAlignedCapture(r);
 if(isBulkUpload(r)||isSharedSurface(r))syncSurfaceDelta(r);
}
const isSharedSurface = r => (['inline','output','rule','pending'].includes(r.surfaceReview?.mode)&&!r.alignedPreview)||r.releaseGroup==='non-system';
const isBulkUpload = r => Boolean(r.bulkUploadReview&&!r.bulkUploadReview.related);
let bulkRole = 'buyer';
function bulkControls(r) {
 if(!isBulkUpload(r))return '';
 const roles=['buyer','cbsl'].map(role=>`<button type="button" data-bulk-role="${role}" aria-pressed="${role===bulkRole}">${role==='buyer'?'Buyer':'CBSL'}</button>`).join('');
 return `<div class="bulk-controls"><button data-open-tab="process" type="button">ACT-026 · Bulk Upload Parts</button><div class="segmented" role="group" aria-label="${t('上传角色','Upload role')}">${roles}</div></div>`;
}
function syncSurfaceDelta(r,target=$('#content .surface-shared-delta')) {
 if(!target)return;
 target.dataset.highlight=String(side==='after'&&highlightChanges);
 target.innerHTML=window.NEO_SURFACES.renderPanel(r,side,{t,esc});
 window.NEO_SURFACES.wirePanel(target,r.surfaceReview,t);
}
function bulkCapture() {
 const role=bulkRole==='buyer'?'Buyer':'CBSL';
 const title=role+' · Bulk Upload Parts';
 return {image:'bulk-upload/'+bulkRole+'-upload.png',title:{zh:title,en:title}};
}
function renderSurface(r,container) {
 const spec=r.surfaceReview;
 const capture=isBulkUpload(r)?bulkCapture():state(r);
 const reference=spec.mode==='pending'
  ? `<div class="preview-boundary">${t('当前相关页面','Current related page')}</div>` : '';
 container.innerHTML=`<section class="surface-comparison" data-surface="${esc(spec.surface)}">
  ${reference}<div class="surface-capture">${image(capture.image,capture.title[lang])}</div>
  <div class="surface-shared-delta"></div>
 </section>`;
 syncSurfaceDelta(r);
}
function alignedCapture(r) {
 const preview=r.alignedPreview;
 if(side==='after'&&highlightChanges&&preview.images?.highlighted)return preview.images.highlighted;
 return preview.images?.[side]||preview.image;
}
function comparisonBasis() {
 return side==='after'
  ? t('同一笔示例 · 12 个月计算口径','Same example · 12-month calculation')
  : t('同一笔示例 · 旧计算口径复现','Same example · Previous calculation reproduced');
}
function syncAlignedCapture(r) {
 if(!r.alignedPreview?.images)return;
 const button=$('#content .image-open');
 const src=alignedCapture(r);
 button.dataset.image=src;
 button.querySelector('img').src=src;
 $('#content .preview-boundary').textContent=comparisonBasis();
}
function renderDetail(){
 const r=C.rows.find(r=>r.id===current);if(!r){$('#detail').innerHTML=`<div class="empty">${t('没有匹配的需求','No matching requirements')}</div>`;return;}
 const rows=filtered(),i=rows.findIndex(x=>x.id===current);
 $('#detail').innerHTML=`<div class="detail-head"><div class="selected-title"><span class="item-id">${esc(r.id)}</span><h2>${esc(title(r))}</h2></div><div class="pager"><button id="prev" aria-label="${t('上一条','Previous requirement')}" ${i<=0?'disabled':''}>←</button><span>${i+1}/${rows.length}</span><button id="next" aria-label="${t('下一条','Next requirement')}" ${i>=rows.length-1?'disabled':''}>→</button></div></div>
 <div class="version-row"><div class="segmented" role="group" aria-label="Before / After"><button data-side="before" aria-pressed="${side==='before'}">Before</button><button data-side="after" aria-pressed="${side==='after'}">After</button></div><div class="canvas-actions">${(side==='after'||r.alignedPreview||r.appianReportPreview||isSharedSurface(r))&&canHighlight(r)?`<button id="highlightChanges" class="highlight-toggle" aria-pressed="${highlightChanges}" title="${t('黄色标示 After 改动；点击隐藏或显示','Yellow marks After changes; click to hide or show')}"><span class="highlight-swatch" aria-hidden="true"></span>${t('高亮改动','Highlight changes')}</button>`:''}<button id="scenarios" hidden aria-pressed="false">${t('场景','Scenarios')}</button>${r.flowPage&&!isBulkUpload(r)?`<button data-open-tab="process">${t('流程','Process')}</button>`:''}<button id="wide" aria-pressed="${document.body.classList.contains('review-full')}">${document.body.classList.contains('review-full')?t('显示目录','Show list'):t('展开页面','Expand page')}</button>${(r.journalReview||r.solutionReview?.liveCaptures?.length)?`<button data-open-tab="screens">${t('新版页面截图','Page screenshots')}</button>`:r.appianReportCaptures?`<button data-open-tab="screens">${t('原 Appian 截图','Appian screenshots')}</button>`:''}<button id="more" data-open-tab="guide">${t('详情','Details')}</button></div></div>${summaryStrip(r)}${bulkControls(r)}<div id="content" class="content-panel"></div>`;
 if($('#highlightChanges'))$('#highlightChanges').onclick=()=>{highlightChanges=!highlightChanges;$('#highlightChanges').setAttribute('aria-pressed',highlightChanges);const el=$('#solutionSummary');el.innerHTML=highlightChanges?`<mark class="after-change-summary">${esc(solutionText(r))}</mark>`:esc(solutionText(r));if(r.alignedPreview){
  syncAlignedCapture(r);
  const canvas=$('#content > iframe');
  canvas?.contentWindow?.setReviewHighlight?.(side==='after'&&highlightChanges);
  if(isBulkUpload(r)){
   const target=$('#content .surface-shared-delta');
   if(target)target.dataset.highlight=String(side==='after'&&highlightChanges);
  }
 }else if(isSharedSurface(r)){
  const target=$('#content .surface-shared-delta');
  if(target)target.dataset.highlight=String(side==='after'&&highlightChanges);
 }else refreshHighlights();};
 $('#detail').querySelectorAll('[data-citation]').forEach(b=>b.onclick=()=>openCitation(r,b.dataset.citation,b));
 $('#detail').querySelectorAll('[data-expand]').forEach(b=>b.onclick=()=>{const expanded=b.getAttribute('aria-expanded')!=='true';document.getElementById(b.dataset.expand).classList.toggle('expanded',expanded);b.setAttribute('aria-expanded',expanded);b.textContent=expanded?t('收起','Show less'):t('展开','Read more');});
 requestAnimationFrame(fitSummaries);
 $('#prev').onclick=()=>choose(rows[i-1].id);$('#next').onclick=()=>choose(rows[i+1].id);
 $('#wide').onclick=()=>{document.body.classList.toggle('review-full');$('#wide').textContent=document.body.classList.contains('review-full')?t('显示目录','Show list'):t('展开页面','Expand page');$('#wide').setAttribute('aria-pressed',document.body.classList.contains('review-full'));};
 $('#detail').querySelectorAll('[data-side]').forEach(b=>b.onclick=()=>{
  if(side===b.dataset.side)return;
  side=b.dataset.side;
  urlState();
  if(r.alignedPreview||r.appianReportPreview||isSharedSurface(r))syncAlignedSide(r);
  else renderDetail();
 });
 $('#detail').querySelectorAll('[data-open-tab]').forEach(b=>b.onclick=()=>openDetails(b.dataset.openTab));
 $('#detail').querySelectorAll('[data-bulk-role]').forEach(button=>button.onclick=()=>{
  if(bulkRole===button.dataset.bulkRole)return;
  bulkRole=button.dataset.bulkRole;
  $('#detail').querySelectorAll('[data-bulk-role]').forEach(el=>el.setAttribute('aria-pressed',el.dataset.bulkRole===bulkRole));
  renderSurface(r,$('#content'));
 });
 $('#scenarios').onclick=()=>{const on=$('#scenarios').getAttribute('aria-pressed')!=='true';$('#scenarios').setAttribute('aria-pressed',on);for(const f of $('#content').querySelectorAll('iframe'))try{f.contentDocument.body.classList.toggle('show-review-scenarios',on)}catch{}};
 const previousTab=tab;tab='page';renderPanel(r);tab=previousTab;prepareFrames($('#content'));urlState();
 const aligned=Boolean(r.alignedPreview||r.appianReportPreview||isSharedSurface(r));
 $('#detail').classList.toggle('aligned-review',aligned);
 if(aligned){
  syncAlignedSide(r);
  $('#content > iframe')?.addEventListener('load',()=>syncAlignedSide(r));
 }
}
function openDetails(v='guide'){
 tab=v;const d=$('#detailsDialog'),r=C.rows.find(r=>r.id===current);
 $('#dialogTitle').textContent=r.id+' · '+title(r);
 const tabs=[...(r.flowPage||isBulkUpload(r)?[['process',t('流程','Process')]]:[]),['guide',t('方案','Solution')],['questions',t('待确认','Questions')],['screens',t('截图','Screenshots')],['sources',t('来源','Sources')],['notes',t('评审记录','Review notes')]];
 $('#detailTabs').innerHTML=tabs.map(([id,label])=>`<button data-tab="${id}" role="tab" aria-selected="${tab===id}">${label}</button>`).join('');
 $('#detailTabs').querySelectorAll('button').forEach(b=>b.onclick=()=>setTab(b.dataset.tab));
 $('#closeDetails').textContent=t('关闭','Close');if(!d.open)d.showModal();setTab(v);
}
function setTab(v){
 tab=v;urlState();$('#detailTabs').querySelectorAll('[data-tab]').forEach(b=>b.setAttribute('aria-selected',b.dataset.tab===v));
 const r=C.rows.find(r=>r.id===current),c=$('#detailsContent');
 if(v==='notes'){
 c.innerHTML=`<section class="review-note"><label for="reviewState">${t('评审状态','Review status')}</label><select id="reviewState">${Object.entries(statusLabels()).map(([v,l])=>`<option value="${v}">${l}</option>`).join('')}</select><label for="reviewText">${t('意见','Comments')}</label><textarea id="reviewText" rows="8"></textarea><div class="note-footer"><span id="saved" aria-live="polite"></span><button id="export">${t('导出记录','Export notes')}</button></div></section>`;
 $('#reviewState').value=status(r.id);$('#reviewText').value=notes[r.id]?.text||'';$('#reviewState').onchange=saveNote;$('#reviewText').oninput=saveNote;$('#export').onclick=exportNotes;
 }else renderPanel(r,c);
 prepareFrames(c);c.scrollTop=0;
}
function frame(src,label){return `<iframe title="${esc(label)}" src="${esc(src)}" sandbox="allow-scripts allow-same-origin allow-forms allow-downloads"></iframe>`;}
function image(src,label){return `<button class="image-open" data-image="${esc(src)}" data-caption="${esc(label)}" aria-label="${t('放大截图','Enlarge screenshot')}"><img src="${esc(src)}" alt="${esc(label)}"></button>`;}
function prepareFrames(container){
 const annotation=container.id==='content'&&side==='after'&&!container.classList.contains('aligned-canvas')?{id:current}:null;
 container.querySelectorAll('iframe').forEach(f=>{f.addEventListener('load',()=>cleanFrame(f,annotation));try{if(f.contentDocument?.readyState==='complete')cleanFrame(f,annotation)}catch{}});
}
function refreshHighlights(){
 const visit=f=>{try{const d=f.contentDocument;if(!d?.body)return;window.NEO_CHANGE_HIGHLIGHTS.apply(d,current,side==='after'&&highlightChanges);d.querySelectorAll('iframe').forEach(visit);}catch{}};
 $('#content').querySelectorAll('iframe').forEach(visit);
}
function cleanFrame(f,annotation=null){
 try{
  const d=f.contentDocument;if(!d?.body||d.getElementById('guide-display-cleanup'))return;
  const style=d.createElement('style');style.id='guide-display-cleanup';style.textContent=`.review-context{display:none!important}.review-bar{display:none!important}.show-review-scenarios .review-bar{display:flex!important}.review-bar>b,.review-bar>span,.review-bar>a{display:none!important}.guide-reference-hidden{display:none!important}`;d.head.appendChild(style);
  let pending=false;
  const tidy=()=>{pending=false;if(annotation)window.NEO_CHANGE_HIGHLIGHTS.apply(d,annotation.id,highlightChanges&&side==='after'&&current===annotation.id);const scenario=$('#scenarios');if(scenario&&d.querySelector('.review-bar input,.review-bar select,.review-bar button'))scenario.hidden=false;
    d.querySelectorAll('a,button').forEach(el=>{if(/^(references|assessment ?(&|and) ?(references|source)( ↗)?)$/i.test(el.textContent.trim()))el.classList.add('guide-reference-hidden');});
    d.querySelectorAll('iframe').forEach(child=>{if(!child.dataset.guideObserved){child.dataset.guideObserved='true';child.addEventListener('load',()=>cleanFrame(child,annotation));try{if(child.contentDocument?.readyState==='complete')cleanFrame(child,annotation)}catch{}}});
  };
  tidy();new MutationObserver(()=>{if(!pending){pending=true;requestAnimationFrame(tidy)}}).observe(d.body,{childList:true,subtree:true});
  d.addEventListener('click',e=>{const a=e.target.closest('a');if(!a)return;const href=a.getAttribute('href')||'';if(!href||href.startsWith('#')||a.hasAttribute('download')||href.startsWith('blob:'))return;if(a.target==='_blank'){e.preventDefault();e.stopPropagation();openAsset(new URL(href,d.baseURI).href,a.textContent.trim());}},true);
 }catch{}
}
async function openAsset(src,label){
 const d=$('#assetDialog'),c=$('#assetContent');$('#assetTitle').textContent=label;$('#closeAsset').textContent=t('关闭','Close');
 const url=new URL(src,location.href);if(url.origin!==location.origin&&url.protocol!=='file:'){openDetails('sources');return;}
 if(/\.(png|jpe?g|webp|svg)(?:$|\?)/i.test(url.href))c.innerHTML=`<img src="${esc(url.href)}" alt="${esc(label)}">`;
 else if(/\.(md|json|csv)(?:$|\?)/i.test(url.href)){try{const response=await fetch(url.href);if(!response.ok)throw Error();const text=await response.text();c.innerHTML=`<div class="reading">${url.pathname.endsWith('.md')?markdown(text):`<pre>${esc(text)}</pre>`}</div>`;}catch{c.innerHTML=`<p>${t('内容暂时无法加载，请重试。','Unable to load this content. Please try again.')}</p>`;}}
 else c.innerHTML=frame(url.href,label);
 if(!d.open)d.showModal();prepareFrames(c);
}
function afterPage(r){if(['NEO-019','NEO-020','NEO-023','NEO-024'].includes(r.id))return r.page.replace('_Page_Proposal.html','_Page_Proposal_Enhancement.html');if(r.id==='NEO-040')return r.page.replace('NEO-040.html','NEO-040_Enhancement.html');return r.page;}
function explanation(r){return r.afterExplanation?`<section class="reading after-explanation"><details><summary>${t('此前确认的 Before / After 说明','Previously reviewed Before / After explanation')}</summary>${r.afterExplanation[lang==='en'?1:0]}</details></section>`:'';}
function appianReportGallery(r){
 if(!r.appianReportCaptures)return '';
 const cards=r.appianReportCaptures.map(({src,caption})=>{
  const label=esc(caption[lang]);
  return `<a class="shot" href="${esc(src)}" data-inline="true"><img src="${esc(src)}" alt="${label}"><span>${label}</span></a>`;
 }).join('');
 return `<section aria-labelledby="appianReportEvidence"><h3 id="appianReportEvidence">${t('原 Appian · POA Part Level Detail Report','Original Appian · POA Part Level Detail Report')}</h3><div class="gallery">${cards}</div></section>`;
}
function journalSources({page,export:journalExport}){
 const card=({src,label})=>`<a class="shot" href="${esc(src)}" data-inline="true"><img src="${esc(src)}" alt="${esc(label)}"><span>${esc(label)}</span></a>`;
 return `<div class="gallery">${card(page)}${card(journalExport)}</div>`;
}
function calculationGallery(captures){
 const cards=captures.map(({src,label})=>`<a class="shot" href="${esc(src)}" data-inline="true"><img src="${esc(src)}" alt="${esc(label[lang])}"><span>${esc(label[lang])}</span></a>`);
 return `<div class="gallery">${cards.join('')}</div>`;
}
function journalDesignGallery(r){
 const design=r.journalReview.design;
 const card=(version,src)=>`<a class="shot" href="${esc(src)}" data-inline="true"><img src="${esc(src)}" alt="NEO Journal Templates · ${version}"><span>NEO Journal Templates · ${version}</span></a>`;
 return `<div class="reading"><div class="gallery">${card('Before',design.before)}${card('After',design.after)}</div></div>`;
}
function alignedGallery(r){
 const preview=r.alignedPreview;
 const before=preview.images?.before||preview.image||`aligned-captures/${r.id}-before.png`;
 const changes=preview.images||preview.removeField||preview.removeStep||preview.action||preview.help;
 const capture=(src,label)=>`<a class="shot" href="${esc(src)}" data-inline="true"><img src="${esc(src)}" alt="${esc(label)}"><span>${esc(label)}</span></a>`;
 const after=changes?capture(preview.images?.after||`aligned-captures/${r.id}-after.png`,'After'):'';
 const label=changes?'Before':t('Before / After 共用页面','Shared Before / After view');
 return `<div class="reading"><div class="gallery">${capture(before,label)}${after}</div></div>`;
}
function solutionReview(r){
 if(!r.solutionReview)return '';
 const {steps,reference,source,example}=r.solutionReview;
 return `<section aria-label="${t('更新后的方案','Updated solution')}"><h3>${t('更新后的方案','Updated solution')}</h3><ol>${steps.map(step=>`<li>${esc(step[lang])}</li>`).join('')}</ol>${example?`<p>${esc(example[lang])}</p>`:''}${source?`<p>${esc(source[lang])}</p>`:''}<p class="meta">${esc(reference)}</p></section>`;
}
function bulkStory(r, withSteps=false) {
 if(!r.bulkUploadReview)return '';
 const story=C.bulkUploadStory;
 const steps=withSteps?`<ol>${story.steps.map(step=>`<li>${esc(step[lang])}</li>`).join('')}</ol>`:'';
 return `<section class="bulk-story"><h3>${story.id} · ${story.title}</h3><p>${esc(story.roles[lang])}</p>${steps}<p>${esc(r.bulkUploadReview[lang])}</p><p class="meta">${esc(story.reference)}</p></section>`;
}
function bulkGallery() {
 const capture=(role,label)=>`<a class="shot" href="bulk-upload/${role}-upload.png" data-inline="true"><img src="bulk-upload/${role}-upload.png" alt="${label}"><span>${label}</span></a>`;
 return `<div class="reading"><h3>ACT-026 · Bulk Upload Parts</h3><div class="gallery">${capture('buyer','Buyer')}${capture('cbsl','CBSL')}</div></div>`;
}
function sharedSurfaceGallery(r,s){
 const label=t('Before / After 共用页面','Shared Before / After page');
 return `<div class="reading"><div class="gallery"><a class="shot" href="${esc(s.image)}" data-inline="true"><img src="${esc(s.image)}" alt="${esc(s.title[lang])}"><span>${esc(s.title[lang])} · ${label}</span></a></div><p>${esc(r.surfaceReview[lang])}</p></div>`;
}
function renderPanel(r,target){
 const c=target||$('#content'),s=state(r),br=B.rows[r.id];
 if(tab==='page'){
   if(r.journalReview){
     c.classList.add('aligned-canvas');
     const src=r.alignedPreview.frame+'?view='+side+'&highlight='+(highlightChanges?'on':'off');
     c.innerHTML=frame(src,r.id+' · Journal Templates');
   }else if(r.appianReportPreview){
     const label=t('原 Appian 页面参考','Original Appian page reference');
     c.innerHTML=`<div class="preview-boundary">${label}</div>${image(r.appianReportPreview,'POA Part Level Detail Report · '+label)}`;
   }else if(isBulkUpload(r)){
     c.classList.add('aligned-canvas');
     renderSurface(r,c);
   }else if(r.alignedPreview){
     c.classList.add('aligned-canvas');
     const preview=r.alignedPreview;
     if(preview.frame)c.innerHTML=frame(preview.frame,r.id+' · '+(side==='after'?'After':'Before'));
     else{
       const note=preview.images?`<div class="preview-boundary">${comparisonBasis()}</div>`:'';
       c.innerHTML=note+image(alignedCapture(r),title(r));
     }
   }else if(isSharedSurface(r)){
     renderSurface(r,c);
   }else if(side==='before'&&r.id!=='AS-IS Baseline'){
     c.innerHTML=r.comparison?frame(beforeLink(r),r.id+' · Before'):(br.related?`<div class="preview-boundary">${t('相关页面','Related page')}</div>`:'')+image(r.beforeCapture||s.image,s.title[lang]);
   }else if(r.id==='NEO-065'){
     c.innerHTML=`<div class="reading short-state"><h3>${t('Gross Claim 字段说明','Gross Claim field guidance')}</h3><p>${t('待确认字段说明；沿用当前录入方式。','Field guidance pending confirmation; retain the current entry method.')}</p><button data-open-tab="guide">${t('查看方案','View solution')}</button></div>`;
   }else if(r.id==='AS-IS Baseline'){
     c.innerHTML=`<div class="reading"><h3>${t('完整 AS-IS 功能基线','Complete AS-IS functional baseline')}</h3>${exact(r.v2Source['Requirement Statement'])}<p>${t('这是一期单独的一条基线，不计入 23 条新需求。原功能、配置及全链路验收继续保留。','This is one separately tracked Phase 1 baseline, not one of the 23 enhancements. Existing functions, configuration and end-to-end acceptance remain in scope.')}</p>${original(t('既有基线说明','Existing baseline notes'),r.guide)}</div>`;
   }else if(r.afterImage){c.innerHTML=image(r.afterImage,r.id+' After');
   }else if(r.page){c.innerHTML=frame(afterPage(r),r.id+' · After');
   }else{c.innerHTML=`<div class="reading"><h3>${t('范围与方案参考','Scope and solution reference')}</h3>${exact(r.currentSolution)}${original(t('既有分析','Existing analysis'),r.guide||r.task)}<p>${t('此项未引用独立可操作页面。','No independent interactive page is referenced for this item.')}</p></div>`;}
 }else if(tab==='process'){
   c.innerHTML=isBulkUpload(r)?`<div class="reading">${bulkStory(r,true)}</div>`:frame(r.flowPage+'?lang='+lang,r.id+' · Before / After process');
 }else if(tab==='guide'){
   c.innerHTML=`<div class="reading"><h3>${t('本版本范围','Scope in this version')}</h3><table class="source-table"><tr><th>Release</th><td>${esc(r.release)}</td></tr><tr><th>Joint Priority</th><td>${priorityLabel(r.jointPriority)}</td></tr><tr><th>Commercial Scope</th><td>${esc(r.commercialScope)}</td></tr><tr><th>Delivery Assessment</th><td>${esc(r.deliveryAssessment)}</td></tr><tr><th>Solution Category</th><td>${esc(r.solutionCategory)}</td></tr></table>${solutionReview(r)}${bulkStory(r,!r.bulkUploadReview?.related)}${explanation(r)}${(r.alignedPreview?.keepProposal||isSharedSurface(r))&&r.page?`<details><summary>${t('此前独立方案','Earlier independent proposal')}</summary><p><a href="${esc(afterPage(r))}" data-inline="true">${t('查看旧方案','View earlier proposal')}</a></p></details>`:''}${isBulkUpload(r)&&r.bulkUploadReview.proposal?`<details><summary>${t('此前独立方案','Earlier independent proposal')}</summary><p><a href="${esc(r.bulkUploadReview.proposal)}" data-inline="true">${t('查看旧方案','View earlier proposal')}</a></p></details>`:''}${r.solutionReview?.captures?`<details><summary>${t('V2 评估原文','Original V2 assessment')}</summary>${exact(r.currentSolution)}<h3>Dependencies</h3>${exact(r.currentDependencies)}</details>`:`<h3>Solution Summary and NTT Assessment</h3>${exact(r.currentSolution)}${guard(r)}<h3>Dependencies</h3>${exact(r.currentDependencies)}`}${reviewQuestions(r)}<h3>${t('沿用的页面与方案','Reused page and proposal')}</h3><p>${r.journalReview?t('Before 和 After 使用新版 NEO Journal Templates，现有生成与下载流程参考 11 月 17 日的走查。','Both views use the new NEO Journal Templates and preserve the generation and download flow shown on 17 November.'):r.appianReportPreview?t('POA Part Level Detail Report · 两边共用原 Appian 报表页面。','POA Part Level Detail Report · Both views use the original Appian report page.'):`${esc(s.title[lang])} — ${esc(br[lang])}`}</p>${original(t('ACT / FR / 页面关联（既有记录）','ACT / FR / page mapping (existing record)'),r.mapping)}${original(t('既有走查说明','Existing review guide'),r.guide||r.task)}<p class="meta">${t('分类和排期按 V2 保留，不因 Direct / Conditional 等标签另行推算日期。','Classification and release follow V2; dates are not inferred from Direct or Conditional labels.')}</p></div>`;
 }else if(tab==='questions'){
   c.innerHTML=`<div class="reading"><h3>Dependencies · W${r.sourceRow}</h3>${exact(r.currentDependencies)}${reviewQuestions(r)}${guard(r)}${r.bulkUploadReview?bulkStory(r):''}${original(t('此前问题与依赖（历史记录）','Earlier questions and dependencies (historical)'),r.questions||r.task)}</div>`;
 }else if(tab==='screens'&&r.solutionReview?.liveCaptures?.length){
   c.innerHTML=`<div class="reading">${calculationGallery(r.solutionReview.liveCaptures)}</div>`;
 }else if(tab==='screens'&&r.journalReview){
   c.innerHTML=journalDesignGallery(r);
 }else if(tab==='screens'&&r.appianReportCaptures){
   c.innerHTML=`<div class="reading">${appianReportGallery(r)}</div>`;
 }else if(tab==='screens'&&isBulkUpload(r)){
   c.innerHTML=bulkGallery();
 }else if(tab==='screens'&&r.alignedPreview){
   c.innerHTML=alignedGallery(r);
 }else if(tab==='screens'&&isSharedSurface(r)){
   c.innerHTML=sharedSurfaceGallery(r,s);
 }else if(tab==='screens'&&r.id==='AS-IS Baseline'){
   c.innerHTML=`<div class="reading"><p>${t('基线覆盖现有 NEO 页面与流程。','The baseline covers the existing NEO pages and workflows.')}</p></div>`;
 }else if(tab==='screens'&&r.id==='NEO-003'){
   const capture=(label,version)=>`<a class="shot" href="${OLD}captures-20261116/NEO-003-${version}.png" data-inline="true"><img src="${OLD}captures-20261116/NEO-003-${version}.png" alt="Part prices · ${label}"><span>Part prices · ${label}</span></a>`;
   c.innerHTML=`<div class="reading"><div class="gallery">${capture('Before','before')}${capture('After','after')}</div></div>`;
 }else if(tab==='screens'){
   const captures=r.solutionReview?.captures||r.screenshots;
   c.innerHTML=`<div class="reading"><h3>Before</h3><div class="gallery"><a class="shot" href="${esc(r.beforeCapture||s.image)}" data-inline="true"><img src="${esc(r.beforeCapture||s.image)}" alt="Before"><span>${esc(s.title[lang])}</span></a></div><h3>${r.id==='NEO-065'?t('此前设计截图（历史参考）','Earlier captures (historical reference)'):'After'}</h3><div class="gallery">${captures.map((x,i)=>`<a class="shot" href="${esc(x.src)}" data-inline="true"><img loading="lazy" src="${esc(x.src)}" alt="${esc(r.id)} After ${i+1}"><span>${esc(x.label?.[lang]??(lang==='zh'?x.label:'Existing design · '+(i+1)))}</span></a>`).join('')}</div>${captures.length?'':`<p>${t('暂无引用截图。','No screenshot is referenced.')}</p>`}</div>`;
 }else{
   const cells=[['M','Requirement Statement'],['N','Finance Desired Outcome (As a user I would need...)'],['O','Procurement Desired Outcome (As a user I would need...)'],['R','Joint Procurement / Finance Priority Rating'],['U','Solution Category'],['V','Solution Summary and NTT Assessment'],['W','Dependencies'],['X','Remarks'],['Y','Delivery Assessment'],['Z',Object.keys(r.v2Source).find(k=>k.startsWith('Suggested Release'))],['AA',Object.keys(r.v2Source).find(k=>k.startsWith('Commercial'))],['AB','Questions'],['AC','To Whom']];
   c.innerHTML=`<div class="reading"><h3>${t('当前评估基准 · V2','Current assessment authority · V2')}</h3><p class="source">${esc(C.sourcePath)}\n${esc(C.sourceSheet)}!A${r.sourceRow}:AC${r.sourceRow}\nSHA-256: ${esc(C.sourceSha256)}</p><details open><summary>${t('当前原文与分类','Current wording and classification')}</summary>${cells.map(([col,k])=>`<h3>${col+r.sourceRow} · ${esc(k)}</h3>${exact(r.v2Source[k])}`).join('')}</details>${isBulkUpload(r)?`<h3>${t('共用上传预览来源','Shared upload preview source')}</h3><p class="source">ACT-026 · 19 Nov 2026 · bulk-upload/index.html</p>`:r.journalReview?`<h3>${t('11 月 17 日 Journal 走查','17 November Journal walkthrough')}</h3><p class="source">${esc(r.journalReview.document)}\n${esc(r.journalReview.page.embedded)} · ${esc(r.journalReview.export.embedded)}</p>${journalSources(r.journalReview)}`:r.appianReportPreview?`<h3>${t('原 Appian 截图','Appian screenshots')}</h3><p class="source">${esc(r.appianReportCaptures.map(capture=>capture.source).join('\n'))}</p>`:`<h3>Before</h3><p class="source">${esc(B.source)}\napp.js SHA-256: ${esc(B.appSha256)}</p><a href="${OLD}BEFORE_VERSION.json" data-inline="true">${t('留存版本清单 ↗','Retained version manifest ↗')}</a>`}${r.bulkUploadReview?bulkStory(r):''}${s.source?`<h3>${t('当前 Before / After 页面','Current comparison surface')}</h3><p class="source">${esc(s.source)}</p>`:''}${r.solutionReview?.captures?`<h3>POC · UC18</h3><p>${esc(r.solutionReview.source[lang])}</p>${calculationGallery(r.solutionReview.captures)}<a href="${esc(r.solutionReview.workQueueExample.src)}" data-inline="true">${esc(r.solutionReview.workQueueExample.label[lang])}</a>`:''}<h3>${t('此前分析与来源','Earlier analysis and sources')}</h3><p class="source">${esc(r.assessmentPath)}</p>${original(t('原有 reference','Existing references'),r.referenceText)}<details><summary>${t('旧版本分类（非当前排期）','Previous classification (not the current release)')}</summary><p class="source">${esc(JSON.stringify(r.previousSource,null,2))}</p></details></div>`;
 }
}
function saveNote(){notes[current]={status:$('#reviewState').value,text:$('#reviewText').value,updatedAt:new Date().toISOString()};try{localStorage.setItem(KEY,JSON.stringify(notes));$('#saved').textContent=t('已保存到此浏览器。','Saved in this browser.');}catch{$('#saved').textContent=t('无法保存，请导出记录。','Could not save; export the notes.');}renderList();}
$('#baseline').onclick=()=>selectRelease('baseline');$('#search').oninput=refilter;
for(const id of ['category','assessment','reviewFilter'])$('#'+id).onchange=refilter;
$('#clearSearch').onclick=()=>{$('#search').value='';refilter();$('#search').focus();};
$('#resetFilters').onclick=()=>{clearFilters();renderNavigation();refilter();};
$('#toggleList').onclick=()=>$('#items').classList.toggle('collapsed');
document.querySelectorAll('[data-lang]').forEach(b=>b.onclick=()=>{lang=b.dataset.lang;statics();renderNavigation();renderList();renderDetail();urlState();});
$('#detailTabs').addEventListener('keydown',e=>{if(!e.target.matches('[data-tab]')||!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;const a=[...$('#detailTabs').querySelectorAll('[data-tab]')],i=a.indexOf(e.target),n=e.key==='Home'?0:e.key==='End'?a.length-1:(i+(e.key==='ArrowRight'?1:-1)+a.length)%a.length;e.preventDefault();setTab(a[n].dataset.tab);a[n].focus();});
$('#closeDetails').onclick=()=>$('#detailsDialog').close();$('#closeAsset').onclick=()=>$('#assetDialog').close();
$('#detailsDialog').addEventListener('close',()=>{tab='page';urlState();$('#more')?.focus();});
$('#assetDialog').addEventListener('close',()=>{$('#assetContent').innerHTML='';if(citationTrigger?.isConnected)citationTrigger.focus();citationTrigger=null;});
document.addEventListener('click',e=>{const btn=e.target.closest('[data-image]');if(btn){openAsset(btn.dataset.image,btn.dataset.caption);return;}const link=e.target.closest('a[data-inline]');if(link){e.preventDefault();openAsset(link.getAttribute('href'),link.textContent.trim());return;}const open=e.target.closest('#content [data-open-tab]');if(open)openDetails(open.dataset.openTab);});
function exportNotes(){const data={kind:'Design review notes — not acceptance results',source:C.sourcePath,sourceSha256:C.sourceSha256,exportedAt:new Date().toISOString(),rows:C.rows.map(r=>({id:r.id,release:r.release,jointPriority:r.jointPriority,commercialScope:r.commercialScope,status:status(r.id),comment:notes[r.id]?.text||'',updatedAt:notes[r.id]?.updatedAt||null}))};const u=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=u;a.download='NEO_Release_V2_Review_Notes.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);};
window.addEventListener('hashchange',()=>{readHash();$('#search').value='';for(const id of ['category','assessment','reviewFilter'])$('#'+id).value='all';statics();renderNavigation();refilter();});
readHash();statics();renderNavigation();refilter();if(tab!=='page')openDetails(tab);

const narrow=matchMedia('(max-width:900px)');if(narrow.matches)$('#items').classList.add('collapsed');narrow.addEventListener('change',e=>{if(e.matches)$('#items').classList.add('collapsed');else $('#items').classList.remove('collapsed')});

window.addEventListener('resize',()=>{for(const b of document.querySelectorAll('[data-expand]'))if(b.getAttribute('aria-expanded')!=='true'){const p=document.getElementById(b.dataset.expand);b.hidden=p.scrollHeight<=p.clientHeight+1;}});
