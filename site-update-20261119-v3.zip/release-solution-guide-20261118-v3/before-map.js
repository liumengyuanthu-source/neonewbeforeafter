window.BEFORE_MAP={
  "source": "dist",
  "appSha256": "3ff8bc0b158ba08f2302e7404bb6185a553088c78614051451e6b5137a26802e",
  "rows": {
    "NEO-001": {
      "key": "auto-pam",
      "related": false,
      "zh": "Auto PAM 文件列表与 ℹ 保持一致。按 Finance 的规则修正结转计算。",
      "en": "Keep the Auto PAM file list and information icons. Apply the Finance rollover rules."
    },
    "NEO-003": {
      "key": "prices-edit",
      "related": false,
      "zh": "在现有 Part prices 操作栏加入 Refresh prices from SAP。",
      "en": "Add Refresh prices from SAP to the existing Part prices toolbar."
    },
    "NEO-004": {
      "key": "appian-poa-report",
      "related": false,
      "zh": "保留原 POA Part Level Detail Report，修正导出的计算与数据。",
      "en": "Keep the original POA Part Level Detail Report and correct the calculations and exported data."
    },
    "NEO-005": {
      "key": "settlement-details",
      "related": false,
      "zh": "在提交 Settlement 前检查正向 LSP 余额，余额不足时记录约定日期及结算安排。",
      "en": "Check the positive LSP balance before submission. Capture the agreed date and settlement arrangement if the balance is insufficient."
    },
    "NEO-007": {
      "key": "approval-detail",
      "related": false,
      "zh": "保留审批详情页。后台按约定的 FTO／GR 金额驱动 DoA，并在 Settlement 重核。",
      "en": "Keep the approval detail page. Apply the agreed FTO/GR basis for DoA and recheck at Settlement."
    },
    "NEO-008": {
      "key": "reserve-detail",
      "related": false,
      "zh": "在同一 Reserve 行使用实施月汇率，并记录汇率与时间。",
      "en": "Use the implementation-month rate for the same Reserve line and log the rate and time."
    },
    "NEO-011": {
      "key": "supplier",
      "related": false,
      "zh": "在当前 Non-Standard Transaction Flag 增加 Deposit 和 Loan，分类与会计映射由 Finance 确认。",
      "en": "Add Deposit and Loan to the existing Non-Standard Transaction Flag. Finance confirms the accounting mapping."
    },
    "NEO-012": {
      "key": "reserve-detail",
      "related": false,
      "zh": "在当前 Reserve 文件区分已实施未收票 LSP 与其他 Accrual。",
      "en": "Distinguish implemented LSPs awaiting an invoice from other accruals in the existing Reserve file."
    },
    "NEO-014": {
      "key": "requests",
      "related": false,
      "zh": "在 Approval Requests 用选定会议场次导出已记录的决定或纪要。",
      "en": "Export recorded decisions or minutes for the selected session from Approval Requests."
    },
    "NEO-015": {
      "key": "reserve-detail",
      "related": false,
      "zh": "交易开始后、实施前按普通负向 Lump Sum 计提。结算且预付款资产建立后衔接余额，Auto PAM 口径照旧。",
      "en": "Apply ordinary negative lump-sum reserve accrual from the start date until implementation. Transition after settlement and asset recognition. Keep the Auto PAM basis."
    },
    "NEO-017": {
      "key": "bulk-upload-current",
      "related": false,
      "zh": "有权访问并维护该记录的 Buyer 和 CBSL，都从同一个 POA Claim Summary 进入 Bulk Upload Parts。上传适用该 Claim 的状态和权限校验。",
      "en": "Authorised Buyer and CBSL users both open Bulk Upload Parts from the same POA Claim Summary. The claim’s state and access checks apply to both roles."
    },
    "NEO-018": {
      "key": "bulk-upload-current",
      "related": false,
      "zh": "有权访问并维护该记录的 Buyer 和 CBSL，都从同一个 POA Claim Summary 进入 Bulk Upload Parts。上传适用该 Claim 的状态和权限校验。",
      "en": "Authorised Buyer and CBSL users both open Bulk Upload Parts from the same POA Claim Summary. The claim’s state and access checks apply to both roles."
    },
    "NEO-019": {
      "key": "bulk-upload-current",
      "related": false,
      "zh": "有权访问并维护该记录的 Buyer 和 CBSL，都从同一个 POA Claim Summary 进入 Bulk Upload Parts。上传适用该 Claim 的状态和权限校验。",
      "en": "Authorised Buyer and CBSL users both open Bulk Upload Parts from the same POA Claim Summary. The claim’s state and access checks apply to both roles."
    },
    "NEO-020": {
      "key": "bulk-upload-current",
      "related": false,
      "zh": "有权访问并维护该记录的 Buyer 和 CBSL，都从同一个 POA Claim Summary 进入 Bulk Upload Parts。上传适用该 Claim 的状态和权限校验。",
      "en": "Authorised Buyer and CBSL users both open Bulk Upload Parts from the same POA Claim Summary. The claim’s state and access checks apply to both roles."
    },
    "NEO-021": {
      "key": "s4-task",
      "related": true,
      "zh": "保留现有 S/4 Task。S/4-only 路由和 BP／GSDB 映射待接口和数据确认。",
      "en": "Keep the existing S/4 Task. S/4-only routing and BP/GSDB mapping depend on the interface and data."
    },
    "NEO-022": {
      "key": "prices-edit",
      "related": false,
      "zh": "在同一 Part prices 页提示冲突。前单实施后复核起始价，再处理后单。",
      "en": "Show overlap on the same Part prices page. Recheck starting prices after the earlier claim is implemented."
    },
    "NEO-024": {
      "key": "bulk-upload-current",
      "related": false,
      "zh": "有权访问并维护该记录的 Buyer 和 CBSL，都从同一个 POA Claim Summary 进入 Bulk Upload Parts。上传适用该 Claim 的状态和权限校验。",
      "en": "Authorised Buyer and CBSL users both open Bulk Upload Parts from the same POA Claim Summary. The claim’s state and access checks apply to both roles."
    },
    "NEO-026": {
      "key": "implemented-summary",
      "related": false,
      "zh": "在 Implemented Claim 的既有 Reporting Category 位置锁定该字段。",
      "en": "Lock Reporting Category in its existing position when the claim is Implemented."
    },
    "NEO-027": {
      "key": "bulk-upload-current",
      "related": false,
      "zh": "有权访问并维护该记录的 Buyer 和 CBSL，都从同一个 POA Claim Summary 进入 Bulk Upload Parts。上传适用该 Claim 的状态和权限校验。",
      "en": "Authorised Buyer and CBSL users both open Bulk Upload Parts from the same POA Claim Summary. The claim’s state and access checks apply to both roles."
    },
    "NEO-028": {
      "key": "buyer-rpa",
      "related": false,
      "zh": "保留 Buyer Review。Include／Exclude 与 Plant 即时反馈，耗时调用显示处理中，计算提醒沿用 POC。",
      "en": "Keep Buyer Review. Give immediate Include/Exclude and Plant feedback, show processing for slower calls and reuse PoC calculation reminders."
    },
    "NEO-029": {
      "key": "poa-calculation-step",
      "related": false,
      "zh": "同一 Calculation 页展示后台进度、完成提醒和返回后的结果。",
      "en": "Use the same Calculation page for background progress, the ready reminder and the result on return."
    },
    "NEO-030": {
      "key": "wips-task",
      "related": false,
      "zh": "CBSL WIPS 任务保留价格列，价格只读。价格差异转给 Buyer 纠正。",
      "en": "Keep the price columns in the CBSL WIPS task, make them read-only and route price corrections to the Buyer."
    },
    "NEO-031": {
      "key": "claim-calculation",
      "related": false,
      "zh": "同一 POA 计算页面只调整 Annualised value 与对应 12 个月结果。",
      "en": "Change only Annualised value and its 12-month result on the same POA calculation page."
    },
    "NEO-032": {
      "key": "bulk-upload-current",
      "related": false,
      "zh": "有权访问并维护该记录的 Buyer 和 CBSL，都从同一个 POA Claim Summary 进入 Bulk Upload Parts。上传适用该 Claim 的状态和权限校验。",
      "en": "Authorised Buyer and CBSL users both open Bulk Upload Parts from the same POA Claim Summary. The claim’s state and access checks apply to both roles."
    },
    "NEO-034": {
      "key": "supplier",
      "related": true,
      "zh": "同一 Supplier Claim Details 校验 Lever 和 Reporting Category 组合，待批准组合表。",
      "en": "Validate Lever and Reporting Category on the same Supplier Claim Details once the allowed list is agreed."
    },
    "NEO-037": {
      "key": "memos",
      "related": false,
      "zh": "在同一 Memos 列表区分 Memo 状态和过账状态，实际汇率、作废及冲销按财务规则。",
      "en": "Distinguish Memo status from posting status in the existing Memos list and apply the agreed FX, deletion and reversal rules."
    },
    "NEO-042": {
      "key": "prices-edit",
      "related": false,
      "zh": "在现有 AMM Part 行追加 Escalator，数量上限按 WIPS 契约确认。",
      "en": "Add escalators within the existing AMM part row. Confirm the limit in the WIPS contract."
    },
    "NEO-044": {
      "key": "neo-journal-044",
      "related": false,
      "zh": "两边使用新版 NEO Journal Templates，After 增加按 NEO ID 对账和 Reserve 导出。",
      "en": "Use the new NEO Journal Templates on both sides. After adds reconciliation by NEO ID and the Reserve export."
    },
    "NEO-045": {
      "key": "lsp-entry",
      "related": false,
      "zh": "在 Lump Sum 原有 Company、Purchasing Org 和财务字段内带出有效组合。",
      "en": "Derive valid combinations within the existing Lump Sum company, purchasing and finance fields."
    },
    "NEO-046": {
      "key": "teams",
      "related": false,
      "zh": "保留 Teams 页面，Team 由 Reporting Category 映射，Raw Materials 划分需财务确认。",
      "en": "Keep Teams. Derive Team from Reporting Category and confirm the Raw Materials split with Finance."
    },
    "NEO-047": {
      "key": "reserve-detail",
      "related": false,
      "zh": "在同一 Reserve 导出增加相关资产负债表和损益列，按 NEO ID 核对。",
      "en": "Add the relevant balance-sheet and P&L columns in the same Reserve export and reconcile by NEO ID."
    },
    "NEO-049": {
      "key": "cbsl-tasks",
      "related": false,
      "zh": "最后适用审批及 GFS 检查完成后生成 Buyer 合同实施任务，再由 Buyer 确认转给 Digitide。",
      "en": "Create the Buyer contract task after the required approvals and GFS checks. The Buyer then assigns that task to Digitide."
    },
    "NEO-050": {
      "key": "clearing-request",
      "related": false,
      "zh": "同一 Request 的审批状态在全部适用审批完成且 FBP 标记 Complete 后变为 Approved。",
      "en": "Change the same request approval status to Approved after all applicable approvals and FBP Complete."
    },
    "NEO-052": {
      "key": "supplier",
      "related": false,
      "zh": "仅在 Supplier Claim Details 移除 Global Commodity Lead Area 输入。",
      "en": "Remove the Global Commodity Lead Area input from Supplier Claim Details."
    },
    "NEO-056": {
      "key": "approval-detail",
      "related": false,
      "zh": "按正式 DoA 生成审批任务，同一审批详情随签署矩阵展示相应节点。",
      "en": "Route using the signed DoA. The existing approval detail shows the steps that the matrix requires."
    },
    "NEO-057": {
      "key": "approval-flow",
      "related": false,
      "zh": "沿用用户指定的 Approval Flow，显示当前待办人与状态，并补齐开放任务下载及逾期提醒。",
      "en": "Use the supplied Approval Flow for the current owner and status, with an open-task download and overdue reminders."
    },
    "AS-IS Baseline": {
      "key": "core",
      "related": true,
      "zh": "相关建单入口，仅用于定位；一张图不能代表全部AS-IS基线。",
      "en": "Related claim entry only; one capture is not evidence of complete AS-IS parity."
    },
    "NEO-002": {
      "key": "claim-calculation",
      "related": true,
      "zh": "保留 Calculations。先确定生产计划量的替代来源或获批计算口径。",
      "en": "Retain Calculations while the replacement volume source or calculation policy is agreed."
    },
    "NEO-040": {
      "key": "bulk-upload-current",
      "related": false,
      "zh": "有权访问并维护该记录的 Buyer 和 CBSL，都从同一个 POA Claim Summary 进入 Bulk Upload Parts。上传适用该 Claim 的状态和权限校验。",
      "en": "Authorised Buyer and CBSL users both open Bulk Upload Parts from the same POA Claim Summary. The claim’s state and access checks apply to both roles."
    },
    "NEO-072": {
      "key": "poa-calculation-step",
      "related": false,
      "zh": "保留 Parts 与 Calculation 页面，增加大批量后台处理、完成提醒及提交状态回查。",
      "en": "Keep Parts and Calculation, with large-batch background processing, ready reminders and submission status lookup."
    },
    "NEO-043": {
      "key": "core",
      "related": false,
      "zh": "在同一创建 Claim 步骤条展示 CO₂ 页移除示意，其余字段按批准清单核对。",
      "en": "Show the proposed CO₂ step removal on the existing create-claim flow. Check the remaining field rules against the approved list."
    },
    "NEO-051": {
      "key": "approval-detail",
      "related": false,
      "zh": "在现有 Add Delegator 追加期间与理由，对级别做校验并留痕。",
      "en": "Add dates and a reason to Add Delegator, validate the level and keep an audit record."
    },
    "NEO-058": {
      "key": "wips-task",
      "related": true,
      "zh": "保留真实 WIPS 任务。重复提交、未知结果和完成判断依赖实际下游回执。",
      "en": "Keep the WIPS task. Retry, unknown outcomes and completion depend on actual downstream responses."
    },
    "NEO-060": {
      "key": "parts-edit",
      "related": false,
      "zh": "在原 Select parts 中按 Supplier＋Part 限制有效 Plant，失败时保留选择。",
      "en": "In the existing Select parts step, limit Plant to valid Supplier + Part combinations and keep selections on failure."
    },
    "NEO-068": {
      "key": "parts-edit",
      "related": false,
      "zh": "保留 Select parts 表格和已选行，补 Supplier／Plant／Vehicle Line 等检索。",
      "en": "Keep the Select parts table and selections. Add Supplier, Plant and Vehicle Line search."
    },
    "NEO-069": {
      "key": "claim-calculation",
      "related": false,
      "zh": "在当前 Calculations 结果旁查看价差输入、期间、FX 和缺失数据。",
      "en": "Open price-gap inputs, period, FX and missing-data details from the existing Calculations result."
    },
    "NEO-023": {
      "key": "bulk-upload-current",
      "related": false,
      "zh": "有权访问并维护该记录的 Buyer 和 CBSL，都从同一个 POA Claim Summary 进入 Bulk Upload Parts。上传适用该 Claim 的状态和权限校验。",
      "en": "Authorised Buyer and CBSL users both open Bulk Upload Parts from the same POA Claim Summary. The claim’s state and access checks apply to both roles."
    },
    "NEO-055": {
      "key": "buyer-forecast",
      "related": false,
      "zh": "在真实 Buyer Forecast 页补 Buyer 筛选，Download Excel 继续使用同一筛选结果。",
      "en": "Add Buyer filtering on the existing Buyer Forecast report and use the same filters for Download Excel."
    },
    "NEO-041": {
      "key": "supplier",
      "related": false,
      "zh": "在原 Lever 位置追加 Lever 明细，各自保留金额，审批和报表汇总按约定。",
      "en": "Extend the existing Lever field with detail rows. Keep the impact per lever and apply agreed approval and reporting totals."
    },
    "NEO-053": {
      "key": "supplier",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-064": {
      "key": "prices-edit",
      "related": false,
      "zh": "在原 Part prices 表格沿用现有勾选，增加批量移除及二次确认。",
      "en": "Add bulk removal and confirmation to the existing Part prices table and its row selection."
    },
    "NEO-062": {
      "key": "supplier",
      "related": false,
      "zh": "同一 Vendor Code 可回读最新名称及来源时间，已批准快照保留提交时名称。",
      "en": "Refresh the name and source time against the same Vendor Code. Keep the historical name in approved snapshots."
    },
    "NEO-065": {
      "key": "supplier",
      "related": false,
      "zh": "在 Gross Claim Value 现有标签旁提供字段说明，计算口径由 Finance 确认。",
      "en": "Provide help beside the existing Gross Claim Value label. Finance confirms the calculation basis."
    },
    "NEO-071": {
      "key": "cbsl-tasks",
      "related": false,
      "zh": "在原任务内开 Conversation，记录 Buyer 与授权 Digitide 的回复及附件。",
      "en": "Add a Conversation within the current task for Buyer and authorised Digitide replies and attachments."
    },
    "NEO-010": {
      "key": "claim-activity",
      "related": false,
      "zh": "在现有 Activity Log 的重大变更条目显示财务影响。",
      "en": "Show the financial impact on significant entries in the existing Activity Log."
    },
    "NEO-016": {
      "key": "bulk-upload-current",
      "related": false,
      "zh": "有权访问并维护该记录的 Buyer 和 CBSL，都从同一个 POA Claim Summary 进入 Bulk Upload Parts。上传适用该 Claim 的状态和权限校验。",
      "en": "Authorised Buyer and CBSL users both open Bulk Upload Parts from the same POA Claim Summary. The claim’s state and access checks apply to both roles."
    },
    "NEO-013": {
      "key": "clearing-agenda",
      "related": false,
      "zh": "沿用 Clearing House Agenda，确认请求、收件人和发送内容后再发送。",
      "en": "Use the same Clearing House Agenda and review the requests, recipients and content before sending."
    },
    "NEO-033": {
      "key": "claim-calculation",
      "related": false,
      "zh": "预算汇率更新只重算符合条件的未批准单；批准版本保留历史值。",
      "en": "Refresh eligible unapproved claims after a budget-rate update. Keep values on approved versions."
    },
    "NEO-025": {
      "key": "lsp-confirmed",
      "related": true,
      "zh": "保留 Lump Sum 页。Goods／Services 字段、SAP RFC 标志与报表映射一起确认。",
      "en": "Keep Lump Sum. Agree the Goods/Services field, SAP RFC flag and reporting mapping together."
    },
    "NEO-048": {
      "key": "reserve-detail",
      "related": true,
      "zh": "现有 Reserve 作为影响面。KSB1 替换需 SAP ECC 付款接口与 NEO ID 对账。",
      "en": "Use Reserve as context. Replacing KSB1 requires an ECC payment interface and NEO ID reconciliation."
    },
    "NEO-039": {
      "key": "prices-edit",
      "related": true,
      "zh": "保留现有价格表；仅改币种时的起始价换算依赖批准的 FX、日期和精度规则。",
      "en": "Keep the price table. Currency-only starting-price conversion depends on the approved FX source, date and precision."
    },
    "NEO-074": {
      "key": "claim-calculation",
      "related": true,
      "zh": "保留 Calculations 作为 NEO 数据上下文。与 Tableau 的差异桥接依赖 Finance／BI 数据契约。",
      "en": "Keep Calculations for NEO context. The Tableau reconciliation bridge depends on the Finance/BI data contract."
    },
    "NEO-035": {
      "key": "claim-calculation",
      "related": true,
      "zh": "ExWorks 的 £／台与 £m 需同一计算口径，待确认车辆量和正式报表位置。",
      "en": "Align ExWorks GBP/vehicle and GBP millions after confirming the volume basis and report location."
    },
    "NEO-038": {
      "key": "supplier",
      "related": false,
      "zh": "在原有 Maturity 与 Likelihood 的基础上派生 G Gate，映射待业务批准。",
      "en": "Derive G Gate from the existing Maturity and Likelihood values using the agreed mapping."
    },
    "NEO-059": {
      "key": "prices-edit",
      "related": true,
      "zh": "当前可使用 Parent 关联 Lines。混合涨跌价及多供应商方案需单独确定规则。",
      "en": "Keep linked Lines under a Parent while mixed price movements and multi-supplier rules are agreed."
    },
    "NEO-061": {
      "key": "supplier",
      "related": true,
      "zh": "保留未来年度 Opportunity 的录入上下文。无零件时的保存、预测和提交规则待定。",
      "en": "Keep the future-year Opportunity context. Agree draft, forecast and submission rules when parts are unavailable."
    },
    "NEO-066": {
      "key": "implemented-summary",
      "related": false,
      "zh": "在当前 Claim 的 Reporting Category 给出建议或校验，规则与例外归属待定。",
      "en": "Suggest or validate the Reporting Category at its current Claim entry, subject to approved rules and exception ownership."
    },
    "NEO-063": {
      "key": "supplier",
      "related": true,
      "zh": "维持当前供应商页，单一协议下多供应商的分摊、审批和下游映射待设计。",
      "en": "Keep the supplier page while allocation, approval and downstream mappings for multiple suppliers under one agreement are designed."
    },
    "NEO-075": {
      "key": "lsp-confirmed",
      "related": true,
      "zh": "保持当前 Lump Sum 入口。Non-BOM 分类、会计和绩效排除规则待批准。",
      "en": "Keep the existing Lump Sum entry while Non-BOM classification, accounting and performance exclusions are agreed."
    },
    "NEO-009": {
      "key": "prices-edit",
      "related": true,
      "zh": "保留 POA Part prices 作为上下文。RMA 自动取零件和交易的数据契约待定。",
      "en": "Keep POA Part prices as context. Automated RMA data and transactions require an agreed ECC contract."
    },
    "NEO-067": {
      "key": "approval-detail",
      "related": true,
      "zh": "保留现有审批页面，Mandate 和 Settlement 合并需确认版本、两项决定及例外。",
      "en": "Keep the existing approval page. A combined flow requires agreement on versions, separate decisions and exceptions."
    },
    "NEO-006": {
      "key": "auto-pam",
      "related": true,
      "zh": "次财年预测需 ExWorks 提供数据和算法，现有 Auto PAM 文件列表可继续评审。",
      "en": "Keep the Auto PAM list for review. Next-year forecasting depends on the ExWorks dataset and rules."
    },
    "NEO-054": {
      "key": "claim-calculation",
      "related": true,
      "zh": "现有 Calculations 作影响面，FTO／FFP 完整性由源文件和映射规则核对。",
      "en": "Keep Calculations as context. Check FTO/FFP completeness against source files and the agreed mapping."
    },
    "NEO-073": {
      "key": "supplier",
      "related": true,
      "zh": "当前以 Copy Claim 支持按年度分开维护。跨年协议和执行模型待定。",
      "en": "Use Copy Claim for separate annual records while the multi-year agreement and implementation model is assessed."
    },
    "NEO-070": {
      "key": "approval-detail",
      "related": true,
      "zh": "保留当前审批链。额外评审的权限和决定效力待确认。",
      "en": "Keep the existing approval chain until additional reviewers’ eligibility and decision rights are agreed."
    },
    "NEO-036": {
      "key": "cbsl-tasks",
      "related": false,
      "zh": "补充异常职责与交接，使用当前 Tasks 作流程参考。",
      "en": "Document exception ownership and handoffs using the current Tasks page as context."
    }
  },
  "states": {
    "prices-edit": {
      "key": "prices-edit",
      "description": "Alice Morgan · existing sample Part prices; not saved",
      "route": "/parts/prices",
      "steps": [
        {
          "role": "button",
          "name": "Update Claim"
        },
        {
          "route": "/parts/prices"
        }
      ],
      "image": "../must-design-guide-20261115-v1/before-captures/prices-edit.png",
      "state": "../must-design-guide-20261115-v1/before-captures/claim-calculation.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:52:32.970Z",
      "title": {
        "zh": "Part Prices 改价",
        "en": "Part prices"
      },
      "launchRoute": "/claim"
    },
    "memos": {
      "key": "memos",
      "description": "Ben Taylor · current Reserve Memos",
      "route": "/finance/reserve?period=training-2024-06&reserveTab=memos",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/memos.png",
      "state": "../must-design-guide-20261115-v1/before-captures/memos.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:52:45.266Z",
      "title": {
        "zh": "Reserve · Memos",
        "en": "Reserve · Memos"
      },
      "launchRoute": "/finance/reserve?period=training-2024-06&reserveTab=memos"
    },
    "reserve-detail": {
      "key": "reserve-detail",
      "description": "Ben Taylor · current Reserve detail",
      "route": "/finance/reserve?period=training-2024-06",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/reserve-detail.png",
      "state": "../must-design-guide-20261115-v1/before-captures/reserve-detail.state.json",
      "recordIDs": [
        "MCI-09101",
        "MCI-09102",
        "MCI-09103",
        "MCI-09104",
        "MCI-09105",
        "MCI-09106",
        "MCI-09107",
        "MCI-09108",
        "MCI-09109",
        "MCI-09110"
      ],
      "at": "2026-11-15T03:45:24.447Z",
      "title": {
        "zh": "Reserve Claims 准备金明细",
        "en": "Reserve Claims"
      },
      "launchRoute": "/finance/reserve?period=training-2024-06"
    },
    "teams": {
      "key": "teams",
      "description": "Jack Edwards · current Teams reference configuration",
      "route": "/admin/master-data?section=teams",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/teams.png",
      "state": "../must-design-guide-20261115-v1/before-captures/teams.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:58:02.575Z",
      "title": {
        "zh": "Team Category Mapping",
        "en": "Team Category Mapping"
      },
      "launchRoute": "/admin/master-data?section=teams"
    },
    "approval-detail": {
      "key": "approval-detail",
      "description": "Ben Taylor · current request detail, REQ-3",
      "route": "/approval",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/approval-detail.png",
      "state": "../must-design-guide-20261115-v1/before-captures/approval-detail.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:52:44.048Z",
      "title": {
        "zh": "Approval Request 申请详情",
        "en": "Approval Request detail"
      },
      "launchRoute": "/approval"
    },
    "journal-mca": {
      "key": "journal-mca",
      "description": "Clara Bennett · current Journal",
      "route": "/finance/journal",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/journal-mca.png",
      "state": "../must-design-guide-20261115-v1/before-captures/journal-mca.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:52:50.365Z",
      "title": {
        "zh": "Journal",
        "en": "Journal"
      },
      "launchRoute": "/finance/journal"
    },
    "lsp-confirmed": {
      "key": "lsp-confirmed",
      "description": "Alice Morgan · saved Lump Sum record, original current form",
      "route": "/claim",
      "steps": [
        {
          "role": "tab",
          "name": "Lump Sum"
        }
      ],
      "image": "../must-design-guide-20261115-v1/before-captures/lsp-confirmed.png",
      "state": "../must-design-guide-20261115-v1/before-captures/lsp-confirmed.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:54:17.574Z",
      "title": {
        "zh": "Lump Sum 明细",
        "en": "Lump Sum details"
      },
      "launchRoute": "/claim"
    },
    "core": {
      "key": "core",
      "description": "Alice Morgan · current Update Claim Core Data; opened only, not saved",
      "route": "/claim",
      "steps": [
        {
          "role": "button",
          "name": "Update Claim"
        }
      ],
      "image": "../must-design-guide-20261115-v1/before-captures/core.png",
      "state": "../must-design-guide-20261115-v1/before-captures/claim.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:45:17.957Z",
      "title": {
        "zh": "Update Claim · Core Data",
        "en": "Update Claim · Core Data"
      },
      "launchRoute": "/claim"
    },
    "claim-calculation": {
      "key": "claim-calculation",
      "description": "Alice Morgan · saved POA calculation detail, existing part-calculation sample",
      "route": "/claim",
      "steps": [
        {
          "role": "tab",
          "name": "Calculations"
        }
      ],
      "image": "../must-design-guide-20261115-v1/before-captures/claim-calculation.png",
      "state": "../must-design-guide-20261115-v1/before-captures/claim-calculation.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:52:30.480Z",
      "title": {
        "zh": "Claim Calculations 计算结果",
        "en": "Claim Calculations"
      },
      "launchRoute": "/claim"
    },
    "requests": {
      "key": "requests",
      "description": "Ben Taylor · current Approval Requests",
      "route": "/requests",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/requests.png",
      "state": "../must-design-guide-20261115-v1/before-captures/requests.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:45:20.996Z",
      "title": {
        "zh": "Approval Requests 审批列表",
        "en": "Approval Requests"
      },
      "launchRoute": "/requests"
    },
    "parts-edit": {
      "key": "parts-edit",
      "description": "Alice Morgan · selected-parts editing for existing sample; not saved",
      "route": "/parts",
      "steps": [
        {
          "role": "button",
          "name": "Update Claim"
        },
        {
          "route": "/parts"
        }
      ],
      "image": "../must-design-guide-20261115-v1/before-captures/parts-edit.png",
      "state": "../must-design-guide-20261115-v1/before-captures/claim-calculation.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:52:31.961Z",
      "title": {
        "zh": "Select Parts 零件选择",
        "en": "Select parts"
      },
      "launchRoute": "/claim"
    },
    "auto-pam": {
      "key": "auto-pam",
      "description": "Ben Taylor · current Auto PAM Report",
      "route": "/reporting?section=auto-pam",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/auto-pam.png",
      "state": "../must-design-guide-20261115-v1/before-captures/auto-pam.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:45:21.969Z",
      "title": {
        "zh": "Auto PAM Report",
        "en": "Auto PAM Report"
      },
      "launchRoute": "/reporting?section=auto-pam"
    },
    "naf-pin-gfs": {
      "key": "naf-pin-gfs",
      "description": "Daniel Foster · current NAF Pin Report",
      "route": "/reporting?section=poa-parts",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/naf-pin-gfs.png",
      "state": "../must-design-guide-20261115-v1/before-captures/naf-pin-gfs.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:52:47.926Z",
      "title": {
        "zh": "NAF Pin Report",
        "en": "NAF Pin Report"
      },
      "launchRoute": "/reporting?section=poa-parts"
    },
    "s4-task": {
      "key": "s4-task",
      "description": "Grace Turner · current Create S4 Hana Claim task",
      "route": "/tasks",
      "steps": [
        {
          "role": "button",
          "name": "Create S4 Hana Claim MCI-00131"
        }
      ],
      "image": "../must-design-guide-20261115-v1/before-captures/s4-task.png",
      "state": "../must-design-guide-20261115-v1/before-captures/s4-task.state.json",
      "recordIDs": [
        "MCI-00131"
      ],
      "at": "2026-11-15T03:54:20.263Z",
      "title": {
        "zh": "CBSL S4 Hana Task",
        "en": "CBSL S4 Hana Task"
      },
      "launchRoute": "/tasks"
    },
    "implemented": {
      "key": "implemented",
      "description": "Alice Morgan · current implemented Claim Summary",
      "route": "/claim",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/implemented.png",
      "state": "../must-design-guide-20261115-v1/before-captures/implemented.state.json",
      "recordIDs": [
        "MCI-00132"
      ],
      "at": "2026-11-15T03:52:40.978Z",
      "title": {
        "zh": "Implemented Claim 已实施单据",
        "en": "Implemented Claim"
      },
      "launchRoute": "/claim"
    },
    "cbsl-tasks": {
      "key": "cbsl-tasks",
      "description": "Grace Turner · current CBSL task list",
      "route": "/tasks",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/cbsl-tasks.png",
      "state": "../must-design-guide-20261115-v1/before-captures/cbsl-tasks.state.json",
      "recordIDs": [
        "MCI-00131",
        "MCI-00130",
        "MCI-00073",
        "MCI-00095",
        "MCI-00100",
        "MCI-00089",
        "MCI-00070",
        "MCI-00141"
      ],
      "at": "2026-11-15T03:45:27.860Z",
      "title": {
        "zh": "CBSL Tasks 任务列表",
        "en": "CBSL Tasks"
      },
      "launchRoute": "/tasks"
    },
    "wips-task": {
      "key": "wips-task",
      "description": "Grace Turner · current WIPS failure / manual task",
      "route": "/tasks",
      "steps": [
        {
          "role": "button",
          "name": "WIPS update error: Manually Create and Approve Claim MCI-00073"
        }
      ],
      "image": "../must-design-guide-20261115-v1/before-captures/wips-task.png",
      "state": "../must-design-guide-20261115-v1/before-captures/wips-task.state.json",
      "recordIDs": [
        "MCI-00073"
      ],
      "at": "2026-11-15T03:57:57.728Z",
      "title": {
        "zh": "CBSL WIPS Claim 任务",
        "en": "CBSL WIPS Claim task"
      },
      "launchRoute": "/tasks"
    },
    "supplier": {
      "key": "supplier",
      "description": "Alice Morgan · current Supplier Claim Details; opened only, not saved",
      "route": "/claim",
      "steps": [
        {
          "role": "button",
          "name": "Update Claim"
        },
        {
          "text": "Supplier Claim Details"
        }
      ],
      "image": "../must-design-guide-20261115-v1/before-captures/supplier.png",
      "state": "../must-design-guide-20261115-v1/before-captures/claim.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:45:18.870Z",
      "title": {
        "zh": "Supplier Claim Details",
        "en": "Supplier Claim Details"
      },
      "launchRoute": "/claim"
    },
    "bulk-upload-current": {
      "key": "bulk-upload-current",
      "description": "Grace Turner / CBSL · restored Bulk Upload Parts · synthetic Claim · local verification only",
      "route": "/parts/import",
      "launchRoute": "/parts/import",
      "steps": [],
      "image": "../bulk-upload-review-20261116/01-upload.png",
      "state": "",
      "recordIDs": [
        "NEO-L-00001"
      ],
      "at": "2026-11-16",
      "title": {
        "zh": "Bulk Upload Parts 批量上传",
        "en": "Bulk Upload Parts"
      },
      "build": "e9a2d592"
    },
    "poa-calculation-step": {
      "title": {
        "zh": "P2.6.3 · POA 计算",
        "en": "P2.6.3 · POA Calculation"
      },
      "image": "../must-design-guide-20261115-v1/before-captures/calculation.png",
      "state": "../must-design-guide-20261115-v1/before-captures/prices-edit.state.json",
      "launchRoute": "/claim",
      "steps": [
        {
          "role": "button",
          "name": "Update Claim"
        },
        {
          "route": "/calculation"
        }
      ]
    },
    "neo-journal-044": {
      "title": {
        "zh": "Reserve · Journal Templates",
        "en": "Reserve · Journal Templates"
      },
      "image": "journal-044/neo-before.png",
      "source": "NEO AppShell, PageHeader, DataTable and theme · 17 November walkthrough, Word images 17–18"
    },
    "settlement-details": {
      "title": {
        "en": "Settlement Request · Request details",
        "zh": "Settlement Request · Request details"
      },
      "image": "aligned-captures/surface-settlement-details.png",
      "source": "request-details-1440.png",
      "sha256": "b3d172ed0ce82293d2ac1153352a38021002c05b2bbcb01ba02caccee69617bb"
    },
    "buyer-forecast": {
      "title": {
        "en": "Reports · Buyer Forecast",
        "zh": "Reports · Buyer Forecast"
      },
      "image": "aligned-captures/surface-buyer-forecast.png",
      "source": "buyer-forecast-generated-1440.png",
      "sha256": "136a97bda9b25b473d494f42234ef8abb4894a2b54369aa002756f8121e2fe62"
    },
    "buyer-rpa": {
      "title": {
        "en": "Tasks · Buyer Review",
        "zh": "Tasks · Buyer Review"
      },
      "image": "aligned-captures/surface-buyer-rpa.png",
      "source": "02-buyer-three-error-details.png",
      "sha256": "6849ea634c68f3aef6f3c6dea9e47be85792b752b60a6c5d3479fa369d957281"
    },
    "clearing-request": {
      "title": {
        "en": "Approval Requests · Clearing House",
        "zh": "Approval Requests · Clearing House"
      },
      "image": "aligned-captures/surface-clearing-request.png",
      "source": "03-awaiting-clearing-house.png",
      "sha256": "70f0e324421f3c9d88ae00749ff1baeaa375d000a4f9924e907ff03bf7e0b8dc"
    },
    "clearing-agenda": {
      "title": {
        "en": "Approval Requests · Clearing House Agenda",
        "zh": "Approval Requests · Clearing House Agenda"
      },
      "image": "aligned-captures/surface-clearing-agenda.png",
      "source": "S3-CLEARING-HOUSE.png",
      "sha256": "0aab43990c46de07160b52a941ad3b976562764f5da5d22b1159b038eac9d085"
    },
    "claim-activity": {
      "title": {
        "en": "Claim · Activity Log",
        "zh": "Claim · Activity Log"
      },
      "image": "aligned-captures/surface-claim-activity.png",
      "source": "claim-activity-log-1440.png",
      "sha256": "444103d98f55383f17ae7c0b448caa669cc424357892943810f56c653a439373"
    },
    "implemented-summary": {
      "title": {
        "en": "Claim · Finance",
        "zh": "Claim · Finance"
      },
      "image": "aligned-captures/surface-implemented-summary.png",
      "source": "claim-finance-1440.png",
      "sha256": "aa3d500c3948068f1c3a7190cd2e51a1e269f7d64442f5f719653fe6b223eba4"
    },
    "lsp-entry": {
      "title": {
        "en": "Lump Sum · Finance details",
        "zh": "Lump Sum · Finance details"
      },
      "image": "aligned-captures/surface-lsp-entry.png",
      "source": "P7.6-lump-sum-fields-1440.png",
      "sha256": "e1131bb322c63d718f3ac7a312ec544f74c06412c7b2b4fed5594370416364c9"
    },
    "approval-flow": {
      "title": {
        "zh": "Approval Requests · Approval Flow",
        "en": "Approval Requests · Approval Flow"
      },
      "image": "../must-design-guide-20261115-v1/assets/neo057-approval-flow-20261116/NEO-057-Approval-Requests-6ee4450d1a44.png",
      "source": "User-supplied Approval Flow screenshot: FBP Returned → Buyer correction Pending"
    },
    "appian-poa-report": {
      "title": {
        "zh": "POA Part Level Detail Report",
        "en": "POA Part Level Detail Report"
      },
      "image": "poa-report/generated-report.png"
    }
  }
};
