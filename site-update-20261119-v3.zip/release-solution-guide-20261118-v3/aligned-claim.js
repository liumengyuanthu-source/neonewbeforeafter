'use strict';

// Render the frozen prototype with isolated fixture storage on both sides.
// The removal overlay is a visual proposal and preserves the original field slots.
const query = new URLSearchParams(location.search);
const id = query.get('id');
const spec = window.MUST_CATALOG.rows.find(row => row.id === id)?.alignedPreview;
const normalize = value => value.trim().replace(/\s+\*/g, '').replace(/\s+/g, ' ');
const visible = element => element.getClientRects().length > 0;
let updateRemoval = () => {};
let updateAdditions = () => {};

window.setReviewSide = side => {
  document.body.dataset.compareSide = side === 'after' ? 'after' : 'before';
  updateRemoval();
  updateAdditions();
};
window.setReviewHighlight = enabled => { document.body.dataset.reviewHighlight = String(enabled); };
window.setReviewSide(query.get('view'));

async function until(find) {
  for (let attempt = 0; attempt < 120; attempt++) {
    const result = find();
    if (result) return result;
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  throw new Error('The comparison could not locate the expected page.');
}

function byText(selector, text) {
  return [...document.querySelectorAll(selector)].find(element =>
    visible(element) && normalize(element.textContent) === text);
}

async function addFieldHelp(labelText) {
  const label = await until(() => byText('label',labelText));
  const help = document.createElement('button');
  help.type = 'button';
  help.className = 'review-inline-help';
  help.dataset.reviewAddition = '';
  help.setAttribute('aria-label','Gross Claim Value help');
  help.setAttribute('aria-expanded','false');
  help.textContent = 'ⓘ';
  const explanation = document.createElement('p');
  explanation.className = 'review-field-explanation';
  explanation.dataset.reviewAddition = '';
  explanation.hidden = true;
  explanation.textContent = 'Enter the gross supplier claim amount in the displayed local currency. Where the approved process uses part data, use the calculated amount for that claim.';
  label.append(help);
  label.closest('.ant-form-item').append(explanation);
  const bounds = label.getBoundingClientRect();
  window.scrollTo(0, window.scrollY + bounds.top - window.innerHeight / 2);
  help.addEventListener('click', event => {
    event.preventDefault();
    explanation.hidden = !explanation.hidden;
    help.setAttribute('aria-expanded',String(!explanation.hidden));
  });
}

async function addBulkRemoval() {
  const toolbar = await until(() => byText('button','Clear targets')?.parentElement);
  const remove = document.createElement('button');
  remove.type = 'button';
  remove.className = toolbar.querySelector('button').className;
  remove.dataset.reviewAddition = '';
  remove.textContent = 'Remove selected parts';
  toolbar.append(remove);
  const marked = () => [...document.querySelectorAll('tr[data-row-key]')]
    .filter(row => row.querySelector('.ant-table-selection-column input:checked'))
    .map(row => row.querySelector('button[aria-label^="Remove price row "]'))
    .filter(button => button && !button.disabled);
  const update = () => { remove.disabled = !marked().length; };
  updateAdditions = update;
  document.addEventListener('change', () => queueMicrotask(update), true);
  new MutationObserver(update).observe(document.querySelector('#root'),{childList:true,subtree:true});
  remove.addEventListener('click', () => {
    const buttons = marked();
    if (!buttons.length) return;
    const labels = buttons.map(button => button.getAttribute('aria-label'));
    const dialog = document.createElement('dialog');
    dialog.className = 'review-removal-dialog';
    dialog.setAttribute('aria-labelledby','review-removal-title');
    dialog.innerHTML = `<h2 id="review-removal-title">Remove ${buttons.length} selected ${buttons.length===1?'part':'parts'}?</h2>
      <p>Review the remaining parts before recalculating.</p>
      <div><button type="button" data-cancel>Cancel</button><button type="button" data-confirm>Remove</button></div>`;
    document.body.append(dialog);
    dialog.querySelector('[data-cancel]').onclick = () => dialog.close();
    dialog.querySelector('[data-confirm]').onclick = async () => {
      dialog.close();
      for (const label of labels) {
        const current = [...document.querySelectorAll('button[aria-label^="Remove price row "]')]
          .find(button => button.getAttribute('aria-label') === label && !button.disabled);
        if (!current) continue;
        current.click();
        try { await until(() => !current.isConnected); } catch { break; }
      }
      update();
    };
    dialog.addEventListener('close', () => { dialog.remove(); remove.focus(); });
    dialog.showModal();
  });
  update();
}

async function openFixture() {
  const state = window.BEFORE_MAP.states[spec?.state];
  if (!state?.state) throw new Error('No fixture is available for this comparison.');
  const response = await fetch(state.state);
  if (!response.ok) throw new Error('The comparison fixture could not be loaded.');
  const values = new Map([['neo.full.react.antd.20261106.v1', await response.text()]]);
  Object.defineProperty(window, 'localStorage', {
    value: {
      getItem: key => values.get(String(key)) ?? null,
      setItem: (key, value) => values.set(String(key), String(value)),
      removeItem: key => values.delete(String(key)),
      clear: () => values.clear(),
      key: index => [...values.keys()][index] ?? null,
      get length() { return values.size; }
    }
  });
  history.replaceState(null, '', location.pathname + location.search + '#' + (spec.create ? '/work-queue' : state.launchRoute));
  const script = document.createElement('script');
  script.src = '../must-design-guide-20261115-v1/before-source/app.js';
  document.body.append(script);
  await until(() => document.querySelector('main'));
  if (spec.create) {
    const create = await until(() => byText('button', 'Create Claim'));
    create.click();
    await until(() => byText('.ant-steps-item-title','Core Data'));
    if (spec.route) {
      location.hash = spec.route;
      await until(() => document.querySelector('[aria-label="Inflation Type"]'));
    } else if (spec.state === 'supplier') {
      (await until(() => byText('.ant-steps-item-title', 'Supplier Claim Details'))).click();
    }
  } else {
    for (const step of state.steps || []) {
      if (step.route) { location.hash = step.route; continue; }
      const selector = step.role === 'tab' ? '[role=tab]' : step.role === 'button' ? 'button' : '.ant-steps-item-title';
      (await until(() => byText(selector, step.name || step.text))).click();
    }
  }
  if (spec.removeField || spec.removeStep) {
    const findRemoval = () => spec.removeField
      ? byText('label', spec.removeField)?.closest('.ant-form-item')
      : byText('.ant-steps-item-title', spec.removeStep)?.closest('.ant-steps-item');
    const target = await until(findRemoval);
    updateRemoval = () => {
      const element = findRemoval();
      if (!element) return;
      element.dataset.reviewRemoval = '';
      element.inert = document.body.dataset.compareSide === 'after';
    };
    updateRemoval();
    new MutationObserver(updateRemoval).observe(document.querySelector('#root'), {childList:true, subtree:true});
    // Highlight the exact location initially on the long Supplier Claim Details form.
    if (spec.removeField) {
      const center = target.getBoundingClientRect().top + target.offsetHeight / 2;
      window.scrollTo(0, window.scrollY + center - window.innerHeight / 2);
    }
  }
  if (spec.action === 'remove-selected-parts') await addBulkRemoval();
  if (spec.help) await addFieldHelp(spec.help);
  if (spec.calculation) {
    const style = document.createElement('link');
    style.rel = 'stylesheet';
    style.href = 'calculation-029/journey.css';
    document.head.append(style);
    const adapter = document.createElement('script');
    adapter.src = 'calculation-029/journey.js';
    document.head.append(adapter);
    const start = await until(() => window.installCalculationReview);
    updateAdditions = await start({ until, visible, byText });
    updateAdditions();
  }
  document.body.dataset.ready = 'true';
}

openFixture().catch(error => {
  document.body.dataset.error = error.message;
  const message = document.createElement('p');
  message.setAttribute('role', 'alert');
  message.textContent = error.message;
  document.body.prepend(message);
});
