window.MUST_EN={
  "NEO-001": {
    "title": "AutoPAM year-end rollover",
    "focus": "Before and After share the Auto PAM file list, breadcrumb and report information icons. Only the backend rollover calculation rules change.",
    "dependency": "The latest Finance text points to NEO-002, correcting the earlier NEO-003 reference. Confirm current Rules 6/7 and Calculations 5/6."
  },
  "NEO-003": {
    "title": "Refresh SAP start prices before approval",
    "focus": "Before and After share the existing Part prices page. After adds only Refresh prices from SAP; bulk adjustments, individual editing and all fields remain.",
    "dependency": "Confirm price freshness, pagination, currency and units. Approved snapshots must not be overwritten."
  },
  "NEO-004": {
    "title": "Correct the POA part detail report",
    "focus": "Before and After share the existing NAF Pin Report page. Correct report calculations and output data without adding filters, tables or pages.",
    "dependency": "Obtain the incorrect fields, current template and correct monetary examples from HJONES20 / DSMITH69."
  },
  "NEO-005": {
    "title": "Supplier balance and Settlement approval",
    "focus": "Walk through Buyer → FBP → DoA → GFS: check balance before Settlement submission; approve explicit Manual Invoice or GFS PO override arrangements when insufficient; recheck before implementation and return if conditions change.",
    "dependency": "Confirm the proposed route, SAP balance contract and authorised GFS override. Manual Invoice stays; removal is a separate decision."
  },
  "NEO-007": {
    "title": "Use the higher FTO / GR amount for DoA",
    "focus": "Before and After use the same approval detail page, with unchanged fields, layout, buttons and interactions. Only the FTO / GR calculation and DoA / further-approval rules change; no comparison panel or new page is added.",
    "dependency": "Finance must confirm signed versus absolute values, period, FX and thresholds. Missing GR is not zero."
  },
  "NEO-008": {
    "title": "Fix prepayment FX to the implementation month",
    "focus": "Review the implementation-month FX basis and reserve detail, including missing rates and revised source versions.",
    "dependency": "The monthly-rate channel is listed; historical completeness and correction versions remain unconfirmed."
  },
  "NEO-011": {
    "title": "Deposit classification and accounting",
    "focus": "Change the non-standard type to Deposits, preview the change and inspect the monthly Reserve review items.",
    "dependency": "Finance must distinguish Deposit from Prepayment and provide approved worked examples."
  },
  "NEO-012": {
    "title": "Separate implemented LSP with no invoice",
    "focus": "Filter implemented LSP with no invoice, inspect line evidence and review export scope.",
    "dependency": "PO status is not invoice receipt. The invoice source, cutoff and grain still need confirmation."
  },
  "NEO-014": {
    "title": "Clearing House minutes",
    "focus": "Select a meeting session, generate and inspect its report, then review missing minutes and changed source records.",
    "dependency": "Report export can be delivered independently; direct email depends on NEO-013 and an agreed mail service."
  },
  "NEO-015": {
    "title": "Prepayment accrual before implementation",
    "focus": "Review accrual detail and a revision preview across agreed settlements, insufficient asset evidence and read-only Final records.",
    "dependency": "Finance must confirm dates and stage-specific treatment with NEO-008, including any AutoPAM effects."
  },
  "NEO-017": {
    "title": "Recognise S4 plants and route tasks",
    "focus": "Review plant recognition and implementation routing, including the handling of an unidentified plant.",
    "dependency": "SAP / S4 / FFP source proposals are not yet confirmed. This also depends on NEO-018 and 021."
  },
  "NEO-018": {
    "title": "S4 master data, prices and GR",
    "focus": "Review proposed S4 data intake and missing-data states. This design does not prove an available interface.",
    "dependency": "S2P-I-034–037 are listed design IDs; obtain functional specifications and payloads before claiming reuse or deployment."
  },
  "NEO-019": {
    "title": "Plant dropdown and validation in import",
    "focus": "Review the proposed template, file validation, preview, error rows and application of valid changes.",
    "dependency": "Confirm stable plant codes and effective dates. Validating display names alone is insufficient."
  },
  "NEO-020": {
    "title": "Preserve leading zeros in part numbers",
    "focus": "Compare part-number segments and full identifiers; inspect numeric cells and inconsistent identifiers.",
    "dependency": "A file that has already lost leading zeros must be corrected at source; the application must not guess them."
  },
  "NEO-021": {
    "title": "S4 POA workflow and BP mapping",
    "focus": "Review S4 / WIPS routing within one Claim, the S4 task, missing BP mappings and S4-only cases.",
    "dependency": "Inbound S4 interfaces do not prove an outbound update interface. Interface acceptance differs from NEO-018."
  },
  "NEO-022": {
    "title": "Prevent price-sequence conflicts across Claims",
    "focus": "Review parallel-Claim conflicts, then compare target-price and percentage choices after the preceding Claim is implemented.",
    "dependency": "Confirm the conflict key, date scope and whether each conflict blocks submission or only warns."
  },
  "NEO-024": {
    "title": "Prevent duplicate Part + Plant rows",
    "focus": "Find duplicate Part + Plant rows within one Claim and inspect their resolution.",
    "dependency": "Retain the same part in different plants. Keep this separate from the cross-Claim control in NEO-022."
  },
  "NEO-026": {
    "title": "Lock fields after implementation",
    "focus": "Compare editable fields before and after implementation; distinguish adding an existing PO reference from changing commercial terms.",
    "dependency": "Confirm the field whitelist. Reference completion must not be locked indiscriminately with commercial fields."
  },
  "NEO-027": {
    "title": "AMM upload: weights and escalators",
    "focus": "Review units, weight and material rows in the proposed upload, including invalid rows and unconfirmed mappings.",
    "dependency": "Use the same detail model as NEO-042. A changed downstream structure requires WIPS contract verification."
  },
  "NEO-028": {
    "title": "Improve task selection response",
    "focus": "Immediate selection feedback; calculation running → ready email and task → completed result, using the same Claim and version.",
    "dependency": "Reuse calculation, task and notification services. Durable background processing, email delivery and actual performance remain unverified; diagnose any SAP bottleneck."
  },
  "NEO-029": {
    "title": "Background calculation and completion reminder",
    "focus": "Reuse the existing POC solution and handoff task. The stopped independent exploration is excluded.",
    "dependency": "IAM / Security must confirm idle and absolute session limits; extending SSO duration is not assumed."
  },
  "NEO-030": {
    "title": "Prevent CBSL from changing approved prices",
    "focus": "CBSL can continue processing WIPS tasks but cannot change prices. Route discrepancies to the Buyer and verify the approved basis before implementation.",
    "dependency": "Confirm restricted users, editable non-price fields, review after price changes, and SAP / WIPS source-verification contracts."
  },
  "NEO-031": {
    "title": "Annual impact must cover 12 months",
    "focus": "Annualised value must represent exactly 12 months of POA impact, rather than repeat the calendarised amount from the effective date to the Claim fiscal-year end.",
    "dependency": "Finance must approve annual volume, calendarisation and cross-year worked examples."
  },
  "NEO-032": {
    "title": "Five-decimal SAP / WIPS prices",
    "focus": "Inspect five-decimal prices, currency and price-unit conversion, distinguishing display from stored precision.",
    "dependency": "Obtain SAP price units, price-per-thousand rules and Apigee examples. Appending zeros cannot restore precision."
  },
  "NEO-034": {
    "title": "Compatible Lever and Reporting Category",
    "focus": "Select Lever and Reporting Category; review allowed combinations, incompatible choices and reference configuration.",
    "dependency": "Finance must provide the allowed combinations and decide when to warn or block."
  },
  "NEO-037": {
    "title": "Review Memo accounting rules",
    "focus": "Review actual FX, posting evidence and void versus reversal. Confirmed must not be presented as Posted.",
    "dependency": "Helen / Linda / Finance must confirm the rules. Posted accounting evidence must not be physically deleted."
  },
  "NEO-042": {
    "title": "More than three AMM escalators per part",
    "focus": "AMM is the Automaterials-related POA price-change scenario here. The Buyer records material-linked Escalator Codes for each Part; after approval, CBSL updates WIPS and the Purchasing Manager confirms WIPS approval. Requirement 042 expands the three-code entry limit per Part; it does not introduce a separate approval route.",
    "dependency": "WIPS / CBSL must confirm the actual per-Part limit and permitted codes / fields, for example whether an eleventh code is supported. The AMM owner should provide one existing ATP to verify the Part / Plant association and handoff detail. Retain FR14 manual implementation; do not treat the generic RPA endpoint as a verified AMM contract."
  },
  "NEO-044": {
    "title": "Reconcile Journal and reports by NEO ID",
    "focus": "Compare Journal and report entries by NEO ID, including differences, sources and missing records.",
    "dependency": "File upload does not establish a new SAP posting API. Obtain the approved SAP template and field contract."
  },
  "NEO-045": {
    "title": "Derive valid LSP finance combinations",
    "focus": "Select LSP master data and review derived finance fields, no match and multiple matches.",
    "dependency": "Independent Company / Organisation / Group lists do not prove valid combinations. Confirm Cost Centre / GL rules."
  },
  "NEO-046": {
    "title": "Derive Team from Reporting Category",
    "focus": "Inspect the Category-to-Team mapping and the impact of changing it.",
    "dependency": "Confirm category grain with NEO-034 / 041 and obtain the detailed mapping from HJONES20."
  },
  "NEO-047": {
    "title": "One Reserve output for all BS accounts",
    "focus": "Review multiple balance-sheet accounts, line details and totals, checking omissions and double counting.",
    "dependency": "This is more than adding columns: account classification, sign and offset rules need Finance approval."
  },
  "NEO-049": {
    "title": "Assign EPMC / BAC contract work to Digitide",
    "focus": "049 has two triggers: completion of the last applicable approval / GFS check creates the Buyer contract-implementation task; only the Buyer’s confirmed Assign to Digitide action hands that implementation task to Digitide.",
    "dependency": "This revision uses an explicit Buyer-confirmed handoff, not automatic cross-group assignment. Implementation needs two configuration sets: (1) the actual route and required contract information for each EPMC / BAC / TD branch; (2) the mapping of SAP approval / release status, effective dates and completion evidence. Existing interface evidence does not establish automatic creation or readback of this container contract. Retain manual SAP work by Digitide and recorded NEO evidence. This is an explanation / process-design revision, not verified task services or SAP functionality."
  },
  "NEO-050": {
    "title": "Approval status: In Approval → Approved",
    "focus": "050 corrects the approval status: show Approved only after all relevant approvals and FBP completion; otherwise retain In Approval.",
    "dependency": "No approval-route change or new external interface. Correct Request status logic and its Line / Parent projection. Retain In Approval until FBP completion, as in the existing independent design. Production persistence, concurrency and cross-page readback still require verification."
  },
  "NEO-052": {
    "title": "Remove Global Commodity Lead Area",
    "focus": "Review the form without this field and the treatment of existing records.",
    "dependency": "Confirm removal versus a maintainable list, and report / interface dependencies. Historical data must be retained."
  },
  "NEO-056": {
    "title": "Follow DoA without extra approval levels",
    "focus": "Inspect the route required by the formal DoA and the boundary for additional approvals.",
    "dependency": "Obtain the signed DoA matrix and clarify escalation / exceptional reviewers. Mock routing is not proof of compliance."
  },
  "NEO-057": {
    "title": "Approval flow, current owner and reminders",
    "focus": "Reuse the existing Approval Flow to show task status, current owner and return paths, with a downloadable open-task report and automated overdue reminders.",
    "dependency": "Confirm mail contracts, calendars and escalation rules. A new table alone cannot implement notifications."
  },
  "AS-IS Baseline": {
    "title": "Full AS-IS baseline",
    "focus": "Preserve existing functionality, configuration and operation. Priorities apply to enhancements, not removal of baseline controls.",
    "dependency": "Current baseline, configuration exports and business-owner acceptance are required."
  },
  "NEO-002": {
    "title": "Production schedule data pipeline change - Existing data feed doesn't work.",
    "focus": "Production schedule data pipeline change - Existing data feed doesn't work.",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-040": {
    "title": "UI/System & Bulk upload template should contain only columns that are actually required.",
    "focus": "UI/System & Bulk upload template should contain only columns that are actually required.\n3x Columns below need to be validated and confirmed if actually required.\nRun Out - Run Out Date - ATP Reference\nCurrency - implied by the GSDB code, not entered by the buyer.",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-072": {
    "title": "Reliable processing of large parts lists",
    "focus": "Improve system performance when processing large volumes of parts to avoid page loading timeouts and failed submissions, reducing the need for buyers to retry and preventing disruption to the claim process.",
    "dependency": "Review the source and dependency assessment. External contracts and business acceptance are not confirmed."
  },
  "NEO-043": {
    "title": "Fields and data collected as part of the Risk/Opp should be reviewed to only collect data that is actually req",
    "focus": "Fields and data collected as part of the Risk/Opp should be reviewed to only collect data that is actually required.",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-051": {
    "title": "DOA Delegation",
    "focus": "DOA Delegation",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-058": {
    "title": "POA Implementation",
    "focus": "POA Implementation",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-060": {
    "title": "Valid plants by part and supplier",
    "focus": "Autopopulate Plant Code details on POA claims",
    "dependency": "Review the source and dependency assessment. External contracts and business acceptance are not confirmed."
  },
  "NEO-068": {
    "title": "Find and filter parts",
    "focus": "Improve part selection efficiency by providing practical search and filtering options(supplier, plant, vehicle line etc.), enabling buyers to quickly identify the correct parts from large datasets.",
    "dependency": "Review the source and dependency assessment. External contracts and business acceptance are not confirmed."
  },
  "NEO-069": {
    "title": "Understand price and impact calculations",
    "focus": "Improve price-gap transparency by clearly showing how the price gap is calculated, including the underlying data and any missing or incorrect information, enabling buyers to understand and resolve issues more efficiently.",
    "dependency": "Review the source and dependency assessment. External contracts and business acceptance are not confirmed."
  },
  "NEO-023": {
    "title": "UX/Workflow logic - New Part Price Currency display",
    "focus": "UX/Workflow logic - New Part Price Currency display\nNew Part Price Currency field is inconsistently filled - should only be required for certain transaction types (resource - currency change).\nRequest from digitide to increase clarity over required/relevant fields and enforce completion where relevant and hide where not relevant to avoid confusion.\nBelieve this is linked to bulk upload tool and the task issued to Digitide",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-055": {
    "title": "The replacement NEO shall provide users with a report called \"Buyer Forecast Download\" and be able to download",
    "focus": "The replacement NEO shall provide users with a report called \"Buyer Forecast Download\" and be able to download as excel. The format of this report and the ability to filter the data downloaded needs to be improved.",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-041": {
    "title": "Allow a single claim to be submitted with multiple levers - linked with NEO-046 where levers are no longer use",
    "focus": "Allow a single claim to be submitted with multiple levers - linked with NEO-046 where levers are no longer used to deterimne financial reporting.",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-053": {
    "title": "Review the inflation levers to drive simplication and ease input for procurement.",
    "focus": "Review the inflation levers to drive simplication and ease input for procurement.",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-064": {
    "title": "Bulk removal of POA parts",
    "focus": "Bulk Deletion of POA Part Records",
    "dependency": "Review the source and dependency assessment. External contracts and business acceptance are not confirmed."
  },
  "NEO-062": {
    "title": "Supplier details from the source system",
    "focus": "Supplier Details update from Source systems",
    "dependency": "Review the source and dependency assessment. External contracts and business acceptance are not confirmed."
  },
  "NEO-065": {
    "title": "Gross Claim Value guidance",
    "focus": "Automatic Gross Claim Value Calculation\nBetter description/explanation of Gross Claim Value field and purpose.",
    "dependency": "Review the source and dependency assessment. External contracts and business acceptance are not confirmed."
  },
  "NEO-071": {
    "title": "Case collaboration with Digitide",
    "focus": "Digitide (CBSL) shared service collaboration should be incorporated within NEO.\nWhere items are routed to a shared service group (i.e. many users can pick up and work on the same item) then there should be the ability to communicate and feedback directly related to each case rather than requiring feedback to be shared via email.\nIf there are items that are raised to Digitide outstide of NEO based on cases within NEO and a workflow does not currently exist then this should be reviewed.",
    "dependency": "Review the source and dependency assessment. External contracts and business acceptance are not confirmed."
  },
  "NEO-010": {
    "title": "Activity Log Functionality improvements",
    "focus": "Activity Log Functionality improvements",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-016": {
    "title": "Bulk Upload template - Alignment of templates to inputs required.",
    "focus": "Bulk Upload template - Alignment of templates to inputs required.",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-013": {
    "title": "Clearing House agenda email ",
    "focus": "Clearing House agenda email \nAs a Finance Business Partner or Clearing House Administrator, I want to generate and send a comprehensive and accurate Clearing House agenda email, So that I can ensure all relevant stakeholders are informed about the items to be discussed and the correct people are invited to the meeting, improving efficiency and clarity of the approval process.",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-033": {
    "title": "Budget Rate Calc Refresh",
    "focus": "Budget Rate Calc Refresh",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-025": {
    "title": "NDPC Lump Sum RFC Amendment - Goods/Services Flag",
    "focus": "NDPC Lump Sum RFC Amendment - Goods/Services Flag\nAmendment to existing SAP RFC call to pass either Goods or Service flag when creating NDPC lump sum. Addition to NEO to add additional Lever drop down box for reason for LSP – based on selection this would then drive whether LSP is Goods or Service.\nAdditional lever would also need to be added into NEO reports to give visibility",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-048": {
    "title": "Payment Data integration from SAP ECC",
    "focus": "Payment Data integration from SAP ECC",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-039": {
    "title": "Currency only resource - calculate starting price based on FX rates.",
    "focus": "Currency only resource - calculate starting price based on FX rates.",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-074": {
    "title": "Reconcile NEO and Tableau performance",
    "focus": "Align NEO & Finance Tableau Reporting volumes\nNEO performance values are based on forecast volumes, while Finance/Tableau uses actual JLR volumes. Need alignment or visibility of both forecast and actual values.",
    "dependency": "Review the source and dependency assessment. External contracts and business acceptance are not confirmed."
  },
  "NEO-035": {
    "title": "Embed ex works and £pu reporting within system",
    "focus": "Embed ex works and £pu reporting within system\nAllow users to see an ex works average car £pu within the ID screens in NEO; and include this as part of the NEO exports for inclusion in ex works. ",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-038": {
    "title": "Simplify and commonise likeihood / maturity language & classification used across NEO with other Finance proce",
    "focus": "Simplify and commonise likeihood / maturity language & classification used across NEO with other Finance process/applications. ",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-059": {
    "title": "Inclusion of both +vs/-ve price changes into single POA",
    "focus": "Inclusion of both +vs/-ve price changes into single POA",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-061": {
    "title": "Future-year opportunity without dummy parts",
    "focus": "Future Year Productivity Opportunity Creation",
    "dependency": "Review the source and dependency assessment. External contracts and business acceptance are not confirmed."
  },
  "NEO-066": {
    "title": "Reporting category validation",
    "focus": "Reporting Category Validation and Assignment",
    "dependency": "Review the source and dependency assessment. External contracts and business acceptance are not confirmed."
  },
  "NEO-063": {
    "title": "Multiple vendor codes in one claim",
    "focus": "Multiple Vendor Code Support within a Single Claim",
    "dependency": "Review the source and dependency assessment. External contracts and business acceptance are not confirmed."
  },
  "NEO-075": {
    "title": "Non-BOM direct procurement claim",
    "focus": "Add line items related to Non-BOM items (such as software/lisence costs and savings) as Risk/Opps in NEO which need to be raised, tracked and paid in a method that doesn't count against purchasing performance.",
    "dependency": "Review the source and dependency assessment. External contracts and business acceptance are not confirmed."
  },
  "NEO-009": {
    "title": "RMA Integration with SAP ECC for Part Level POA transactions.",
    "focus": "RMA Integration with SAP ECC for Part Level POA transactions.",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-067": {
    "title": "Combined Mandate and Settlement decisions",
    "focus": "Where mandate and settlement approval is required from the same audience - the approvals shoud be collected/approved at the same time.",
    "dependency": "Review the source and dependency assessment. External contracts and business acceptance are not confirmed."
  },
  "NEO-006": {
    "title": "A new AutoPAM CY+1 file to view forecast impact of claims in future FY.  ",
    "focus": "A new AutoPAM CY+1 file to view forecast impact of claims in future FY.  \nForecasted view of claims in CY+1. This functionality did not exist pre-NEO. No viable data sets to support this requirement.  ",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-054": {
    "title": "FFP/FTO Accuracy",
    "focus": "FFP/FTO Accuracy",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  },
  "NEO-073": {
    "title": "Multi-year productivity agreement",
    "focus": "Support multi-year productivity agreements, as many supplier commitments extend beyond a single year.",
    "dependency": "Review the source and dependency assessment. External contracts and business acceptance are not confirmed."
  },
  "NEO-070": {
    "title": "Additional reviewers beyond DoA",
    "focus": "Include additional Ad-hoc approvers in workflows.\nEnable users to include additional users for further approvals on items beyond those required for the DoA.\nSo that approvers can add additional or more senior-level approvers when specific or exceptional cases require further review (including non-procurement users) so that feedback can be captured within NEO.",
    "dependency": "Review the source and dependency assessment. External contracts and business acceptance are not confirmed."
  },
  "NEO-036": {
    "title": "Review workflows & RACI - specifically to data issues, digitide issues, issue resoloution, payments not made e",
    "focus": "Review workflows & RACI - specifically to data issues, digitide issues, issue resoloution, payments not made etc.",
    "dependency": "See the existing assessment and the latest source delta. Priority does not establish readiness or acceptance."
  }
};
