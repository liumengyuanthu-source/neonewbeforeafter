window.REVIEW_SUMMARIES={
  "sourceSha256": "e630477932f6d12aaa106c1b91139b6168985b91d2462465678352c201e7f545",
  "solutionsZh": {
    "NEO-001": "按 Finance 提供的规则和预期结果修正 AutoPAM 年末结转公式；保持现有报告页面不变。",
    "NEO-002": "先确定替代生产计划数据源或获批的计算调整；新增接口另行评估。",
    "NEO-003": "提交前提供 SAP 起始价刷新按钮，后台读取最新价格并在完成时提醒；复用既有价格接口，先确认价格口径、精度及刷新契约。",
    "NEO-004": "按 Finance 示例修正 POA Part Detail 报表公式和输出，沿用现有页面，不增加接口。",
    "NEO-005": "提交 Settlement 前检查付款日期和供应商余额；不足时将结算安排交审批人决定。确认余额来源及查询失败处理；取消 Manual Invoice 仍是独立决定。",
    "NEO-006": "先与 ExWorks 团队确认次财年 AutoPAM 规则及可用数据；按独立项目事项评估。",
    "NEO-007": "按确认的 FTO／GR 金额口径匹配 DoA，并在 Settlement 复核已批准金额；沿用同一审批页面，规则以签署矩阵和边界案例为准。",
    "NEO-008": "按实施月汇率固定预付款的 GBP 基础，保留汇率和时间记录。例：USD 100,000 × 0.80 = GBP 80,000；剩余 50% 为 GBP 40,000，不按本月 0.72 改为 GBP 36,000。",
    "NEO-009": "先明确零件级 RMA 业务设计及 SAP ECC 接口契约；作为独立集成评估。",
    "NEO-010": "扩展现有活动及字段审计日志，记录约定的关键变更和财务影响，供有权限的用户查看。",
    "NEO-011": "使用现有交易数据和报告规则区分 Deposits／Loans；由 Finance 确认会计分类边界。",
    "NEO-012": "使用既有实施状态及发票状态，在 Reserve 报表中区分已实施但未收票的 LSP 与其他应计项。",
    "NEO-013": "在 NEO 生成 Clearing House 议程摘要，按确认的收件人规则通过既有通知渠道发送邮件。",
    "NEO-014": "根据 Clearing House 的决定和结果生成会议纪要；先确认会议关联及输出格式。",
    "NEO-015": "Prepayment 在实施前应用通常的负向 Lump Sum 计提规则，按交易开始日计提；结算并建立对应预付款资产后释放，保持 Auto-PAM 计算不受影响。",
    "NEO-016": "按交易类型拆分或精简现有上传模板，并同步调整输入校验。",
    "NEO-017": "本地完善工厂必选校验；S/4 任务路由需与 NEO-018／021 的接口及 BP／GSDB 映射一并交付。",
    "NEO-018": "为价格、需求、供应商／BP 和收货数据单独确认 SAP S/4 接口；实施依赖 S/4 就绪情况。",
    "NEO-019": "Excel 模板使用 NEO 现有工厂下拉数据，上传后由服务端校验工厂代码及描述。",
    "NEO-020": "将零件编号按文本保存和导入，保留前导零，并校验编号格式。",
    "NEO-021": "待 NEO-018 接口具备后，完善 S/4 专属工厂路由及 BP→GSDB 映射。",
    "NEO-022": "识别 Part／Plant／Supplier 重叠的审批中 Claim，提示冲突并按确认的并发及审批状态规则拦截重复提交。",
    "NEO-023": "按交易类型显示并校验 New Part Price Currency，同步调整批量上传模板；适用规则由采购确认。",
    "NEO-024": "在上传及提交时校验同一 Claim 的 Part＋Plant 组合，阻止重复行。",
    "NEO-025": "在 LSP 增加 Goods／Services 标识并传入 SAP RFC，配套调整映射和报告；先确认接口契约及责任人。",
    "NEO-026": "Claim 实施后锁定 Reporting Category，保留历史值；受控例外的操作权限需明确。",
    "NEO-027": "AMM 批量上传与 NEO-042 一并设计，先确认重量、escalator 的模板结构以及 WIPS 数量限制和 payload。",
    "NEO-028": "优化勾选、下拉及后台处理的响应；展示计算中、完成提醒和结果，完成时提供任务／邮件／通知，按实测耗时验证。",
    "NEO-029": "大批量 POA 计算转后台，显示进度和预计剩余时间；完成后提醒买家回到同一 Claim 查看结果。",
    "NEO-030": "CBSL 的价格字段只读；需要改价时退回 Buyer 修正，再按确认的处理路线继续任务。",
    "NEO-031": "将标题恢复为 Annualised value，修正为完整 12 个月的 POA 影响，并同步修正 Annual 列；移除用于解释旧计算的 tooltip。",
    "NEO-032": "在存储、上传、计算及输出中保留五位价格精度；端到端一致性需核对 SAP／Apigee／WIPS 的现有精度契约。",
    "NEO-033": "财年预算汇率变化后，按允许的重算规则刷新未批准 Claim 的 GBP 值，并保留执行日志。",
    "NEO-034": "维护 Reporting Category 与 Lever 的有效组合并做校验；当前为 Not Now，排期随优先级决定。",
    "NEO-035": "按确认的 ExWorks 公式及车辆量来源，同时展示和导出 GBP／vehicle 与 GBP millions；单独确认报告口径。",
    "NEO-036": "明确数据、付款及 Digitide 异常的处理责任和交接；作为运营职责事项维护。",
    "NEO-037": "修正 Memo 的实际汇率、过账状态及删除处理，去除重复的预付款条目；使用 Finance 确认的过账及汇率规则。",
    "NEO-038": "按确认的 Maturity／Likelihood 对照表生成 G0–G5，保留历史审计记录。",
    "NEO-039": "按确认的汇率来源、日期及舍入规则预览币种变更后的起始价；先明确供应商／币种映射。",
    "NEO-040": "精简页面和上传模板中的 Runout、Runout Date、ATP Reference 等输入；只移除已确认不用的字段，保留历史数据，币种按确认的供应商规则带出。",
    "NEO-041": "在现有 Claim／Line 结构内记录各 Lever 的影响并计算合计；先确认混合 Lever 的审批、报告及会计规则。",
    "NEO-042": "页面和上传支持每个 Part 多于 3 个 AMM escalator；允许数量及数据结构以 WIPS 的实际限制和 payload 契约为准。",
    "NEO-043": "移除或隐藏已确认不再需要的 CO₂ 等输入，简化必填和校验，保留历史记录。",
    "NEO-044": "Reserve 报告和 SAP 上传文件共用 NEO ID 粒度数据并对账；Finance 提供模板及对账案例，本项不增加直接 SAP 接口。",
    "NEO-045": "通过维护好的内部映射带出有效 Company、采购及财务编码组合；提供筛选并将配置错误交责任人修正。",
    "NEO-046": "按 Reporting Category 自动匹配 Team，并按约定拆分 Raw Materials 类别；使用 Finance 确认的会计映射和过渡规则。",
    "NEO-047": "按 NEO ID 在同一 Reserve 输出中展示所需资产负债表及损益金额；与 NEO-044 共用数据，核对科目列和总额。",
    "NEO-048": "单独评估 SAP ECC 付款导入接口及历史数据对账；按 NEO ID 匹配成功后才替代 KSB1 手工上传。",
    "NEO-049": "复用既有任务模型，由 Buyer 将合同指令交 Digitide；资料不足退回补齐，完成时登记合同编号、结果及证据。先确认交接和完成条件。",
    "NEO-050": "全部必要审批完成且 FBP 标记 Complete 后，申请状态改为 Approved，并关联保存到 Lines 和 Parent；与工作流完成状态分开。",
    "NEO-051": "增加有起止日期的 DoA 委托、级别校验、理由和审计记录；有效期及资格字段需先明确设计。",
    "NEO-052": "从新建录入页面移除 Global Commodity Lead Area，保留历史值，并检查相关映射和导出影响。",
    "NEO-053": "按确认清单精简 Inflation 类型及相关输入，保留历史类型名称和记录。",
    "NEO-054": "导入时校验 FTO／FFP 的完整性及已知错误，交数据责任人修正；源数据准确性由来源团队治理。",
    "NEO-055": "改进现有 Buyer Forecast 的筛选、Excel 列和格式；下载范围与筛选结果一致，输出样例和筛选含义需确认。",
    "NEO-056": "按签署的 DoA 矩阵和人员映射配置审批链，移除没有政策依据的额外审批，并验证金额边界。",
    "NEO-057": "在审批流程中显示未完成任务的状态和当前处理人，导出同一范围；按确认的 SLA 通过既有通知渠道提醒逾期责任人。",
    "NEO-058": "根据 WIPS／SAP／S4 的实际结果更新实施状态；异常交 CBSL 处理并保留完成证据，需先具备回执及重试契约。",
    "NEO-059": "先使用 Parent 关联多条 Lines；同一 Line 混合涨跌价或多币种须另行设计金额、DoA 及下游处理规则。",
    "NEO-060": "使用既有主数据提供有效 Part／Supplier／Plant 组合的筛选和校验；先确认字段及数据异常处理。",
    "NEO-061": "先定义无 Parts 的未来年度 Opportunity 的草稿、预测和提交规则，再确认生命周期及计算所需数据。",
    "NEO-062": "通过现有主数据接口刷新供应商显示信息，保留审批快照；确认增量更新和名称变更处理。",
    "NEO-063": "为同一 Claim 的多个供应商代码单独设计关联、分摊、审批及下游输出模型。",
    "NEO-064": "在 POA 零件列表勾选多行后确认移除，重新校验和计算并记录操作；已锁定版本仍受保护。",
    "NEO-065": "先补充 Gross Claim Value 的字段用途说明。自动计算与当前字段说明范围尚有差异，待公式、精度及适用范围确认后处理。",
    "NEO-066": "使用维护的分类规则校验或带出 Reporting Category；先确认规则及例外处理责任人。",
    "NEO-067": "合并 Mandate 和 Settlement 会改变审批证据、例外及模板；先独立确认设计，当前仍分别保留申请实例。",
    "NEO-068": "在零件选择中增加供应商、工厂、Vehicle Line 筛选及分页；先核对既有接口中的 Vehicle Line 和 commodity 字段。",
    "NEO-069": "在结果旁展示价差输入和计算依据，并标明缺失数据；使用确认的公式、输入版本和缺失处理规则。",
    "NEO-070": "复用 POC 加签流程并明确决定权限；动态加签超出现有多模板范围，当前按 Not Now 另行评估。",
    "NEO-071": "复用 Tasks、Enquiry 和活动日志与 CBSL 协作，显示负责人和进度；确认用户组权限、交接及通知规则。",
    "NEO-072": "采用后台分页、批处理和防重复提交；计算完成时提供任务／邮件及返回页面提醒，按真实数据量和响应目标验收。",
    "NEO-073": "先通过 Copy Claim 建立分年度 Claim；完整多年协议对价格期间、审批、Reserve 和实施的影响另行设计。",
    "NEO-074": "NEO／Tableau 对账需 Finance／BI 确认数据契约和刷新规则；实时比较按单独接口需求评估。",
    "NEO-075": "非 BOM 项目需单独确认分类、会计及绩效排除规则后再扩展模型。",
    "AS-IS Baseline": "保留现有 AS-IS 的功能、要求和配置；下列新需求仅描述在此基线上的变化。"
  },
  "reviewQuestions": {
    "NEO-002": {
      "en": [
        "Should NEO keep the remaining goods receipt forecast using a replacement feed, or use a Finance-approved calculation without it?",
        "If the forecast stays, which data and timing rules apply to mid-month changes and missing files? How should the result feed the Settlement-to-Mandate comparison?"
      ],
      "zh": [
        "未来收货预测要接替代数据源继续保留，还是采用 Finance 批准的不依赖该预测的计算方案？",
        "如果保留预测，月中生效或文件未到时用什么数据和时间口径？Settlement 与 Mandate 比对怎样用这个结果？"
      ]
    },
    "NEO-010": {
      "en": [
        "Which field changes should record a financial impact, and is there a materiality threshold?",
        "Which before-and-after amounts should the audit show, and how should it display missing historical values or a failed recalculation?"
      ],
      "zh": [
        "哪些字段一变就要记录财务影响？是否有金额或百分比门槛？",
        "审计应显示哪些改前和改后金额？缺历史值或重算失败时怎么显示？"
      ]
    },
    "NEO-016": {
      "en": [
        "Which transaction types need separate templates, and which Claim field determines whether to use Standard, Resource or AMM?",
        "Which columns are required for each template, and should one invalid row stop the entire upload?"
      ],
      "zh": [
        "哪些交易类型要单独的模板？根据 Claim 的哪个字段选择 Standard、Resource 或 AMM？",
        "各模板哪些列必填？有一行校验失败时，是否要拦住整批上传？"
      ]
    },
    "NEO-017": {
      "en": [
        "Which official Plant codes route to S/4, and which source and rule identify a valid order for each part?",
        "When is the Plant list fixed, and who resolves a missing or inconsistent Plant before the implementation task can be assigned?"
      ],
      "zh": [
        "哪些正式 Plant 代码走 S/4？每个零件从哪里取订单，怎样判断订单有效？",
        "在哪一步锁定 Plant 清单？缺数据或工厂对不上时，谁处理后才能分派实施任务？"
      ]
    },
    "NEO-018": {
      "en": [
        "Can the SAP team share the S/4 contracts and test data for supplier/BP, pricing, demand and GR, including BP-to-GSDB mapping by company and plant?",
        "What is the ECC-to-S/4 cutoff for each plant, and how should NEO handle returns, reversals and missing records?"
      ],
      "zh": [
        "SAP 团队能否提供供应商／BP、价格、需求和 GR 的 S/4 接口和测试数据，包括按公司和工厂的 BP 与 GSDB 对应关系？",
        "各工厂从 ECC 切到 S/4 的时间是什么？退货、冲销和缺记录怎样处理？"
      ]
    },
    "NEO-021": {
      "en": [
        "Which event releases the S/4 task for a POA with no WIPS step, and which team receives it?",
        "For a POA with both WIPS and S/4 plants, can routes complete separately, and what S/4 evidence confirms each plant was updated?"
      ],
      "zh": [
        "没有 WIPS 步骤的 POA 在什么事件后生成 S/4 任务？任务派给哪个团队？",
        "一笔 POA 同时有 WIPS 和 S/4 工厂时，两路能否分别完成？用什么 S/4 凭证确认各工厂已更新？"
      ]
    },
    "NEO-022": {
      "en": [
        "Is Part + Plant + Supplier enough to identify an overlap, or must company and effective dates also match?",
        "Which request states keep a part blocked, and which implementation result releases it?",
        "If the first claim changes the starting price, what price and amount changes send the second claim back for approval?"
      ],
      "zh": [
        "用零件＋工厂＋供应商就能判定冲突吗？是否还要核对公司和生效日期？",
        "哪些申请状态继续占用该零件？收到什么实施结果后才放行？",
        "前一笔改变起始价后，后一笔的价格或金额发生什么变化时需要重审？"
      ]
    },
    "NEO-023": {
      "en": [
        "Which existing transaction values show and require New Part Price Currency? For a Resource row in the same currency, can the old currency carry forward?",
        "Which columns does Digitide need for Standard, Resource and AMM, and does the task show them directly or supply them in a file?"
      ],
      "zh": [
        "现有交易类型中，哪些要显示并必填 New Part Price Currency？Resource 同币种行能否沿用旧币种？",
        "Standard、Resource 和 AMM 分别需要给 Digitide 哪些列？直接在任务显示还是以文件提供？"
      ]
    },
    "NEO-024": {
      "en": [
        "Does Part + Plant remain unique when model year or effective dates differ, and how are plant aliases matched?",
        "If an upload repeats a part already on the claim, how should the Buyer correct it? If removing a duplicate changes an approved amount, when is reapproval required?"
      ],
      "zh": [
        "车型年或生效日期不同时，同一个零件＋工厂是否仍只能有一条？如何识别工厂别名？",
        "上传时发现 Claim 已有该零件，Buyer 怎么纠正？去重改变已批准金额时，什么时候要重审？"
      ]
    },
    "NEO-025": {
      "en": [
        "Which NDPC Lump Sum reasons map to Goods or Services, and how is a mixed claim handled?",
        "Who can confirm or change the classification, and when does that require reapproval?",
        "Which existing SAP RFC field can carry the flag, and what mapping, validation and PO response does SAP support?"
      ],
      "zh": [
        "哪些 NDPC Lump Sum 原因对应 Goods 或 Services？同一笔同时包含两类时怎么处理？",
        "谁可以确认或更改分类？什么时候要重新审批？",
        "现有 SAP RFC 哪个字段能传该标记？SAP 支持什么映射、校验和 PO 回执？"
      ]
    },
    "NEO-028": {
      "en": [
        "Can we get a trace of a slow RPA Error task, with the part count and SAP timings, and agree the target response time for Include and Plant selection?",
        "Does Exclude apply only to the RPA retry, and what starts the next step after the Buyer saves the selection?"
      ],
      "zh": [
        "能否给一次 RPA Error 慢任务的请求记录、零件数和 SAP 耗时，并约定 Include 和选工厂的响应目标？",
        "Exclude 是否只影响这次 RPA 重试？Buyer 保存选择后，什么事件触发下一步？"
      ]
    },
    "NEO-029": {
      "en": [
        "Above how many POA rows should NEO switch to background calculation?",
        "Should Calculation Ready appear in the work queue only, or also be sent by email?"
      ],
      "zh": [
        "POA 超过多少行后，NEO 应转为后台计算？",
        "Calculation Ready 提醒只放在工作队列，还是也要发邮件？"
      ]
    },
    "NEO-031": {
      "en": [
        "Which 12-month window applies when the price effective date is in an earlier fiscal year? Can Finance provide a worked example with a mid-year Runout and the expected Annualised Impact?",
        "Should the correction apply to existing approved claims, and when would a recalculated amount require reapproval?"
      ],
      "zh": [
        "价格生效日在更早财年时，应用哪个 12 个月窗口？Finance 能否给一个年中 Runout 的案例和预期 Annualised Impact？",
        "旧的已批准 Claim 要不要重算？重算后的金额在什么情况下需要重新审批？"
      ]
    },
    "NEO-032": {
      "en": [
        "Can SAP, Apigee and WIPS show the same sample price at each step, with its currency and unit, to confirm where conversion and rounding occur?",
        "How should NEO handle values with more than five decimal places and approved claims that contain a previously truncated price?"
      ],
      "zh": [
        "SAP、Apigee 和 WIPS 能否给同一笔价格在各环节的值、币种和单位，确认在哪里换算和舍入？",
        "超过五位小数时怎么处理？旧 Claim 已经用了被截断的价格审批，后续怎么纠正？"
      ]
    },
    "NEO-048": {
      "en": [
        "Which KSB1 variant, fields and transaction key should SAP ECC supply, and how does each payment match a NEO ID?",
        "What monthly cutoff and reconciliation checks are required, and how should the import handle previously uploaded rows, reversals and late entries?"
      ],
      "zh": [
        "SAP ECC 要提供哪个 KSB1 variant、哪些字段和交易主键？付款如何关联到 NEO ID？",
        "月结需要什么截止时间和对账检查？已手工上传、已冲销和迟到的流水怎么处理？"
      ]
    },
    "NEO-050": {
      "en": [
        "If two Lines are approved and a third is rejected, what approval result should NEO store on each Line and on the Parent after FBP marks the request complete?"
      ],
      "zh": [
        "如果两条 Line 获批、一条被拒，FBP 标记 Complete 后，每条 Line 和 Parent 应分别记录什么审批结果？"
      ]
    },
    "NEO-051": {
      "en": [
        "Does a dated delegation cover one task or all current and future approvals at the delegated DoA level?",
        "Which DoA levels are eligible, who can set a delegation, and who receives unfinished approvals when it expires?"
      ],
      "zh": [
        "有起止日期的委派只作用于当前任务，还是该 DoA 级别下现有和新到的审批都适用？",
        "哪些 DoA 级别可以接手？谁能设置委派？到期后未完成的审批交回给谁？"
      ]
    },
    "NEO-052": {
      "en": [
        "Which historical views, report filters and exports still need Global Commodity Lead Area after it is removed from new Claim entry?"
      ],
      "zh": [
        "Global Commodity Lead Area 从新建 Claim 移除后，哪些历史页面、报表筛选和导出仍需保留它？"
      ]
    },
    "NEO-057": {
      "en": [
        "Which open tasks and approvals receive reminders, who receives them when a task is unassigned, and how often do reminders repeat?",
        "Which calendar and time zone drive overdue status? For Trading Division, does the first reminder run the day after creation or on the Tuesday/Thursday schedule?"
      ],
      "zh": [
        "哪些开放任务和审批需要提醒？任务未领取时提醒谁？多久提醒一次？",
        "逾期按哪个日历和时区算？Trading Division 首次提醒按任务创建次日，还是按周二／周四调度？"
      ]
    },
    "NEO-060": {
      "en": [
        "Does MCI_getPartDetails return all valid Part/Supplier/Plant combinations, including validity and S/4 coverage? What should NEO do when the lookup fails or finds no valid match?"
      ],
      "zh": [
        "MCI_getPartDetails 是否能返回完整有效的零件／供应商／工厂组合，包括有效期和 S/4 范围？查询失败或没匹配到时 NEO 怎么处理？"
      ]
    },
    "NEO-062": {
      "en": [
        "Does the supplier feed support incremental updates? Which changes, such as name or currency, can refresh live records while approved versions keep their original values?"
      ],
      "zh": [
        "供应商数据是否支持增量更新？名称、币种等变化中，哪些可刷新当前记录并保留获批版本的原值？"
      ]
    },
    "NEO-063": {
      "en": [
        "What identifies supplier codes that belong to the same supplier, and can one agreement cover different currencies?",
        "How should amounts, approvals and downstream orders be split by supplier code?"
      ],
      "zh": [
        "怎样判定多个供应商代码属于同一主体？一份协议能否包含不同币种？",
        "金额、审批和下游订单如何按供应商代码拆分？"
      ]
    },
    "NEO-064": {
      "en": [
        "In which Claim states can a Buyer remove multiple POA parts? Can all parts be removed from a returned Claim, and when must the amount be recalculated before resubmitting?"
      ],
      "zh": [
        "Buyer 在哪些 Claim 状态可以批量删除 POA 零件？退回后能不能删光，什么情况下重提之前必须重新计算？"
      ]
    },
    "NEO-067": {
      "en": [
        "Which requests can use a combined Mandate and Settlement approval, and at which point must the signed agreement already be available?"
      ],
      "zh": [
        "哪些申请允许合并 Mandate 和 Settlement 审批？已签署协议最晚要在哪一步备齐？"
      ]
    },
    "NEO-068": {
      "en": [
        "Does the existing SAP parts feed provide Vehicle Line and Commodity, and can it apply those filters before returning a page of parts?"
      ],
      "zh": [
        "现有 SAP 零件接口是否提供 Vehicle Line 和 Commodity，能否在分页返回之前按这两个字段筛选？"
      ]
    },
    "NEO-069": {
      "en": [
        "Which formula and input versions should the price-gap explanation show, and how should it distinguish a missing input from a valid zero?"
      ],
      "zh": [
        "价差说明应该展示哪条公式和哪些输入版本？缺数据和有效零值怎么区分？"
      ]
    },
    "NEO-072": {
      "en": [
        "What part count, concurrent load and response time should the large-claim test cover?",
        "What SAP batch and timeout limits apply, and which result should NEO check before retrying an uncertain submission?"
      ],
      "zh": [
        "大单测试要覆盖多少零件、多少并发，响应时间目标是多少？",
        "SAP 的批量和超时限制是什么？提交结果不明时，重试前在 NEO 应先核对什么结果？"
      ]
    },
    "NEO-074": {
      "en": [
        "Which Finance or BI dataset is authoritative for the comparison, and what refresh time, matching level and reconciliation tolerance should NEO use?"
      ],
      "zh": [
        "对账以哪套 Finance 或 BI 数据为准？刷新时间、匹配粒度和对账容差怎么定？"
      ]
    },
    "NEO-075": {
      "en": [
        "Which non-BOM items are eligible, and what Goods/Services and account mappings apply?",
        "How should a non-BOM claim be identified and excluded from the applicable performance measures?"
      ],
      "zh": [
        "哪些非 BOM 项可以建 Claim？对应的 Goods／Services 和科目映射是什么？",
        "如何标识非 BOM Claim，并从适用的绩效指标里排除？"
      ]
    }
  }
};
