'use strict';

// Review-only UC18 state. The frozen NEO shell and saved Claim remain the source of the page and result.
window.installCalculationReview = async ({ until, visible, byText }) => {
  const claimId = 'NEO-L-00006';
  const total = 8;
  const duration = 12000;
  const storageKey = 'neo-029-calculation-review-v1';
  let started = 0;
  try { started = Number(sessionStorage.getItem(storageKey)) || 0; } catch {}
  let panel;
  let renderKey = '';
  let scheduled = false;
  let timer;
  let opening = false;
  let activeCalculate;

  const isAfter = () => document.body.dataset.compareSide === 'after';
  const route = () => location.hash.slice(1).split('?')[0];
  const phase = elapsed => !started ? 'idle' : elapsed >= duration ? 'ready' : 'running';
  const calculateButton = () => byText('button','Calculate');
  const nativeClaim = () =>
    [...document.querySelectorAll('main h1, main h2')].some(h => h.textContent.includes(claimId));
  const queueLink = () => document.querySelector(`button[aria-label="Open ${claimId}"]`)
    || byText('button',claimId);

  function setCalculateBusy(busy) {
    if (activeCalculate && !busy && activeCalculate.dataset.neo029Busy) {
      activeCalculate.removeAttribute('aria-disabled');
      delete activeCalculate.dataset.neo029Busy;
    }
    activeCalculate = route() === '/calculation' ? calculateButton() : null;
    if (activeCalculate && busy && !activeCalculate.dataset.neo029Busy) {
      activeCalculate.dataset.neo029Busy = 'true';
      activeCalculate.setAttribute('aria-disabled','true');
    }
  }

  function begin() {
    if (phase(Date.now()-started)==='running') return;
    started = Date.now();
    try { sessionStorage.setItem(storageKey,String(started)); } catch {}
    refresh();
  }

  async function openResult(link) {
    if (opening) return;
    opening = true;
    link.disabled = true;
    try {
      if (route() === '/calculation') {
        location.hash = '/work-queue';
        await until(() => byText('h1,h2','Work Queue'));
      }
      if (!queueLink()) {
        const search = await until(() => document.querySelector('input[placeholder="Search Risk Opportunities"]'));
        Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(search,claimId);
        search.dispatchEvent(new Event('input',{bubbles:true}));
        (await until(() => byText('button','Search'))).click();
      }
      (await until(() => queueLink() && visible(queueLink()) && queueLink())).click();
      await until(() => route() === '/claim' && nativeClaim());
      const tab = await until(() => byText('[role=tab]','Calculations'));
      tab.click();
      await until(() => document.querySelector('section[aria-label="Claim calculations"]'));
      refresh();
      panel?.focus();
    } catch {
      const line = panel?.querySelector('p');
      if (line) {
        line.setAttribute('role','alert');
        line.textContent = `Could not open ${claimId}. Search for this Claim and open Calculations.`;
      }
      link.disabled = false;
    } finally { opening = false; }
  }

  function refresh() {
    scheduled = false;
    const elapsed = Math.max(0,Date.now()-started);
    const state = phase(elapsed);
    clearTimeout(timer);
    if (state === 'running') timer=setTimeout(refresh,Math.min(650,duration-elapsed+10));
    const page = route();
    const button=calculateButton();
    const queueHeader=byText('h1,h2','Work Queue')?.closest('header');
    const result=document.querySelector('section[aria-label="Claim calculations"]');
    const lastHeading = result && byText('h3','Calculations');
    const inResult=page==='/claim'&&nativeClaim()&&Boolean(result&&lastHeading&&result.contains(lastHeading));
    const anchor = page==='/calculation' ? button?.parentElement
      : page==='/work-queue'&&started ? queueHeader
      : inResult&&state==='ready' ? lastHeading
      : null;
    setCalculateBusy(isAfter()&&state==='running'&&page==='/calculation');
    const prior = page==='/calculation' && [...document.querySelectorAll('main h3')]
      .find(node=>node.textContent.trim()==='Buyer Forecast Calculations')?.parentElement;
    if (prior) prior.toggleAttribute('data-neo029-pending-result',isAfter()&&state==='running');
    const current = page==='/calculation' && [...document.querySelectorAll('main .ant-typography')]
      .find(node=>node.textContent.trim()==='Current');
    if (current) current.toggleAttribute('data-neo029-pending-result',isAfter()&&state==='running');
    if (!isAfter() || !anchor) {
      panel?.remove();
      panel = null;
      renderKey='';
      return;
    }
    if (!panel || panel.previousElementSibling!==anchor) {
      panel?.remove();
      panel=document.createElement('section');
      panel.className='neo029-status';
      panel.setAttribute('aria-label','Background calculation');
      panel.tabIndex=-1;
      anchor.after(panel);
      renderKey='';
    }
    const processed = state==='ready' ? total : Math.min(total-1,Math.floor(elapsed/duration*total));
    const remaining = Math.max(1,Math.ceil((duration-elapsed)/1000));
    panel.dataset.state=state;
    panel.dataset.surface=inResult?'result':page==='/work-queue'?'queue':'calculation';

    const heading = inResult ? 'Calculation ready'
      : state==='running' && page==='/calculation' ? `Calculating ${processed} of ${total} parts`
      : state==='running' ? 'Calculation in progress'
      : state==='ready' ? 'Calculation ready'
      : 'Background calculation';
    const detail = inResult ? `${total} parts processed. Review the saved result below.`
      : state==='running' && page==='/calculation' ? `About ${remaining} seconds remaining. You can leave and keep working.`
      : state==='running' ? `${claimId} · You’ll see a reminder here when it’s ready.`
      : state==='ready' ? `${claimId} · ${total} parts processed.`
      : 'You can leave this page while the calculation runs.';
    const key = `${page}/${state}`;
    if (key!==renderKey) {
      renderKey=key;
      const progress = state==='running' ? `<progress aria-label="Parts processed" value="${processed}" max="${total}"></progress>` : '';
      const action = !inResult && (state==='ready'||state==='running'&&page==='/calculation')
        ? `<button type="button">${state==='ready'?'Open calculation result':'Leave and keep working'}</button>` : '';
      panel.innerHTML=`<div class="neo029-copy"><strong role="status"></strong><p></p>${progress}</div>${action}`;
      const control=panel.querySelector('button');
      if (control) control.onclick=state==='ready' ? ()=>openResult(control) : ()=>{location.hash='/work-queue';};
    }
    const title = panel.querySelector('strong');
    const message = panel.querySelector('p');
    const meter = panel.querySelector('progress');
    if (title.textContent!==heading) title.textContent=heading;
    if (message.textContent!==detail) message.textContent=detail;
    if (meter && meter.value!==processed) meter.value=processed;
  }

  function schedule() {
    if (scheduled) return;
    scheduled=true;
    requestAnimationFrame(refresh);
  }

  await until(calculateButton);
  document.addEventListener('click',event=>{
    const button=calculateButton();
    if (!isAfter() || route()!=='/calculation' || !button || event.target.closest('button')!==button) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (!button.disabled) begin();
  },true);
  new MutationObserver(schedule).observe(document.getElementById('root'),{childList:true,subtree:true});
  window.addEventListener('hashchange',schedule);
  return refresh;
};
