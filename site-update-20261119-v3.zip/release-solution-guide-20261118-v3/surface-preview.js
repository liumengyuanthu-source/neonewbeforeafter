'use strict';

window.NEO_SURFACES = (() => {
  function renderPanel(row, side, { t, esc }) {
    const { mode, delta } = row.surfaceReview;
    const after = side === 'after';
    if (!delta || (!after && !delta.before)) return '';
    const changes = (delta.changed || []);
    const rows = after ? delta.after : delta.before;
    const columns = delta.columns || [];
    const table = rows?.length ? `<div class="table-wrap" tabindex="0" role="region" aria-label="${esc(delta.title)}"><table>
      <thead><tr>${columns.map((column, i) => `<th scope="col"${cellChange(i)}>${esc(column)}</th>`).join('')}</tr></thead>
      <tbody>${rows.map(line => `<tr>${line.map((value, i) => `<td${cellChange(i)}>${esc(value)}</td>`).join('')}</tr>`).join('')}</tbody>
    </table></div>` : '';
    function cellChange(index) {
      return after && changes.includes(index) ? ' class="surface-change"' : '';
    }
    const field = (spec, index) => {
      const label = esc(spec.label);
      const disabled = spec.readonly ? ' disabled' : '';
      const control = spec.values
        ? `<select${disabled}>${spec.values.map(value => `<option>${esc(value)}</option>`).join('')}</select>`
        : `<input type="${esc(spec.type || 'text')}" value="${esc(spec.value || '')}" placeholder="${esc(spec.placeholder || '')}"${spec.readonly ? ' readonly' : ''}>`;
      return `<label class="surface-field surface-change" data-field-index="${index}"><span>${label}</span>${control}${spec.help ? `<small>${esc(spec.help)}</small>` : ''}</label>`;
    };
    let content = after && delta.fields && delta.type !== 'repeat'
      ? `<div class="surface-fields">${delta.fields.map(field).join('')}</div>` : '';
    if (after && delta.type === 'balance') {
      content = `<div class="surface-fields">
        ${field({ label:'Balance check', values:['Insufficient balance','Sufficient balance','Check unavailable'] }, 0)}
        <div data-balance-plan>
          ${field({ label:'Agreed payment date', type:'date' }, 1)}
          ${field({ label:'Settlement route', values:['Supplier settles against the Lump Sum PO','Manual invoice · existing route'] }, 2)}
          ${field({ label:'Supplier confirmation', placeholder:'Enter evidence reference' }, 3)}
        </div>
        <p role="status" data-preview-status></p>
      </div>`;
    }
    if (after && delta.type === 'approval') {
      content = `<div class="surface-status surface-change">
        <label><input type="checkbox" data-approval-condition> ${t('全部适用审批已完成','All applicable approvals complete')}</label>
        <label><input type="checkbox" data-approval-condition> ${t('FBP 已标记 Complete','FBP marked Complete')}</label>
        <output data-approval-state aria-live="polite">In Approval</output>
      </div>`;
    }
    if (after && delta.type === 'repeat') {
      content = `<div data-repeat-rows></div><button type="button" class="surface-control surface-change" data-add-repeat>${esc(delta.add)}</button>`;
    }
    const action = after && delta.action
      ? `<button type="button" class="surface-control surface-change" data-surface-action>${esc(delta.action)}</button><p data-preview-status role="status" hidden></p>` : '';
    // The example is separate from the reference capture. It does not make a business write.
    const previewLabel = mode === 'output' ? t('输出示例','Output example') : t('改动示例','Change example');
    return `<section class="surface-delta" aria-label="${esc(delta.title)}">
      <div class="surface-delta-head"><h3>${esc(delta.title)}</h3><span>${previewLabel}</span></div>
      ${content}${table}${action}
    </section>`;
  }

  function wirePanel(root, spec, t) {
    const delta = spec.delta;
    const add = root.querySelector('[data-add-repeat]');
    if (add) {
      const rows = root.querySelector('[data-repeat-rows]');
      const append = () => {
        const number = rows.children.length + 1;
        const line = document.createElement('div');
        line.className = 'surface-fields surface-repeat-row';
        for (const field of delta.fields) {
          const label = document.createElement('label');
          label.className = 'surface-field surface-change';
          label.append(document.createTextNode(field + ' ' + number), document.createElement('input'));
          line.append(label);
        }
        rows.append(line);
        return line;
      };
      for (let index=0; index<delta.initial; index++) append();
      add.addEventListener('click', () => append().querySelector('input').focus());
    }
    const conditions = [...root.querySelectorAll('[data-approval-condition]')];
    for (const condition of conditions) {
      condition.addEventListener('change', () => {
        root.querySelector('[data-approval-state]').textContent = conditions.every(input => input.checked) ? 'Approved' : 'In Approval';
      });
    }
    const balance = root.querySelector('[data-balance-plan]');
    if (balance) {
      const choice = root.querySelector('select');
      const status = root.querySelector('[data-preview-status]');
      const update = () => {
        balance.hidden = choice.selectedIndex !== 0;
        status.textContent = [
          t('审批人可看到收款日期、方式和供应商确认。','The approver can review the payment date, route and supplier confirmation.'),
          t('审批人可查看余额检查结果。','The approver can view the balance result.'),
          t('先核实余额结果，再继续提交。','Verify the balance result before continuing.')
        ][choice.selectedIndex];
      };
      choice.addEventListener('change', update);
      update();
    }
    if (delta?.type === 'rpa') {
      const select = root.querySelector('[data-field-index="0"] select');
      const plant = root.querySelector('[data-field-index="1"] select');
      if (select && plant) {
        select.addEventListener('change', () => { plant.disabled = select.value === 'Exclude'; });
      }
    }
    const action = root.querySelector('[data-surface-action]');
    if (action) {
      action.addEventListener('click', () => {
        const output = root.querySelector('[data-preview-status]');
        output.hidden = false;
        output.textContent = spec[t('zh','en')];
      });
    }
  }

  return { renderPanel, wirePanel };
})();

