/* Review annotations only. Source pages, data and business behavior remain unchanged.
 * Targets are based on qa/HIGHLIGHT_DOM_INVENTORY.json and the current V2 solution.
 * No UI target is invented for removed fields, calculation-only unchanged screens,
 * reused handoffs or an unresolved proposal. Those changes remain in Solution.
 */
window.NEO_CHANGE_HIGHLIGHTS=(()=>{
 const rules={
  'NEO-026':{fields:['Reporting Category'],when:d=>[...d.querySelectorAll('.ant-descriptions-item-content')].some(e=>e.textContent.trim()==='Implemented')},
  'NEO-031':{sections:['Annualised value'],columns:['Annual (£mils)']},
  'NEO-008':{stats:['GBP basis at implementation','Current month Reserve · GBP'],columns:['Implementation-month rate','Current month Reserve · GBP'],buttons:['VIEW VALUATION BASIS']},
  'NEO-011':{fields:['Non-standard accounting']},
  'NEO-012':{fields:['Accrual reporting group'],columns:['Reporting group','Accrual reporting group']},
  'NEO-015':{rowIncludes:'Payment alone does not determine reserve recognition.',columns:['Revised Reserve (GBP)','Movement (GBP)','Review basis']},
  'NEO-019':{buttons:['DOWNLOAD TEMPLATE','PREVIEW PLANT DROPDOWN'],columns:['Plant code','Plant name']},
  'NEO-020':{buttons:['DOWNLOAD TEMPLATE'],columns:['Full Part Number','Prefix','Base','Suffix']},
  'NEO-023':{headers:['New Part Price Currency','New Part Price (GBP)']},
  'NEO-024':{buttons:['REVIEW DUPLICATES'],alerts:['duplicate Part / Plant combination'],cells:['Duplicate']},
  'NEO-037':{fields:['Actual rate · GBP per EUR','Amount GBP','Rate effective date','Rate source'],labels:['Posting status','Posting reference']},
  'NEO-044':{buttons:['Download package'],columns:['Journal GBP','Difference GBP','Adjustment GBP']},
  'NEO-047':{columns:['ST Prepayment GBP','LT Prepayment GBP','Loan GBP','Deposit GBP','Receivable GBP','Income statement GBP']},
  'NEO-053':{fields:['Inflation Type']},
  'NEO-055':{fields:['Financial years','Supplier code','CoC','Finance status'],buttons:['Download Excel']},
  'NEO-064':{buttons:['Remove selected parts'],selectors:['.ant-table-selection-column']},
  'NEO-003':{buttons:['Refresh starting prices from SAP','Refresh SAP starting prices','Refresh SAP prices']}
 };
 const css=`.neo-review-change{outline:2px solid #e5b700!important;outline-offset:-2px;}.neo-review-change:not(button):not(a){background-color:#fff7cc!important}.neo-review-change.ant-btn,.neo-review-change:is(button,a){box-shadow:0 0 0 3px #ffd84d!important;outline:none!important}.neo-review-change:focus-visible{outline:3px solid #1677ff!important;outline-offset:4px!important}`;
 const norm=s=>(s||'').replace(/\s+/g,' ').trim().toLowerCase();
 const match=(s,list)=>list?.some(x=>norm(x)===norm(s));
 function apply(d,id,enabled){
  d.querySelectorAll('.neo-review-change').forEach(e=>e.classList.remove('neo-review-change'));
  if(!enabled)return;
  const r=rules[id];if(!r||r.when&&!r.when(d))return;
  if(!d.getElementById('neo-review-change-style')){const s=d.createElement('style');s.id='neo-review-change-style';s.textContent=css;d.head.appendChild(s);}
  const mark=e=>{if(e&&e.getClientRects().length&&!e.closest('.review-bar,.review-context,[hidden],.ant-table-measure-row'))e.classList.add('neo-review-change');};
  d.querySelectorAll('button').forEach(e=>{if(match(e.textContent,r.buttons))mark(e);});
  d.querySelectorAll('label').forEach(e=>{if(match(e.innerText.split('\n')[0],r.fields)||match(e.querySelector('span')?.textContent,r.fields))mark(e.closest('.ant-form-item,.field')||e);});
  d.querySelectorAll('.ant-statistic-title').forEach(e=>{if(match(e.textContent,r.stats))mark(e.closest('.ant-statistic'));});
  d.querySelectorAll('h2,h3').forEach(e=>{if(match(e.textContent,r.sections))mark(e.closest('section')||e);});
  d.querySelectorAll('th').forEach(e=>{if(match(e.textContent,r.headers))mark(e);if(!match(e.textContent,r.columns))return;const table=e.closest('table'),i=[...e.parentElement.children].indexOf(e);mark(e);table.querySelectorAll('tbody tr').forEach(row=>{if(!r.rowIncludes||row.textContent.includes(r.rowIncludes))mark(row.children[i]);});});
  d.querySelectorAll('td').forEach(e=>{if(match(e.textContent,r.cells))mark(e);});
  d.querySelectorAll('.ant-descriptions-item-label').forEach(e=>{if(match(e.textContent,r.labels)){mark(e);mark(e.parentElement.querySelector('.ant-descriptions-item-content'));}});
  d.querySelectorAll('.ant-alert').forEach(e=>{if(r.alerts?.some(s=>norm(e.textContent).includes(norm(s))))mark(e);});
  r.selectors?.forEach(s=>d.querySelectorAll(s).forEach(mark));
 }
 return {rules,apply};
})();
