window.BEFORE_MAP={
  "source": "/Volumes/KIOXIA/JLR Appian/NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/dist",
  "appSha256": "3ff8bc0b158ba08f2302e7404bb6185a553088c78614051451e6b5137a26802e",
  "rows": {
    "NEO-001": {
      "key": "auto-pam",
      "related": false,
      "zh": "Before / After 共用 Auto PAM 文件列表、面包屑和每个报告旁的 i。仅修改后台结转计算规则。",
      "en": "Before and After share the Auto PAM file list, breadcrumb and report information icons. Only the backend rollover calculation rules change."
    },
    "NEO-003": {
      "key": "prices-edit",
      "related": false,
      "zh": "Before / After 共用现有 Part prices 页面。After 只增加 Refresh prices from SAP 按钮，保留批量改价、逐行编辑及全部字段。",
      "en": "Before and After share the existing Part prices page. After adds only Refresh prices from SAP; bulk adjustments, individual editing and all fields remain."
    },
    "NEO-004": {
      "key": "naf-pin-gfs",
      "related": false,
      "zh": "Before / After 共用现有 NAF Pin Report 页面。仅修正报表计算和输出数据，不增加筛选、表格或页面。",
      "en": "Before and After share the existing NAF Pin Report page. Correct report calculations and output data without adding filters, tables or pages."
    },
    "NEO-005": {
      "key": "approval-detail",
      "related": true,
      "zh": "当前 Approval Check 的上级申请详情；截图是已有 POA 申请，不冒充正向 LSP 余额检查结果。",
      "en": "The existing request detail provides the Approval Check entry. This is a POA request, not evidence of a positive-LSP balance check."
    },
    "NEO-007": {
      "key": "approval-detail",
      "related": true,
      "zh": "Before / After 保持同一审批详情页，字段、布局、按钮和交互均不变。仅调整后台 FTO／GR 金额计算及 DoA／补批判断，不新增对比区或页面。 当前 mock 记录仅用于页面对照，不证明新计算或审批规则已实现。",
      "en": "Before and After use the same approval detail page, with unchanged fields, layout, buttons and interactions. Only the FTO / GR calculation and DoA / further-approval rules change; no comparison panel or new page is added. This mock record is for UI comparison only; it does not verify the new calculation or approval rules."
    },
    "NEO-008": {
      "key": "reserve-detail",
      "related": false,
      "zh": "当前月度 Reserve 明细；用来对比预付款估值依据的呈现，不将当前总额当作新汇率规则金样。",
      "en": "Current monthly Reserve detail, for comparing how the valuation basis is presented. Existing totals are not golden cases for the proposed FX rule."
    },
    "NEO-011": {
      "key": "reserve-detail",
      "related": false,
      "zh": "当前 Reserve Claims 入口和财务明细。After 聚焦 Deposit 分类编辑与核对；不改变原有 Final 的事实。",
      "en": "Current Reserve Claims and finance detail. After focuses on Deposit classification and review; existing Final evidence is not rewritten."
    },
    "NEO-012": {
      "key": "reserve-detail",
      "related": false,
      "zh": "当前 Reserve Claims 列表。After 增加已实施 LSP 与发票证据的分组，当前数据不证明已接通发票来源。",
      "en": "Current Reserve Claims list. After adds grouping by LSP implementation and invoice evidence; the existing data does not prove an invoice integration."
    },
    "NEO-014": {
      "key": "requests",
      "related": true,
      "zh": "当前审批申请列表及 Agenda Email 入口；本次没有把它当成完整的场次会议纪要报表。",
      "en": "Current approval requests and the Agenda Email entry. This is not presented as the full meeting-session minutes report."
    },
    "NEO-015": {
      "key": "reserve-detail",
      "related": false,
      "zh": "当前 Reserve 入口及明细，用来比较实施前预付款的计提与修订交互。",
      "en": "Current Reserve entry and details, used to compare pre-implementation prepayment accrual and revision interactions."
    },
    "NEO-017": {
      "key": "bulk-upload-current",
      "related": false,
      "zh": "2026-11-16 补齐后的当前原型：CBSL → Claim Summary → Bulk Upload Parts。保留真实上传、校验、预览及确认；不是历史 Appian 截图。",
      "en": "Restored current prototype, 16 Nov 2026: CBSL → Claim Summary → Bulk Upload Parts. Actual upload, validation, preview and confirmation; not a historical Appian capture."
    },
    "NEO-018": {
      "key": "bulk-upload-current",
      "related": false,
      "zh": "2026-11-16 补齐后的当前原型：CBSL → Claim Summary → Bulk Upload Parts。保留真实上传、校验、预览及确认；不是历史 Appian 截图。",
      "en": "Restored current prototype, 16 Nov 2026: CBSL → Claim Summary → Bulk Upload Parts. Actual upload, validation, preview and confirmation; not a historical Appian capture."
    },
    "NEO-019": {
      "key": "bulk-upload-current",
      "related": false,
      "zh": "2026-11-16 补齐后的当前原型：CBSL → Claim Summary → Bulk Upload Parts。保留真实上传、校验、预览及确认；不是历史 Appian 截图。",
      "en": "Restored current prototype, 16 Nov 2026: CBSL → Claim Summary → Bulk Upload Parts. Actual upload, validation, preview and confirmation; not a historical Appian capture."
    },
    "NEO-020": {
      "key": "bulk-upload-current",
      "related": false,
      "zh": "2026-11-16 补齐后的当前原型：CBSL → Claim Summary → Bulk Upload Parts。保留真实上传、校验、预览及确认；不是历史 Appian 截图。",
      "en": "Restored current prototype, 16 Nov 2026: CBSL → Claim Summary → Bulk Upload Parts. Actual upload, validation, preview and confirmation; not a historical Appian capture."
    },
    "NEO-021": {
      "key": "s4-task",
      "related": false,
      "zh": "当前已存在 CBSL S4 Hana Task，保留真实字段和操作。After 对比跨系统分流与 BP 映射的新增要求。",
      "en": "A CBSL S4 Hana Task already exists. Its actual fields and actions are retained; After adds the cross-system routing and BP-mapping proposal."
    },
    "NEO-022": {
      "key": "prices-edit",
      "related": false,
      "zh": "当前单条 Claim 的改价页。After 关注跨 Claim 冲突和前单实施后的复核，不等同于现有批量改价。",
      "en": "Current price editing within one Claim. After addresses cross-Claim conflicts and review after a preceding implementation, which differs from bulk adjustment."
    },
    "NEO-024": {
      "key": "bulk-upload-current",
      "related": false,
      "zh": "2026-11-16 补齐后的当前原型：CBSL → Claim Summary → Bulk Upload Parts。保留真实上传、校验、预览及确认；不是历史 Appian 截图。",
      "en": "Restored current prototype, 16 Nov 2026: CBSL → Claim Summary → Bulk Upload Parts. Actual upload, validation, preview and confirmation; not a historical Appian capture."
    },
    "NEO-026": {
      "key": "implemented",
      "related": false,
      "zh": "当前 MCI-00132 已显示只读限制。After 需要逐字段核对锁定和补录例外，不能宣称 Before 完全没有锁。",
      "en": "MCI-00132 already shows a read-only restriction. After needs field-level locking and reference-completion review; Before is not presented as entirely unlocked."
    },
    "NEO-027": {
      "key": "bulk-upload-current",
      "related": false,
      "zh": "2026-11-16 补齐后的当前原型：CBSL → Claim Summary → Bulk Upload Parts。保留真实上传、校验、预览及确认；不是历史 Appian 截图。",
      "en": "Restored current prototype, 16 Nov 2026: CBSL → Claim Summary → Bulk Upload Parts. Actual upload, validation, preview and confirmation; not a historical Appian capture."
    },
    "NEO-028": {
      "key": "cbsl-tasks",
      "related": true,
      "zh": "展示当前 Tasks 列表入口；此截图不是 Buyer RPA 任务性能实测，也不证明原响应时间。",
      "en": "Current Tasks entry. This capture is not a Buyer RPA performance measurement and does not establish the reported response time."
    },
    "NEO-029": {
      "key": "core",
      "related": true,
      "zh": "当前 Update Claim 表单；未在截图中模拟真实超时。After 继续沿用已交给 POC 的任务，不启用停止的探索稿。",
      "en": "Current Update Claim form; no actual timeout is simulated in this capture. After retains the POC handoff, excluding the stopped exploration."
    },
    "NEO-030": {
      "key": "wips-task",
      "related": false,
      "zh": "当前 CBSL WIPS 处理任务及零件信息。新要求需核对批准价格、起始价例外和退回 Buyer 的边界。",
      "en": "Current CBSL WIPS task and part information. Review approved-price controls, start-price exceptions and the return-to-Buyer boundary against the proposal."
    },
    "NEO-031": {
      "key": "claim-calculation",
      "related": false,
      "zh": "当前已分列 Full Fiscal Year 与 Calendarised Impact。After 对比十二个月口径，不把现有字段当作公式已验收。",
      "en": "Full Fiscal Year and Calendarised Impact are already separated. After reviews the twelve-month basis; the existing labels do not establish formula acceptance."
    },
    "NEO-032": {
      "key": "bulk-upload-current",
      "related": false,
      "zh": "2026-11-16 补齐后的当前原型：CBSL → Claim Summary → Bulk Upload Parts。保留真实上传、校验、预览及确认；不是历史 Appian 截图。",
      "en": "Restored current prototype, 16 Nov 2026: CBSL → Claim Summary → Bulk Upload Parts. Actual upload, validation, preview and confirmation; not a historical Appian capture."
    },
    "NEO-034": {
      "key": "supplier",
      "related": false,
      "zh": "当前 Supplier Claim Details 的业务分类字段；After 增加组合兼容性方案。",
      "en": "Current business-classification fields in Supplier Claim Details. After proposes combination-compatibility controls."
    },
    "NEO-037": {
      "key": "memos",
      "related": false,
      "zh": "当前 Reserve 下的 Memos 页签。After 对比汇率、确认、过账和冲销，不能把当前确认状态解释成 SAP Posted。",
      "en": "Current Memos tab under Reserve. After distinguishes FX, confirmation, posting and reversal; confirmation is not evidence of SAP posting."
    },
    "NEO-042": {
      "key": "parts-edit",
      "related": true,
      "zh": "当前零件选择入口；本快照没有可核对的单 Part 多 escalator 编辑状态，不能称为已存在完整页面。",
      "en": "Current parts entry. This capture has no matching multi-escalator editor for one part and is not presented as an exact baseline page."
    },
    "NEO-044": {
      "key": "journal-mca",
      "related": false,
      "zh": "当前 Journal 准备入口仍有原型限制说明。After 关注 NEO ID 粒度和对账，并不证明真实 SAP 已过账。",
      "en": "The current Journal entry retains its prototype limitations. After addresses NEO-ID grain and reconciliation, not evidence of actual SAP posting."
    },
    "NEO-045": {
      "key": "lsp-confirmed",
      "related": false,
      "zh": "当前已保存的 Lump Sum 页面；样例部分财务字段为空。After 展示有效组合自动带出，空值不等于真实主数据缺失结论。",
      "en": "Current saved Lump Sum page; some sample finance fields are blank. After proposes valid combinations. Empty mock fields do not prove a production master-data gap."
    },
    "NEO-046": {
      "key": "teams",
      "related": false,
      "zh": "当前 Team Category Mapping 已有 Team、Category、Lever 和科目列。After 调整映射依据，保留现有配置事实。",
      "en": "Team Category Mapping already contains Team, Category, Lever and account columns. After changes the mapping basis while retaining this existing capability."
    },
    "NEO-047": {
      "key": "reserve-detail",
      "related": false,
      "zh": "当前 Reserve 明细及汇总；After 对比更多 BS 类别同源呈现，不能仅靠页面列数证明完整会计覆盖。",
      "en": "Current Reserve detail and totals. After proposes a shared output for more BS types; column count alone does not prove complete accounting coverage."
    },
    "NEO-049": {
      "key": "cbsl-tasks",
      "related": true,
      "zh": "当前 CBSL 任务入口；没有把 CBSL 人员或任务重命名成 Digitide，Digitide 合同任务仍是 After 方案。",
      "en": "Current CBSL task entry. CBSL actors and tasks are not relabelled as Digitide; the Digitide contract task remains an After proposal."
    },
    "NEO-050": {
      "key": "approval-detail",
      "related": false,
      "zh": "保留当前原型申请详情及状态列。050 修正状态判断：审批未齐不能显示 Awaiting implementation；审批齐且 FBP Complete 后才为 Approved。历史问题见需求表 M51，不把本截图当作该问题的复现证据。",
      "en": "Retain the current request detail and state fields. 050 corrects status logic: no Awaiting implementation while approvals remain outstanding; Approved requires all approvals plus FBP completion. The historical issue is recorded in M51, not reproduced by this capture."
    },
    "NEO-052": {
      "key": "supplier",
      "related": false,
      "zh": "当前 Supplier Claim Details 保留现有分类。After 评审是否移除 Global Commodity Lead Area，历史数据保留另行核对。",
      "en": "Current Supplier Claim Details retains existing classifications. After reviews removal of Global Commodity Lead Area and preservation of historical values."
    },
    "NEO-056": {
      "key": "approval-detail",
      "related": false,
      "zh": "当前 mock 审批路线。它可作为页面对比，不能替代签认 DoA 矩阵或证明实际金额阈值正确。",
      "en": "The current mock approval route can be compared visually; it is not a signed DoA matrix or proof of correct monetary thresholds."
    },
    "NEO-057": {
      "key": "approval-detail",
      "related": false,
      "zh": "Approval Requests → 申请详情 → Approval Flow。Before 保留当前原型的审批详情截图，After 使用用户指定的审批流程图。报告与提醒属于配套范围。",
      "en": "Approval Requests → request detail → Approval Flow. Before retains the current prototype approval-detail capture; After uses the user-selected approval-flow image. Reports and reminders are supporting scope."
    },
    "AS-IS Baseline": {
      "key": "core",
      "related": true,
      "zh": "相关建单入口，仅用于定位；一张图不能代表全部AS-IS基线。",
      "en": "Related claim entry only; one capture is not evidence of complete AS-IS parity."
    },
    "NEO-002": {
      "key": "claim-calculation",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-040": {
      "key": "bulk-upload-current",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-072": {
      "key": "parts-edit",
      "related": true,
      "zh": "本主题来自旧066；沿用028运行/完成提醒设计，但这条还覆盖大批零件和提交未知结果。",
      "en": "Current prototype reference; compare the existing page with the scoped enhancement. This is not production acceptance."
    },
    "NEO-043": {
      "key": "core",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-051": {
      "key": "approval-detail",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-058": {
      "key": "wips-task",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-060": {
      "key": "parts-edit",
      "related": true,
      "zh": "当前零件选择页可选择工厂；不能据此证明已按最新来源限制全部有效组合。",
      "en": "Current prototype reference; compare the existing page with the scoped enhancement. This is not production acceptance."
    },
    "NEO-068": {
      "key": "parts-edit",
      "related": true,
      "zh": "复用旧061的筛选方案；Before已有零件筛选，不把它写成从零新增。",
      "en": "Current prototype reference; compare the existing page with the scoped enhancement. This is not production acceptance."
    },
    "NEO-069": {
      "key": "claim-calculation",
      "related": true,
      "zh": "本主题来自旧062；Before已有计算结果和POC Insight，仍需补逐行输入及问题追溯。",
      "en": "Current prototype reference; compare the existing page with the scoped enhancement. This is not production acceptance."
    },
    "NEO-023": {
      "key": "prices-edit",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-055": {
      "key": "naf-pin-gfs",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-041": {
      "key": "supplier",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-053": {
      "key": "supplier",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-064": {
      "key": "prices-edit",
      "related": true,
      "zh": "当前价格页已有选行与逐行删除；尚不能将它等同本条批量移除控制。",
      "en": "Current prototype reference; compare the existing page with the scoped enhancement. This is not production acceptance."
    },
    "NEO-062": {
      "key": "supplier",
      "related": true,
      "zh": "现有页面显示供应商名称和代码；展示值不能证明源系统改名已同步。",
      "en": "Current prototype reference; compare the existing page with the scoped enhancement. This is not production acceptance."
    },
    "NEO-065": {
      "key": "claim-calculation",
      "related": true,
      "zh": "当前有Gross Claim及计算输出；字典字段存在不代表自动派生公式已确认。",
      "en": "Current prototype reference; compare the existing page with the scoped enhancement. This is not production acceptance."
    },
    "NEO-071": {
      "key": "cbsl-tasks",
      "related": true,
      "zh": "本主题来自旧065；已有任务和Notes不等于可随组接手的完整案例对话。",
      "en": "Current prototype reference; compare the existing page with the scoped enhancement. This is not production acceptance."
    },
    "NEO-010": {
      "key": "implemented",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-016": {
      "key": "bulk-upload-current",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-013": {
      "key": "approval-detail",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-033": {
      "key": "claim-calculation",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-025": {
      "key": "lsp-confirmed",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-048": {
      "key": "reserve-detail",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-039": {
      "key": "prices-edit",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-074": {
      "key": "claim-calculation",
      "related": true,
      "zh": "现有截图不能证明NEO和Tableau有可比同版本数据；最新需求明确预测量与实际量不同。",
      "en": "Current prototype reference; compare the existing page with the scoped enhancement. This is not production acceptance."
    },
    "NEO-035": {
      "key": "claim-calculation",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-038": {
      "key": "supplier",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-059": {
      "key": "prices-edit",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-061": {
      "key": "supplier",
      "related": true,
      "zh": "现有建单支持 Draft；尚无证据证明未来年度无 Part/FTO 的完整生命周期。",
      "en": "Current prototype reference; compare the existing page with the scoped enhancement. This is not production acceptance."
    },
    "NEO-066": {
      "key": "supplier",
      "related": true,
      "zh": "当前可选Reporting Category；不证明存在自动匹配和完整兼容性校验。",
      "en": "Current prototype reference; compare the existing page with the scoped enhancement. This is not production acceptance."
    },
    "NEO-063": {
      "key": "supplier",
      "related": true,
      "zh": "当前建单以单一Vendor为主；Parent关联多条Line不等于一个Claim支持多个Vendor。",
      "en": "Current prototype reference; compare the existing page with the scoped enhancement. This is not production acceptance."
    },
    "NEO-075": {
      "key": "lsp-confirmed",
      "related": true,
      "zh": "现有LSP表单可录金额，但不证明支持Non-BOM分类和采购绩效排除。",
      "en": "Current prototype reference; compare the existing page with the scoped enhancement. This is not production acceptance."
    },
    "NEO-009": {
      "key": "prices-edit",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-067": {
      "key": "approval-detail",
      "related": true,
      "zh": "当前Mandate与Settlement为不同请求/阶段，不能只因人员相同就视为同一批准。",
      "en": "Current prototype reference; compare the existing page with the scoped enhancement. This is not production acceptance."
    },
    "NEO-006": {
      "key": "auto-pam",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-054": {
      "key": "claim-calculation",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    },
    "NEO-073": {
      "key": "supplier",
      "related": true,
      "zh": "主题来自旧068，当前Could；旧方案逐年审批不能冒充新文要求的一次跨年交易。",
      "en": "Current prototype reference; compare the existing page with the scoped enhancement. This is not production acceptance."
    },
    "NEO-070": {
      "key": "approval-detail",
      "related": true,
      "zh": "本主题来自旧063；本轮联合优先级Not Now，保留方案但不放入Must实施范围。",
      "en": "Current prototype reference; compare the existing page with the scoped enhancement. This is not production acceptance."
    },
    "NEO-036": {
      "key": "cbsl-tasks",
      "related": true,
      "zh": "当前原型的相关入口；原方案映射和界面覆盖仍需逐项复核。",
      "en": "Related current prototype entry. The earlier assessment and page coverage still require item-level verification."
    }
  },
  "states": {
    "prices-edit": {
      "key": "prices-edit",
      "description": "Alice Morgan · existing sample Part prices; not saved",
      "route": "/parts/prices",
      "steps": [
        {
          "role": "button",
          "name": "Update Claim"
        },
        {
          "route": "/parts/prices"
        }
      ],
      "image": "../must-design-guide-20261115-v1/before-captures/prices-edit.png",
      "state": "../must-design-guide-20261115-v1/before-captures/claim-calculation.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:52:32.970Z",
      "title": {
        "zh": "Part Prices 改价",
        "en": "Part prices"
      },
      "launchRoute": "/claim"
    },
    "memos": {
      "key": "memos",
      "description": "Ben Taylor · current Reserve Memos",
      "route": "/finance/reserve?period=training-2024-06&reserveTab=memos",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/memos.png",
      "state": "../must-design-guide-20261115-v1/before-captures/memos.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:52:45.266Z",
      "title": {
        "zh": "Reserve · Memos",
        "en": "Reserve · Memos"
      },
      "launchRoute": "/finance/reserve?period=training-2024-06&reserveTab=memos"
    },
    "reserve-detail": {
      "key": "reserve-detail",
      "description": "Ben Taylor · current Reserve detail",
      "route": "/finance/reserve?period=training-2024-06",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/reserve-detail.png",
      "state": "../must-design-guide-20261115-v1/before-captures/reserve-detail.state.json",
      "recordIDs": [
        "MCI-09101",
        "MCI-09102",
        "MCI-09103",
        "MCI-09104",
        "MCI-09105",
        "MCI-09106",
        "MCI-09107",
        "MCI-09108",
        "MCI-09109",
        "MCI-09110"
      ],
      "at": "2026-11-15T03:45:24.447Z",
      "title": {
        "zh": "Reserve Claims 准备金明细",
        "en": "Reserve Claims"
      },
      "launchRoute": "/finance/reserve?period=training-2024-06"
    },
    "teams": {
      "key": "teams",
      "description": "Jack Edwards · current Teams reference configuration",
      "route": "/admin/master-data?section=teams",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/teams.png",
      "state": "../must-design-guide-20261115-v1/before-captures/teams.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:58:02.575Z",
      "title": {
        "zh": "Team Category Mapping",
        "en": "Team Category Mapping"
      },
      "launchRoute": "/admin/master-data?section=teams"
    },
    "approval-detail": {
      "key": "approval-detail",
      "description": "Ben Taylor · current request detail, REQ-3",
      "route": "/approval",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/approval-detail.png",
      "state": "../must-design-guide-20261115-v1/before-captures/approval-detail.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:52:44.048Z",
      "title": {
        "zh": "Approval Request 申请详情",
        "en": "Approval Request detail"
      },
      "launchRoute": "/approval"
    },
    "journal-mca": {
      "key": "journal-mca",
      "description": "Clara Bennett · current Journal",
      "route": "/finance/journal",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/journal-mca.png",
      "state": "../must-design-guide-20261115-v1/before-captures/journal-mca.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:52:50.365Z",
      "title": {
        "zh": "Journal",
        "en": "Journal"
      },
      "launchRoute": "/finance/journal"
    },
    "lsp-confirmed": {
      "key": "lsp-confirmed",
      "description": "Alice Morgan · saved Lump Sum record, original current form",
      "route": "/claim",
      "steps": [
        {
          "role": "tab",
          "name": "Lump Sum"
        }
      ],
      "image": "../must-design-guide-20261115-v1/before-captures/lsp-confirmed.png",
      "state": "../must-design-guide-20261115-v1/before-captures/lsp-confirmed.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:54:17.574Z",
      "title": {
        "zh": "Lump Sum 明细",
        "en": "Lump Sum details"
      },
      "launchRoute": "/claim"
    },
    "core": {
      "key": "core",
      "description": "Alice Morgan · current Update Claim Core Data; opened only, not saved",
      "route": "/claim",
      "steps": [
        {
          "role": "button",
          "name": "Update Claim"
        }
      ],
      "image": "../must-design-guide-20261115-v1/before-captures/core.png",
      "state": "../must-design-guide-20261115-v1/before-captures/claim.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:45:17.957Z",
      "title": {
        "zh": "Update Claim · Core Data",
        "en": "Update Claim · Core Data"
      },
      "launchRoute": "/claim"
    },
    "claim-calculation": {
      "key": "claim-calculation",
      "description": "Alice Morgan · saved POA calculation detail, existing part-calculation sample",
      "route": "/claim",
      "steps": [
        {
          "role": "tab",
          "name": "Calculations"
        }
      ],
      "image": "../must-design-guide-20261115-v1/before-captures/claim-calculation.png",
      "state": "../must-design-guide-20261115-v1/before-captures/claim-calculation.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:52:30.480Z",
      "title": {
        "zh": "Claim Calculations 计算结果",
        "en": "Claim Calculations"
      },
      "launchRoute": "/claim"
    },
    "requests": {
      "key": "requests",
      "description": "Ben Taylor · current Approval Requests",
      "route": "/requests",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/requests.png",
      "state": "../must-design-guide-20261115-v1/before-captures/requests.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:45:20.996Z",
      "title": {
        "zh": "Approval Requests 审批列表",
        "en": "Approval Requests"
      },
      "launchRoute": "/requests"
    },
    "parts-edit": {
      "key": "parts-edit",
      "description": "Alice Morgan · selected-parts editing for existing sample; not saved",
      "route": "/parts",
      "steps": [
        {
          "role": "button",
          "name": "Update Claim"
        },
        {
          "route": "/parts"
        }
      ],
      "image": "../must-design-guide-20261115-v1/before-captures/parts-edit.png",
      "state": "../must-design-guide-20261115-v1/before-captures/claim-calculation.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:52:31.961Z",
      "title": {
        "zh": "Select Parts 零件选择",
        "en": "Select parts"
      },
      "launchRoute": "/claim"
    },
    "auto-pam": {
      "key": "auto-pam",
      "description": "Ben Taylor · current Auto PAM Report",
      "route": "/reporting?section=auto-pam",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/auto-pam.png",
      "state": "../must-design-guide-20261115-v1/before-captures/auto-pam.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:45:21.969Z",
      "title": {
        "zh": "Auto PAM Report",
        "en": "Auto PAM Report"
      },
      "launchRoute": "/reporting?section=auto-pam"
    },
    "naf-pin-gfs": {
      "key": "naf-pin-gfs",
      "description": "Daniel Foster · current NAF Pin Report",
      "route": "/reporting?section=poa-parts",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/naf-pin-gfs.png",
      "state": "../must-design-guide-20261115-v1/before-captures/naf-pin-gfs.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:52:47.926Z",
      "title": {
        "zh": "NAF Pin Report",
        "en": "NAF Pin Report"
      },
      "launchRoute": "/reporting?section=poa-parts"
    },
    "s4-task": {
      "key": "s4-task",
      "description": "Grace Turner · current Create S4 Hana Claim task",
      "route": "/tasks",
      "steps": [
        {
          "role": "button",
          "name": "Create S4 Hana Claim MCI-00131"
        }
      ],
      "image": "../must-design-guide-20261115-v1/before-captures/s4-task.png",
      "state": "../must-design-guide-20261115-v1/before-captures/s4-task.state.json",
      "recordIDs": [
        "MCI-00131"
      ],
      "at": "2026-11-15T03:54:20.263Z",
      "title": {
        "zh": "CBSL S4 Hana Task",
        "en": "CBSL S4 Hana Task"
      },
      "launchRoute": "/tasks"
    },
    "implemented": {
      "key": "implemented",
      "description": "Alice Morgan · current implemented Claim Summary",
      "route": "/claim",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/implemented.png",
      "state": "../must-design-guide-20261115-v1/before-captures/implemented.state.json",
      "recordIDs": [
        "MCI-00132"
      ],
      "at": "2026-11-15T03:52:40.978Z",
      "title": {
        "zh": "Implemented Claim 已实施单据",
        "en": "Implemented Claim"
      },
      "launchRoute": "/claim"
    },
    "cbsl-tasks": {
      "key": "cbsl-tasks",
      "description": "Grace Turner · current CBSL task list",
      "route": "/tasks",
      "steps": [],
      "image": "../must-design-guide-20261115-v1/before-captures/cbsl-tasks.png",
      "state": "../must-design-guide-20261115-v1/before-captures/cbsl-tasks.state.json",
      "recordIDs": [
        "MCI-00131",
        "MCI-00130",
        "MCI-00073",
        "MCI-00095",
        "MCI-00100",
        "MCI-00089",
        "MCI-00070",
        "MCI-00141"
      ],
      "at": "2026-11-15T03:45:27.860Z",
      "title": {
        "zh": "CBSL Tasks 任务列表",
        "en": "CBSL Tasks"
      },
      "launchRoute": "/tasks"
    },
    "wips-task": {
      "key": "wips-task",
      "description": "Grace Turner · current WIPS failure / manual task",
      "route": "/tasks",
      "steps": [
        {
          "role": "button",
          "name": "WIPS update error: Manually Create and Approve Claim MCI-00073"
        }
      ],
      "image": "../must-design-guide-20261115-v1/before-captures/wips-task.png",
      "state": "../must-design-guide-20261115-v1/before-captures/wips-task.state.json",
      "recordIDs": [
        "MCI-00073"
      ],
      "at": "2026-11-15T03:57:57.728Z",
      "title": {
        "zh": "CBSL WIPS Claim 任务",
        "en": "CBSL WIPS Claim task"
      },
      "launchRoute": "/tasks"
    },
    "supplier": {
      "key": "supplier",
      "description": "Alice Morgan · current Supplier Claim Details; opened only, not saved",
      "route": "/claim",
      "steps": [
        {
          "role": "button",
          "name": "Update Claim"
        },
        {
          "text": "Supplier Claim Details"
        }
      ],
      "image": "../must-design-guide-20261115-v1/before-captures/supplier.png",
      "state": "../must-design-guide-20261115-v1/before-captures/claim.state.json",
      "recordIDs": [],
      "at": "2026-11-15T03:45:18.870Z",
      "title": {
        "zh": "Supplier Claim Details",
        "en": "Supplier Claim Details"
      },
      "launchRoute": "/claim"
    },
    "bulk-upload-current": {
      "key": "bulk-upload-current",
      "description": "Grace Turner / CBSL · restored Bulk Upload Parts · synthetic Claim · local verification only",
      "route": "/parts/import",
      "launchRoute": "/parts/import",
      "steps": [],
      "image": "../bulk-upload-review-20261116/01-upload.png",
      "state": "",
      "recordIDs": [
        "NEO-L-00001"
      ],
      "at": "2026-11-16",
      "title": {
        "zh": "Bulk Upload Parts 批量上传",
        "en": "Bulk Upload Parts"
      },
      "build": "e9a2d592"
    }
  }
};
