# NEO Before / After — 20261118-v2

Independent bilingual design guide. Default: 23 Phase 1 enhancements. All 76 records remain accessible: 23 Phase 1 enhancements, 1 baseline, 31 Phase 2, 20 CR, 1 non-system. Yellow review annotations identify After changes. This is a design-guide publication, not business or integration acceptance.
