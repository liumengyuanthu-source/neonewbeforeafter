# NEO-030 · Restrict CBSL price changes

<!-- NEO030_AFTER_FLOW_START -->
## After 更新：Solution 与页面流程（2026-11-16）

CBSL 可继续处理 WIPS 任务，但不能修改价格；发现差异时交给 Buyer 纠正，核对批准依据后再实施。

- **价格只读**：Claim 和 RPA Error Task 中的 Start / Current Price、New Part Price、价差、百分比和币种统一受保护；批量操作及后台请求也不能绕过。
- **保留可用操作**：按任务权限保留 WIPS / ATP Reference、评论和 Raise enquiry；不能通过改 Part / Plant 间接改价。
- **明确纠错责任**：询问发送给该单关联且有权限的 Buyer。Buyer 回复原因或提出修正，原批准值和版本保留。
- **核对后继续**：价格依据未变：CBSL 核对来源后继续。价格依据改变：暂停实施，重算并完成适用的复核／重审；不能凭一句“已修好”放行。

主要改动：应用内部前后端权限、任务流转、批准版本与审计控制。不是仅把输入框置灰。限制改价本身不要求新增 SAP 接口；Check source 仍需确认现有 SAP / WIPS 回读能提供匹配字段和版本。

| 步骤 | 页面 | 操作及结果 |
|---|---|---|
| 01 | P15.7 / P15.8 · P7 / P7.5 | CBSL · Grace Turner：查看任务与批准价格。打开 WIPS 失败／手工任务，或 Claim prices。批准 Start Price 90、New Price 86 只读；来源显示 92 时提示差异，不直接覆盖任何一方。 |
| 02 | P15.7 / P15.8 · Raise enquiry | CBSL → Buyer：发起询问。点击 Raise enquiry，填写 Summary 并选择受影响的 Part，发送给 Alice Morgan。当前任务等待 Buyer 回复，CBSL 不能跳过询问继续完成。 |
| 03 | P15.10 · Buyer Enquiry | Buyer · Alice Morgan：说明原因或提出修正。Buyer 查看 90／92 的差异。仅修正来源映射时保留批准价格；若提出 Start Price 92，单独保存为拟修正值，不改写原批准 90。 |
| 04A | P15.7 / P15.8 · Check source | 价格依据未变 · CBSL：核对来源，再继续。Buyer 回复后，CBSL 点击 Check source。核对同一 Line、Part、Plant、币种、批准价格及 WIPS 关联；仍不一致或查询失败时继续等待，保留输入。 |
| 04B | 原任务 · Correction awaiting review | 价格依据改变 · Buyer／审批责任人：暂停实施，先完成复核。显示原批准值与拟修正值，禁止 CBSL 直接完成。正式实现需重算，并按已确认规则进入适用复核／重审；本交互停在 Review required，不假造已批准的路线。 |
| 05 | P15.7 / P15.8 · Mark as Complete | CBSL · Grace Turner：记录手工结果，等待批准。仅从已核对的 04A 分支继续，填写 WIPS-0042、ATP-030-1 并确认。任务 Completed，Workflow 为 Data Posted Manually - Awaiting Approval；不代表外部已批准或财务 Implemented。 |

分支：01 → 02 → 03 → 04A → 05；价格依据改变时 03 → 04B，当前独立设计停在复核等待。

页面使用既有独立设计的合成人员和数据。04B 的正式重审衔接、服务端权限、SAP / WIPS 回读均不以页面演示证明已实现。Start Price 例外未确认前，CBSL 同样只读。

[中英文页面流程与截图](NEO-030_Before_After_Flow.html) · [既有 After 交互](NEO-030_Page_Proposal.html)

Reference：S1 Requested Changes E31 / Q31；S3 Training Body1343–1355 /1624–1639；S5 页面目录；S6 当前任务源码；S19 接口目录。原问题清单、原始来源和既有测试记录继续保留。
<!-- NEO030_AFTER_FLOW_END -->

## 1. 需求原文和这次的范围

来源：RTM for Requested Changes第31行，E31、F31、K31、M31、Q31；Proc Triage384第1项，Must。[S1]

业务报告曾有Digitide／CBSL人员在WIPS RPA Error任务中误改价格，产生错误价格和审计风险。要求限制这类用户在NEO Claim和RPA Error任务中的改价能力，同时保留清楚的纠错路径，避免没有人能处理导致任务循环卡住。原文把Start Price不一致时是否仍需可编辑列为待发现事项，**没有授予CBSL改Start Price的例外**。

本轮默认：CBSL价格只读；必要时发给有权限的Buyer纠正。若修正改变已批准的商业依据，先走正式复核，不能直接覆盖旧批准值再实施。这个保守闸口是候选方案，具体重算／重审路由仍需业务确认。

本次是独立页面、分析和局部验证；不改产品／prototype／共享QA，不部署，也没有向POC另发030开发任务。029已按用户指示交现有POC方案处理，不恢复其独立设计。

## 2. 改动类型、优先级和映射

| 项目 | 评估 |
|---|---|
| 主要改动类型 | Application内部前后端：字段级权限、命令白名单、任务权限／版本核对、受控纠错与审计 |
| UX/UI only？ | 不是。只把输入框置灰，挡不住其他入口、批量修改或直接请求 |
| Integration needed？ | 权限限制本身不新增SAP/WIPS接口；纠错后的来源核对和真实结果验证需要既有SAP/Apigee、WIPS/Automation Anywhere契约 |
| 能否复用接口 | 可评估现有Part/Price读取、WIPS部署与返回接口；登记目录不能证明完整价格回读、错误码、关联ID和授权能力都已提供 [S19] |
| 新架构？ | 暂无证据需要新外部系统。优先沿用现有身份授权、应用服务、任务与重审流程；若现有内部命令不支持，补字段保护及版本检查 |
| 原优先级 / 建议 | 原文Must。建议P0控制项，业务报告涉及错误价格实施；这是建议，不是本轮重现了当前生产漏洞 |
| Epic / ACT | 主CNP-234、ACT-061 WIPS update fail — CBSL Task；关联ACT-023／025／027／037／064；Claim入口关联CNP-231、ACT-004 [S4] |
| FR | 主FR13，FR14关联手工异常；FR6保留Claim可编辑范围及Settlement锁，FR1.6是价格／Part字段来源 [S2] |
| UC | 沿用ACT-061 RPA失败与ACT-037 Buyer Enquiry；未找到签核的独立“Digitide禁改价”UC编号，以下S1–S6只是候选场景名 |
| 页面 | P15.7／P15.8既有WIPS Complete／Manual上下文；P15.10 Buyer Enquiry。P7／P7.5为Claim价格锁定覆盖范围，不宣称本候选重做整个Wizard [S5] |

RPA专用子页在现有143页目录未单列一个新编号，最终编号由页面目录负责人确认。本包用一个HTML展示相连任务状态和Claim价格只读视图，截图不等于新增6张业务页面。

同号NEO-030在Archive第33行是Actions & Enquiries，在NEO RTM第34行是Parent分组。本轮只按Requested Changes第31行，不把同号当同一个需求。[S1-ID-A、S1-ID-B]

## 3. 当前已经有什么，缺什么

当前离线WipsRpaTask.tsx已将价格作为文本渲染，可编辑的是WIPS Reference、ATP Reference和询问内容。WipsCreationTask.tsx也保留只读价格、CBSL Comments／ATP。不能据此说“当前离线CBSL页面仍能直接改价”，也不能把历史事故当本轮复现的FAIL。[S6、S7]

WipsBuyerEnquiry.tsx及creation.ts支持Buyer处理询问、维护Part数据并回复。Training第1343–1355段也说明：CBSL询问交Buyer，Buyer补Part数据／评论后返回CBSL。这个早期WIPS创建场景的可编辑能力，不能不加核对就套到已经批准Settlement的RPA实施阶段。[S3、S8–S10]

Training第1624–1639段明确：CBSL处理WIPS失败任务，可记录WIPS编号；完成后为Data Posted Manually - Awaiting Approval；取消Settlement会取消CBSL任务。第1718–1730段另有Buyer专属RPA Error任务，实际错误码仍未定。[S3]

共享QA的F1021-10、FR16-Q02以及NQA-104／106／119／122保留相关本地结果和真实接口缺口。本包不改这些历史结论。[S17]

## 4. 页面与权限方案

| 字段／动作 | CBSL／受限Digitide | 有权Buyer | 限制与依据 |
|---|---|---|---|
| Current／Start Price、New Part Price | 只读，不渲染输入框 | 仅在本人被分派的纠错任务提出修正 | 不直接改旧批准快照；Start Price例外未批准 [S1、S3] |
| Absolute Change、% Difference、Sign、币种 | 不允许写入或通过派生字段绕过 | 依现有授权规则；本候选不计算正式财务影响 | 保护全部价格路径，不只一个New Price控件 [S13、S18] |
| Part／Plant／来源及批准版本 | 不能通过换关联间接改价 | 变动须核对适用规则和批准依据 | 字典外键不是权限规则；本候选固定这些字段 [S18] |
| WIPS Reference、ATP Reference | 保留适用任务中的录入 | 本候选Buyer仅看询问与拟修正值 | 沿用当前代码；编号写入不代表外部已成功 [S6、S7] |
| Raise enquiry | 当前CBSL任务Owner可发，须写Summary并选受影响Part | 实际关联Buyer接收并回复 | 不让CBSL任意选一个人绕开原Buyer权限 |
| Buyer reply：价格未变 | 等待Buyer，回复后恢复CBSL；仍要核对来源 | 回复和相关信息保留 | 文本“已修好”不能当WIPS价格回执 |
| Buyer reply：价格变化 | 暂停实施，原批准值仍可见 | 只记录拟修正值 | 正式重算／重审／原Settlement如何处理待签认，不自动保留原批准 |
| Mark as Complete | 来源与批准依据一致、WIPS编号匹配后确认 | 不属于此Buyer任务的权限 | 仅记录手工更新，下一状态仍Awaiting Approval；不自动Implemented [S3] |

Start Price90、批准New Price86、WIPS错误源Start Price92只是合成示例。不能因为WIPS显示92，就默认WIPS正确、把NEO90改成92；也不能反过来擅改WIPS。需要先确认哪一方错、批准是基于哪份数据。

候选命令按字段白名单接收：询问只收Summary／Part keys；Buyer回复只收拟修正价格和评论；完成只收WIPS／ATP及确认。其他价格、币种、关联或批准字段一律拒绝。真实后端必须执行相同保护，不能信任浏览器声明的角色或“来源已核对”。

兼有Buyer／CBSL权限的受限人员在本候选不能靠切换页面绕过禁改价；真实Digitide成员、混合角色和例外须确认。这是保守示例，不是擅自改所有人员角色。

## 5. 六张实际页面图

均为本轮独立候选HTML的真实浏览器截图，合成人员／数据，不是现网验收或原Appian截图。

### S1 · CBSL价格只读，仍可处理询问与编号

![CBSL read-only prices](screenshots/01-cbsl-readonly-prices.png)

Grace Turner看到批准值和来源差异，价格无输入框；Raise enquiry、WIPS／ATP仍可按权限操作。

### S2 · 明确把问题发给关联Buyer

![Raise enquiry](screenshots/02-raise-buyer-enquiry.png)

Summary说明90与92的差异，Part／Plant明确；取消不建任务，提交后记录实际发起人并转给Alice Morgan。

### S3 · Buyer提出修正，原批准值保留

![Buyer proposed correction](screenshots/03-buyer-proposed-correction.png)

Buyer可提出Start Price92；这是拟修正信息，原批准90和New Price86没有被覆盖。

### S4 · 改价后暂停实施

![Changed-price review gate](screenshots/04-price-correction-hold.png)

拟修正单独可读，CBSL不能直接完成任务。正式重审的承接角色、任务和版本衔接尚未开发／验收；本候选没有假造一套已批准DoA路由。

### S5 · 价格未变，来源核对后恢复处理

![Source checked](screenshots/05-source-checked-cbsl.png)

同一合成任务先经过CBSL询问和Buyer回复，再模拟外部映射被纠正、显式Check source。确认WIPS-0042及价格匹配后才可Mark as Complete。

### S6 · 手工更新记录完成，仍等批准

![Manual update awaiting approval](screenshots/06-manual-update-awaiting-approval.png)

WIPS-0042与ATP-030-1回读正确；任务Completed，Workflow为Data Posted Manually - Awaiting Approval，Finance仍Not Implemented。没有创建或批准真实WIPS单。

## 6. 数据与操作顺序

| 场景 | 操作 | 预期 |
|---|---|---|
| 主价格纠错 | Grace发询问→外部评审工具切Alice→Start Price提出92→Submit response | 只记录Proposal；原Claim／批准值90不动；实施Hold |
| 未改价的完整本地链 | Grace发询问→Alice只回复映射问题、价格不变→切回Grace→Check source仍Mismatch | 不允许完成，不能只凭Buyer文字放行 |
| 来源纠正后继续 | 外部评审工具Simulate corrected source mapping→再次Check source→录WIPS-0042／ATP-030-1→确认完成 | 同一TASK-030内核对与回读；只到Awaiting Approval，不到Implemented |
| 来源不可用／错误关联 | Source result unavailable／belongs to another Claim | 不确认匹配、不实施；保留已输入编号，重试不丢失 |
| 角色与状态 | 另一CBSL、混合受限角色、取消Settlement、Owner／Revision变更 | 禁止越权或陈旧命令，保留可恢复输入 |
| 结果未知 | 询问已提交但结果未收到→Check enquiry result | 查原intent，不再建第二条询问；读不到继续保持Unknown |

外部灰色评审工具的“切用户”和“模拟纠正来源”只推动合成场景；不是生产CBSL的远程改价能力，也不是身份认证。正常业务页没有这些生产权限。

## 7. 系统、接口与实施影响

| 层次 | 该做什么 | 证据与未决 |
|---|---|---|
| 前端 | CBSL Claim／RPA／快捷编辑／批量入口统一不展示价格编辑；保留授权的询问／编号，明确谁接下一步 | 当前两类CBSL任务已有只读价格，可复用；不要重做旧截图样式 |
| 应用后端 | 依真实身份和任务上下文检查字段白名单，复核Owner／Assignment／Claim及Approval版本，原子保存和幂等回读 | 当前源码可追踪，但真实服务防绕过未执行 [S6–S14] |
| 数据库 | 原批准值与拟修正值、审计及实际操作者分别存；原审批快照不能被重写 | 字典有Claim-Part字段，不足以定义新纠错对象、权限或最终payload [S18] |
| 流程／BPM | 询问交实际Buyer；回复后恢复原任务。价格依据改变先进入已确认复核路线；不要自动实施或错误取消原批准 | 价格变化后的正式路由、版本关系仍需业务签认；本候选只Hold |
| SAP / Apigee | 现有MCI_getPartDetails、MCI_getPartPriceDetails可评估复用来核对来源 | CSV第7／8行是目录，不是完整授权、精度、来源版本和回读契约 [S19] |
| WIPS / Automation Anywhere | 保持原MCI_raiseWIPSClaim与MCI AA WIPS Response边界；核对原单和价格结果，不重复建单 | CSV第18／22行不能证明已具备本轮全部验证字段；不得编造新endpoint [S19] |
| 外部WIPS权限 | NEO禁改价不能自动限制人在外部WIPS界面的权限 | 若要端到端管控，需外部系统Owner确认职责分离，不在本包擅改WIPS配置 |

开发前先核对当前分支和原型，只对实际缺口做小范围差异；不要把已经只读的页面当成要重建。Claim常规编辑、Buyer早期WIPS询问和已批准Settlement的RPA纠错要分开核验，不能共享一条“谁都能改价”的快捷命令。

## 8. 实测、退出条件和未测项

85项浏览器检查和79项内存模型检查结果见PAGE_VISUAL_CHECK.json、DOMAIN_CHECK.json。覆盖命令额外字段拒绝、混合角色、改价Hold、不改价返回、来源不匹配、同记录手工完成、错误WIPS关联、取消、版本冲突、失败／未知结果、六屏宽及键盘／手机操作。

| 范围 | 当前结论 | 退出证据 |
|---|---|---|
| 独立交互和内存策略 | 仅局部执行结果见附件 | 当前HTML同版截图、Expected/Actual、原批准值不变 |
| 真实前端全入口 | NOT RUN | Claim／RPA／批量／旧链接逐一复验，不因单页只读就全局PASS |
| 实际服务、身份、DB | NOT RUN | 真角色、服务端越权／篡改请求拒绝、持久审计与回读 |
| 改价后正式重审 | NOT IMPLEMENTED in candidate / NOT RUN in product | 规则、Owner、计算／审批版本及原Settlement关系签认，实际完成受控重审 |
| 真实SAP／WIPS／RPA | NOT RUN | 同记录、同批准版本的可信回读和最终外部结果 |
| 业务验收／部署 | NOT RUN | 权限边界和例外签认、正式环境全链通过及发布授权 |

当前设计不是业务已批准的完整工作流。尤其价格变化后的正式复核尚未接通，不能因为本地Hold正确就说整个NEO-030验收完成。CSS200%单列为本地检查；原生浏览器200%未执行。

## 9. 业务问题（讲人话）

1. **哪些人属于这次限制？** 例：所有CBSL都不能改，还是仅Digitide员工？有人兼Buyer／CBSL时按哪种资格判断？请给实际Group／人员映射；本候选先从严，不给混合角色绕过。
2. **Start Price例外到底给谁？** 例：NEO90、WIPS92，是Buyer纠正NEO，还是来源团队纠正WIPS？未签认前CBSL不能改Start Price，也不能默认WIPS一定正确。
3. **哪些非价格字段必须继续能改？** 例：WIPS编号、ATP、CBSL评论可以保留，但能否换Part／Plant？换关联可能间接改变金额，须提供逐字段清单。
4. **已批准Settlement后发现价格错，怎么重审？** 例：New Price仍86，但Start Price由90改92，差额已改变。由谁发起、谁接收、原Request／Settlement是否冻结或换版？本包不自动覆盖或取消。
5. **什么时候可以判定价格“没有变”？** 例：只修附件／映射，90.00000写成90是格式变化，不应误判为改价；币种、价格依据或批准版本变化则不能忽略。请确认核对字段和容差／精度。
6. **来源核对能拿到什么？** 例：WIPS回执是否有Part、Plant、币种、起始／新价和NEO关联版本？拿不到时谁提供人工证据、由谁确认？不能让浏览器自己声明“已经匹配”。
7. **未知结果如何避免重复动作？** 例：询问已创建但页面超时，如何按原intent查询；WIPS已建单但回执丢失，又用什么关联键查原单？需真实接口契约。
8. **外部WIPS权限要不要同步限制？** 例：NEO页面禁改价，但人员仍可直接在WIPS改价，是否属于同一控制范围？需业务和WIPS系统Owner明确，不能靠NEO前端承诺。

这些问题关联已有F1021-10／FR16-Q02；本包不另建主问题台账。缺正式路由与字段契约的部分，开发时仍须标未测。

## 10. 交付和下一步

NEO-030_Page_Proposal.html；中文HTML／MD；6张实际截图；OPEN_QUESTIONS_CN.md；SOURCE_EVIDENCE.json；局部验证JSON；可编辑TSX／模型／主题快照／build／test及README；完整ZIP。没有新增Word／Excel主QA。

下一条NEO-031：修正Annualised POA impact，使其代表12个月；Requested Changes第32行，具体财务规则另行取证，不从本轮价格样例推导。

### 10.1 来源索引

本轮读取日期2026-11-13；历史事故时间、原截图拍摄日期未推定。精确原文、完整原路径及SHA见SOURCE_EVIDENCE.json；源码检查不等于产品实测，API目录不等于完整契约。

| ID | 文件 | 定位 | SHA前12位 |
|---|---|---|---|
| S1 | NEO Business Requirements (added China requirements) 1.xlsx | RTM for Requested Changes row31 (1-based) | b83b74cb3eb2 |
| S1-ID-A | NEO Business Requirements (added China requirements) 1.xlsx | RTM - Archive row33 (1-based) | b83b74cb3eb2 |
| S1-ID-B | NEO Business Requirements (added China requirements) 1.xlsx | NEO RTM row34 (1-based) | b83b74cb3eb2 |
| S2-8 | Material Cost & Inventory - BRD V3.1.docx | Table6 row8 (1-based) | 0d6aedc1538c |
| S2-14 | Material Cost & Inventory - BRD V3.1.docx | Table6 row14 (1-based) | 0d6aedc1538c |
| S2-38 | Material Cost & Inventory - BRD V3.1.docx | Table6 row38 (1-based) | 0d6aedc1538c |
| S2-39 | Material Cost & Inventory - BRD V3.1.docx | Table6 row39 (1-based) | 0d6aedc1538c |
| S3 | NEO User Training.docx | Body1343–1355 /1624–1639 /1718–1730 (1-based); Buyer correction, CBSL task, no actual bot code contract | bf942f7a70e6 |
| S4 | story_data.json | ACT004/023/025/027/037/061/064 current mapping; not Jira write | a2e47d1cde32 |
| S5 | scope.json | Existing P7/P7.5/P15.7/P15.8/P15.10/P15.19; no new business page ID | 74aae9869a99 |
| S6 | WipsRpaTask.tsx | Numbered current source lines (1-based); read-only inspection, not fresh product execution | 6c7e80ed9e85 |
| S7 | WipsCreationTask.tsx | Numbered current source lines (1-based); read-only inspection, not fresh product execution | 4484a1a1513b |
| S8 | WipsBuyerEnquiry.tsx | Numbered current source lines (1-based); read-only inspection, not fresh product execution | 507ac4ebf09a |
| S9 | creation.ts | Numbered current source lines (1-based); read-only inspection, not fresh product execution | 367c4a020e0f |
| S10 | enquiry-parts.ts | Numbered current source lines (1-based); read-only inspection, not fresh product execution | 4569f09932f0 |
| S11 | manual-wips.ts | Numbered current source lines (1-based); read-only inspection, not fresh product execution | 64e5ffc18328 |
| S12 | policy.ts | Numbered current source lines (1-based); read-only inspection, not fresh product execution | 3d3c6024ec8b |
| S13 | price-columns.ts | Numbered current source lines (1-based); read-only inspection, not fresh product execution | 6e91f232b74a |
| S14 | locks.ts | Numbered current source lines (1-based); read-only inspection, not fresh product execution | f29c970d2c72 |
| S15 | index.ts | Numbered current source lines (1-based); read-only inspection, not fresh product execution | 82b56dcd8c92 |
| S16 | personas.ts | Numbered current source lines (1-based); read-only inspection, not fresh product execution | 9c30e405c28f |
| S17 | review-data.json | FR16-Q02/F1021-10 andNQA104/106/119/122 existing scope/results retained | 8fcbf8fdf490 |
| S18 | NEO_数据字典.xlsx | 字段字典 rows681–685/814–843; Claim/Part identity and prices, not field permission or signed correction policy | 22342fd6253c |
| S19 | Integrations - 2026-11-09_0941(Sheet 1).csv | CSV physical rows7/8/18/22: parts/price APIs and WIPS deploy/callback directory, not authoritative price-verification contract | 5e40049996bb |
| S20 | NEO_UXUI_PRINCIPLES.md | Current NEO UX, unchanged theme/32-24-16 edges/leading actions | 2722dc05eae2 |
