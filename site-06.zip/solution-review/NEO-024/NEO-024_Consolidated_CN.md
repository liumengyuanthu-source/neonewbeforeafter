# NEO-024 · 同一Claim的Part／Plant重复检查

独立英文交互页，复用当前NEO theme、JLR字体和Ant Design。未改现有prototype、共享QA、Jira、数据库、BPM或线上系统。合成Line、Part、价格、人员及引用ID仅供本包审阅；保存／回读在当前页面内存中完成，刷新后重置。Incoming Parts是预置的待审数据，不是已执行的真实文件上传；当前移除的Parts Excel导入未恢复。

## 1. 原需求和证据

问题是同一NEO Line里，同一个Part在同一个Plant出现几次，下游不知道应该实施哪一个价格。不同Plant上的同一个Part必须保留，不能只按Part Number去重。

| 来源 | 原文／结论及边界 |
|---|---|
| S1：新需求工作簿 RTM for Requested Changes 第25行 | NEO-024，Procurement / POA Input；Existing functionality - Update UX / Workflow；CR-2026-1557 / 8。采购Must，财务优先级空白；Exists／Meets字段没有填，不解读成No。 |
| S1：需求 | “enforce a single line per Part & Plant Combination on any given NEO ID.” |
| S1：不合法例子 | Part A/Solihull、Part A/Solihull、Part A/Solihull，应提示／阻止。 |
| S1：合法例子 | Part A/Solihull、Part A/Halewood、Part A/CB应允许，不触发重复错误。 |
| S1：风险 | “Unclear what price should be implemented.” 新旧价格相同也仍然是重复行；不同则更不能偷偷覆盖。 |
| S2-8：BRD Table6第8行 FR1.6 | 需要保留Part／Plant层级价格，支持WIPS返回Plant细分；不同完整Part后缀也应分别保留。 |
| S2-14：FR6 | Buyer／PM／SPM须有对应Buyer Code权限；active／approved Settlement限制修改；金额变动需要理由及审计。 |
| S3：Training 518–550段 | 历史Bulk Upload由CBSL管理；只是历史入口／权限证据，不自动授权当前Buyer恢复产品上传。 |
| S1-ID-A/B：旧表同ID不同含义 | Archive第27行NEO-024是FR9.3 Ad-Hoc；NEO RTM第28行是FR1.6相关Part后缀提示，不能当作本条去重已实现证据。 |

SOURCE_EVIDENCE.json保存20条来源的完整路径、坐标、摘录与SHA。原文只说明warn or prevent，并没有给出自动选价格、override、历史清理及全部数据库约束政策。

## 2. Solution、改动类型、优先级及关联

建议当前有效Claim Part列表按“本Claim＋正式Part身份＋正式Plant身份”唯一。输入可以暂存供纠正，但有重复时不进入有效保存、计算和正式提交。发现重复后让用户明确处理，不自动取第一行／最后一行，不平均、不相加价格，也不自动覆盖已选Part。

| 项目 | 评估 |
|---|---|
| 主要改动类型 | Application前端＋后端＋数据一致性校验为主，含UXUI修改。不是UXUI only，也不需要新增外部平台。 |
| 页面控制 | 显示冲突的Part／Plant、来源行、价格；区分待加入数据内部重复、与已选Part冲突、已保存历史重复。保留不同Plant及不同完整Part后缀。 |
| Integration needed？ | 去重本身由NEO应用完成；消费SAP等既有Part／Plant参考身份。下游WIPS／CBSL应只收到已验证的唯一有效价格行。没有据此新增外部接口的必要。 |
| 与谁对接／复用 | SAP／Apigee负责真实Part／Plant身份和价格来源；NEO／将来Flowable应用负责本Claim唯一性、保存、版本及权限；WIPS／RPA／CBSL消费验证后的范围。[S14] |
| 需要补的契约 | 真实canonical ID／别名、源数据一对多粒度、当前有效行／历史修订、完整上传schema及幂等／版本。接口登记不能代替这些payload或DDL。 |
| 新架构？ | 暂不建议新平台。优先统一校验服务、事务边界与适用的数据库唯一约束；具体SQL／软删除／历史表设计需正式schema确认。 |
| Priority | 原采购Must；建议P0，避免重复实施／错误价格。正式排期仍需与团队确认，不自称已批准。 |
| Epic | CNP-231 Claims and data；CNP-234下游实施关联回归。没有写Jira。 |
| ACT | ACT-001 Create Claim、ACT-004 Update Claim、ACT-026 Bulk Upload Parts；关联ACT-027 Create WIPS Claim。[S5] |
| FR | 直接FR1.6、FR6；关联FR9／FR13及Part reference。FR6.1是Lump Sum，不把所有POA编辑误写为FR6.1。 |
| 页面 | P2.6 Parts Data；P6.5 Parts详情；P7.5 Update — Parts。P7.5.1 Upload Parts Data保留历史编号但未恢复入口。[S13] |
| UC | D024-UC01–10为本轮评审场景，待纳入正式UC；不是虚构已签收的原UC编号。 |

与NEO-022不同：022处理不同Claim之间的审批／实施并行；024处理同一Claim内部重复。不能把024做成全系统禁止同Part／Plant出现在其他Forecast Claim。

## 3. 现有能力、差异及复用方式

| 当前代码／资料 | 对本条意味着什么 |
|---|---|
| S6：selection.ts 第3行 occurrenceKey | 当前键含Vendor、Company、Plant、Part、Vehicle Line、Model Year及SourceVersion；其粒度是来源occurrence，不能直接代表Claim内唯一价格行。 |
| S6：selectOccurrences | selectedIds用Set，能防同一个occurrenceId重复选择；不能证明不同occurrenceId但同Part／Plant必然被拦住。 |
| S8：stageImport | 已有seen occurrenceKey、来源版本、歧义及价格校验。不能说“完全没有校验”；本条需要明确更窄的业务键并与已有已选行一起检查。 |
| S8：applyImportBatch | 按occurrenceId合并并可替换前一批数据。本条须明确重新导入是新增、更新还是替换，不能以技术Map覆盖代替业务确认。 |
| S9：SelectParts | 已有Part到Plant映射、Select All Plants及Part variations入口。优先统一这些入口的规则，不另做一套只管文件的逻辑。 |
| S10：WIPS构造 | 会按已选Part／Plant生成payload；本条最终防线应在构造实施范围前再次校验，不能只靠前端灰按钮。 |
| S12：NQA-132/133 | 当前上传入口受阻／移除边界保留。本包用预置待审行验证设计，没有声明真实Bulk Upload通过。 |

同Part／Plant的来源数据可能对应不同车型、MY、期间或版本。应保留必要的来源／计算关系；不要为了去重就删主数据、丢Vehicle Volume或擅自汇总FTO。价格主行与关联明细如何分层需业务／数据团队确认。

## 4. 字段、主键与数据控制

| 对象／字段 | 来源 | 建议控制 |
|---|---|---|
| Claim身份 | MCI_RISK_OPPORTUNITY_PART.RISK_OPPORTUNITY_ID，第815行[S4] | 唯一性限定在当前Claim，不是Parent或Request ID。跨Claim审批控制另属022。 |
| Part身份 | PART_ID第816行，关联MCI_REF_PART | 用完整正式Part／主数据ID匹配；不去后缀、不把P03001当P3001，不按名字模糊匹配。 |
| Plant身份 | PLANT_ID第817行，关联MCI_REF_PLANT | 按正式Plant身份识别；同Plant的显示别名不能绕过去重。未知／歧义映射不猜。 |
| 价格与币种 | CURRENT_VALUE／CURRENT_VALUE_CURRENCY第818–819行，NEW_PART_PRICE／CURRENCY第825–826行 | 比较时原样并列，不能因为重复就任意选价／覆盖；不计算跨币种差额。 |
| 来源版本／车型／MY | 当前p03 occurrence模型[S6/S7] | 可以作为来源证据和计算关联；不能加入业务去重键，让同Part／Plant因版本不同就算不同价格行。 |
| 来源行／保留选择 | 本包候选审阅字段 | Incoming row2等是夹具行位置，不是新的NEO业务编号；记录保留／剔除哪些行及价格。 |
| 数据库约束 | 字典仅证明列及FK，不证明已建唯一索引 | 当前有效成员需受控唯一；历史修订仍可保留多版本。具体约束必须适配正式DB、有效标志与归档设计。 |

本包内部MAT／PLANT引用是夹具命名空间，不是正式数据库整数主键或真实接口字段值。正式系统应由后端解析权威身份，不能信任客户端上传的IDs或mapped=true。

## 5. 页面图与操作

### 5.1 先指出重复，不丢原始数据

![待加入数据内的重复Part](NEO-024_Incoming.png)

Alice Morgan打开MCI-00057。待加入P03001/H01分别为90和85 GBP，另有P03001/S01=95。页面指出1组重复，保留全部3行供比较；不能只取当前可见页，也不能先保存不重复的一部分。

### 5.2 Buyer明确选择保留哪行

![对比重复来源与价格](NEO-024_Compare.png)

Review duplicate显示来源行、价格、来源版本、Vehicle Line及MY。默认不替用户选第一行；选择Incoming row2后，Keep selected row才可操作。Cancel／Escape保留原3行。只移除本组未选的行，其他Plant不受影响。

### 5.3 不同Plant合法保留

![同Part不同Plant的两行保留](NEO-024_Reviewed.png)

处理后P03001/H01和P03001/S01继续分别存在。此时只是待审数据变化，尚未保存；View saved Parts仍读原有P03002/S01。

### 5.4 显式保存后读取完整列表

![保存后的唯一Part和Plant](NEO-024_Saved.png)

确认Save后，页内保存3条有效组合、Claim v8。P03001/H01为明确选择的90，P03001/S01为95；原P03002/S01=45不变。Activity保留去掉的来源行，不只是记录剩余行。没有执行计算、审批或外部更新。

### 5.5 已选Part不能被新行悄悄覆盖

![与已选Part冲突时保留原价](NEO-024_Existing.png)

当P03001/H01已经被选中、价格90，Incoming row2=85不能自动覆盖。此候选默认保留已选Part，且禁止把Incoming当作替换操作。若要改价，应走现有获授权的Update／改价流程，不混在Add里。

### 5.6 手工选择入口同样防重复

![选择Parts时置灰已存在组合](NEO-024_Selection.png)

Choose Parts里，本次审阅已包含的Part／Plant置灰；新增可选。示例新增Part用当前参考价作为未改价初值，不自动制造一个新的谈判价格。加入review仍不等于保存，Cancel保留原选择。

## 6. 场景、角色与数据

| UC | 用户／数据／操作 | 预期行为 |
|---|---|---|
| D024-UC01 文件／工具待审行内部重复 | Alice；默认3行，P03001/H01=90及85 → Review duplicates → Keep Incoming row2 | 只能明确保留一行；Cancel不动原数据；其他Plant保留。实际文件解析未执行。 |
| D024-UC02 与当前Claim已选行冲突 | Already in selected Parts；原90，新85 | 保留原90、丢待加入重复行；不把添加操作变为隐式改价。 |
| D024-UC03 合法多Plant／后缀 | Same Part · different Plants；Different full Part Numbers | H01/S01合法；P03001AA与P03001AB不能因同基段被合并。 |
| D024-UC04 不同来源属性 | Same identity · different attributes，来源v4/v5、MY2027/2028 | 仍为同Part／Plant重复；若选了旧／不一致来源，还须删除该待入行并从当前参考重新选择，不强改版本来“修好”。 |
| D024-UC05 历史已保存重复 | Duplicates already saved → 选保留行，填理由“Confirmed the original negotiated price is90GBP.” | review暂时剩2行，旧保存仍3行；确认Save才更新，保留剔除位置及理由。 |
| D024-UC06 跨分页 | Duplicates across pages，26行，重复在Incoming row2与row27 | 第1页只显示10行仍能发现全量重复；不允许保存。 |
| D024-UC07 手工选择 | Choose Parts → 已存在组合置灰 → P03003/H01 → Cancel或Add selection to review | Cancel不变；Add暂存1行，再确认保存；初值用原参考价，没有新价格协议。 |
| D024-UC08 来源／权限状态 | Part reference unavailable → Retry；mapping ambiguous；active Settlement | 来源未恢复／身份歧义不能保存；active Settlement不能处理重复／新增。页面权限样例不等于真实服务端权限验证。 |
| D024-UC09 保存前版本变化 | Claim changes before save，另一操作先加入P03001/S01 | 第一次保存拒绝、保留2条Incoming；Review latest Parts后发现新重复，明确保留已选，再保存v9，不覆盖新版本。 |
| D024-UC10 保存结果未知 | Save result not received → Check saved Parts | 新操作停用，先回读同一intent；找到3条、v8，不重复新增为6条；仅1条保存审计。 |

12个外部scenario是独立合成夹具，不同scenario不拼接成生产端到端证据。当前价格均GBP；Resource／币种字段规则继续衔接023，不在本条新增换汇计算。

## 7. 开发交接与影响

| 层 | 应补齐的内容 | 不能做什么 |
|---|---|---|
| 页面 | 统一Add／Select All／Part variations／待入行／现有已选行的重复提示及处理；正常同Part多Plant保留 | 只在导入时检查；悄悄取第一行、最后一行、最便宜价；按Part Number全局去重。 |
| 应用服务 | 在真实Claim与权限上下文解析canonical身份；提交完整最终集合前再次校验；保存采用版本／intent防重复 | 相信前端按钮、mapped或传入ID；先写一半后面再报错；把源版本／MY加进业务唯一键绕过规则。 |
| 数据库 | 对当前有效成员建立适用唯一性保障，并与事务／并发冲突处理配套；保留历史版本 | 仅加前端Set就宣称并发安全；未核实既有数据就直接加索引；删历史Request／Settlement证据。 |
| 数据／计算 | 统一价格主行和来源occurrence关联；纠正已保存重复后使旧计算失效，重新按正式规则核算 | 删除所有Reference明细；简单把重复FTO量相加／平均；沿用可能重复计入的旧总额。 |
| BPM／审批／实施 | 正式申请与下游handoff再检查唯一范围；已批准对象只通过受控纠正处理 | 因页面去重成功就继承旧金额／审批；直接清理已批准或真实历史单。 |
| 接口 | 复用正式Part／Plant参考和现有实施契约，输入一对多来源须明确；输出唯一当前商业行 | 自定义新SAP／WIPS写口；把RPA成功当作本Claim唯一约束已验证。 |
| 性能 | 校验完整集合后再分页；分组使用Map，可按真实规模设计批量身份解析及索引；避免逐行远程查询 | 从26行样本承诺生产吞吐或数据库锁性能。 |

实际批量文件的格式、权限、schema版本、整批回滚和错误导出应与020／023统一；当前已移除的上传路径保持不变。业务若要恢复，需要明确授权及专项开发／回归。

## 8. 验证与退出条件

88项浏览器检查和44项纯模型检查通过，逐项expected／actual在PAGE_VISUAL_CHECK.json及DOMAIN_CHECK.json。记录实际Chrome、页面及模型SHA、合成actor／record、环境和时间；未执行项不写通过。

| 范围 | 本轮结果与限制 |
|---|---|
| 页面／内存回读 | PASS：重复比较、明确选择／Cancel、已选价保护、不同Plant／后缀、手工选择、历史纠正理由、跨分页、来源失败／歧义、锁定、版本冲突／恢复、未知结果回读。 |
| 模型 | PASS：canonical Part／Plant比较、同价也重复、忽略MY／来源版本差异、防别名绕过、保留后缀／前导零、不修改原数组、整批拒绝、权限／版本／参考护栏、intent重复／冲突、不同Claim分别存储及价格边界。 |
| 布局 | PASS：1920／1440／1024／768／390／360无页面横溢，页边距32／24／16；手机对比和价格文字可达；CSS200%无横溢。原生200% NOT RUN。 |
| 文件导入／原生Excel | NOT RUN：未选文件或解析真实Excel；Incoming为预置行，也没有恢复原产品入口。 |
| 后端／DB／真实权限／并发 | NOT RUN：纯内存模型，不证明SQL唯一约束、真实持久化、两会话竞争、事务回滚或服务端身份解析。 |
| 计算／业务审批／SAP／WIPS | NOT RUN：没有真实总额重算、审批继承／重审、有效外部payload及实施回执。 |
| 商业签收／部署 | NOT RUN：硬阻断、替换方式、历史清理及特殊粒度待确认；未部署。 |

AntD lint无deprecated／a11y／usage问题，仅固定12个外部场景Select关闭virtual的performance提醒；不把它作为生产大参考列表的实现方式。

独立包退出条件：6张图可读、来源可查、关键分支有真实本地结果、数据不静默丢失／覆盖、问题明确、ZIP与源码可校验。正式开发退出还需：业务键和权限签收，全部真实入口一致校验，DB约束／并发／整批事务验证，历史数据纠正方案及计算／审批／实施整链回归。

## 9. 需要业务确认的问题（讲人话）

| 优先级 | 问题／建议 | 例子和影响 |
|---|---|---|
| P0 | 重复时仅提醒，还是禁止保存有效Part列表？建议保留待审输入，但有效保存／计算／正式申请硬阻断。 | 若只是黄色提示还能提交，RPA仍可能收到90和85两个价格。原文warn or prevent尚需签收。 |
| P0 | 同Part／Plant不同车型、MY、Company或有效期，是否仍是一条价格主行？建议先遵守本条Part／Plant唯一，再明确关联明细。 | 同H01、同Part但MY2027和2028，不能因来源多行就产生两次价格实施；特殊情况请明确分Claim还是额外明细。 |
| P0 | 已选Part被重新导入时，是加数据、更新价格，还是整批替换？建议Add不覆盖，Update走显式授权及确认。 | 原90，重传85；不能悄悄最后一行胜出，也不能误以为用户只是在补另一个Plant。 |
| P0 | 哪个Part／Plant主数据ID及别名映射是权威？ | H01与Halewood若是同Plant必须识别；未知映射不能按名称或大小写猜。 |
| P0 | 历史重复单由谁清理，哪些状态可改？建议保留原数据和审计，active／approved对象走受控纠正。 | 已批准MCI里有两行相同Part，不能为了加唯一索引就直接删一行。 |
| P0 | 清理重复后，计算、Mandate／Settlement和实施范围怎样更新？ | 如果原总额把同一Part算两次，去掉一行会影响金额和DoA；不能只改表格继续用旧批准。 |
| P1 | 完全同价的重复能否自动折叠？本候选仍要求明确确认。 | 即使两行都是90，来源证据／车型量可能不同，自动丢行可能丢关联。 |
| P1 | 真实批量文件入口和角色是否还要恢复？历史Training CBSL only，新需求以Buyer描述。 | Buyer能在Create Claim选Part，不代表可以使用已移除的Bulk上传入口。 |
| P1 | 去重时Runout、ATP Reference、原因和来源附件不同怎么办？ | 价格同但一行Runout Yes、一行No，不能只比较价格就删除。正式比较面板需包含所有会改变实施的字段。 |
| P1 | 大批量发现重复时，整批停止还是允许用户明确选择子集？建议默认整批停止。 | 100行中2行冲突，不能系统暗中只保存98行。若要部分处理，须另行确认范围及单独回执。 |

## 10. 交付物与下一步

- NEO-024_Page_Proposal.html：独立可操作英文页面，12个评审场景；没有真实文件上传。
- NEO-024_Consolidated_CN.html／.md：本文、6张实际页面截图、分类／Epic／ACT／FR／Page／UC及来源。
- OPEN_QUESTIONS_CN.md：10个讲人话的问题，含建议、例子和影响。
- SOURCE_EVIDENCE.json：20条来源，保留原始路径／位置／摘录／SHA。
- PAGE_VISUAL_CHECK.json／DOMAIN_CHECK.json／VALIDATION.json：实际本地结果与NOT RUN边界。
- design-source：可编辑React、分组／保存模型、合成夹具、原theme快照、build／test／README；不创建第二份QA台账。
- NEO-024_Review_Pack.zip：完整独立交接包；原产品及旧包不变。

下一条NEO-025是NDPC Lump Sum Goods／Services标识和相关Lever／SAP接口。本轮不自动开始。
