# NEO-025 · NDPC Lump Sum 的 Goods / Services 分类

独立设计评审包 · 2026-11-13 · 英文交互页面 / 中文分析。未修改现有 NEO prototype、产品代码、共享 QA、数据库或线上环境。

## 1. 原始需求与本次边界

**建 NDPC Lump Sum PO 前，把“买货还是买服务”判断正确；Buyer 提供原因，Finance 在批准流程中确认或改判；原因同时进入报表。** PO 创建后无法直接改分类，目前需要 Tax 手工返工。[S1]

| 核对项 | 原文及结论 |
|---|---|
| 唯一本次条目 | `NEO Business Requirements (added China requirements) 1.xlsx` → **RTM for Requested Changes，第26行**，NEO-025，CR-2026-1557 / 10。[S1] |
| 原文要求 | “Amendment to existing SAP RFC call to pass either Goods or Service flag when creating NDPC lump sum.”；另增 LSP 原因下拉及报表可见性。[S1，E26] |
| Finance 诉求 | 由 Risk/Opp 已有信息判断，或在审批阶段人工指定；详细要求由 **Paul Davies / Tax team** 提供。[S1，P26] |
| Procurement 诉求 | 自动判断，或者默认 Goods；Finance 必要时调整。这是建议，尚不是签收的默认规则。[S1，Q26] |
| 原始优先级 | Procurement **Could**；Finance **Should**；Alignment **N**。[S1，K26/L26/R26] |
| 同号冲突 | Archive 第28行的 NEO-025 是 FR9.4 DoA；NEO RTM 第29行的 NEO-025 是 FR1.6 批量百分比调价。本包未把三项混成同一需求。[S1-ID-A/B] |

**本次建议**：已有 Lever 保留；新增字段暂名 **Lump Sum Reason**；原因给出建议值，Finance 显式确认；改判或无法自动判断时填写原因。未知或混合货物/服务场景不默认 Goods。原因映射、名称和 Finance 权限都是待评审方案，非已批准 Tax 规则。

本包没有新增完整 Lump Sum 表单，也不替换已有 Material Group、Vehicle Line、Manual Invoice、组织、Company、Plant、Cost Centre、Account、Value 等字段。本页面仅展示新分类增量及必要的现有上下文。[S2-15]

## 2. 改动类型、优先级与追踪

| 分类 | 判断与影响 |
|---|---|
| UX/UI only | **否**。增加下拉、Finance 确认、只读状态及报表列；单做界面无法让 SAP PO 使用正确分类。 |
| Application 内部前后端 | **是**。保存原因、最终分类、确认人/时间/理由、依据版本；校验权限和当前版本；PO 已建或结果未知时锁定；报表读取同一保存结果。 |
| Integration needed | **是：NEO → Apigee → SAP**。原系统 Appian 发起，替换后由新应用适配器发起；SAP/Apigee 团队需确认 RFC/REST 字段和响应契约。[S14] |
| 可否复用现有接口 | 优先评估 `MCI_raiseLumpSumPO` 建 PO 接口扩展。登记样例没有 Goods/Services 字段，**不能直接宣布现有契约已支持**。`MCI_getPurchaseOrderDetails` 可作为已知 PO 编号状态读取入口；不能据此保证按 NEO ID 找回未知 PO。[S14] |
| 新增架构 | 目前没有证据要求新平台；建议扩展现有业务模型、Tax 参考映射及 PO 适配器。SAP RFC 后端是否还需改造，待契约评审。 |
| 建议排期 | **P1**，依据 Finance Should / Procurement Could。Tax 分类、Finance 权限和 SAP 契约先确认；新 NDPC 分类上线前必须满足这些前置，不能用“多数是 Goods”绕过。 |

| Epic / User Story | FR / 场景 | 影响页面（沿用现有目录） |
|---|---|---|
| Claims and data / CNP-231；ACT-001 Create Claim、ACT-004 Update Claim | FR1.2、FR6.1；D025-UC01 原因录入、D025-UC03 退回修正 | **P2.5 Lump Sum Data**、**P7.6 Update — Lump Sum**；P6.6 Lump Sum 只读展示 |
| Finance / CNP-235；ACT-006 Edit Finance Data | FR6.2；D025-UC02 确认/改判 | **P8 Update Finance Data**：具体是否放这里，或放批准任务内，需 Finance 确认；不新增正式 Page ID |
| Approvals / CNP-233；ACT-012 Submit Settlement Request、ACT-013 Approval Check、ACT-022 Manage Task | FR9.1、FR9.4、FR11；D025-UC04 当前版本/状态检查 | **P12.1 Create Settlement Request**、**P15.4 Manage Task — GFS Check**；沿用原 DoA / GFS 前置，不用分类确认代替审批 |
| 下游 PO 实施 | FR12；D025-UC05 逻辑分类准备、未知结果回读、已建 PO 锁定 | 现有实施任务/适配器；未给本增量另造已批准页面编号 |
| Finance / CNP-235；ACT-041 Finance Claim Report | FR20、FR20.1，关联 FR20.5；D025-UC06 报表/导出 | **P20 Reports — Finance Claims**；哪些其他报表应加字段待确认 |

[S5/S13] 以上 Epic、ACT、FR 和页面是复用现有资料的关联；D025-UC01～06 是本包新增的**设计场景编号**，不冒充原 BRD UC 或已写入 Jira 的需求。

## 3. 旧功能、现有实现和缺口

| 现有依据 | 能复用什么 | 尚缺什么 |
|---|---|---|
| BRD FR1.2 / FR6.1 | 原 Lever 及 LSP 明细、SAP 主数据关联。[S2-4/15] | 原 Lever 不等于新增 LSP 原因；缺 Tax 原因清单和分类规则。 |
| Training Reference data — Levers | 原 Lever 层级和“更改可能影响 Reserve，应通知 GFS”提醒。[S3] | 不能把新原因直接塞进旧 Lever 层级，造成历史报表或 Reserve 含义变化。 |
| 字典 `MCI_REF_LEVER` / Claim LEVER_ID | 既有 Lever 表及引用；LSP 公司、金额和 PO 字段。[S4] | 本次限定字段名检索未找到可确认的新原因/分类同义字段；需正式模型映射。不是断言全系统不存在任何别名。 |
| 现有 LSP 合同 / 参考数据 | 表单结构可沿用；当前检查到的参考数据注明为 synthetic offline。[S6/S7] | 在所查类型中未看到该新分类；真实主数据和权限不能从示例推导。 |
| 原 PO 表单 | ZNLO、K、Quantity 1、EA 等旧映射可复核复用。[S8/S2-37] | **Goods Receipt 是收货标识，不是 Goods / Services 分类。** 不得互相代替。 |
| 当前实施模块 | attempt、correlation、版本与不确定结果处理模式可复用。[S9] | 不证明本项已有真实 SAP 支持或幂等契约。 |
| Finance Claims 报表 | 现有报表基础结构可复用。[S10] | 所查列尚未包含本项新原因/分类；需同版本查询/导出映射。 |
| 共享 QA 已有 F1021-09、NQA-73 | 沿用 SAP PO 契约和参考数据未决事项。[S12] | 两项保持其原状态；本包没有把旧缺口改成 PASS，也未另建 QA 总表。 |

## 4. 字段、系统来源与接口

| 字段 / 数据 | 来源与责任 | 保存 / 输出建议 | 证据和缺口 |
|---|---|---|---|
| 原 Lever | NEO Claim → MCI_REF_LEVER | 保留原 LEVER_ID、层级及报表语义 | 字典248–259、706行；Training293、326、340、344–352。[S3/S4] |
| Lump Sum Reason | Buyer 选择；Tax / Paul Davies 定义选项和映射 | 新增独立原因引用及显示名/版本；物理列名待定 | 原需求 E26。暂名不是新数据库契约。[S1] |
| Suggested Goods / Services | 新应用根据已签收的 Tax 映射派生 | 建议值与最终确认分开，未知不兜底 | 目前映射未收到；包内四个原因均为合成示例。 |
| Final Goods / Services | 获授权 Finance 确认；必要时改判并解释 | 保存实际确认人、时间、理由、依据及规则版本 | Finance 要求 P26；角色级别和改判权限待定，不能从 FR6.2 自动扩权。[S1/S2-16] |
| Value / Currency / Company / Material Group 等 | 既有 LSP / SAP 参考数据 | 沿用旧字段和精度，不由分类控件改金额、科目或 VAT | 字典720–742；FR6.1 / FR12。[S4/S2-15/37] |
| SAP Goods / Services technical field | **新应用出站；Apigee / SAP 提供并签收接收契约** | 新分类映射到 RFC/REST 确切路径及代码 | 路径、Goods/Service 代码、必填条件、header/item 粒度均未收到。不得虚构 `G/S`、布尔字段或字段名。 |
| SAP PO Number / status | SAP 返回；经约定响应或回读进入 NEO | 关联原 Line、Settlement、attempt；未知先对账 | `MCI_raiseLumpSumPO` 登记 No output body；`getPurchaseOrderDetails` URL 使用 VAR_PO_NUMBER。未知 PO 编号如何找回仍缺契约。[S14] |
| 报表原因 / 分类 / 状态 | 新应用已保存的分类版本 | 保留原 Lever，加新原因及分类；CSV 示例按当前过滤结果导出 | 报表 staging 已有 LEVER2466、SAP_PO_NUMBER2522；新字段映射未收到。[S4] |

**原接口定位**：[S14] CSV 物理第16行，登记 ID10 `MCI_raiseLumpSumPO`，POST `.../material-cost-inventory-service/create-purchase-order`，Appian → SAP，Apigee。示例包含 header / item / account，但没有 Goods/Services；原拼写 `accountAssignmnetCategory` 作为来源原文保留。CSV 物理第11行，ID5 `MCI_getPurchaseOrderDetails`，GET `.../list/purchase-order-details/VAR_PO_NUMBER`。

页面“Prepare classification data”只生成内存中的逻辑分类快照，不是实际 SAP payload；未发送 HTTP，也未创建 PO。正式出站还要绑定批准的 Settlement/文件/金额版本、完整旧字段、幂等键和回执，不得只发页面上的少数字段。

## 5. 六张主要页面截图

### 5.1 Buyer 选择 LSP 原因

Alice Morgan / Buyer；MCI-00057 v7；选物理零件示例后建议 Goods。原 Lever “Supplier recovery” 保留。Save reason 前不写入当前记录。

![Buyer选择原因](NEO-025_Buyer.png)

### 5.2 Finance 明确确认或改判

Ben Taylor / FBP 合成角色；建议 Goods，实际选 Services，填写 “Invoice is for technical support only.”。未填理由不能改判。

![Finance改判](NEO-025_Finance.png)

### 5.3 保存后查看分类

本场景保存为 v8；显示 Services、Finance reviewer、原 Lever、LSP 原因及实际输入的说明。这里是同页内存回读，不是数据库持久化。

![已保存分类](NEO-025_Saved.png)

### 5.4 准备分类信息

准备的当前版本、原因、Services、Finance reviewer 与保存值一致。SAP 字段和代码未确认时明确不可创建 PO。

![分类准备](NEO-025_Prepared.png)

### 5.5 Finance 报表

三条不同 Line，原 Lever 与新增原因分列；当前 MCI-00057 为 Services，另有 Services / Unconfirmed 样例。过滤 Services 后实际导出两条，未确认记录不被伪装为 Goods。

![Finance报表](NEO-025_Report.png)

### 5.6 PO 已创建后锁定

合成 SAP PO CLM-01；禁止修改分类。需走业务确认的 Tax 修正路径，本包没有实现或假装执行该路径。

![PO创建后锁定](NEO-025_Locked.png)

附 `NEO-025_Mobile.png`：390 px 实际页面。顶部场景选择器是外部设计评审工具；每次切换重置为独立 fixture，**不是跨角色共享的端到端交易**。

## 6. 可操作场景与字面输入

| 场景 | 谁 / 数据 | 点击与输入 | 本地预期 / 结果 |
|---|---|---|---|
| D025-UC01 原因保存 | Alice Morgan / Buyer，MCI-00057 v7，1200.00000 GBP | 原因选 One-off purchase of physical parts；Save reason → No；再 Save reason → Yes | No 保留 v7；Yes 保存 v8；建议 Goods，但最终分类仍待 Finance。原 Lever 不变。 |
| D025-UC02 Finance 改判 | Ben Taylor / FBP，独立 v7 fixture，原因 physical parts | Services；先不填理由点 Confirm；再填 Invoice is for technical support only.；Confirm → Yes | 首次拒绝且不写；确认后 Services / Ben Taylor / v8；View saved classification 回读原金额和说明。 |
| 手工确认 | Ben，Other / Finance review required | Goods，空说明；再填 Physical parts purchased separately; Finance reviewed the invoice. | 无映射不默认 Goods；空说明拒绝，明确选择+理由后可确认。 |
| D025-UC03 退回修正 | Alice，已有 Goods 确认的独立 v7 | 改选 One-off technical support service；Save reason → Yes | 原确认进入历史；当前最终分类清空，重新等待 Finance。 |
| 映射缺失 / 混合范围 | Buyer missing / Finance mixed | Retry reason mapping；或选择 Combined goods and support fixture | 缺映射不保存、不默认 Goods；恢复合成数据后可用。Mixed 不提供单一确认/准备，等待 Tax 决策或拆分规则。 |
| D025-UC04 规则变化 | Ben，rule fixture | Services + Technical support confirmed by Finance.；Confirm → Yes | 首次遇 v2 拒绝，保留输入；Review latest rule → Use reviewed rule → 再确认。 |
| D025-UC04 Claim 变化 | Ben，conflict fixture | Services + Support scope checked; price version also requires review.；Confirm → Yes | 最新金额1300.00000 GBP / v8；先拒绝；Review latest Claim 后保留说明重新确认到 v9，不复用旧 DoA 结论。 |
| D025-UC05 未知 / 已建 PO | Ben，unknown / created fixture | Check original PO result；View saved classification | 回读原合成 CLM-01，不创建第二张 PO；已建状态仍锁定。不是实际 SAP 对账验证。 |
| D025-UC06 报表 | Ben，在 Finance 改判后的同场景 | Reporting；Goods / Services = Services；Export classification report | 打开 CSV，含57/58两条，不含59；Lever、LSP 原因和 Services 与保存结果一致。 |
| 不适用交易 | Other Lump Sum / POA fixture | 打开场景 | 不展示 NDPC 新分类操作；不能把规则扩到所有交易。 |

正式测试应另外覆盖：Finance 实际授权范围、全链路同一 Line/Settlement、签署文件版本、映射生效日、真正新旧规则差异、SAP 实际分类/回执、并发原子保存、金额调整后的重审、历史报表和真实 PO 修正。此包未执行这些条件。

## 7. 后续开发的具体修改范围

| 层 | 建议修改 | 验收前置 |
|---|---|---|
| 页面 | 在既有 LSP 创建/修改增加原因；只读详情显示结果；Finance 处理处确认/改判；报表增加原因和分类 | 保留最新 NEO banner、tokens、AntD 间距/控件、单标题、横向 tabs、4/2/1 字段组、前置 Actions 和表内横向滚动。不带回旧截图样式。 |
| 应用服务 / 数据库 | 原因引用、建议与最终值分离、决策审计及冻结依据；服务端权限、版本检查和 PO 状态锁定 | 正式列名/枚举/长度/迁移映射待模型评审；255 字说明仅本候选控件限制，不当作数据库已确认长度。 |
| 流程 | 分类在发送 PO 前就绪；原因/范围变更后重新核对；确认与 DoA / GFS / SAP release 分离 | 由 Finance 确认是否新增任务、在哪一步拦截、谁可改判；本包不自动增加审批路线或修改 DoA。 |
| SAP 适配器 | 优先扩展已有 PO 创建接口；新增分类映射并保留原 payload；未知先按原 correlation 回读 | SAP RFC、Apigee schema、PO ID 返回和查重规则未齐，真实发送禁用。 |
| 报告与运维 | 同版本读取/过滤/导出；原 Lever 保留；监控缺分类和接口失败 | 确认所有受影响报表及历史数据回填策略；不重写旧批准内容。 |

本包仅在本需求目录实现设计与本地测试，未编辑这些产品层文件。若后续获准开发，应在当时最新分支核对上述来源与并行改动，再做差异，不直接覆盖本轮只读查看的源文件。

## 8. 验证结果与退出条件

| 验证层 | 本轮结果 | 证据 / 限制 |
|---|---|---|
| 实际浏览器交互 | **108 项 PASS** | `PAGE_VISUAL_CHECK.json`：选择/取消/保存/回读、改判、历史失效、规则和金额版本冲突、PO 锁定/合成回读、过滤/实际 CSV 内容、手机操作、无外部 HTTP。 |
| 纯逻辑检查 | **79 项 PASS** | `DOMAIN_CHECK.json`：分类建议、权限保护、版本一致性、原因变更历史、冻结准备数据及 CSV。只验证候选内存逻辑。 |
| 响应式 | 1920/1440/1024/768/390/360 CSS px 无文档横向溢出；页面边距32/24/16；CSS 200% 检查通过 | 手机模态框、保存和报表 sticky action 已操作；**原生浏览器200% zoom NOT RUN**。 |
| 视觉检查 | 6张主要截图 + 手机图；实际打开查看 | 截图反映这份独立页面，不能充当现有产品或生产截图。 |
| Source / ZIP | 包装时重新核对原文件 SHA 与 ZIP 解压内容 | `SOURCE_EVIDENCE.json` 原始摘录；`VALIDATION.json` 文件哈希和版本边界。 |
| 正式 Tax / Finance 规则 | **NOT RUN / 未签收** | 只有合成原因映射；角色授权、最终枚举、混合范围、变更后的重审批策略待确认。 |
| 后端 / DB / BPM / 实际 SAP | **NOT RUN** | 无实际保存/权限/工作流发布或 PO；也未验证 SAP 成功、失败、超时、未知回读和真实并发。 |
| 业务验收 / 部署 | **NOT RUN** | 未上线，不把本地总检查数当完整业务验收。 |

**本设计退出条件**：源条目无混淆；已有 Lever 与新原因区分；可查看六个主页面状态；本地操作与预期相等；包可离线打开且附可编辑源码/测试/来源；未决事项列明。本轮达到的是这份独立设计包的本地检查条件。

**正式实现退出条件**：Tax 原因和分类签收；Finance 权限/修改时点明确；API 和存储映射签收；同一测试 Line/Settlement 走完当前批准版本 → GFS → SAP 创建 → 分类/PO ID/状态回读 → 报表；正常、失败、未知、重试不重建、退回修正、已建锁定均有真实证据。当前未达到。

## 9. 业务确认问题（讲人话）

| ID / 建议责任 | 需要确认什么、为什么 | 例子 / 本包暂定方案 |
|---|---|---|
| Q025-01 / Paul Davies + Tax | 到底有哪些 LSP 原因，各自判断 Goods 还是 Services？未知可否默认 Goods？ | “技术支持费”到底是不是 Services？包内采用合成映射，未知不默认 Goods。需真实清单、适用条件和生效版本。 |
| Q025-02 / Tax + Finance + Procurement | 新增的是独立 LSP 原因，还是修改现有 Lever 层级？ | 现有 Supplier recovery 同时可能包含货物或服务；不能覆盖旧 Lever，否则历史报表/Reserve 解释会变。建议独立字段。 |
| Q025-03 / Finance owner | 哪些 Finance 角色可确认或改判，放在哪一步？分类变化是否需要重新审批？ | Ben 可把 Goods 改为 Services 只是展示，不代表所有 FBP/GFS 都获授权；也不代表可绕过 DoA / GFS。 |
| Q025-04 / Tax + SAP + Procurement | 哪些 NDPC 工厂、订单类型、手工发票/应收应付路线适用？ | 同是 Lump Sum，Manual Invoice 或非 NDPC 是否应出现该字段？本包只对明确 NDPC fixture 开放。 |
| Q025-05 / Tax + SAP | 一笔同时有零件和服务，分类按 PO header、item 还是拆单？ | 1000 GBP 零件+200 GBP 支持能否发一张 PO？未收到规则，本包不猜单一标识。 |
| Q025-06 / SAP + Apigee + App team | RFC/REST 新字段的名字、层级、取值、必填、响应和校验是什么？ | 现有 create-purchase-order 样例没有分类字段，不能直接加自创 serviceFlag。请提供两类成功 payload 和拒绝样例。 |
| Q025-07 / SAP + Apigee | 如果 SAP 已建单但 NEO 没拿到编号，怎样找回？ | 不能先“再发一次”；现有 getPurchaseOrderDetails 用 PO Number，未知 Number 时需要什么 NEO ID / correlation 查询入口？ |
| Q025-08 / Tax + Finance + SAP | PO 已建后分类错误，谁负责怎样修正，结果怎样回写？ | 是 Tax 手工修正、取消重建还是其他流程？本包只锁定并告知，不伪造 Tax 修正按钮。 |
| Q025-09 / Reporting owner + Finance | 哪些报表/导出/Tableau 要增加原因、分类和确认状态？旧数据如何显示？ | Buyer Forecast Download、Finance Claims 是否都要？本包只有候选 Finance 分类 CSV，未把它等同全部现有报表。 |
| Q025-10 / Tax + Finance + App team | 映射或金额变化后，已有确认如何处理？ | v1 把某原因判 Goods，v2 改 Services；旧 PO/批准不能被新规则静默改写。建议冻结旧依据，对尚未发送的变更范围重新确认；具体规则待签收。 |

## 10. 交付物与下一项

- `NEO-025_Page_Proposal.html`：独立英文 React / AntD 页面，13个外部评审场景。
- `NEO-025_Consolidated_CN.html` / `.md`：本分析，6张嵌入图；`OPEN_QUESTIONS_CN.md`：问题清单。
- `SOURCE_EVIDENCE.json`：24条来源记录，含原文/定位/路径/SHA；未收到材料单列。
- `PAGE_VISUAL_CHECK.json` / `DOMAIN_CHECK.json`：预期、实际、PASS和执行边界；`VALIDATION.json`：本版哈希及未测层。
- `NEO-025_Filtered_Classification_Report.csv`：本轮实际过滤后导出并打开核对的合成两行数据，不是正式报告模板。
- `design-source/`：可编辑 TSX / 纯模型 / NEO theme快照 / 字体logo / build / tests / README / lint说明。
- `NEO-025_Review_Pack.zip`：完整离线包；共享 `index.html` 追加本条，不改旧条目。

下一项 **NEO-026** 是实施后 Reporting Category / 财务编码锁定的独立需求；本轮没有一并实现。

### 10.1 来源索引

本轮取证 2026-11-13；来源文档的内容日期以原件为准。API 登记 CSV 导出日期为2026-11-09，其中接口行自身记录的更新时间为2025年5月，不能把导出日期当作契约签收日期。完整路径、原文和SHA-256均在 SOURCE_EVIDENCE.json；原文件回读时间及一致性见 VALIDATION.json。

| ID | 原始文件 | 定位 | SHA-256 前12位 |
|---|---|---|---|
| S1 | NEO Business Requirements (added China requirements) 1.xlsx | RTM for Requested Changes row26 (1-based) | b83b74cb3eb2 |
| S1-ID-A | NEO Business Requirements (added China requirements) 1.xlsx | RTM - Archive row28 (1-based) | b83b74cb3eb2 |
| S1-ID-B | NEO Business Requirements (added China requirements) 1.xlsx | NEO RTM row29 (1-based) | b83b74cb3eb2 |
| S2-4 | Material Cost & Inventory - BRD V3.1.docx | Table6 row4 (1-based) | 0d6aedc1538c |
| S2-15 | Material Cost & Inventory - BRD V3.1.docx | Table6 row15 (1-based) | 0d6aedc1538c |
| S2-16 | Material Cost & Inventory - BRD V3.1.docx | Table6 row16 (1-based) | 0d6aedc1538c |
| S2-25 | Material Cost & Inventory - BRD V3.1.docx | Table6 row25 (1-based) | 0d6aedc1538c |
| S2-35 | Material Cost & Inventory - BRD V3.1.docx | Table6 row35 (1-based) | 0d6aedc1538c |
| S2-37 | Material Cost & Inventory - BRD V3.1.docx | Table6 row37 (1-based) | 0d6aedc1538c |
| S2-67 | Material Cost & Inventory - BRD V3.1.docx | Table6 row67 (1-based) | 0d6aedc1538c |
| S2-68 | Material Cost & Inventory - BRD V3.1.docx | Table6 row68 (1-based) | 0d6aedc1538c |
| S2-72 | Material Cost & Inventory - BRD V3.1.docx | Table6 row72 (1-based) | 0d6aedc1538c |
| S3 | NEO User Training.docx | Body293,326,340,344–352 and1169; existing Lever/Reserve notices and LSP route only | bf942f7a70e6 |
| S4 | NEO_数据字典.xlsx | 字段字典 rows248–259,706,720–742 and report selected fields; explicit field-name search boundary | 22342fd6253c |
| S5 | story_data.json | ACT001/004/006/012/013/022/041 existing mappings; no Jira writes | a2e47d1cde32 |
| S6 | contracts.ts | Numbered source lines (1-based); scoped inspection only | a9e7ce73f811 |
| S7 | lsp-reference.ts | Numbered source lines (1-based); scoped inspection only | bee30fa39f25 |
| S8 | manual-po-form.ts | Numbered source lines (1-based); scoped inspection only | 0dabc344e4c9 |
| S9 | implementation.ts | Numbered source lines (1-based); scoped inspection only | 9e7fd4070f2e |
| S10 | FinanceClaims.tsx | Numbered source lines (1-based); scoped inspection only | 79b419471847 |
| S11 | index.ts | Numbered source lines (1-based); scoped inspection only | 82b56dcd8c92 |
| S12 | review-data.json | Existing issueF1021-09 and NQA-73; not new feature acceptance | 8fcbf8fdf490 |
| S13 | scope.json | Existing LumpSum/Finance/Settlement/report pages | 74aae9869a99 |
| S14 | Integrations - 2026-11-09_0941(Sheet 1).csv | CSV physical rows11/16 (1-based): register IDs5 getPurchaseOrderDetails,10 raiseLumpSumPO; exact payload remains dated sample | 5e40049996bb |
