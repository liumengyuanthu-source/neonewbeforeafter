# NEO-027 · AMM Parts 批量上传单位、重量与材料信息

独立设计评审包 · 2026-11-13 · 英文交互页面 / 中文分析。未修改现有 NEO prototype、产品代码、共享 QA、数据库、流程或线上环境，也未恢复产品中已移除的通用 Parts 导入入口。

## 1. 原始要求和本次结论

**Buyer 建立 AMM Claim 时，希望一次上传零件及 AMM 参数，避免几百条数据逐行填写。** 采用独立 AMM 模板先解析、预览和校验，再明确应用；不把上传等同下游 AMM 实施。

| 核对项 | 原文 / 结论 |
|---|---|
| 本次唯一条目 | `NEO Business Requirements (added China requirements) 1.xlsx` → **RTM for Requested Changes 第28行**，NEO-027，CR-2026-1557 / 13。[S1] |
| 原始内容 E28 | “Bulk Upload Tool - AMM Field Support”；现有工具只支持加入 Part Numbers，缺少 weights/materials/measures；建议扩展现有模板或提供新模板。 |
| Buyer 需求 Q28 | 上传 parts 时一并包含 AMM escalators，不再逐项手填。[S1] |
| 原始优先级 | Procurement **Must**，Alignment **N**；不能把已登记理解为字段和公式已签收。[S1] |
| 同号差异 | Archive 第30行 NEO-027 是 FR10 Approval grid；NEO RTM 第31行 NEO-027 是 FR1.6 WIPS plant-specific prices。这两项不是本包需求。[S1-ID-A/B] |
| 现有明确字段 | 字典有 AMM_MEASURE_UNIT、AMM_TOTAL_WEIGHT、AMM_NET_WEIGHT、AMM_GROSS_WEIGHT；重量为 decimal(19,5)。[S4，848–851] |
| 尚未明确 | “Material / escalator”对应哪个实体、是否一零件多材料/多指数、AMM_LINKED_VALUE含义、单位/重量关系、计算公式和完整现行模板。不能用同名相近列猜填。[S4/S17] |

**本稿已完成的是独立设计和已知字段的本地验证。Material 字段只保留在待核对区，填入后整批禁止应用。** 这项需求的完整业务实现、材料结构及正式上传契约仍未完成。

## 2. 分类、优先级与 User Story / FR / 页面

| 改动类型 | 评估与依赖 |
|---|---|
| UX/UI only | **否**。增加模板、文件选择、行预览、逐行纠正、错误定位、整批确认和回读；不能只增加几个表格列。 |
| Application 内部前后端 | **主要改动**。独立 AMM import profile、XLSX解析、格式/字段/身份校验、权限和状态复核、精确小数保存、批次/文件/行审计、版本与不确定结果恢复。 |
| Integration needed | 核心上传来自 **Buyer 的文件**，不必凭空增加外部接口。零件身份/价格可评估复用 SAP 参考查询；若材料/指数需要来自另一个来源系统，必须先确认提供方、契约及主数据，不假定已有接口支持。 |
| 对接谁 / 能否复用 | 原 Appian 调用 SAP via Apigee 的 `MCI_getPartDetails`、`MCI_getPartPriceDetails` 可作为零件/价格查询复用候选；登记没有证明可写 AMM 重量或材料参数。[S16] |
| 新架构 | 当前证据不要求新平台。建议在现有应用内新增受控 AMM profile 和工作线程解析；服务端复用既有存储/审计。多材料/指数若是新子表结构，需模型评审，不能现在宣布完全无需改数据库。 |
| 建议优先级 | **P1**，依据 Procurement Must 和大量重复录入的业务影响。模板、材料粒度、权限和计算规则为开发/验收前置；已明确的预览和重量字段可独立推进。 |

| Epic / User Story | FR / 本包设计场景 | 页面 / 影响范围 |
|---|---|---|
| Claims and data / CNP-231；**ACT-001 Create Claim**、**ACT-004 Update Claim** | FR1.2、FR1.6、FR6；D027-UC01 AMM文件准备与选择 | **P2.6 Parts Data — create POA**、**P7.5 Update — Parts** |
| Claims and data / CNP-231；**ACT-026 Bulk Upload Parts** | FR1.6，关联原 FR13；D027-UC02 文件解析、UC03 预览与纠正、UC04 应用/回读 | **P7.5.1 Upload Parts Data** 的 AMM独立profile候选；具体创建页入口位置待与最新导航核对，不另造正式 Page ID |
| 读取 Claim Parts | FR5.1、FR6、FR16；D027-UC04 / UC05 异常恢复 | **P6.5 Parts**；保留原零件、价格与状态 |
| Implementation / CNP-234；**ACT-025 Complete Task** | **FR14**；本稿仅保留后续依赖 | **P15.15 Manual System Update — AMM**；上传不等于 CBSL 已经完成 ATP→AMM linking |
| 财务计算 / 报告依赖 | FR7、FR20.5 | BRD允许 RMA / Automaterials 的 Buyer Performance 人工录入；不能发明“重量×材料指数＝已批准Claim金额”的新公式。[S2-18] |

[S5/S15] ACT、Epic、FR和Page是已有登记；D027-UC01～05仅为本包评审场景，不是新写入 Jira 的 UC。

## 3. 原资料、现有实现和差异

| 来源 | 能确认什么 | 仍需保留的区别 |
|---|---|---|
| Training Bulk Upload Parts | 正文518–550的角色提示是 **CBSL only**。[S3] | ACT-026既有故事已记录 matrix/body 的 Buyer/CBSL差异；本次新需求明确要求 Buyer。新增权限需受控授予，不能悄悄扩大旧CBSL任务权限。[S5] |
| 原 POA guide 物理第18页 | AMM首次关联；**超过一个 index 要附 complex worksheet**；Settlement批准并Mark As Complete后，由CBSL经ATP链接AMM。[S17] | 一行Part/Plant并不能代表全部多材料/多指数关系；上传也不会替代该下游流程。原页只在内部证据中保留，不重做Before页面汇总。 |
| 字典 Claim Part | AMM Measure Unit为varchar255，三种Weight为decimal(19,5)；AMM_LINKED_VALUE也是decimal(19,5)。[S4] | 字段结构不提供单位清单、总/净/毛关系、linked value公式或原材料实体定义。 |
| 字典报表结构 | MCI_STG_REPORT_EXTRACT 的 AMM_MEASURE_UNIT 2517行是 **decimal(19,5)**，与业务表848行的文本类型不同。[S4] | 需确认是旧定义错误、不同含义还是转换规则；本稿不直接修库或把kg转数字。 |
| 当前通用 import schema | 现有技术代码有15列旧profile、Worker、ZIP预检和校验机制。[S6/S7/S8] | 旧列是Vendor/Part/Price/Runout等，并无本次AMM重量列；源码存在不等于当前业务入口已开放。本稿不恢复那个入口。 |
| 当前 AMM task | CBSL AMM手工任务、负责人/文档/原单版本检查已有实现结构。[S9/S10] | 不证明新Buyer上传或外部AMM参数更新已开发完成。 |
| 原QA记录 | 保留HIST-03、F1021-11、NQA-103/107/132/133。[S14] | 文件解析、附件、CSV、模拟回执、实际流程验收各自独立。本包只追加独立设计证据，不改共享QA状态或另起总表。 |

## 4. 字段及系统 / 接口映射

| 输入或事实 | 数据来源 / 提供方 | 本候选处理 | 正式映射 / 缺口 |
|---|---|---|---|
| VendorCode / CompanyCode | 当前 Claim 上下文；上传文件仅作交叉核对 | 必须与V002 / GB01合成场景一致，文件不能更换供应商或公司 | 正式供应商/组织作用域及授权查询由应用服务复核，不信任Excel列。 |
| PartNumber / PlantCode | 文件带精确文本；SAP参考数据经NEO核对 | 仅接受唯一、明确、同作用域匹配；同Part不同Plant保留；当前引用不明/重复禁止 | Claim Part 的 PART_ID816 / PLANT_ID817；前端显示文字不是正式数据库整数ID。[S4] |
| MeasureUnit | Buyer文件 | kg为合成参考；不猜g/tonne转换；已有单位变更需先有转换规则 | **AMM_MEASURE_UNIT848，varchar255**；正式单位来源/代码清单未收到。 |
| TotalWeight | Buyer文件 | 保留精确文本后按5位小数保存；本候选非负校验；空白保留原值 | **AMM_TOTAL_WEIGHT849，decimal(19,5)**。业务含义、必填、负值/零值政策待签收。 |
| NetWeight / GrossWeight | Buyer文件 | 同上；显式0可写为0.00000；不发明Net≤Gross或Total=两者组合 | **AMM_NET_WEIGHT850 / AMM_GROSS_WEIGHT851**。 |
| Material / escalator | Buyer文件的待评审内容 | 在预览保留Steel / index A，**整批阻止应用**；不忽略、不写入其他列 | 未确认raw material、index、rate、composition或多行结构；MCI_REF_PART.MATERIAL320同名不足以证明同义；AMM_LINKED_VALUE847是数值，不能塞材料文本。 |
| 当前价格 / 币种 | 已有Part/Plant参考数据 | 文件不提供价格改写列；原90/45GBP保持，新S01从参考取95GBP | 可评估复用 SAP ID1/ID2查询；AMM价格公式/外部权威结果未收到。[S16] |
| 上传人 / 文件 / 行 / 时间 | 应用认证主体、原文件SHA、原物理行号、批次意图 | 本地事件保留实际字段old/new、Alice、源行、file/hash/intent | 实际后端身份、原子持久化、保留期与可重放规则待实现。 |

[S16] CSV物理第7行 / ID1：GET `.../material-parts-data/VAR_VENDOR_CODE?plant=...&offset=...&limit=...`；第8行 / ID2：GET `.../material-price-history/VAR_VENDOR_CODE?plant=...&materialNumber=...&offset=...&limit=...`。Appian为调用方、SAP为提供方、Apigee为中间层；未来新应用承接调用。**登记不是完整payload/response，也没有证明存在本项AMM写接口。** 本轮没有访问这些地址。

## 5. 六张主要页面图

### 5.1 AMM上传入口

Alice Morgan / Buyer；MCI-00057，POA / AMM，Supplier Negotiation。下载候选模板，选择真实XLSX；未选文件不出现可应用的数据。

![AMM上传入口](NEO-027_Upload.png)

### 5.2 XLSX解析后的预览

实际上传本包模板，原物理第2、3行对应同一Part的H01/S01两Plant；每行有校验和只读身份，单位/重量保留5位小数。预览不保存。

![真实XLSX预览](NEO-027_Preview.png)

### 5.3 错误行逐项纠正

负重量、未知单位或多于5位小数会阻止整批应用。Review显示原文件行和字段，Keep row for review只修改待核对数据，不等于更新Claim。

![错误行核对与修正](NEO-027_Review.png)

### 5.4 材料映射未确认

Material / Escalator保留原输入Steel / index A，并说明未确认映射；不能把它塞进Part.MATERIAL或数值AMM_LINKED_VALUE，也不会偷偷忽略它后只导入重量。

![材料字段待确认阻止应用](NEO-027_Material.png)

### 5.5 应用后查看保存值

确认后v8：更新P03001/H01重量、加入P03001/S01、保留P03002/H01；原价格90/45及新行参考95不变。这里是内存保存/回读，非数据库。

![AMM字段应用后回读](NEO-027_Saved.png)

### 5.6 300行分页面板

完整300行先校验，表格每页显示10行；应用全部300条后，加上原两条未被覆盖的Part，共302条。此图是**合成已解析行fixture**，不冒充300行真实XLSX吞吐压测。

![300行批次分页](NEO-027_Large.png)

另附手机图、完整错误列表图和两张工作簿渲染图；原POA p18在evidence内。页面场景切换会重置为独立fixture，不能当跨角色数据库端到端证据。

## 6. 具体操作、输入和预期

| 场景 | 谁 / 怎么操作 | 字面数据 | 本地预期与实际 |
|---|---|---|---|
| D027-UC01/02 真实文件 | Alice → Download AMM template → Choose AMM workbook | 第2行V002/GB01/H01/P03001/kg/1.25000/1.00000/1.50000；第3行S01/kg/1.80000/1.60000/2.00000；Material空 | 实际XLSX ZIP/结构/单元格解析，2行Ready；原saved Parts仍为2条。 |
| D027-UC03 取消 | Review row2，Total改1.30000，再Cancel；Apply→No | 原输入1.25000 | 行取消保留1.25000；整批No不写入；可再次查看原2条保存值。 |
| D027-UC04 应用 | Apply AMM details → Yes | 使用上面两行 | v8，保存3条；H01重量1.25000/1.00000/1.50000；S01从参考取95GBP；P03002原2/1.8/2.2及45GBP不变；6条重量字段审计。 |
| 无效重量与单位 | Invalid weights and units | 行2Total=-1；行3Unit=g，Net=1.123456 | 整批拒绝；修行2还不能应用；行3修kg/1.60000后才可明确应用。 |
| 空白与零 | Blank keeps value · zero updates | 行2Total空、Net=0、Gross空、Unit空 | 原Total1.00000/Gross1.10000/kg保持；Net变0.00000；只1条Net Weight事件。 |
| Material未映射 | Material / escalator mapping unresolved | Steel / index A | 保留输入供核对，整批不可应用；不是字段已实现通过。 |
| 身份/重复 | Duplicate Part and Plant / Different supplier or company | 同P03001/H01两行，或V999/GB99 | 重复两行都提示；错误作用域拒绝；不随便保留第一条或替换供应商。 |
| 参考/角色/状态 | Retry Part reference；Approval、Non-AMM、CBSL场景 | 同一合成Claim上下文 | 缺参考先阻止，恢复再核对；批准/非AMM锁定；旧CBSL权限不自动扩大到新Buyer profile。 |
| D027-UC05 状态/版本竞争 | Apply时Claim进入In Approval，或Parts升v8 | 上传行保持；最新H01 Total=1.10000 | 拒绝旧输入覆盖；查看最新状态/Parts。批准后继续锁；仅版本变更时可明确采用最新basis再确认v9。 |
| 已知失败/未知结果 | failure / unknown场景 | 原两行；原apply intent | 已知未提交可重试；未知禁止新写，先Check original apply result，回到v8/3条，不重复应用。 |
| 批量分页 | 300 AMM rows across pages | P10000～P10299/H01，单位kg、同示例重量 | 第1页10条，第2页从P10010开始；完整批次应用后302条。仅本地合成规模。 |
| 格式/精度异常 | 实际上传坏XLSX、公式、数字身份/数字小数单元格、额外Sheet或版本不符 | 自动化测试构造无效输入 | 拒绝且不保存；重新上传有效文件可恢复。宏/链接/ZIP风险检查不是完整安全认证。 |

候选模板包含 **AMMParts + Metadata**。身份和精确小数均按Text存储，避免Excel预先丢前导零或超过安全整数精度；数字单元格被明确拒绝，不悄悄转值。空白=保留、0=写零、整批成功/失败、覆盖已填AMM值等均为本候选方案，正式规则仍须签收。

候选技术限制为8MiB、最多5000行；这是隔离页面的技术保护，不是业务容量承诺或生产SLA。真实单位、必填和完整模板未收到，不擅自要求Total/Net/Gross全填，也不推导价格。

## 7. 后续正式开发的修改范围

| 层 | 修改内容 | 与现有能力的衔接 |
|---|---|---|
| 页面 | 新AMM profile，下载/选择/预览/错误定位/整批确认/回读；使用最新NEO theme、AntD、32/24/16边距、前置sticky Actions、表内横向滚动和明确状态 | 不带回旧Before样式；不恢复已停用的通用Parts导入；正式入口与实现负责人协调。 |
| 文件解析 | 有版本的模板；Worker解析；受限ZIP/格式/字段检查；取消、重选、错误恢复及原文件hash | 本包复用只读审查过的ZIP防护机制，新增独立schema；不能把旧15列价格模板直接当AMM模板。 |
| 应用服务 / DB | 作用域与正式Part/PlantID匹配；版本/状态/权限最终复核；字段级原子写入；来源文件/行/修改审计 | 已知AMM列优先复核复用；Material多材料/多指数若需子实体再设计，不凭空建表。IS_UPLOADED_BY_CBSL844不能给Buyer上传错误置true。[S4] |
| 价格/财务 | 更改AMM参数后如何重新计算、更新Estimate、重新审批，由已确认计算服务/业务规则负责 | 本包保留价格和状态，不把未计算误写成金额已正确；FR7对Automaterials还有人工Buyer Performance依据。[S2-18] |
| 外部实施 | 保留Settlement/Mark As Complete→CBSL→ATP/AMM及适用PM后续 | 不加WIPS模拟机器人或新AMM API；真实外部payload和回执如果变更，应由提供方确认。[S2-39/S17/S3] |
| 报表与归档 | 原AMM字段、上传人/文件/行、历史版本及报表类型一致性 | 核对AMM_MEASURE_UNIT文本/数值差异，不能静默丢单位或修改历史财务依据。 |

## 8. 本轮验证与退出条件

| 层 | 结果 | 范围 / 未测 |
|---|---|---|
| 浏览器交互 | **98 项 PASS** | 实际下载并重新上传候选XLSX、Worker解析、预览/取消/纠正/应用/回读、整批阻止、冲突/未知结果、300行分页、手机操作。详见PAGE_VISUAL_CHECK.json。 |
| 模型与XLSX解码 | **85 项 PASS** | 全批身份/精度/空白/零/价格不变、来源行审计、非法workbook拒绝、版本/权限/原意图回读。DOMAIN_CHECK.json。 |
| 工作簿 | artifact-tool导出；两Sheet均渲染查看；最终XLSX重新读取精确Text/5位小数；页面实际接受该文件 | WORKBOOK_AUTHORING.json及原文件；**Microsoft Excel原生打开/编辑/保存 NOT RUN**。渲染器显示数值可能压缩尾零，最终XLSX值经独立读取确认。 |
| 响应式 | 六宽度1920/1440/1024/768/390/360，无文档溢出；边距32/24/16；CSS200%检查 | 手机行核对模态框、sticky Actions已操作；原生浏览器200%zoom NOT RUN。 |
| 材料/多指数/计算规则 | **未实现正式映射 / NOT RUN** | Material输入明确阻止应用；kg及行粒度为合成约束。没有完整AMM escalator模型或价格计算证据。 |
| 现有产品、真实API/DB/BPM/ATP/AMM | **NOT RUN** | 本包未编辑产品，没有真实业务数据、认证、持久化、集成或实施操作。 |
| 业务/生产/性能容量 | **NOT RUN** | 小文件解析时间是本机证据，不是SLA；300行fixture不是生产吞吐验收。 |

**本设计包退出条件**：原条目无混淆；已知字段与Material缺口分开；Buyer新诉求与CBSL历史权限分开；真实XLSX能预览并明确应用已知字段；异常不部分写入；价格/无关Parts/状态保持；六图、来源、可编辑源码/模板/测试与ZIP可用。本轮完成此独立范围。

**整项正式退出条件**：签收真实模板、完整AMM材料/指数数据结构及单位/精度/空白策略；确认角色和生命周期；真实服务端/DB原子保护；同一AMM Claim上传到计算/批准及CBSL实施后回读；文件正常/失败/未知/重复/并发与生产规模性能有证据；报表和财务版本一致。当前不能声称已满足全部需求。

## 9. 业务确认问题（讲人话）

| ID / 优先级 / 建议责任 | 背景、例子与需要的决定 | 建议及影响 |
|---|---|---|
| Q027-01 / P0 / AMM业务Owner + Procurement | 能提供今天使用的完整模板和一份真实匿名样例吗？现在只有“加part但缺AMM参数”的描述。 | 需原模板、必填、列顺序、单位、成功/失败样例；候选模板不能当正式模板。页面/通用解析可继续。 |
| Q027-02 / P0 / AMM SME + Data owner | materials/escalators到底是什么？材料类型、材料编号、价格指数、含量，还是linked value？ | 例：Steel / index A应存文本、参考ID还是一组价格数据？先确认字段和实体；不能塞进AMM_LINKED_VALUE数值列。相关列暂阻止。 |
| Q027-03 / P0 / Procurement + Security + CBSL | 新Buyer入口与旧CBSL Bulk Upload怎么分工，哪些Buyer可上传/覆盖？ | 例：Buyer建单先上传参数，CBSL审批后执行链接。建议各自授权，不把新入口当旧任务权限；沿用ACT-026原问题。 |
| Q027-04 / P0 / AMM SME + Finance | Total / Net / Gross各指什么，哪些必填，0/负值允许吗？单位有哪些、转换由谁负责？ | 例：g变kg时，三个weight是否也要换算？候选不转换，未知单位或单位变化阻止；不编造Net≤Gross公式。 |
| Q027-05 / P0 / AMM SME + Data/ATP owner | 一零件一Plant是否只有一组重量，还是同一零件可有多材料/多index行？ | 原p18明确多index需complex worksheet。建议先确定行粒度和唯一键；不能把合法多材料行当重复后删掉。 |
| Q027-06 / P0 / Buyer SME + App owner | 文件空白是保留、清空，还是错误？覆盖旧重量是否要逐行确认？ | 候选空白保留、0写零、整批校验、明确Apply。例：Net从0.9变0不能被当“没填”。完整语义未签收，不改变产品旧值。 |
| Q027-07 / P0 / AMM/Finance + Calculation owner | AMM参数改后谁计算价格和Claim影响，采用哪个指数/期间/汇率版本？何时需要重审？ | 例：重量从1.0变1.25是否就能决定新价？目前不能。FR7还保留Automaterials人工Buyer Performance；原金额不自动伪造。 |
| Q027-08 / P1 / Data owner + Reporting | 为什么AMM_MEASURE_UNIT在业务表是文本、报表表却是decimal？ | 例：kg不能写成数字单位。请确认真实schema/转换；本稿标出差异，不直接改数据库或报表。 |
| Q027-09 / P1 / App + Integration owners | 材料/指数来自Buyer文件、SAP、ATP、AMM还是其他主数据？现有接口实际返回哪些字段？ | API1/2只登记Part/Price查询，不能证明有AMM写接口。先做输入与来源核对；需要新接口时再找对应系统owner签收。 |
| Q027-10 / P1 / QA + Operations + Business | 典型/最大文件多少行、多大，峰值用户多少，处理时长和失败补跑怎么验收？ | 8MiB/5000行仅候选技术保护；300行本地fixture不能当生产压测。正式按真实数据规模和环境设目标，仍可先完成交互/错误恢复。 |

以上为本需求的问题清单，不是新增QA主表；相关既有记录见S14。

## 10. 交付物与下一项

- `NEO-027_Page_Proposal.html`：独立英文React/AntD交互页，15个外部评审场景；内嵌模板及XLSX解析Worker，无外部HTTP。
- `NEO-027_Consolidated_CN.html` / `.md`：本方案、6张嵌入主图、类型/Epic/ACT/FR/Page/字段/接口/priority；`OPEN_QUESTIONS_CN.md`：十个确认问题。
- `NEO-027_AMM_Upload_Candidate.xlsx`：候选模板及两行合成输入，不是正式原模板；两张sheet预览和作者记录。
- `SOURCE_EVIDENCE.json`：24条来源摘录/定位/路径/SHA；`evidence/Original_POA_Physical_p18.png`：原始流程说明的物理页渲染及来源。
- `PAGE_VISUAL_CHECK.json`、`DOMAIN_CHECK.json`、`VALIDATION.json`：本版实际预期/结果、文件/页面/模型SHA和未测层。
- `design-source/`：可编辑UI、模型、XLSX解码/Worker/ZIP防护、模板builder/bytes、theme快照、字体logo、依赖/构建/测试/README。
- `NEO-027_Review_Pack.zip`：完整离线包；公共index追加本条。未产生第二份测试Word/QA总表/Excel结果台账或PDF。

下一条 **NEO-028：NEO Processing Time**，包括RPA Error任务选Include及Plant选择的明显延迟；本轮未开始。

### 10.1 来源索引

本轮读取/截图日期2026-11-13，历史Training与PDF截图自身日期未推定。API登记CSV导出日期为2026-11-09，不能当新接口验收时间。完整原路径、原文与SHA-256见SOURCE_EVIDENCE.json；来源回读时间和一致性见VALIDATION.json。

| ID | 原始文件 | 定位 | SHA-256前12位 |
|---|---|---|---|
| S1 | NEO Business Requirements (added China requirements) 1.xlsx | RTM for Requested Changes row28 (1-based) | b83b74cb3eb2 |
| S1-ID-A | NEO Business Requirements (added China requirements) 1.xlsx | RTM - Archive row30 (1-based) | b83b74cb3eb2 |
| S1-ID-B | NEO Business Requirements (added China requirements) 1.xlsx | NEO RTM row31 (1-based) | b83b74cb3eb2 |
| S2-4 | Material Cost & Inventory - BRD V3.1.docx | Table6 row4 (1-based) | 0d6aedc1538c |
| S2-8 | Material Cost & Inventory - BRD V3.1.docx | Table6 row8 (1-based) | 0d6aedc1538c |
| S2-18 | Material Cost & Inventory - BRD V3.1.docx | Table6 row18 (1-based) | 0d6aedc1538c |
| S2-39 | Material Cost & Inventory - BRD V3.1.docx | Table6 row39 (1-based) | 0d6aedc1538c |
| S2-41 | Material Cost & Inventory - BRD V3.1.docx | Table6 row41 (1-based) | 0d6aedc1538c |
| S2-72 | Material Cost & Inventory - BRD V3.1.docx | Table6 row72 (1-based) | 0d6aedc1538c |
| S3 | NEO User Training.docx | Body518–550,1193,1239–1242,1368 (1-based); historical CBSL upload vs new Buyer request | bf942f7a70e6 |
| S4 | NEO_数据字典.xlsx | 字段字典 rows318–330,814–857,1114–1118,2517–2520; weight/measure definitions and conflicting report-unit type | 22342fd6253c |
| S5 | story_data.json | ACT001/004/025/026 existing story mappings; no Jira writes | a2e47d1cde32 |
| S6 | schema.ts | Numbered source lines (1-based); read-only source inspection, not product execution | fdeaa81f8915 |
| S7 | decoder.ts | Numbered source lines (1-based); read-only source inspection, not product execution | 407880ac1703 |
| S8 | zip-preflight.ts | Numbered source lines (1-based); read-only source inspection, not product execution | bca11c38186c |
| S9 | amm-task.ts | Numbered source lines (1-based); read-only source inspection, not product execution | 6818ae055630 |
| S10 | fixtures.ts | Numbered source lines (1-based); read-only source inspection, not product execution | 1ce2066b2ff0 |
| S11 | locks.ts | Numbered source lines (1-based); read-only source inspection, not product execution | f29c970d2c72 |
| S12 | index.ts | Numbered source lines (1-based); read-only source inspection, not product execution | 82b56dcd8c92 |
| S13 | personas.ts | Numbered source lines (1-based); read-only source inspection, not product execution | 9c30e405c28f |
| S14 | review-data.json | F1021-11 and HIST-03/NQA-103/NQA-107/NQA-132/NQA-133 retained; no canonical QA update | 8fcbf8fdf490 |
| S15 | scope.json | Existing P2.6/P6.5/P7.5/P7.5.1/P15.15/P20.3 page IDs | 74aae9869a99 |
| S16 | Integrations - 2026-11-09_0941(Sheet 1).csv | CSV physical rows7/8, register IDs1/2; part reference APIs, not proven AMM write contract | 5e40049996bb |
| S17 | NEO Creating a POA Claim.pdf | Physical PDF p18, visually rendered in this review; capture date not stated | 45e201af1d94 |
