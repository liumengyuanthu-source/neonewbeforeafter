# NEO-032 · 价格5位精度与计价数量换算

## 1. 本次结论

**这条不是把页面补成5位小数。** 要保证SAP原价经过RFC、Apigee、NEO保存／计算，再到WIPS／RPA时，真实价格没有先被截成4位。若上游已丢失第5位，NEO显示0.12340并不能证明原价就是0.12340，更不能猜回丢掉的数。[S1]

建议把“原始金额＋计价数量＋单位＋是否已换算”的来源依据一起确认，再由指定的一层完成一次换算。例如123.45GBP／1,000EA＝0.12345GBP／EA。不能假设所有Vendor都按1,000计价，也不能把已经是单价的0.12345再除1,000。

当前离线代码已经使用十进制字符串、DECIMAL(19,5)校验及字符串WIPS字段；**本轮没有真实SAP／RFC／Apigee请求，不能声称复现了现网4位截断，或已修好真实接口。** 缺的是经过签认的来源／单位／序列化契约与同一条记录的原始样本。本包是独立页面与解决方案，现有prototype未改。[S6–S16、S20]

## 2. 来源、改动分类与优先级

| 项目 | 内容 |
|---|---|
| 主记录 | RTM for Requested Changes第33行；NEO-032；Both / POA Input；K33与L33均Must |
| 用户报告 | E33／M33：NEO改成5位，但SAP取价API仍4位，导致WIPS价格不一致和RPA返工。原文要求核对SAP RFC、Apigee及NEO逻辑，并提到SAP金额2位／每千件计价 |
| 明确预期 | Q33：来源／录入的起始价格应与SAP、WIPS精度一致，通常5位；系统不得在最大5位范围内提前舍入 |
| 原表分类 | Existing functionality - Update UX / Workflow；保留原文分类，不把它当技术实现范围的最终判断 |
| 主要改动类型 | **Application内部前后端＋Integration needed**；页面5位只是其中一层，还涉及取价、换算、存储、计算、导出和RPA字段 |
| Integration对象 | SAP／RFC Owner、Apigee Owner、NEO应用适配层、Automation Anywhere／WIPS Owner |
| 可复用 | 现有MCI_getPartPriceDetails、MCI_getPartDetails、MCI_raiseWIPSClaim与MCI AA WIPS Response；当前十进制字符串和5位校验亦可复用 |
| 是否新架构 | 没有证据要求新增平台。先核对既有链路在哪一层丢精度／单位；若现DTO不能表达完整价格依据，考虑兼容扩展／接口版本，不先造新系统 |
| 优先级 | 来源Must；建议P0先冻结一组SAP→Apigee→NEO→WIPS精度样例与契约，再实施差异。价格错误会重复触发RPA失败，也可能影响计算与审批依据 |

**同编号不能混用：** Archive第35行NEO-032是Action Task／FR10.5；NEO RTM第36行NEO-032是Edit parent／FR3。本次不继承这两个FR。[S1-ID-A、S1-ID-B]

## 3. Epic、ACT、FR、UC和页面

| 层次 | 对应 | 范围说明 |
|---|---|---|
| Epic | CNP-231：建档／编辑／Parts；CNP-234：WIPS实施与纠错 | 来自现有story_data，不新增Jira写入 |
| 主FR | FR1.6 | Current Price／币种取自参考数据，New Part Price／差额与WIPS交互；Resource／Currency允许直接新价，不能因此给所有流程开放Start Price修改 |
| 关联FR | FR6／6.1、FR7／8.1、FR13；FR19.13关联Part来源 | 编辑、计算、WIPS实施都要使用同一有效价格依据，不能只修一个输入框 |
| ACT-001 Create Claim / ACT-004 Update Claim | 创建／编辑时使用正确单价 | 本候选主页面展示合成Buyer、Resource直接新价情形 |
| ACT-026 Bulk Upload Parts | 历史批量线路的精度关联 | Training第518–520段写CBSL only；本次不恢复已移除Parts Excel导入，也不把Buyer新价需求当成批量上传授权 |
| ACT-027 Create WIPS Claim / ACT-023 Raise WIPS Claim Manually | WIPS自动／手工处理中的价格一致性 | 精度方案不改变建单时机、外部权限、审批或Implemented条件 |
| ACT-037 Buyer Enquiry - WIPS Claim Creation | 价格不一致后的受控核查 | 优先从取价端避免返工，不自动赋予CBSL改价权限；沿用NEO-030的权限边界 |
| UC场景 | 每千件、每100／1件、已换算、未知4位、有效第5位为0、缺单位、6位输入、保存及回读 | S1–S6为本包评审场景别名，未发明正式UC编号 |
| P2.6 Parts Data — create POA | 主要影响页，重点Part prices | 原表并未登记独立小步官方编号，不把本页新造为P2.6.2 |
| P6.1 Calculations / Financial Impact | 使用精确价格差的计算消费者 | 不提前舍入单价；NEO-031年度窗口规则另外处理 |
| P7.5.2 WIPS plant-specific price confirmation | Plant／Vendor特定价格一致性 | 必须保留Part／Plant关联，不以单个Part覆盖所有Plant |
| P15.7 / P15.8 / P15.19 | 对应WIPS任务与失败纠错关联 | 沿用既有登记范围，精度回读不等于这些任务已完整通过 |

Training第1255–1259段描述Buyer在Supplier Negotiation／POA阶段的Create WIPS Claim；第1730段列Start Part Price Mismatch等错误。它们不能替代真实5位API／RPA契约，也不能授权本包在Resource案例真正建WIPS单。[S3–S5、S2-8、S2-38]

## 4. 关键交互和数据规则

| 情形 | 候选处理 | 为什么 |
|---|---|---|
| SAP原金额123.45，计价1,000EA | 精确得到0.12345GBP／EA，保留原金额／数量／单位／来源版本 | 不能先算成4位再补0 |
| 已返回单价0.12345 | 明确标识Already a unit price，使用0.12345，不再除数量 | 避免重复换算 |
| API仅0.1234且精度未知 | Current Price—，说明精度未确认；保存和导出阻止，输入保留 | 仅凭4位文本无法知道原价是0.12340、0.12345或其他值 |
| 来源契约确认真实值0.1234 | 可以显示0.12340并正常处理 | 第5位为0不是错误，不能按字符串长度误判 |
| 缺计价数量／单位不一致／未知基准 | 不猜1或1,000，不执行未知单位转换 | 由提供方补齐契约，不能用页面手改Start Price掩盖问题 |
| 换算后超过5位且不能精确表示 | 阻止保存，要求确认舍入规则 | 如1.00÷3不能在5位精确表示；本条没有给这类舍入政策 |
| 新价格0.123456 | 原文本保留，明确未舍入，阻止Preview／Save | 用户可以改为已确认的5位数；不悄悄写成0.12346 |
| 合法新价格0、0.1234、21.40000 | 分别以0.00000、0.12340、21.40000参与价格读写 | 0与缺失不同；单位价格不能按总金额2位展示来比较 |
| 保存 | Preview changes→核对→Save prices；原价不开放编辑 | 对新价确认，不绕过来源权威与审批限制 |
| 来源／输入变化 | 旧Preview过期，保留新价，重新Preview | 不让陈旧单价及版本进入保存 |
| 结果未知 | Check save result查原intent，未确认前锁定新保存 | 不因超时制造第二次写入 |
| 读回WIPS价被舍成4位 | 指出与本保存版本不同，不能视为匹配或完成 | 比对Part／Plant／币种／源版本和价格，不能仅看一个成功状态 |

候选使用BigInt十进制有理数／整数运算，不经JavaScript Number计算单价。来源计算结果须精确容纳在decimal(19,5)；手工新价只接收最多5位的普通非负十进制输入。技术上的字段名、精度确认标志是**待签认契约概念**，不是给业务用户勾选的“信任来源”开关。

价格单位与普通金额区别明确：历史NQA-25记录过“计算5位、金额UI2位”的范围，本次NEO-032明确要求比对5位单价；不能用金额2位格式遮住价格第5位。[S18]

## 5. 字段、接口与payload提案

| 内容 | 已有来源／字典 | 差异／待确认 |
|---|---|---|
| 参考Current Price | MCI_REF_PART_PRICE.CURRENT_VALUE，第341行，decimal(19,5) | 列类型已5位不证明SAP输入没有先丢位 |
| 参考币种／有效期 | CURRENT_VALUE_CURRENCY、EFFECTIVE_DATE_FROM／TO，第342–344行 | 实际API按什么日期选价、同Part多Plant或多条件怎么选，要与接口确认 |
| Claim Current Price／币种 | MCI_RISK_OPPORTUNITY_PART.CURRENT_VALUE／CURRENT_VALUE_CURRENCY，第818–819行 | 不与新的报价混写；保留记录当时的来源版本／匹配依据 |
| 当前值改动标记／原因 | IS_CURRENT_VALUE_CHANGED、CURRENT_VALUE_CHANGE_REASONING，第822–823行 | 字段存在不等于CBSL或Buyer有任意覆盖起始价格的权力；本页不提供Start Price覆盖 |
| 新价及差额 | ABSOLUTE_PART_PRICE_CHANGE、NEW_PART_PRICE、PRICE_DIFFERENCE，第824／825／827行，decimal(19,5) | 输入、服务、保存、导出及RPA都检查精度；不能靠前端控件保护 |
| SAP原金额、计价数量、UoM、是否已归一 | 当前ReferenceOccurrence仅有currentPrice／currency等；所读参考／Claim价格表未给出完整这一组契约 | 不把通用proposal字段冒充实际RFC／Apigee字段名；可能需适配层来源元数据／快照，而不一定给每张业务表加列 |
| 来源保证及版本 | 本地有sourceVersion；真实粒度／保证未收到 | 服务端可信契约提供，不信任浏览器自行声明confirmed |
| WIPS价格字段 | 本地WipsPayload.priceChanges含currentPrice／priceChange／newPrice／currency | 本候选沿用这些逻辑概念，但actualAA JSON及Vendor特定精度仍未签认 |

提议输入概念：source amount、pricing quantity、price UoM、Part UoM、currency、Vendor／Part／Plant、有效期、source record／version、amount-for-quantity或per-unit基准。建议价格以精确十进制串跨服务；若现系统使用JSON number，必须证明解码后未发生二进制精度损失。真实SAP字段名和单位语义由SAP／RFC Owner提供，不在本包猜定。

输出提案仅覆盖价格字段：本例Current0.12345、New0.12346、PriceChange0.00001，同一币种／Plant；不组成完整WIPS请求，不允许据此直接调用RPA。CONTRACT_PROPOSAL.json和PRICE_HANDOFF_PROPOSAL.json明确标为候选；真实契约、授权、路由、重试、幂等和回执仍未验收。

## 6. 独立页面与六张实际截图

沿用NEO／Ant Design、JLR字体、32／24／16边距；数字右对齐，Source details前置固定图标，全量分页与导出。页面只解释会阻止下一步的错误；没有Pending i和AI长说明。灰色外部工具栏、技术映射弹窗用于独立评审，不是生产操作入口。

### S1 · Current和New均看得到第5位

![Five decimal Part prices](screenshots/01-five-decimal-part-prices.png)

合成Buyer Alice Morgan，Resource案例，原价0.12345→新价0.12346，差额0.00001。另一低价Part保留0.00001；原价只读。没有扩展普通Price Claim的直接改价权限。

### S2 · 点行前图标，看原金额和计价数量

![Source pricing quantity and exact unit price](screenshots/02-source-pricing-quantity.png)

显示123.45GBP÷1000EA＝0.12345GBP／EA，同时保留原始record／version。Already a unit price场景则不再除1,000；“原计价数量”只是其来源信息，不重新参与归一化。

### S3 · 来源精度未确认，不把补0当已修好

![Unconfirmed four decimal source](screenshots/03-source-precision-unconfirmed.png)

API只提供0.1234且精度未确认，Current—，明确提示并阻止保存；Buyer填写0.12347仍保留。外部模拟“取得完整新来源”后Current恢复0.12345，新价不丢失。这不是Buyer手工纠正SAP的权限。

### S4 · 6位新价保留原输入并拒绝

![Six decimal input retained and blocked](screenshots/04-six-decimals-retained-and-blocked.png)

0.123456不会偷偷变成0.12346。输入保留以便核对，修成合法5位后重新Preview。应用保存边界也检查，不能通过批量／直接payload绕过。

### S5 · 没有计价数量就不算

![Missing source pricing quantity](screenshots/05-missing-quantity-source-details.png)

原金额仍可追溯，但没有明确数量就没有可信单价。单位不一致或未知amount／unit基准同样不猜；留给提供方确认。

### S6 · 保存后回读，再看候选WIPS价格映射

![Saved price and proposed WIPS decimal readback](screenshots/06-saved-price-mapping-readback.png)

PRICE-032-1中的Current0.12345／New0.12346／Change0.00001保持一致。外部工具模拟的回读若同版匹配，比较通过；若变成0.12350，明确不匹配。此图是**结构化价格字段对照，不是真WIPS回执、建单成功、批准或Implemented**。

## 7. 逐步操作与样例

| 场景 | 具体操作 | 预期 |
|---|---|---|
| 主例保存 | Alice，Current0.12345；New填0.12346→Preview changes→核对Price preview→Save prices | 新价0.12346、差额0.00001，存PRICE-032-1；原始金额123.45／数量1000不变 |
| 查看来源 | 点Part前眼睛图标 | 来源金额／数量／单位／版本和精确单价；Current不能编辑 |
| 取消 | Preview changes→Cancel preview | 没有保存写入，输入保留 |
| 来源修复 | 外部选API precision unconfirmed→填0.12347→Simulate refreshed source | 原数据缺口解除、New0.12347保留；重新Preview才保存 |
| 13条 | 选13 parts→翻第2页→Download prices | 第2页3条，实际CSV含全部13条及每条完整源依据，不只当前页 |
| 保存回读 | Saved prices→Open PRICE-032-1→View decimal handoff | 保留完整单价及原版本；未收到回读时不能显示已核对 |
| 对比回读 | 先关映射弹窗→外部Simulate WIPS price readback；再关闭→Simulate rounded WIPS price | 前者同版本匹配；后者指出价格不一致，旧保存值不被重写 |
| CAS／失败／未知 | 对应外部评审场景→Preview→Save；已知失败重试；未知先Check save result | 保留输入，版本冲突须重Preview；未知结果查原intent，不重复写入 |
| CBSL只读 | 外部选择CBSL | 能按既有读取范围看单价；不出现New编辑／Preview保存能力。真实人员权限仍需实际系统验证 |

例子只用于精度与单位运算，不是假定的Finance黄金数据、SAP实际单或WIPS实际Vendor配置。若真实来源计价数量允许非整数或其他单位，须由契约确认；本候选不宣称已覆盖这些未给出的场景。

## 8. 系统依赖与开发顺序

| 环节 | 谁提供／谁负责 | 先做什么、是否复用 |
|---|---|---|
| SAP／RFC | SAP价格／RFC Owner提供真实字段与样本 | 同Part／Vendor／Plant原金额、计价数量、币种小数／单位／有效期，核对第5位是否在RFC前就已丢失 |
| Apigee | Apigee集成Owner | 复用现MCI_getPartPriceDetails路由（CSV物理第8行）；查序列化／映射／舍入。若已提供精确单价则不重复除数量；若字段不足评估兼容扩展 |
| NEO／将来应用侧 | 应用后端＋数据团队 | 在已明确的一层归一化，保存原始证据和精确单价；前端／API／DB／缓存／导出全程不提前4位舍入。Flowable流程变量引用对应版本，不让BPM图代替价格服务 |
| Part身份 | SAP／Apigee＋NEO | MCI_getPartDetails（CSV第7行）辅助Part／Plant匹配，不只按Part Number覆盖Vendor／Plant差异 |
| WIPS／AA | Automation Anywhere和WIPS Owner | 复用MCI_raiseWIPSClaim（CSV第18行）与MCI AA WIPS Response（第22行）；核对发价、取价、回执精度和Vendor设置，不新造接口名 |
| 数据库 | 应用／数据团队 | 当前价格列已decimal(19,5)；先查实际映射与持久回读。原始金额／数量／版本怎样留存需确认，不因类型已5位就宣告完成 |
| 计算／审批／历史 | 业务／Finance＋应用团队 | 输入变化导致计算版本失效；对已批准单的旧错误价格，按批准政策处理，不自动回填／重新审批或改变Implemented |

开发顺序：①取一笔第5位非0、一笔第5位0、每千件／已归一单价真实样例，逐跳抓原始值；②冻结来源契约与唯一换算Owner；③只修实际丢位／单位缺口，复用现有5位代码；④前端与服务／DB回读／导出一致；⑤真实RPA发价／回读、错误与重试同记录验证；⑥确认历史修复与业务验收。当前资料不足以确定根因在哪一层，不能先认定只需要Apigee改一个precision参数。

## 9. 讲人话的问题清单

1. **SAP一笔价格到底给什么？** 例：123.45是每件，还是每1,000件？请给真实RFC字段、币种与单位，不只给NEO截图。
2. **Apigee返回的价已经除过数量了吗？** 例：0.12345带quantity1000可能仅是原始来源信息，不能再除。由哪一层负责一次换算、谁保证不重复？
3. **第5位在哪里丢的？** 例：SAP0.12345，RFC／Apigee／NEO分别是什么？0.1234可能是截断，0.1235可能是舍入，需要同一条记录逐跳原始request／response才能定位。
4. **哪些Vendor用5位，单位和格式有没有不同？** 例：每件／每100／每1,000，EA／KG、不同币种是否有小数缩放？请给WIPS／AA接受和回读样例，不能把一个Vendor规则推广给全部。
5. **超过5位时怎么处理？** 例：1÷3无法精确落5位；是来源不应产生这种组合，还是应在指定一层按确定方式舍入？本候选先拒绝，不替Finance决定。
6. **起始价不对时谁修？** 例：不要让CBSL改到WIPS看起来匹配就算解决，应刷新正确来源，还是由授权角色通过正式更正？字段可写不等于有权限，需与NEO-030一致。
7. **批量输入走哪个现有入口？** Training写Bulk Upload Parts由CBSL管理，但此需求也提到录入／上传。要保留哪条批量流程？本轮不恢复退役的Parts Excel按钮，也不默认Buyer有批量导入权。
8. **历史错误价格和批准单怎么办？** 例：旧Start少了0.00001，新来源恢复后是否重算、换版或补审？谁批准修复，哪些已实施记录只能补证据不能改历史？

这些是本条评审附件，关联原FR16-Q02／F1021-30；RV04只保留其历史本地修复范围，不因本包又做了5位检查就重写旧验收或宣布真实接口通过。

## 10. 验证、退出条件和交付

106项实际浏览器检查、124项模型检查。逐项Expected／Actual和实际版本见PAGE_VISUAL_CHECK.json、DOMAIN_CHECK.json；实际CSV下载字节保留EXPORT_READBACK.csv。覆盖同版保存／回读、缺源、6位拒绝、已归一不重复除、全量导出、只读、冲突、已知失败／未知结果、六屏宽、键盘和CSS200%。

| 验收层 | 当前状态 | 退出条件 |
|---|---|---|
| 独立页／精确数值模型 | 实测结果见JSON | 预先定义的字面预期与实际一致；六张同版截图、来源哈希、保存回读和导出无丢位 |
| 来源与目标契约 | 待SAP／Apigee／WIPS签认 | 逐字段语义、单位／数量、有效期、精度／舍入、来源版本和回执可关联 |
| 真实SAP／RFC／Apigee | NOT RUN | 同记录原始数据逐跳核对；不靠补0或页面显示证明精度 |
| 真实NEO服务／DB／权限 | NOT RUN | 持久回读、绕过UI的6位／溢出拒绝、整批原子性、版本／权限检查 |
| 真实WIPS／AA／BPM | NOT RUN | 合法业务场景、同批准版本发价与回读，第5位非0／0、失败／未知查原单均验证；价匹配不等于实施完成 |
| Finance／历史修复／部署 | NOT RUN | 影响案例和历史政策确认，实际环境全链验收与独立发布授权 |

本候选只有13条合成行，未证明生产数据量、API／SQL或并发性能。原生浏览器200%未执行；CSS200%是单独压力检查。AntD CLI保留固定15个外部场景Select关闭虚拟滚动的一项性能警告，不宣称无警告或完成无障碍认证。

交付：独立英文NEO页面；中文汇总HTML／MD与8个问题；6张主截图及手机图；数据／payload概念提案；源码／构建／测试、源证据／SHA、Expected／Actual JSON；完整ZIP。现有prototype、分支、共享QA和线上环境均未修改，没有另建Word／Excel主QA。

下一条NEO-033：预算汇率更新后刷新未批准ID的GBP换算。它涉及重算范围与批准版本保护，不混入本次单价精度修正。

### 10.1 来源索引

本轮读取2026-11-13；历史报错发生日、原截图拍摄日与实际生产配置时间未推定。原文、完整原路径及SHA见SOURCE_EVIDENCE.json；接口目录不是完整payload或本轮调用证据。

| ID | 文件 | 定位 | SHA前12位 |
|---|---|---|---|
| S1 | NEO Business Requirements (added China requirements) 1.xlsx | RTM for Requested Changes row33 (1-based) | b83b74cb3eb2 |
| S1-ID-A | NEO Business Requirements (added China requirements) 1.xlsx | RTM - Archive row35 (1-based) | b83b74cb3eb2 |
| S1-ID-B | NEO Business Requirements (added China requirements) 1.xlsx | NEO RTM row36 (1-based) | b83b74cb3eb2 |
| S1-NEXT | NEO Business Requirements (added China requirements) 1.xlsx | RTM for Requested Changes row34 (1-based) | b83b74cb3eb2 |
| S2-8 | Material Cost & Inventory - BRD V3.1.docx | Table6 row8 (1-based) | 0d6aedc1538c |
| S2-18 | Material Cost & Inventory - BRD V3.1.docx | Table6 row18 (1-based) | 0d6aedc1538c |
| S2-20 | Material Cost & Inventory - BRD V3.1.docx | Table6 row20 (1-based) | 0d6aedc1538c |
| S2-38 | Material Cost & Inventory - BRD V3.1.docx | Table6 row38 (1-based) | 0d6aedc1538c |
| S2-65 | Material Cost & Inventory - BRD V3.1.docx | Table6 row65 (1-based) | 0d6aedc1538c |
| S3 | NEO User Training.docx | Body paragraphs matching Part Price/Current Price/Price Change/Create WIPS Claim/Bulk Upload Parts, with context; exact locators in extract | bf942f7a70e6 |
| S4 | story_data.json | ACT001/004/023/026/027/037; input, WIPS and historical bulk action associations, not new grants or Jira write | a2e47d1cde32 |
| S5 | scope.json | Existing P2.6/P6.1/P7.5.2/P15.7/P15.8/P15.19 and reference-related price pages; no invented page/UC ID | 74aae9869a99 |
| S6 | decimal.ts | Numbered current source lines (1-based); read-only inspection, not current product regression | 727cc261b26b |
| S7 | pricing.ts | Numbered current source lines (1-based); read-only inspection, not current product regression | 6fc5068c9eca |
| S8 | fr1-prices.ts | Numbered current source lines (1-based); read-only inspection, not current product regression | 5e8af102dabd |
| S9 | wips.ts | Numbered current source lines (1-based); read-only inspection, not current product regression | b88f4d9062d5 |
| S10 | PartPrices.tsx | Numbered current source lines (1-based); read-only inspection, not current product regression | acb5c017bf6c |
| S11 | price-columns.ts | Numbered current source lines (1-based); read-only inspection, not current product regression | 6e91f232b74a |
| S12 | contracts.ts | Numbered current source lines (1-based); read-only inspection, not current product regression | a9e7ce73f811 |
| S13 | schema.ts | Numbered current source lines (1-based); read-only inspection, not current product regression | fdeaa81f8915 |
| S14 | batch.ts | Numbered current source lines (1-based); read-only inspection, not current product regression | a755985c3060 |
| S15 | import.test.ts | Numbered current source lines (1-based); read-only inspection, not current product regression | 4b9cdea9e703 |
| S16 | fr1-wips.test.ts | Numbered current source lines (1-based); read-only inspection, not current product regression | a145858ae6be |
| S17 | index.ts | Numbered current source lines (1-based); read-only inspection, not current product regression | 82b56dcd8c92 |
| S18 | review-data.json | Existing RV04/FR16-Q02/F1021-30 and NQA-25; keep scopes and old execution evidence unchanged | 8fcbf8fdf490 |
| S19 | NEO_数据字典.xlsx | 字段字典 rows339–352,814–831: reference/Claim price decimal19,5 and identity; not raw SAP price-quantity contract | 22342fd6253c |
| S20 | Integrations - 2026-11-09_0941(Sheet 1).csv | Physical CSV rows7/8/18/22: SAP/Apigee parts/price APIs, RPA WIPS creation and response; endpoint directory is not a complete RFC/DTO contract | 5e40049996bb |
| S21 | NEO_UXUI_PRINCIPLES.md | NEO UX standard; numeric precision, read-only current price, no restored Parts Excel import, shared theme/leading action icons | 2722dc05eae2 |
