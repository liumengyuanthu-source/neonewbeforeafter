# NEO-023 · 按交易场景显示新价格币种、模板和任务列

独立英文交互页，复用当前NEO theme、JLR字体及Ant Design。本文为中文评审稿，未改现有prototype、共享QA、Jira、后端、实际任务或线上系统。合成人员／Part／Line／价格／版本仅供本包审阅；保存及回读只在当前页面内存，刷新后重置。两份Excel是价格编辑区的候选模板，不是已批准的完整Bulk Upload契约，也不恢复已移除的上传入口。

## 1. 原需求与证据

同一个通用模板／任务输出把所有字段都放进去，Buyer和Digitide不清楚哪些要填。普通改价不应让用户选择新币种；Resource／币种变更才应显示、明确必填，并把相应数据正确传给实施任务。

| 来源 | 原文／结论和边界 |
|---|---|
| S1：新需求工作簿 RTM for Requested Changes 第24行 | NEO-023，Procurement / POA Input；Existing functionality - Update UX / Workflow；CR-2026-1557 / 5。Exists Yes、Partially、Pain Yes；采购Should，财务优先级空白，Alignment N。 |
| S1：需求描述 | “New Part Price Currency field is inconsistently filled”；“only be required for certain transaction types (resource - currency change)”。 |
| S1：Buyer期望 | 模板匹配当前页面，只包含相关字段，明确必填；“standard claim should not contain currency, only resource”。本包理解为新价格币种输入，不抹掉源价格的原币种。 |
| S1：Task期望 | “Outputs in tasks should only contain relevant columns and headers”，避免下游团队不清楚要做什么。 |
| S2-8：BRD Table6第8行 FR1.6 | New Part Price Currency：Resource或currency时显示用户选的新币种；Else等于Current Value Currency。两种情况下存储仍需要币种，不是隐藏就存空。 |
| S2-4：FR1.2 | POA Breakdown、Supplier Currency及Transaction Drivers语境不能混用；Vendor Currency来自Vendor reference。Part的原价格币种也不能仅凭供应商币种代替。 |
| S2-39：FR14 | Resource为CBSL人工更新场景。该行同时写ATP加“is this related to resource = Yes”，与直接Resource Breakdown的表达不同，保留差异。 |
| S3：Training第518–550段及P533图 | 历史Bulk Upload章节写CBSL users only；图image95的通用模板含NEW_PART_PRICE_CURRENCY，说明历史存在此列，不能证明每种交易都应填写。 |
| S3-V1245：Training第1245段图 | 原Resource任务页含Description、Claim ID、必填Comments、File Upload及Save as Draft／Complete。没有展示本次候选的Part价格表格；新增价格数据区不能冒充As-is已有截图。 |
| S1-ID-A/B：旧表同ID异义 | Archive第26行是FR9.2 Trading Division；NEO RTM第27行是FR1.6百分比计算，不是本条币种／模板需求。 |

SOURCE_EVIDENCE.json保存23条证据的完整路径、坐标、原文和SHA。历史内容、当前源码、本包建议及真实验收结果分开记录。

## 2. Solution、分类、Priority和关联

建议由同一份“交易上下文→字段规则”配置，统一控制页面、校验、候选模板和任务输出。只隐藏页面列不够：旧USD值若仍留在后台，仍可能被保存或导出。

| 项目 | 评估 |
|---|---|
| 主要改动类型 | Application前端＋后端字段／模板／输出校验为主；包括UXUI调整。不是UXUI only，也不自动等于新增外部接口。 |
| 交互方案 | 普通同币种改价：输入signed Absolute Part Price Change，派生新价，新币种沿用每行原币种；不显示New Part Price Currency输入。Resource／币种变更：直接填新价并逐行选新币种，不展示无FX依据的跨币种差额／百分比。 |
| Integration needed？ | 需要核对既有字段输出契约：源价格／币种由SAP等主数据来源提供；NEO／将来Flowable应用负责派生、校验、保存、冻结及任务数据投影；CBSL／Digitide消费对应实施数据。 |
| 能否复用接口 | S14的MCI_getPartDetails、MCI_getPartPriceDetails可作为源输入登记依据；未证明完整现行payload。S15现有WIPS价格构造会拒绝新旧币种不一致，不能把跨币种Resource硬塞进标准WIPS价格机器人。 |
| 是否新增架构 | 暂不需要新平台。优先统一字段规则、版本化模板及输出DTO；只有现行下游契约无法承载已确认币种语义时，才评估修改／扩展接口。该结论不授权新建S4/WIPS写口。 |
| Priority | 原采购Should；建议P1。若现网有错币实施证据，再按实际风险升级；本次未收到这类执行证据。 |
| Epic | CNP-231 Claims and data；CNP-234实施任务关联。没有新建Jira编号。 |
| ACT | ACT-001 Create Claim、ACT-004 Update Claim、ACT-026 Bulk Upload Parts；关联ACT-025 Complete Task、ACT-027 Create WIPS Claim。[S5] |
| FR | 直接FR1.6；关联FR6、FR14、FR13及字段／数据输出控制。FR6.1本身是Lump Sum，不把本条POA币种修改误归为FR6.1。 |
| 页面 | P2.6 Parts Data；P7.5 Update — Parts；P7.5.1 Upload Parts Data为历史登记、不是已授权恢复；P15.16 Resource及P15.18 ATP任务，AMM等其他任务需复用确认后的列配置。[S13] |
| UC | D023-UC01–10为本轮独立评审场景，待纳入正式UC；没有伪造已签收的原UC编号。 |

这里采用“普通同币种”和“Resource／币种变更”两个明确候选场景。原BRD还允许Currency driver，且当前代码也参考Lever Currency；其完整对应关系待确认。页面保留单独场景并阻断未确认的profile，不新增一个假Breakdown值来掩盖差异。

## 3. 当前已有能力与Gap

| 当前证据 | 应保留／需要补什么 |
|---|---|
| S6：PartPrices.tsx | allowDirect按Resource、transactionDrivers Currency或Lever Currency决定；Currency列来自统一priceColumns。普通场景仍显示该列的只读值，未达到本条“隐藏不相关新币种列”的目标。 |
| S7：fr1-prices.ts | 已有editClaimCurrency、跨币种只能direct price的拒绝逻辑，可复用。当前写入只是trim／uppercase；不能据此证明币种属于有效参考清单。 |
| S8：import/schema.ts | 已有静态通用Currency列。文件、页面和任务字段并非同一上下文规则的证明；而且历史导入源码存在不等于当前路由可用。 |
| S9/S10：ManualSystemTask和domain | 已有CBSL权限、状态、行级来源、Comments／附件、保存／完成及版本检查。候选新增价格区应嵌入原任务，不删除这些已有能力。 |
| S16：price-columns.ts | 新旧币种不同会让差额／百分比返回空，可复用该语义。不能只减GBP100与USD90得到“节省10”。 |
| S12：NQA-132/133与RV79-09 | 既有Bulk Upload入口受阻／移除边界及跨币种百分比分母问题继续保留。本包未恢复路由，也没有宣称修复RV79-09或重跑所有产品QA。 |

本轮是指定文件的只读检查，不是全仓库或生产系统功能缺失断言。旧NEO-020候选模板保留原版本，本条只提出后续上下文模板整合方向，不静默覆盖旧交付。

## 4. 字段、来源及控制

| 字段／用途 | 现有对应 | 规则／待确认 |
|---|---|---|
| Part Number、Plant | MCI_RISK_OPPORTUNITY_PART.PART_ID / PLANT_ID，第816–817行；关联Reference | 当前候选使用完整Part Number文本。NEO-020关于Prefix/Base/Suffix和前导零的输入连续性保留；正式完整上传列仍需统一。 |
| Current Price / Current Value Currency | CURRENT_VALUE、CURRENT_VALUE_CURRENCY，第818–819行；MCI_REF_PART_PRICE第339–352行 | 来源系统提供，不因隐藏新币种字段而覆盖。普通样本各行均GBP；正式混合币种必须按行明确原币种，不能只用Vendor Currency推断。 |
| New Part Price | NEW_PART_PRICE，第825行 | 普通从原价＋signed change派生；Resource按选定新币种直接输入。零价与空值分开；实际允许范围还需业务规则。 |
| New Part Price Currency | NEW_PART_PRICE_CURRENCY，第826行 | 普通后台保留该行原币种，但页面／模板不显示输入；Resource候选要求有效币种，缺失不允许保存或输出实施数据。 |
| Absolute／Percentage | ABSOLUTE_PART_PRICE_CHANGE / PRICE_DIFFERENCE / PERCENT_DIFFERENCE，第824、827–828行 | 本包只演示普通同币种单位价格变化；跨币种不计算差额和百分比，不假设FX。正式符号、精度、Finance公式沿用已签规则。 |
| Price Change Reason | 现有UI／domain metadata[S6/S7]，FR6金额变更须理由 | 本包将理由设为必填、255字符上限的候选约束，仍需确认页面字段与正式数据库写入及长度；不把CURRENT_VALUE_CHANGE_REASONING直接当成任意改价理由。 |
| Currency选项 | 字典只提供结构，不提供本次已签收选项／生效版本 | GBP／USD／EUR是本包参考夹具，不是生产Setup。未知币种不自动uppercase成有效值，也不无条件自由输入。 |
| 模板及任务schema | 本包profile-manifest.json与profiles.ts | 是候选版本，不是新增数据库表或真实API契约。正式应用必须从服务端权威上下文校验，不能相信客户端传来的profile。 |

本条不要求新汇率服务。若Resource的金额计算／DoA／报告需要跨币种换算，仍须引用已确认汇率来源与版本；属于既有计算控制及关联需求，不在此凭空补公式。

## 5. 页面截图与操作

### 5.1 普通改价：不显示新币种输入

![普通改价页面](NEO-023_Standard.png)

Alice Morgan，MCI-00057；P03001/H01原价100 GBP，signed change −10，派生90 GBP；P03002/S01为50→45。New Part Price Currency不作为输入；后台保存时仍明确newCurrency=该行currentCurrency。当前未复刻全部Claim表单，仅展示本条影响的价格区域。

### 5.2 普通模板：只有本区相关输入

![普通价格模板字段](NEO-023_StandardTemplate.png)

4列：Part Number、Plant、Absolute Part Price Change (GBP)、Price Change Reason，均标*。实际XLSX另有Reference，记录原价／原币种、候选profile、合成数据与来源。不是完整Part／Runout／ATP／签署文件等所有交易数据的替代。

### 5.3 Resource：逐行选择新币种

![Resource新币种输入](NEO-023_Resource.png)

P03001新价90.12345 USD，P03002新价45 EUR；原价仍为GBP。每一行都要填有效币种，不能因为第一行填了就放过第二行，也不能自动修改Supplier Currency。

### 5.4 显式保存与读取

![保存后价格与币种](NEO-023_Saved.png)

View saved prices在保存前仍读旧保存内容；No／Escape不保存输入。确认Save后变Claim v8，能读出90.12345、USD和EUR；没有提交审批或更新SAP。当前内存保存不是刷新持久化。

### 5.5 Resource模板与页面一致

![Resource价格模板字段](NEO-023_ResourceTemplate.png)

5列：Part Number、Plant、New Part Price、New Part Price Currency、Price Change Reason。新币种有native dropdown／Stop定义，Part／Plant保留Text。Excel粘贴可能绕过校验，正式接入时仍必须服务端整表校验；本包没有上传入口。

### 5.6 CBSL只看到适用数据

![Resource任务价格数据区](NEO-023_ResourceTask.png)

Grace Turner / CBSL的Resource候选价格区显示新旧价格与各自币种，不显示无依据的差额／百分比。标准ATP任务仅显示同币种相关列，没有新币种列或Manual Invoice字段。可以实际下载候选CSV并对账。

这是拟加入现有任务的价格数据区；原Comments、附件、Save as Draft和Complete继续保留在产品任务，本包不实施／替换这些动作。历史Resource图只有它们及Claim入口，不能把本图当作已上线的原系统页面。

## 6. 演示场景与具体数据

| UC | 用谁／操作 | 预期结果 |
|---|---|---|
| D023-UC01 普通改价 | Alice；默认页P03001改−20 → View saved prices → Save → No／Yes | 编辑时派生80，但保存前仍读90；No不保存；Yes保存v8。没有New Part Price Currency输入，后台继承GBP。 |
| D023-UC02 必填币种 | Resource → Save，先不填；再只填P03001 USD | 拦截；第二行P03002仍须选EUR，不能部分保存。 |
| D023-UC03 Resource保存 | 新价90.12345 USD／45 EUR → Save确认 → View saved | 价格／币种精确回读，Supplier Currency保持GBP，不产生跨币种差额。 |
| D023-UC04 对应模板 | 各profile → Price template → Download | 实际下载分别4／5列XLSX；页面预览与二进制模板使用同一manifest。 |
| D023-UC05 隐藏残留 | Standard · previous USD input → Save／Clear incompatible price | 旧USD输入不能隐藏后继续当GBP；Cancel保留原值；明确Clear后只清不兼容行，重新输入GBP变化再保存。 |
| D023-UC06 参考失效 | Currency reference unavailable → Retry | 无参考时币种和保存停用；恢复夹具参考后可填、可存。不调用真实接口。 |
| D023-UC07 版本冲突 | Claim version changed → 输入−21 → Save | 第一次停止保存，仍读旧90且保留−21；Review latest Claim确认保留输入后再存v9。真实多用户合并未测。 |
| D023-UC08 状态／上下文 | Active Settlement；或Currency driver · scope pending | 前者保留锁定；后者Breakdown仍为Price Claim，Driver单独Currency，规则未确认不直接选标准profile保存。 |
| D023-UC09 任务输出 | Grace分别打开Standard task和Resource task → Download task data | Standard输出无新币种列；Resource输出USD／EUR，不输出跨币种绝对差／百分比。均只读，不完成任务。 |
| D023-UC10 权限／缺字段 | Resource task · missing currency；Buyer opens CBSL task | 缺币种不能下载实施数据，要求纠正批准范围；Buyer不显示CBSL任务表或下载入口。真实服务端权限NOT RUN。 |

所有Line／Part／参考币种均是合成示例。不同外部scenario会重建独立夹具，不把不同记录拼成一条生产E2E通过。

## 7. 给开发的修改清单

| 层 | 修改范围 | 要避免什么 |
|---|---|---|
| 前端 | 按明确交易上下文呈现字段；隐去普通新币种输入，保留币种单位；Resource逐行必填；状态锁／冲突保留数据并给恢复入口 | 只隐藏DOM却继续提交USD残留；把Currency driver填到Breakdown；在普通场景删除原币种。 |
| 后端 | 从权威Claim上下文生成字段规则；验证有效币种、身份、必填、版本与权限；普通newCurrency继承来源；Resource保存用户明确选择 | 接受任意profile／任意币种；把新币种覆盖Vendor Currency；把缓存字段直接传RPA。 |
| 文件 | 由同一schema生成列与必填规则；明确新旧模板版本，Part文本和source校验 | 直接接受错模板／旧版隐藏列；把候选价格编辑区当成完整上传文件；擅自恢复当前移除的Parts导入。 |
| 任务／输出 | 对冻结批准版本生成适用列和文件；保留原任务Comments／附件／权限／完成流程 | 标准任务输出一堆不相关币种／发票字段；Resource缺币种仍让实施团队猜；自动完成任务。 |
| Integration | 对接现有SAP价格／币种参考、CBSL／Digitide输出契约；保留标准WIPS同币种限制 | 擅自创建币种转换、直接跨币种调用标准WIPS机器人或假造新payload。 |
| 性能与兼容 | 统一schema读取，币种参考按版本复用；真实规模下测下载、序列化、列表及服务端验证 | 无实测就承诺毫秒或并发指标；从两行样本宣称大文件／多实例通过。 |

实现时与NEO-016的价格精度、019的Plant选择、020的Part标识／模板版本连续对齐。NEO-024同Claim重复Part／Plant规则是下一条，不在本包静默算成已完成。

## 8. 验证结果及退出条件

实际102项浏览器检查、31项纯模型检查、26项XLSX结构检查通过。结果逐项记录expected／actual，不把未执行项写通过。真实Chrome版本、页面SHA、输入夹具及时间在报告中。

| 验证范围 | 本次结果／边界 |
|---|---|
| 页面与下载 | PASS：普通隐藏／Resource逐行必填，signed change／直接价格，精确保存与读回，No／Escape，旧USD残留，参考Retry、状态锁、版本恢复，权限投影，实际XLSX下载字节与包内一致、CSV列和币种核对。 |
| 纯模型 | PASS：固定5位单位价格、非法输入／负价／空理由／未知币种／未知profile拒绝，标准继承原币种、Supplier Currency不变、stale revision、输出schema及CSV转义。 |
| 工作簿 | PASS：两份文件各2页、4／5个实际输入列、Part Text、数值类型／5位显示、native Stop／dropdown定义、版本、无宏及公式错误。本包2行示例，不证明完整导入或原生Excel操作。 |
| 布局 | PASS：价格页、Standard任务区、Resource任务区均测1920／1440／1024／768／390／360无页面横溢；页边距32／24／16，手机Select／确认可用。CSS200%另测无横溢，原生200% NOT RUN。 |
| 原生Excel／真实上传 | NOT RUN：没有Excel桌面开关保存测试；没有产品上传、粘贴绕过校验或完整旧文件迁移执行。 |
| 后端／数据库／真实权限 | NOT RUN：当前保存内存化，刷新重置；没有真实API、DB回读、多用户并发或服务端权限测试。 |
| BPM／SAP／WIPS／财务 | NOT RUN：不完成实际任务，不更新源系统，不执行FX／DoA／Reserve；RV79-09保留未复验。 |
| 商业签收与部署 | NOT RUN：币种适用范围、权限及完整模板仍待确认；未部署。 |

AntD lint未发现deprecated／a11y／usage问题。两条performance提醒来自外部11场景和每行3币种示例Select关闭virtual，均为固定小集合；正式大参考列表仍需按真实规模实现与验证。

独立包退出条件：来源可追、6张图可看、页面／候选模板／任务列一致、所有本地检查有实际结果、问题清单明确、源码／ZIP可校验。正式开发退出还需要完整上下文规则／模板／字段契约签收、全部任务类型矩阵、服务端验证与权限、真实保存回读及接口／财务回归。当前设计交付不代表这些均已完成。

## 9. 待确认问题（讲人话）

| 优先级 | 要确认什么／建议 | 例子和影响 |
|---|---|---|
| P0 | 到底哪些情况能选新币种？BRD是Resource或Currency，需求行更强调Resource currency change。需要完整字段值映射。 | Price Claim的Driver=Currency，或Lever=Currency，是否也显示？不能写成一个新Breakdown来绕过。 |
| P0 | Resource但币种不变时，是否仍要填新币种？本候选选Resource变币场景强制逐行选。 | 原GBP新GBP是否直接继承？同一个Resource类别不能靠猜决定必填。 |
| P0 | 已批准的旧数据缺新币种，谁纠正／是否重审？建议不能交实施团队猜。 | Resource新价90没写USD还是EUR；补币种可能改变商业金额与审批依据。 |
| P1 | 新币种选项由谁提供、按什么组织／有效期过滤？ | 不是所有ISO码都一定可用于这个Vendor／Plant；示例GBP／USD／EUR不是生产清单。 |
| P1 | Buyer是否能下载／使用Bulk模板？历史Training写CBSL only，新需求写As a Buyer。 | 开放Buyer会改变权限，不能仅凭模板显示就默认获准上传。 |
| P1 | 仍要完整Bulk Upload，还是保留当前移除入口、只优化现有编辑和任务？ | 当前包不恢复上传；若要恢复，需要另行确认入口、权限、完整模板、验证和回归。 |
| P1 | 请提供当前完整模板和每类任务实际发给Digitide的文件／payload。 | ATP、AMM、Resource、WIPS失败任务哪些列相同？本包只演示Standard与Resource两类，不虚构全部矩阵。 |
| P1 | 价格变更理由的必填、长度及数据库字段是哪一个？ | 改基准价原因和改目标价原因可能不同；不能一概写入CURRENT_VALUE_CHANGE_REASONING。 |
| P1 | 新模板保留Prefix/Base/Suffix，还是用完整Part Number？建议版本化兼容，不静默替换。 | NEO-020有分段及前导零验证；本包仅价区候选用完整Part文本，未决定旧上传文件最终迁移方式。 |
| P1 | 任务数据是附加表／下载文件，还是Digitide接口字段？请确认消费人和格式。 | Training Resource页只有Claim链接、Comments、上传；新表是为了少点一次，还是实施机器人确实要读此文件？ |
| P1 | 下游标准交易是否仍必须传币种字段，即使页面隐藏？建议存储／payload保留语义，不因UI隐藏改为空。 | 用户不填New Currency，但RPA仍可能要GBP；应由受控映射提供，不让每个前端自己猜。 |

## 10. 交付物与下一步

- NEO-023_Page_Proposal.html：独立英文页面，11个评审场景；不恢复上传，不连接真实系统。
- NEO-023_Consolidated_CN.html／.md：本文、6张实际页面截图、分类／Epic／ACT／FR／Page／UC及来源。
- OPEN_QUESTIONS_CN.md：上述11个业务问题，可单独分享。
- 两份Price_Template_Candidate.xlsx：Standard与Resource价区候选，原生格式／校验定义可检查；不替换当前正式模板。
- SOURCE_EVIDENCE.json及PAGE_VISUAL_CHECK／DOMAIN_CHECK／WORKBOOK_CHECK／VALIDATION.json：摘录、定位、SHA、真实本地结果及未测边界。
- design-source：React／AntD、统一profile manifest、字段模型、native模板builder、build／test／README；无额外业务规则台账。
- NEO-023_Review_Pack.zip：完整可编辑独立交接包，旧包与产品保持不变。

下一条NEO-024处理同一Claim下重复Part／Plant；本轮不自动开始。
