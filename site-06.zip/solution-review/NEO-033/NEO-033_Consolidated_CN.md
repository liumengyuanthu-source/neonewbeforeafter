# NEO-033 · 新预算汇率加载后刷新 GBP 金额

## 1. 本次结论

这条要解决的是：**Buyer 已经建好的未来财年 Claim，在正式预算汇率补齐后，GBP 金额仍停留在旧汇率。** 不应要求 Buyer 为了刷新金额，逐条打开、编辑和保存。[S1]

建议在预算汇率成功加载后，按财年、币种和发布版本触发重算；也可以由获授权的人点 **Review GBP refresh → Refresh GBP values**。两种入口使用相同的计算、权限和保护规则。普通列表 Refresh 只重新读取汇率列表，不能冒充 Claim 金额重算。[S6–S10]

本包提供独立英文页面、六张实际截图、模型和浏览器结果。**现有 prototype、共享 QA、业务配置和线上数据均未改。** 新增预算汇率发布事件、后台任务和持久化仍是实施提案；本次没有真实 Finance 黄金样例或接口调用。

来源写的是“所有未批准 IDs”。“审批中”“曾批准后取消”“部分批准”等边界没有完整定义。因此本候选先保护已批准／锁定记录，并把审批中的记录列为 Review required。**这不是把较窄候选当成已满足全部未批准场景。** 规则签认后仍须补齐这些边界。[S1、S14–S15]

## 2. 来源、改动分类与优先级

| 项目 | 内容 |
|---|---|
| 主记录 | Requested Changes 第34行，NEO-033；Finance / Finance Reserves；New functionality；L34 Should |
| 问题原文 | E34：未来财年尚无正式预算汇率时先装旧年汇率；正式汇率加载后，GBP 不会自动更新，除非 Buyer 恰好编辑该 ID |
| 目标原文 | P34：新预算汇率加载后，刷新所有未批准 IDs 的 GBP budget conversions；自动或统一按钮均可 |
| 主要改动类型 | **Application 内部前后端＋重算任务编排**；不是 UXUI only |
| Integration needed | 要接入已确认的预算汇率加载／发布入口及其版本；当前材料不足以确认可直接复用的“预算发布事件／刷新 API” |
| 可复用能力 | P18 汇率查看页、既有预算汇率表／暂存表、十进制计算、Claim 金额消费者及审批快照／锁定机制；是否完整兼容须验证 |
| 对接谁 | Finance 口径 Owner、NEO 应用／数据团队、现有预算汇率加载维护团队；月度 Monex／BODS 团队只在相关契约确需改变时参与 |
| 既有外部接口能否复用 | 月度 MFT M Exchange Rate 是 Monex→BODS→SFTP，不是本条预算汇率刷新接口证据；不能直接拿月度汇率代替 Budget rate |
| 是否新增架构 | 没有证据要求新增外部平台。先在既有应用／任务能力内增加版本化重算；是否需队列、outbox 或新表由实际部署和原子性要求决定 |
| Priority | 来源 Should，建议 P1；正式实施前 P0 前置是确认未批准范围、报价方向、GBP 消费者和版本政策 |

**同编号不要混用：** Archive 第36行 NEO-033 是 Clearing House DoA／FR10.6；NEO RTM 第37行 NEO-033 是 Parent 描述／FR3。本条不继承它们。[S1-ID-A、S1-ID-B]

## 3. Epic、User Story、FR、UC 与页面

| 层次 | 对应 | 本次影响 |
|---|---|---|
| Epic | CNP-231 建档／编辑／参考数据；CNP-235 Finance 消费者 | 采用现有 story_data 关联，不写 Jira，不发明 Epic |
| ACT-040 View Reference Data | FR19.02 / FR19.03 | 原能力是查看预算／月度汇率；**查看权限不等于全局重算写权限** |
| ACT-051 Reference data | FR19 及子项 | 关联配置维护，但不能据此给只读汇率表增添任意编辑权 |
| ACT-001 Create Claim / ACT-004 Update Claim | FR1.2、FR6 / FR6.1 | 不再依赖 Buyer 重新编辑，后台刷新同一 Claim 的预算 GBP 派生值 |
| 计算消费者 | FR7、FR8.1 | POA 的预算口径计算须一起核对；不能只改 Claim 的汇率引用，留下旧 GBP 结果 |
| ACT-029 Generate Reserve | FR17.5 | 下次 Draft 的输入版本和期间一致性要确认；不能自动重写已有 Final Reserve |
| ACT-041 Finance Claim Report | FR20 / FR20.1 | 报告、导出、缓存应与新版本一致，历史快照另行保留 |
| 主页面 P18 | Currency Exchange Rates | 新增评审／刷新及历史入口；不恢复源文件编辑器 |
| 消费页 P6 / P6.1 / P6.2 | Summary / Calculations / Finance | 同一 Claim 应读到一致预算版本；本候选通过金额详情查看，未修改这些现有页面 |
| P13 / P20 | Request Summary / Finance Report | 已审批请求保护；报表刷新范围待核对 |
| UC 场景 | 新预算替换旧预算、POA／LSP、零金额、已批准、审批中、失败／重试、并发变化 | S1–S6 仅为本包评审别名；没有新增官方 ACT、UC 或页面编号 |

原 BRD FR19.02 要求查看预算汇率，描述年度人工加载且不需要页面编辑；新 NEO-033 扩展的是**加载后的重算**。FR19.03 的月度汇率仍独立。[S2-4、S2-18、S2-20、S2-54、S2-55、S3–S5]

## 4. 关键交互与保护规则

| 情形 | 候选处理 | 业务含义 |
|---|---|---|
| 新预算版本已加载 | 先查财年／币种、明确报价方向和版本，再评审匹配 Claim | 没收到有效汇率不能沿用旧年汇率假装刷新 |
| 未申请、无批准事实、有效且未锁定 | 重算所有已明确的预算 GBP 消费者，绑定新版本 | 本币金额、Part 价格和数量不改变 |
| 已批准、部分批准、存在历史批准依据 | 保留旧值与批准快照 | 不因为汇率更新偷偷改变已批准商业依据 |
| Settlement 锁定 | Protected，不刷新 | 不触发外部实施或解锁 |
| 审批中／批准事实不完整 | Review required，保留原值 | 需要确认撤回重提、审批路线和金额基准政策 |
| 已是新版本 | Already current | 重复事件不重复改值／加审计 |
| 金额为 0 | 仍可更新旧汇率引用和审计，金额保持 0 | 0 不等于没有数据，也不能因数字没变而漏掉源版本 |
| 未明确的 GBP 计算消费者 | 整条 Line 挂起核对，其他合格 Line 可继续 | 不只刷新其中两列而留下同一 Line 的其他旧结果 |
| 评审后单据被修改／批准 | 保存前再核验；修改冲突保留新输入，新批准立即保护 | 不覆盖 Buyer 修改或审批证据 |
| 评审后来源版本／全量记录范围变化 | 整批停止，重新评审 | 不悄悄遗漏新到的 Claim，或用旧汇率写入 |
| 单条已知保存失败 | 保留该条原值，其他条继续；只重试失败／冲突条 | 成功条不能被第二次重算覆盖 |
| 提交结果未知 | Check refresh result 查原 intent | 查到原结果前不启动第二笔写入 |

Review 的筛选器和分页只改变看到的内容，**不缩小已明确的任务范围**。目前独立任务范围是一组财年＋币种；真实预算文件可能同时更新多个币种／财年，发布端必须完整列举所有变化并生成对应任务，不能从前端当前筛选值决定范围。这种整份文件的 fan-out／汇总服务本次未实现。

候选状态区分 Completed、Completed with review items、Completed with exceptions。存在 Review required 时不写“全部完成”。手工全无可更新记录时禁用提交；自动重复事件返回原批次，无需更新时只保留无更新回执。[S13–S15]

## 5. 金额、数据字典及接口边界

| 内容 | 已有证据 | 候选与差异 |
|---|---|---|
| Claim 预算汇率引用 | MCI_RISK_OPPORTUNITY.BUDGET_EXCHANGE_RATE，第702行，decimal(19,5) | 单一数值不是完整来源版本；需保留发布记录／财年／币种／方向及不可变版本 |
| Annual / Calendarised Local | 第715、719行；BRD FR1.2 | 保留本币基础，只按已签认 Budget rate 换算 GBP，不在本条重新定义本币期间分摊 |
| LSP Local / GBP | VALUE_LOCAL、VALUE_GBP，第731–732行 | LSP 实际金额和 Buyer Forecast 分开，不能用一个字段顶替所有 GBP 结果 |
| POA Part 计算输出 | Claim Part 第832–843行；FR7 / FR8.1 | 本候选只实现已知同币种预算口径，跨币种或月度 Part 依据不明时整条留待核对 |
| 参考汇率表 | MCI_CURRENCY_EXCHANGE_RATE，第1874–1884行；M_EXCHANGE_RATE、Y_EXCHANGE_RATE 分开 | 表中字段不证明已有发布事件、不可变版本或批量重算服务 |
| 年度汇率暂存 | MCI_STG_Y_CURRENCY_EXCHANGE_RATE，第2966–2973行 | Y_EXCHANGE_RATE 是 varchar(50)，加载时须校验，不从“字符串有值”推断可计算 |
| 报表派生列 | MCI_STG_REPORT_EXTRACT：EXCHANGE_RATE、ANNUAL_FORECAST_GBP、CALENDARIZED_FORECAST_GBP，第2470、2472、2476行 | 这些是报表暂存，不是 Claim 主表同名列存在的证据；真实持久化／查询／导出映射待确认 |
| 月度外部 Feed | Integration CSV 物理第25行；Scheduler Sheet1 第9行 | Monex 月度来源独立；不拿来证明年度 Budget 的接口／报价方向 |
| 年度提醒 | Scheduler Sheet1 第13行 | 从 March 起给 Super Users 发预算汇率提醒；提醒不是加载成功事件或 Claim 重算结果 |

**独立样例（合成，非 Finance 签认值）：** FY2028–2029，USD→GBP；旧 0.80000、新 0.75000，报价明确为 1 USD 等于多少 GBP。乘法只对该方向成立。

| 同一记录 | 本币基础保持 | 旧 GBP | 新 GBP |
|---|---|---|---|
| MCI-00057 POA Annual Forecast | USD 10,000 | 8,000 | 7,500 |
| 同一 POA Calendarised Forecast | USD 8,000 | 6,400 | 6,000 |
| 同一 POA Part annual / calendarised | Start 10→New 9 USD；annual volume 1,000，calendar volume 800 | −800 / −640 | −750 / −600 |
| MCI-00056 LSP Forecast | Annual／Calendarised 均 USD 20,000 | 16,000 | 15,000 |
| 同一 LSP Value | USD 15,000，独立于 Forecast | 12,000 | 11,250 |
| MCI-00055 Approved | 已批准 Annual GBP 24,000 | 24,000 | 24,000；批准和 Final Reserve 版本均不动 |

用精确十进制字符串／BigInt 计算，中间不先舍入，候选存储输出按复用 decimal 工具的5位边界，金额界面2位。**真实舍入、正负号及 Finance 样例仍待签认。** Monthly GBP、手工 Buyer Performance、批准请求及 Final Reserve 快照保持不变；本条不自动触发重新审批、SAP／WIPS、Journal 或付款。

现有计算引擎要求 asOf 位于 Claim 财年内，对未来财年有明确约束。本候选没有把系统时钟“调到未来”来伪证支持，也没有调用该引擎；仅独立演示已知同币种 Budget 公式。**正式实现须改造／核验未来 FY 消费者，不是只把当前引擎循环调用一遍。** 已有 FR16-Q06 的报价方向缺口、NQA-72 的“仅参考查看”范围均保留。[S8、S11–S13、S17–S20]

REFRESH_SERVICE_PROPOSAL.json 和 CONSUMER_MAPPING.json 给出候选事件／请求／结果概念，没有冒充既有 API 路径、实际 payload 或已迁移数据库结构。

## 6. 独立页面与六张实际截图

复用 NEO theme、JLR Emeric 字体和 Ant Design 6.7.0，桌面／平板／手机32／24／16边距，行首固定详情图标，金额右对齐，表格内横向滚动。主页面不放 Pending i。灰色顶部情景切换栏是评审工具，不是生产控件。

### S1 · 新预算已加载，汇率只读

![Loaded budget rate](screenshots/01-loaded-budget-rate.png)

合成 Jack Edwards 具有独立刷新权限，选择2028–2029、USD，看到 Budget-FY28-v2、0.75000及明确报价方向。页面不新增编辑源汇率的输入框。

### S2 · 看同一批单据的刷新前后金额

![Review before and after GBP amounts](screenshots/02-before-after-refresh-review.png)

筛选 Update 看到3条，仍保留全批12条评审范围。Description 区分未生成业务 Line ID 的记录，不制造新业务编号。

### S3 · 已批准依据保持原样

![Approved snapshot protected](screenshots/03-approved-snapshot-protected.png)

MCI-00055 的 Annual GBP 前后均24,000；旧预算版本、Approved version 1和 Final Reserve version 1保持。Return／Cancel 不会执行写入。

### S4 · 结果明确列出更新、保护和待核对

![Refresh results and review items](screenshots/04-refresh-results-and-review-items.png)

FX-033-1 为内部刷新批次，不替代 Line／Request ID。默认更新3条，另有保护／待核对5条；结果为 Completed with review items，不声称全量业务验收。

### S5 · 单条失败，成功条保留

![Partial failure and retry entry](screenshots/05-partial-failure-retry-entry.png)

LSP 刷新失败仍保留旧金额，其他2条完成。Review failed Claims 只重试失败C2，原成功记录的审计不再增加。

### S6 · 自动触发与重复事件去重

![Automatic refresh and event deduplication](screenshots/06-automatic-refresh-and-event-dedup.png)

合成 Budget rate loaded 事件与手动使用同一策略，Actor 为 System · Budget FX refresh。重复发送相同版本只返回原批次。真实定时器、队列、回调和身份系统未连接。

## 7. 操作步骤与本地验收

| 场景 | 谁、填什么、点哪里 | 预期／实际本地结果 |
|---|---|---|
| 手工主线 | Jack → Budget rates → FY2028–2029 / USD → Review GBP refresh →核对→Refresh GBP values→Confirm refresh | POA7,500／6,000；LSP Forecast15,000、Value11,250；零金额更新引用；3条更新，保护项不动 |
| 查看依据 | Review 中筛选 Protected→行首眼睛→Approved commercial terms | 同一已批准记录前后值／旧版本一致；Back to refresh review 保留原评审 |
| 导出 | Refresh history→Download result | 实际下载CSV含12条结果，含原／新金额、版本、Actor、批次；不只导当前页 |
| 失败与重试 | 外部选 One Claim refresh fails→执行→Review failed Claims→再确认 | 失败LSP旧12,000不变；重试后11,250；首条成功Claim只有一条审计 |
| 审批／编辑竞态 | 选对应外部场景→Review→确认 | 新获批准记录Protected；新输入保留并Conflict；其他安全条继续 |
| 来源／范围变化 | 选 A newer budget rate arrives 或 A new Claim arrives after review→确认 | 全批停止；重新打开评审后显示新版本或新增Claim |
| 未知结果 | Refresh result not received→执行→Check refresh result | 原intent回读，同一批次；不重复重算 |
| 权限 | Reference viewer 只查看评审，无提交；Buyer 无参考权限不展示数据 | 没有因ACT-040查看能力获得新写权限；仅合成权限验证 |
| 全量分页 | 选27 Claims→翻页→执行 | 27条全评审，18条更新，分页／过滤不缩小后台候选范围 |

**实际结果：113项浏览器检查、159项模型检查通过。** Expected／Actual／PASS分别写入 PAGE_VISUAL_CHECK.json 和 DOMAIN_CHECK.json；实际下载内容见 EXPORT_READBACK.csv。另有27条模型输出例，不能称作真实接口回执。

覆盖：零金额、缺汇率／非法值／方向不明／重复有效率、未知消费者、源版本冲突、记录修改／批准、失败重试、同intent防重复、自动事件去重、全量分页、批准／月度／手工／Final Reserve不变、手机与键盘操作。检查6种视宽和CSS200%；原生浏览器200%缩放、真实负载／并发和辅助技术认证 NOT RUN。

真实年度源数据、权限／后端API／数据库事务、后台worker恢复、BPM审批／DoA／SLA、同一记录跨P6/P13/P20真实回读、月结／报表与Finance签认、现有prototype回归及部署均 **NOT RUN**。本地测试不解除这些缺口。

## 8. 开发依赖、顺序与退出条件

| 顺序 | 需要谁／交付什么 | 退出条件 |
|---|---|---|
| 1 · 口径冻结 | Finance／业务Owner | 未批准范围、报价方向、币种／FY、有效版本、舍入、历史审批及期间政策签认；有POA／LSP黄金样例 |
| 2 · 消费者盘点 | 应用后端／数据／报表团队 | 每一预算GBP字段的输入、公式、写入／查询／导出、缓存和版本清楚；不能只更新report staging |
| 3 · 加载事件 | 预算加载维护团队＋应用团队 | 已校验预算提交后发不可变发布事件；覆盖整份文件变化范围；坏文件／重复事件有明确结果 |
| 4 · 重算服务 | 后端／数据团队 | 服务端权限／全量查询／状态复核／逐条CAS／幂等／断点与原结果回读通过；来源变化不会混版本 |
| 5 · 前端接入 | 前端团队 | P18评审／结果与真实API绑定；新入口遵守NEO设计，不恢复源汇率任意编辑 |
| 6 · E2E／Finance | QA＋Finance＋流程Owner | 同一条POA／LSP从源加载到Claim／报告回读一致；批准／Final不变；失效重试与多币种文件范围验证有证据 |

Flowable 可在确有需要时编排后台工作和等待，但金额计算属于计算服务，不能把任务状态“完成”当金额正确。是否触发重新审批、邮件或SLA是另外的已批准流程规则，本候选不新增这些副作用。

**本包退出：** 独立页面、六图、源引用、候选数据映射、问题清单、本地实际结果、重建源文件和ZIP齐全且可回读。**生产退出：** 上述真实服务、跨页面及Finance条件通过；本包不代表生产完成。

## 9. 待业务／技术确认的问题（讲人话）

| 优先级 | 问什么 | Context 与例子 | 建议／影响 |
|---|---|---|---|
| P0 | “未批准”包含哪些状态？ | 正在FBP评审的USD10,000原GBP8,000，新率后7,500；能直接变吗？曾批准后撤销、部分批准怎么算？ | 先冻结旧审批依据；确认撤回／重新评审方式。未确认前In approval留Review required，不能算全量已覆盖 |
| P0 | 新预算报价方向和黄金例子是什么？ | 0.75是GBP/USD还是USD/GBP？误用乘除会让同一笔10,000得到不同结果 | Finance提供正式版本／有效FY及POA、LSP核对例；当前0.75仅合成 |
| P0 | “所有GBP换算”到底有哪些消费者？ | Annual Forecast已更新，但Part Performance、LSP Value、导出还用旧率，会对不上 | 按CONSUMER_MAPPING逐项签认；未知整条先挂起，不能只改汇率引用 |
| P0 | 正式预算从哪里装入，怎么确认整份成功？ | 一份文件同时更新USD和EUR，只刷新用户当前USD筛选会漏EUR | 加载方提供现入口／回执／整份变化清单；按财年币种fan-out，真实聚合未实现 |
| P1 | 谁能点全局刷新？ | Super User现在能看汇率，但是否所有Super User都能改全量Claim？ | 建立独立写权限并服务端校验；合成Jack不代表现网授权 |
| P1 | 已保存Draft／Final Reserve和历史报告如何处理？ | 新预算7,500，已签Final仍8,000；是保留并说明版本，还是另出调整？ | Final／已审批快照不原地重写；Draft重建／报告current-vs-snapshot规则由Finance确认 |
| P1 | 审批金额或DoA边界变化时要不要通知／重审？ | 刷新导致一笔待提交单跨审批边界，下一次申请用哪版金额？ | 下一请求读已确认新版本；在途请求不暗改。是否通知另签，不从本需求推定 |
| P1 | 精度、负数、未来FY及失败补跑口径是什么？ | 未来FY尚未开始，现引擎asOf限制；0.33333换算需如何舍入？整批断电后怎么接着跑？ | Finance签认金额规则，技术提供未来FY和幂等恢复方案；当前局部公式／内存回执不等于后台验收 |

这些是本包评审问题，不另建或改写共享QA台账。已有FR16-Q06沿用；缺资料处在HTML黄色突出。

## 10. 交付和范围

NEO-033_Page_Proposal.html 是可离线打开的英文交互页；本HTML／MD合并方案与截图；SOURCE_EVIDENCE.json保留原文／完整路径／定位／SHA；REFRESH_SERVICE_PROPOSAL.json、CONSUMER_MAPPING.json均标明候选；design-source含可编辑代码、原样theme／decimal、字体、构建脚本及验证脚本。独立ZIP不带node_modules，不包含任何实际生产记录写入。

下一项 **NEO-034：Reporting Category 与 Lever 组合约束／提示**。这不是本条预算刷新中的新增规则。

### 10.1 来源索引

本轮读取2026-11-13。完整原文、路径、行号／表行及SHA见SOURCE_EVIDENCE.json。文档日期不等于实际生产配置或截图日期；现有代码是离线观察，不是本轮现网复现。

| ID | 文件 | 定位 | SHA前12位 |
|---|---|---|---|
| S1 | NEO Business Requirements (added China requirements) 1.xlsx | RTM for Requested Changes row34 (1-based) | b83b74cb3eb2 |
| S1-ID-A | NEO Business Requirements (added China requirements) 1.xlsx | RTM - Archive row36 (1-based) | b83b74cb3eb2 |
| S1-ID-B | NEO Business Requirements (added China requirements) 1.xlsx | NEO RTM row37 (1-based) | b83b74cb3eb2 |
| S1-NEXT | NEO Business Requirements (added China requirements) 1.xlsx | RTM for Requested Changes row35 (1-based) | b83b74cb3eb2 |
| S2-4 | Material Cost & Inventory - BRD V3.1.docx | Table6 row4 (1-based) | 0d6aedc1538c |
| S2-18 | Material Cost & Inventory - BRD V3.1.docx | Table6 row18 (1-based) | 0d6aedc1538c |
| S2-20 | Material Cost & Inventory - BRD V3.1.docx | Table6 row20 (1-based) | 0d6aedc1538c |
| S2-54 | Material Cost & Inventory - BRD V3.1.docx | Table6 row54 (1-based) | 0d6aedc1538c |
| S2-55 | Material Cost & Inventory - BRD V3.1.docx | Table6 row55 (1-based) | 0d6aedc1538c |
| S3 | NEO User Training.docx | Body paragraphs266–273 (1-based): Super User View Exchange Rate, not a claim-refresh permission | bf942f7a70e6 |
| S4 | story_data.json | ACT001/004/040/051/029/041; CNP231/CNP235 associations, new refresh action not currently a separate ACT | a2e47d1cde32 |
| S5 | scope.json | Existing P18 rate page, P6/P6.1/P6.2/P13/P20 consumers; no new official page IDs | 74aae9869a99 |
| S6 | ExchangeRates.tsx | Numbered current source lines (1-based), read-only inspection; not live production behavior | 02129b1797f7 |
| S7 | exchange-rates.ts | Numbered current source lines (1-based), read-only inspection; not live production behavior | 914eef46248e |
| S8 | readiness.ts | Numbered current source lines (1-based), read-only inspection; not live production behavior | df3dc292bf35 |
| S9 | claim-update-drafts.ts | Numbered current source lines (1-based), read-only inspection; not live production behavior | 998fb0e96819 |
| S10 | draft-session.ts | Numbered current source lines (1-based), read-only inspection; not live production behavior | 79e6681cd2f8 |
| S11 | calculation.ts | Numbered current source lines (1-based), read-only inspection; not live production behavior | 68ad563730b6 |
| S12 | calculation-context.ts | Numbered current source lines (1-based), read-only inspection; not live production behavior | b44161996aa1 |
| S13 | decimal.ts | Numbered current source lines (1-based), read-only inspection; not live production behavior | 727cc261b26b |
| S14 | locks.ts | Numbered current source lines (1-based), read-only inspection; not live production behavior | f29c970d2c72 |
| S15 | request.ts | Numbered current source lines (1-based), read-only inspection; not live production behavior | 1d601c037626 |
| S16 | index.ts | Numbered current source lines (1-based), read-only inspection; not live production behavior | 82b56dcd8c92 |
| S17 | review-data.json | Existing FR16-Q06/UI-FX-REACT-01 and NQA72; reference-list local acceptance does not cover calculation refresh | 8fcbf8fdf490 |
| S18 | NEO_数据字典.xlsx | 字段字典 rows702/715–741/832–843/1874–1884/2470–2476/2966–2973: budget reference, monetary outputs and staging; not a refresh-job schema | 22342fd6253c |
| S19 | Integrations - 2026-11-09_0941(Sheet 1).csv | Physical CSV row25 monthly Monex feed; not evidence of a budget-rate claim-refresh endpoint | 5e40049996bb |
| S20 | Scheduler Processes - 2026-11-09_0944.xlsx | Sheet1 rows9/13 monthlyFX loading and budget-rate reminder; neither proves bulk claim recalculation | 390f6aad6886 |
| S21 | NEO_UXUI_PRINCIPLES.md | NEO standard; reference list refresh separate from business recalculation, 32/24/16 edges, exact source versions | 2722dc05eae2 |
