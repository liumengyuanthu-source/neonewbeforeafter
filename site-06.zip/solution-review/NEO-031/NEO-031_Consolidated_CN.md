# NEO-031 · Annualised POA impact：恢复12个月口径

<!-- NEO031_EXPLANATION_START -->
## Before / After 更新说明（2026-11-16）

Annualised value 必须表示完整12个月的 POA 影响；不能重复生效日至 Claim 财年末的 Calendarised 金额。

| 项目 | 说明 |
|---|---|
| Before：历史问题 | 生效日在上一财年时，Annual 逐行值及汇总重复 Calendarised，可能覆盖18个月或更长。改名为 Full Fiscal year effect 并加 tooltip，没有修正计算。 |
| After：计算修正 | 按完整12个月的年度量计算每条 Part 的 Annual，再汇总为 Annualised value。Calendarised 继续单独按适用期间计算，不能共用 Annual 结果。 |
| After：页面显示 | P6.1 Calculations 将 Full Fiscal year effect 改回 Annualised value，删除解释“可能不满／超过12个月”的补丁 tooltip；保留 Annual (£mils) 列，并同步修正列值和汇总。其他布局及有效说明保持不变。 |
| 影响 | 纠正年度比较及使用该年度字段的后续计算／导出，避免将跨年累计金额误当年度值。已有批准和历史快照保留，不因改标题自动覆盖或重算。 |

### 同一笔数据，Before / After 怎么看

沿用现有设计样例：Claim FY 2026–2027，生效日 01 Oct 2025。年度窗口暂按 Claim 财年 01 Apr 2026–31 Mar 2027；两条 Part 的12个月影响各 £36,500，合计 £73,000（0.073 £mils）。从生效日到财年末的 Calendarised 为 £109,400（0.1094 £mils）。历史缺陷若重复 Calendarised，Annual 也会显示 £109,400；After 的 Annual 应为 £73,000，而 Calendarised 仍为 £109,400。这个例子展示两种口径，不能直接把任意18个月总额乘12/18。

Before 截图继续使用冻结的 NEO prototype；上述缺陷来自需求原文，不是本轮现网复现。Finance 仍须确认年度窗口、Runout 和舍入规则。样例沿用既有独立设计，不是 Finance 签收金样；本次更新说明，不改计算引擎或主原型。

Reference: NEO-031 / Requested Changes E32, P32; BRD FR7 / FR8.1; NEO Frozen Turnover (FTO) Overview pp.3–7; existing NEO-031 assessment sections 4 and 6, scenario S1.

<!-- NEO031_EXPLANATION_END -->

## 1. 本次结论

本条要求修正 Annualised POA value：不能因为生效日在上一个财年，就把生效日至本财年结束的18个月或更长金额当成12个月。恢复标题“Annualised value”，逐行 Annual (£mils) 和汇总使用同一年度计算依据；Calendarised 继续单独显示。[S1]

**当前源码已经把 Annual 与 Calendarised 分开计算，不能声称本轮复现了原系统所报的重复金额错误。** 当前React页面仍叫 Full Fiscal Year Effect，标题与新要求不一致。引擎Annual取Claim当财年FTO；Calendarised另加上一财年追溯量。原问题是历史报告，本包提供独立页面、对照案例和待确认点，没有改现有prototype。[S6、S9]

建议以Claim财年作为12个月窗口，依据是BRD FR7的Current Full Year Part Volumes。新需求没有明确写“从生效日起滚动12个月”，也没有签认Runout和正负号；这些不能自行补成新财务政策。本页沿用现有引擎作候选对照，Runout等未确认情形阻止保存，不宣称是Finance认可的标准答案。[S1、S2-18]

## 2. 原始要求、分类与优先级

| 项目 | 本轮对应 |
|---|---|
| 主需求来源 | Requested Changes第32行；NEO-031；Finance / POA Input；Existing functionality - Update/correct logic；L32=Must |
| 明确改动 | P32：Full Fiscal year effect改回Annualised value；对应Annual (£mils)列与汇总代表恰好12个月，不随Effective Date至Claim FY末的跨度增长 |
| 主要改动类型 | **应用内部前后端计算＋页面文案**；不是UX/UI only。服务、数据库、报表和历史快照须按确认口径做兼容性核验 |
| Integration needed | 本条日期／年度口径修正本身未证明需要新增外部接口。需复用实际可用的FTO、价格、FX来源并绑定版本；契约不足仍是联调依赖 |
| 新架构 | 未发现必须新增系统／架构的证据。现有计算服务与版本化结果可评估复用，不能从一个新标题推导出新平台 |
| 优先级 | 来源Must；建议P0核对金额与公式，先确认Finance样例后改正式服务。影响全年目标、审批值与后续财务引用，不能只换标题结项 |
| 实施边界 | 独立候选页、模型和截图；现有产品／prototype／共享QA／Jira未修改，未部署 |

**同编号隔离：** RTM - Archive第34行NEO031是Enquiry Task / FR10.4；NEO RTM第35行NEO031是Edit parent / FR3。均不是本次Finance年度计算要求，不能把它们的FR继承过来。[S1-ID-A、S1-ID-B]

## 3. Epic、User Story、FR、UC与页面

| 层次 | 对应 | 注意 |
|---|---|---|
| Epic | 现有故事映射CNP-231 | 沿用现有映射，不创建或写入Jira |
| 主FR | FR7、FR8.1 | FR7定义年度和Calendarized Buyer Performance；FR8.1定义计算明细和汇总 |
| 关联FR | FR1.6输入Part；FR8 Actual／Remaining财务影响 | FR8的GR实际＋E2SC剩余预测不是本次FR7 Calendarised FTO值，不能混成一个数字 |
| ACT-001 Create Claim / ACT-004 Update Claim | 输入日期、价格、Part后关联计算 | 是上下游关联，不把本条新增成其已验收范围 |
| ACT-008 Update Buyer Performance | FR7下的**手工**Buyer Performance与NAF动作 | 现有ACT008并不等于自动POA计算；不得将本条全部自动计算强塞进手工动作 |
| ACT-054 FTO Refresh | BRD Appendix7.2 CR10，关联FR8.1 | 刷新来源后需要重算，真实角色和刷新过程沿用其规则。灰色评审工具不代表Buyer有生产FTO上传权 |
| UC场景 | 上财年生效、当财年生效、闰年、Runout、缺源、版本变化、完整导出 | 本包用S1–S6作评审别名；未新增正式UC编号 |
| P6.1 Calculations / Financial Impact | 主要改动页 | 沿用已登记页面编号，独立候选不改页面目录 |
| P6.1.1 Manage FTO Part Volume | 关联输入维护 | 不因本条重建其业务表单／权限 |
| P19 / P19.2 FTO Processor / FTO Data | 来源版本与匹配依赖 | 不在本候选执行上传或替换整年FTO |

映射依据现有story_data、143页scope和Training FTO Refresh / Update Buyer Performance段落。[S4、S5、S19]

## 4. 规则与口径：哪些有依据，哪些尚未确认

| 内容 | 有来源的描述／本候选行为 | 未决或限制 |
|---|---|---|
| 年度窗口 | FR7：当财年Full Year FTO；候选2026-04-01至2027-03-31，共12个月／365天 | Finance仍需确认新要求是否沿用Claim财年；不可自行改为Effective Date起滚动12个月 |
| 闰年 | FY2023–2024同样12个月，但366天 | 不硬编码365天；日期端点含首尾是候选参数，仍需签认 |
| Annual | 价格差额GBP × Current Full Year Part Volumes | 不叠加上一财年的追溯量。候选使用已有精确有理数算法，无价格精度规则变更 |
| Calendarised Buyer Performance | 上财年适用量＋当财年适用量，再乘价格差额 | 原BRD和现引擎只明确上一财年；更早年份不静默截掉，标出不能完成 |
| Runout | FR7已有按FY起点至Runout分摊Annual量的描述；候选保留现算法展示差异 | 新要求“恰好12个月”是否应标准化全年暴露？未确认前本情形不可保存；不能称已满足全部新要求 |
| 金额正负号 | 当前引擎New − Start；历史FTO图价格上涨却显示负影响 | **资料不一致**，候选不翻转现有源码；由Finance确认Risk／Opportunity与报表方向，样例不是golden case |
| 汇率 | FR7区分Budget与Monthly；候选复制当前选择实现 | 无实际FX或重复时不能默认1。默认GBP例子不等于跨币种已验收 |
| 缺FTO | FY／Part／Vendor／Plant或carline匹配，缺量不能算 | 未知显示—，不是0；重复匹配也阻止保存 |
| 真实0 | 匹配到数值0的FTO结果显示0 | 可保存零计算供核查，不表示满足“至少一个有FTO量的Part”正式审批条件 |
| Annual与Finance Actual | 使用不同输出／数据来源 | 本候选不把FR8 actual、remaining或Reserve伪造成0；不展示其未取到的结果 |
| 保存 | 明确Recalculate后再Save calculation；来源／输入变更使当前结果过期 | 内存演示，刷新页面会重置。未修改已批准Request或历史数据，真实持久化／失效策略待确认 |

FTO Guide第3页说明Price delta × FTO volume及四维匹配，第4页可见Annual与Calendarized两套列／汇总，第7页说明FTO Refresh后重算；这是历史材料，不证明当前生产调度仍是该时间。[S3]

精度边界另有实际发现：两行各£0.000005，现引擎逐行输出到5位后各为£0.00001，但精确加总后输出为£0.00001，和显示行相加£0.00002不同。本候选识别该差异并阻止保存／导出，等待Finance确认舍入位置；没有悄悄改引擎来凑相等。该边界不计为已解决的财务规则。

## 5. 字段与数据字典

| 页面／计算项 | 字典字段或对象 | 处理建议 |
|---|---|---|
| Part、Plant、价格、币种、Runout | MCI_RISK_OPPORTUNITY_PART，第814–831行 | 保留原字段含义，不为改标题改写存储语义 |
| FTO匹配与量 | FTO_VOLUME_CALCULATION，第832行；CURRENT_FULL_YEAR_PART_VOLUMES，第837行 | Annual量来自匹配成功的同一来源版本；Runout适用范围待确认 |
| 上财年Calendarised量 | PRIOR_YEAR_CALENDARIZED_VOLUMES，第833行 | 与Annual分列，不再借Annual字段承载较长期间 |
| 当财年Calendarised量 | CURRENT_YEAR_CALENDARIZED_VOLUMES，第834行 | 保留期间边界与来源 |
| Annual (£mils)／Annualised value | FULL_FISCAL_BUYER_PERFORMANCE_CALCULATION，第835行 | 库字段名可以保留兼容；页面标题变更不强迫重命名数据库列。原值GBP和展示£mils应分清 |
| Calendarised (£mils) | CALENDARIZED_BUYER_PERFORMANCE_CALCULATION，第836行 | 不与第835行共用数值，不把FR8 financial字段替代过来 |
| FR8 Actual／Remaining | 第838–843行财务影响字段 | 属于另一计算输出，本轮未运行真实GR／E2SC对账 |
| 计算窗口、输入／FTO／FX／公式版本 | 当前引擎有input、sourceVersion、version | 字典未证明已有完整结果快照／版本审计契约。先确认实际服务和表结构，再决定是否需要新增字段／对象 |

字典提供decimal(19,5)结构，不足以签认财务公式、四舍五入、币种、记录粒度或业务权限。本包不借NEO-031提前解决下一条NEO-032的SAP／WIPS价格精度问题。[S15]

## 6. 独立页面与六张实际截图

沿用NEO Ant Design主题、JLR字体、32／24／16边距；水平Tabs、数字右对齐、全量总计后分页。没有左侧只读步骤栏、Pending i或页面AI说明。灰色工具栏只用于独立评审切场景与模拟来源变化；不是正式业务能力。

### S1 · 上财年生效，Annual仍只取12个月

![Previous FY effective date](screenshots/01-prior-fy-annualised.png)

Alice Morgan（合成Buyer），POA，Claim FY2026–2027，Effective Date01 Oct2025。两条Part的Annual各£36,500，全年总£73,000／0.073 £mils；Calendarised合计£109,400／0.1094 £mils。Annual没有重复Calendarised。正负号沿用当前引擎，非Finance签认政策。

### S2 · 查看计算期间、量和来源版本

![Calculation period and source](screenshots/02-calculation-period-and-source.png)

Calculation details明确Annual01 Apr2026–31 Mar2027、365天、来源版本；同屏查看Annual量、Prior／Current Calendarised量及原始GBP。技术formula版本在导出和证据里，不塞到每行业务文案。

### S3 · 闰年仍是12个月

![Leap year annualised basis](screenshots/03-leap-year-12-month-basis.png)

FY2023–2024为366天。使用相应FTO后Annual£73,200，Calendarised£36,600；不会用365硬除造成偏差。

### S4 · Runout保留差异，不假装规则已确认

![Runout requires Finance decision](screenshots/04-runout-policy-check.png)

首条Part Runout30 Sep2026，原规则把全年量分摊至183天。Annual汇总£54,800，其中Runout£18,300；界面明确需确认Runout口径，Save和Export均阻止。这个候选分支没有通过正式业务验收。

### S5 · 缺FTO不显示一个看似有效的0

![Missing FTO blocks incomplete result](screenshots/05-missing-fto-blocked.png)

缺哪条Part直接点名；总额—，Save／Export阻止。上一财年FTO缺失时，已知Annual可以显示，但Calendarised仍—，不能把不完整计算保存为完整结果。

### S6 · 原版本可回读，新来源不覆盖旧结果

![Saved calculation version readback](screenshots/06-saved-calculation-version-readback.png)

先Save CALC-031-1，再模拟来源更新、Recalculate并Save CALC-031-2；打开第一版仍为Annual0.073、Calendarised0.1094及原来源。保存为本地内存演示，不是数据库验收或批准版本自动迁移。

## 7. 用什么数据、点哪里、看什么

| 场景 | 用户／输入／操作 | 独立页面预期 |
|---|---|---|
| 主例 | Alice；首Part10→11GBP、FY FTO36500；次Part20→22GBP、FTO18250；上财年FTO同量；Effective01 Oct2025 | Annual73000；Calendarised109400；12个月窗口清楚 |
| 当财年生效 | Edit effective date→01 Oct2026→Apply date→Recalculate | Apply后旧结果标过期；重算后Annual仍73000，Calendarised36400 |
| 闰年 | 外部评审选择Leap-year | Annual73200；Calendarised36600；12个月／366天 |
| Runout | 外部评审Runout30 Sep2026 | 原规则结果54800／91200；分列Runout；等待政策确认，禁止Save |
| 13条Part | 外部评审13 parts，翻到第2页、Export CSV | 第2页3条，Annual仍474500；实际CSV13条＋TOTAL，不只导出当前页 |
| 来源变化 | Save→外部Simulate source update→Recalculate→Save→Saved calculations→Open第一版 | 新Annual146000；旧版73000不动。外部工具只是测试控制，不是Buyer生产FTO权限 |
| 保存失败／未知 | Save fails／Save result not received场景 | 已知失败保留输入再试；未知结果先Check save result读原intent，禁止再建第二次保存 |
| 只读 | Read-only Finance user合成场景 | 可看、可导出完整数据；不能改日期／保存。实际授权矩阵仍须核实 |

上述数字是可重算的合成算术对照，测试前已定义预期；不是Finance签字golden cases。USD缺FX场景只验证拒绝，不宣称真实汇率或币种政策已齐。

## 8. 系统／接口影响和开发顺序

| 层 | 修改或核验 | 来源／限制 |
|---|---|---|
| HTML／前端 | 恢复Annualised value；Annual逐行与汇总一致；Calendarised独立；保存版本、加载／空／错误／重试 | 当前CalculationResults.tsx、Calculation.tsx、calculation-display.ts可复用；先做实际差异，不重写整页 [S8–S10] |
| 计算服务／应用后端 | 确认年度窗口、FTO匹配、Runout、FX、精度；同一输入／来源／公式版本输出；服务重算而非信任浏览器汇总 | 本候选复制现有引擎，真实后端未执行。原系统“把Calendarised复制给Annual”的实现未收到，不能直接指定其根因 |
| 数据库／缓存／报表 | 排查两个金额字段写入、缓存、报表映射；保留旧结果与批准依据；重算需要明确版本策略 | 第835／836行分列已存在，但不证明实际写入正确；是否新增计算快照待实际schema核对 |
| SAP／Apigee | 可评估复用MCI_getPartDetails及MCI_getPartPriceDetails获取Part／价格 | integration CSV物理第7／8行是现有接口目录；未给本次完整价格粒度／有效期／回读契约，不擅造新endpoint [S16] |
| FTO | 历史Guide说明GPF协同采购准备FTO，缺Part联系FBP；需要FY、Vendor、Part、Plant／carline和版本 | 未收到当前正式文件、完整契约和生产调度；本包不上传或替换FTO [S3、S14] |
| FX | Monex→BODS→SFTP→NEO月度FX；Budget有单独维护提醒 | CSV第25行；Scheduler第9／13行。资料记录的调度不是当前部署实证，Budget／Monthly不可混用 [S16、S17] |
| E2SC／GR | FR8 Actual与Remaining Financial Impact另外核对 | E2SC目录CSV第24行、Scheduler第15行说明BODS／EDW通路；不是FR7全年FTO的自动替代 [S2-19、S16、S17] |
| BPM／审批 | 正式申请使用哪一版金额，来源更新是否触发重审或只影响新计算，须先签认 | 不自动改已批准Request／Settlement，不因页面数字更新便修改审批结果或Implemented |

建议执行：先签认Finance最小golden cases→定位服务／DB／报表实际映射→只修差异并更新HTML／前端／服务→同一版本回读→审批引用／历史快照回归→接口联调与业务验收。已有层满足要求则核验兼容，不为本条增加新的平台流程或接口。

## 9. 讲人话的问题清单

1. **“12个月”从哪天算？** 例：生效01 Oct2025、Claim FY2026–2027，Annual是01 Apr2026至31 Mar2027，还是从生效日起12个月？BRD支持前者，本页先按前者展示，需Finance签认。
2. **Runout以后没有量，还要年化成全年吗？** 例：9月底停产，原规则只取半年量。新要求是否仍保留Runout半年的年度影响，还是展示全年标准化暴露？本包保留旧结果比较，未确认不保存。
3. **价格上涨的影响是正还是负？** 例：10涨至11，现引擎算+1；历史截图把上涨影响写成括号负数。请按Risk／Opportunity、Buyer Performance和Finance报告分别给一例。
4. **首尾日期怎么计，超过上一财年怎么算？** 例：01 Oct至31 Mar是否两天都计入；2024年生效、2026财年Claim要不要追溯全部年份？当前只明确上一财年，不能静默少算。
5. **汇率和金额如何定版？** 例：同币种用预算汇率、换币用哪个月，汇率更新是否影响原批准单？逐行先舍入再相加，还是精确相加后汇总舍入？请给Finance认可样例和容差。
6. **修正后，历史单怎么办？** 例：原批准用旧Annual金额，新算法改变DoA档位，要新版本补审还是只对新单生效？谁批准重算／回填，历史报表如何保持可追踪？本包没有自动回写。
7. **完整来源谁提供？** 例：同一Part在两Plant，FTO只给carline总量；怎么分配，重复／缺量怎么处理？需要当前FTO／FX文件、来源版本与匹配规则，不能拿合成数据当接口证据。
8. **哪些地方都要改？** 例：Calculation页、审批卡、导出、Finance Claim Report是否都引用同一个Annual字段？请确认消费者清单与当前系统示例，防止只修标题仍读错字段。

正式缺口沿用FR79-Q03、F1021-25，不另建主问题台账；原有旧结果按原环境保留。本独立包的问题清单是本条评审附件，不取代主QA。

## 10. 本地验证、退出条件与交付

106项浏览器检查、93项模型检查，逐项Expected／Actual见PAGE_VISUAL_CHECK.json、DOMAIN_CHECK.json。包含真实点击、CSV下载打开、保存／回读、失败／未知、六屏宽、键盘和CSS200%压力检查。算术字面预期预先定义；本次曾修正测试对canonical decimal输出格式的误解和菜单／关闭按钮的测试定位，未改变业务公式来凑通过。

| 验收层 | 当前结论 | 退出条件 |
|---|---|---|
| 独立候选／本地算术 | 实测结果见JSON；不等于Finance公式通过 | 同版页面、六张截图、预期与实际一致、完整来源／计算版本 |
| 年度基准／Runout／符号／精度 | **待Finance确认** | 签认12个月起点、Runout、方向、端点及golden cases，涵盖正常与边界 |
| 正式产品全入口 | NOT RUN | Calculation／审批引用／导出／报告同一输入版本无错映射，旧历史保持原依据 |
| 真实服务／DB／身份／BPM | NOT RUN | 服务端重新校验、持久保存回读、越权／陈旧版本拒绝、历史审计及申请引用正确 |
| 真实FTO／FX／SAP／GR／E2SC | NOT RUN | 正式契约与非生产样例、同记录／同来源版本对账；FR8另有完整测试 |
| Finance业务验收／迁移／部署 | NOT RUN | 签认golden cases和历史处理方案、通过实际环境验证及单独发布授权 |

本地13行不能证明生产数据规模／并发性能；没有伪造性能指标。原生浏览器200%未执行，CSS200%单列，不混称。CLI有一项固定17场景外部Select关闭虚拟滚动的性能警告，业务计算表仍分页，未宣称全量无警告或无障碍认证。

交付：独立HTML；中文汇总HTML／MD；6张实际主截图及手机截图；业务问题清单；源码与公式快照；构建／测试；源证据与SHA；实际结果JSON；完整ZIP。没有新增Word／Excel主QA，没有改现有prototype。

下一条NEO-032：SAP／WIPS价格小数精度与千件价格换算。031不提前修改其接口、价格精度或舍入规则。

### 10.1 来源索引

本轮读取日期2026-11-13；原历史截图拍摄日与生产生效时间未推定。精确原文、原路径和SHA见SOURCE_EVIDENCE.json。API／调度目录不是当前部署／完整payload证明。

| ID | 文件 | 定位 | SHA前12位 |
|---|---|---|---|
| S1 | NEO Business Requirements (added China requirements) 1.xlsx | RTM for Requested Changes row32 (1-based) | b83b74cb3eb2 |
| S1-ID-A | NEO Business Requirements (added China requirements) 1.xlsx | RTM - Archive row34 (1-based) | b83b74cb3eb2 |
| S1-ID-B | NEO Business Requirements (added China requirements) 1.xlsx | NEO RTM row35 (1-based) | b83b74cb3eb2 |
| S2-8 | Material Cost & Inventory - BRD V3.1.docx | Table6 row8 (1-based) | 0d6aedc1538c |
| S2-18 | Material Cost & Inventory - BRD V3.1.docx | Table6 row18 (1-based) | 0d6aedc1538c |
| S2-19 | Material Cost & Inventory - BRD V3.1.docx | Table6 row19 (1-based) | 0d6aedc1538c |
| S2-20 | Material Cost & Inventory - BRD V3.1.docx | Table6 row20 (1-based) | 0d6aedc1538c |
| S3 | NEO Frozen Turnover (FTO) Overview.pdf | Physical pages3–7; page4 visually inspected; sign conflict with current engine noted | 842e3acd9b7b |
| S4 | story_data.json | ACT001/004 input association; ACT008 manual Buyer Performance distinct from automatic POA; ACT054 FTO Refresh; no Jira write | a2e47d1cde32 |
| S5 | scope.json | Existing P6.1/P6.1.1/P19/P19.2; no new official UC or page ID | 74aae9869a99 |
| S6 | calculation.ts | Numbered current source lines (1-based); read-only code inspection, not fresh product execution | 68ad563730b6 |
| S7 | decimal.ts | Numbered current source lines (1-based); read-only code inspection, not fresh product execution | 727cc261b26b |
| S8 | calculation-display.ts | Numbered current source lines (1-based); read-only code inspection, not fresh product execution | 6b97c9141ffc |
| S9 | CalculationResults.tsx | Numbered current source lines (1-based); read-only code inspection, not fresh product execution | 6136a1d90d2c |
| S10 | Calculation.tsx | Numbered current source lines (1-based); read-only code inspection, not fresh product execution | 9c27d39ac464 |
| S11 | calculation-context.ts | Numbered current source lines (1-based); read-only code inspection, not fresh product execution | b44161996aa1 |
| S12 | index.ts | Numbered current source lines (1-based); read-only code inspection, not fresh product execution | 82b56dcd8c92 |
| S13 | fr7-8-calculation.test.ts | Numbered current source lines (1-based); read-only code inspection, not fresh product execution | 81c9c4c65731 |
| S14 | review-data.json | Existing FR79-Q03/F1021-25/UI-FTO-REACT-01; old verdicts not rerun | 8fcbf8fdf490 |
| S15 | NEO_数据字典.xlsx | 字段字典 rows814–843; Claim-Part fields, not proof of signed formula or source contract | 22342fd6253c |
| S16 | Integrations - 2026-11-09_0941(Sheet 1).csv | Physical CSV rows selected for parts/prices and forecast/FX; directory only | 5e40049996bb |
| S17 | Scheduler Processes - 2026-11-09_0944.xlsx | FTO/E2SC/FX scheduler name matches, not current deployed schedule or contract | 390f6aad6886 |
| S18 | NEO_UXUI_PRINCIPLES.md | Current NEO UX; unchanged theme, 32/24/16 edges, 4/2/1 grouping | 2722dc05eae2 |
| S19 | NEO User Training.docx | Body paragraphs726–760 (1-based): FTO Refresh and manual Update Buyer Performance; automatic FR7 calculation is not the same as ACT008 | bf942f7a70e6 |
