# NEO-026 · Implemented 后锁定 Reporting Category 与业务字段

独立设计评审包 · 2026-11-13 · 英文页面 / 中文分析。未修改现有 NEO prototype、产品代码、共享 QA、数据库、流程或线上环境。

## 1. 原始要求与本次解释

**已经实施的单据，不能再随意改分类和商业/财务内容；确需补录原 PO 编号时，走单独的受控入口。** 不能只把下拉置灰，保存端也必须按最新状态拒绝修改。

| 项目 | 原始证据 / 判断 |
|---|---|
| 本次条目 | `NEO Business Requirements (added China requirements) 1.xlsx` → **RTM for Requested Changes 第27行**，NEO-026，CR-2026-1557 / 12。[S1] |
| 原文 E27 | “Reporting Category field should be locked in NEO once a claim is implemented (especially NDPC lump Sums) as the GL/Cost Centre can’t be changed once the PO has been posted leading to manual corrections having to be made.” |
| Finance 补充 P27 | 大部分 Risk/Opp 字段在 Implemented 后应锁定；极少数 Super User / Senior User 可能例外；允许实施后补充数据，例如 PO Number。具体例外权限及字段清单未提供。 |
| 原始分类 / 优先级 | Existing functionality — Update UX / Workflow；Finance **Must**；Alignment **N**。不把 Must 当作已经签收全部例外细节。[S1] |
| 同号冲突 | Archive 第29行的 NEO-026 是 FR9.5 DoA 配置；NEO RTM 第30行的 NEO-026 是 FR1.6 WIPS simulation。它们不是本次锁定需求。[S1-ID-A/B] |

本包推荐：统一的状态/字段保存保护；普通角色只读；Senior / Super User 不自动绕过；补充 PO 引用与“修改财务数据”分离。原权限、批准/Settlement 锁、自动回写字段继续保留。

**当前只明确 Reporting Category 必须锁。** 其他“大部分字段”需要逐字段签收。本候选暂按商业/Finance 字段从严只读，不把这一默认方案当作已确认的完整例外清单。Finance Remarks 是否可追加、附件/Note/Buyer Performance 等哪些动作可保留，均待确认。

## 2. 改动分类、优先级及关联

| 主要类型 | 评估 |
|---|---|
| UX/UI only | **否**。页面展示只读原因、禁用合适控件、保留保存值和补录入口；仅靠前端不足以防止 API、批处理或旧页面写入。 |
| Application 内部前后端 | **主要改动**。集中判断当前及历史实施状态、现有批准锁、角色和字段白名单；提交前原子复核；保留审计与批准/实施依据；报告读取保存版本。 |
| Integration needed | **核心锁定不要求新外部系统**，但依赖可信的 SAP/手工实施结果。若需补回 PO 编号，要复用/补齐原结果回读契约。不能用 UI mock 证明真实 PO 已找到。 |
| 与谁 / 谁提供接口 | 新应用调用 Apigee，SAP 提供 PO 结果/状态。原 Appian 是调用方；未来平台适配器承接这一职责。[S17] |
| 现有接口能否复用 | `MCI_getPurchaseOrderDetails` 是已知 PO 编号的状态 GET；能否按 NEO ID / 原 attempt 找回未知编号，登记表未说明。`MCI_raiseLumpSumPO` 不应因补录而再次调用。[S17] |
| 是否新增架构 | 没有证据要求新平台。建议集中应用策略、现有持久化/审计及适配器协作；不新建一套通用“管理员解锁流程”。 |
| 建议优先级 | **P0 / 实施及生产放行前的财务控制前置**，依据 Finance Must 与已过账信息可能被不当修改的影响。是本轮建议排序，不是原表已签收的 Sprint 排期。 |

| Epic / User Story | Related FR / UC 场景 | 页面编号 / 名称与影响 |
|---|---|---|
| Finance / CNP-235；**ACT-006 Edit Finance Data** | FR6.2、FR16；D026-UC01 实施前编辑、UC02 实施后锁定、UC04 保存时复核 | **P8 Update Finance Data**；**P6.2 Finance** 只读详情 |
| Claims and data / CNP-231；**ACT-004 Update Claim** | FR6、FR6.1、FR16；D026-UC02 商业字段保护 | **P7 Update Risk / Opportunity**、**P7.6 Update — Lump Sum**；**P6/P6.6** 详情 |
| Approvals / CNP-233；**ACT-022 Manage Task**，关联实施处理 | FR11、FR12、FR16；D026-UC03 原结果补录 | 既有实施任务 / P8 受控补充入口；具体落点待确认，不另造正式 Page ID |
| Finance / CNP-235；**ACT-041 Finance Claim Report** | FR20、FR20.1、关联 FR20.5；D026-UC05 报表保持原值 | **P20 Reports — Finance Claims** |
| 关联财务数据口径 | **FR17.2**，关联 FR19 | Reporting Category / Lever → Reserve Team → Income Statement Account / Associated Cost Centre；不等同 SAP PO 账户映射。[S2-44/S18] |

[S5/S16] Epic、ACT、FR、Page 来自既有登记。D026-UC01～05 是本包拟定的评审场景编号，不冒充 BRD 原 UC，也未写入 Jira。

## 3. 原规则、当前观察和缺口

| 依据 | 已有规则 / 可复用部分 | 本次不能臆断的地方 |
|---|---|---|
| BRD FR6.2 | GFS / FBP 可编辑 Finance；自动得到的 Claim No 不允许手工输入；Reporting Category 来自参考数据。[S2-16] | “黄色项改为只读”的精确清单仍有既有问题 **FR16-Q08**，不能从纯文本猜齐。[S15] |
| BRD FR16 | Implemented 后 Buyer 不得编辑；自动、手工实施状态区分；Cancelled 是另一分支。[S2-41] | 新要求扩大 Finance 锁定，不能沿用“Buyer 锁了就等于全角色锁了”。也不能把状态缺失当 Forecast。 |
| BRD FR12 | **Data Posted Awaiting Approval ≠ Implemented**；SAP/GFS 的后续结果才决定适用实施状态。[S2-37] | PO Number 存在不是“已实施”的充分条件；本包保留已批准 Settlement 的原锁定，不把它误称为新 Implemented 锁。 |
| 当前 Finance UI / 服务源码 | `ClaimFinance.tsx` 使用 `lockedDraftReason`；管理服务保存也调用 lock；`lockedDraftReason` 检查 active Settlement locks。[S6/S8/S9/S10] | 所查路径未见独立的 Implemented 锁判断；这提示需要核查全部入口，**不等同实际运行中所有 Implemented 单据都可编辑的已复现缺陷**。本轮未运行产品。 |
| 当前 Finance 投影 | 多种手工 / 自动路径会产生 Finance Implemented；WIPS PM 完成还可另投影状态。[S6/S7] | 需要统一服务端保护及状态映射，不能只看某个前端标签。真实状态 ID / 事件版本待签收。 |
| 参考数据 | Reporting Category 有独立参考表和原值；Training 的 Finance 角色范围明确。[S3/S4/S12] | 参考项停用/改名不能让已实施记录自动改成另一个现行分类；历史显示和回填规则待确认。 |
| 未决接口事项 | 已有 **F1021-09** 保留 SAP PO payload、回执、查重与对账缺口。[S15] | 本包未修改共享问题状态，不把合成补录操作写成真实 SAP 对账通过。 |

**特别区分两个财务映射**：

- **NDPC PO**：FR12 的 GL Account 来自 Material Group 关联 Account Code；Cost Centre 来自 Vehicle Line 关联 Cost Centre。字典结构支持这两层引用。[S2-15/37/52，S4]
- **Reserve**：FR17.2 的 Reporting Category 与 Lever 用于 Team 映射，映射表还包含 Income Statement Account 和 Associated Cost Centre。[S2-44/S18]

因此，不能写成“Reporting Category 改一下就一定直接改 SAP PO GL”。但改分类可能使 Reserve / 报表口径与已实施交易不一致，仍需保护并核对真实映射版本。本候选没有计算或改动 Reserve / Journal。

## 4. 字段、数据源与接口责任

| 页面字段 / 事实 | 数据与提供方 | 保护 / 回读设计 | Source / 缺口 |
|---|---|---|---|
| Line ID / 状态 | NEO 业务对象和流程结果 | 业务 ID 不变；Finance Status 与 Workflow Status 分列；既有实施历史不因改回 Forecast 自动消失 | 字典681–685、FR16；真实状态 ID 对照待提供。[S4/S2-41] |
| Reporting Category | NEO 管理参考数据 → Claim 引用 | 实施后只读；显示保存的历史名称/ID，不默认换新值 | `MCI_REF_REPORTING_CATEGORY`383–392；Claim REPORTING_CATEGORY_ID749；报表2524。[S4] |
| Finance Remarks | NEO Finance 用户输入 | 本候选实施后只读；是否允许“追加但不改旧备注”待签收 | `FINANACE_COMMENTS`750，varchar4000；不擅自修正原字段拼写。[S4] |
| Material Group / Account Code | SAP 参考数据经 NEO 引用 | Account Code 是原 LSP 依据，分类保存不隐式改它；已实施上下文只读 | Material Group 表282–292，ACCOUNT_CODE_ID286；Claim720/730。[S4/S2-52] |
| Vehicle Line / Cost Centre | 原 Vehicle Line 参考映射 | 仍用原 Cost Centre，不用“分类建议”替换 | Vehicle Line572–581，COST_CENTER_ID575；Claim721/729。[S4] |
| PO Number | **SAP 提供结果；新应用适配器读取并关联** | 补录仅填空值，核对同 Line / Settlement / 原建单 attempt 及金额/币种/账户依据；已有不同编号拒绝覆盖 | Claim PO_NUMBER739；FR6.2/FR12；确切真实 lookup/correlation payload 未收到。[S4/S2-16/37/S17] |
| 修改人 / 时间 / 原值 / 新值 / 理由 | 应用认证主体及审计 | 成功提交后记录；失败不写；结果未知先回读原保存意图，避免重复 | 本包纯内存候选，不是实际数据库或服务端认证证明。 |
| 报表 / Reserve 的分类口径 | NEO 保存版本及有效映射 | 报表读取已保存值；保留实施依据；映射更新如何影响历史期间待确认 | FR17.2、FR20；不重算本包之外的财务期间。[S2-44/67/68/72] |

接口登记：[S17] CSV 物理第11行 / ID5，`MCI_getPurchaseOrderDetails`，GET `.../list/purchase-order-details/VAR_PO_NUMBER`；物理第16行 / ID10，`MCI_raiseLumpSumPO`，POST `.../create-purchase-order`，Appian → SAP via Apigee，登记为 No output body。**本包没有调用这些地址。** 补录不发新建 PO 请求，也不改变 SAP GL/Cost Centre。

候选的 `implementedBefore`、内部 save intent / attempt / snapshot 都是说明保护机制的合成模型，不是已确认的新数据库列或外部字段。正式实现应依可靠实施历史/事件版本判定，不靠浏览器变量或英文标签兜底。

## 5. 六张主要页面图

### 5.1 实施前 Finance 编辑

Ben Taylor / FBP；MCI-00057 v7，Forecast。分类改为 Other Matl Cost，Finance Remarks 输入 Reviewed before implementation.，理由 Correct classification before implementation.。保存前可取消；不把分类选择直接转换为 SAP 账户变更。

![实施前Finance编辑](NEO-026_Before.png)

### 5.2 Implemented 后 Finance 只读

同号独立合成记录，Finance Implemented、Workflow Implemented - Automatic、PO CLM-01。分类置灰，Remarks 只读，授权 Finance 的保存按钮因状态禁用，并显示原因。

![Implemented后锁定](NEO-026_Implemented.png)

### 5.3 商业字段上下文

Claim details 展示 Description、金额、Material Group、Vehicle Line、GL、Cost Centre 等保存值，Implemented 状态不出现修改入口。此为锁定增量示意，**不是全量 Create/Update Claim 的完整重建或全字段验收**。

![商业字段只读上下文](NEO-026_Claim.png)

### 5.4 原 PO 结果补充确认

Daniel Foster / GFS；核对当前 Line、结果 Line、Settlement、PO 编号和金额/账户依据。只能补引用，不解锁分类和商业数据。GFS 这一补录权限是候选安排，仍须业务确认。

![原PO结果补录确认](NEO-026_Reference.png)

### 5.5 补录后回读

原空值补为 CLM-01，Claim v8；分类、金额、GL、Cost Centre、Finance/Workflow 状态及原实施依据保持。只有 SAP PO Number 一条审计变化。

![补录后查看保存值](NEO-026_Saved.png)

### 5.6 保存时状态已变化

用户编辑时为 Forecast，但保存时最新版本已 Implemented。系统拒绝旧表单；显示最新只读事实，另保留用户未保存的分类和理由供查看，不把旧输入覆盖回实施记录。

![保存时状态冲突](NEO-026_Conflict.png)

另附 `NEO-026_Mobile.png` 为390 px 实际截图。每个外部评审场景独立重置；这些截图不是不同角色共用同一笔数据库交易的端到端证据。

## 6. 场景、具体输入及预期

| 场景 | 谁 / 条件 | 怎么点、填什么 | 本地预期与实际 |
|---|---|---|---|
| D026-UC01 实施前编辑 | Ben / FBP；Forecast v7 | Reporting Category = Other Matl Cost；Remarks = Reviewed before implementation.；Reason = Correct classification before implementation.；Save → No；再 Yes | No 保留旧值/v7；Yes 保存v8；两条字段审计；GL1100040501、CC GB03LUU018、金额1200.00000 GBP和 Forecast 不变。 |
| D026-UC02 Implemented | Ben / FBP，Implemented NDPC | 打开 Finance、Claim details、View saved Finance data | Category 禁用、Remarks 只读、Save 禁用；原分类 Purchasing Negotiation、PO CLM-01 和实施依据保留。 |
| Buyer / Super User | Alice / Buyer；Jack / Super User | 打开 Finance | 均无 Finance 写入动作；Super User 不自动成为例外授权。 |
| POA / 历史实施重开 | FBP；Implemented POA，或历史实施后当前 Forecast | 打开分类 / 详情 | POA 也锁分类，不显示 LSP GL；重开候选保留财务保护，待受控修正规则，不能借状态回退解锁。 |
| PO posted 未实施 | FBP，Data Posted Awaiting Approval | 打开 Finance | 仍显示 Awaiting implementation，而非 Implemented；既有 approved Settlement 锁继续生效。 |
| D026-UC03 补充原 PO 引用 | Daniel / GFS；Implemented 手工路径，原 PO 引用空 | Check original PO result → Cancel；再 Check → Save supplementary PO reference | Cancel 不存；确认后仅 PO_NUMBER空值→CLM-01，v8；原分类/GL/CC/状态不变；审计实际人 Daniel。重复同编号不再保存。 |
| 引用不匹配 / 不覆盖 | GFS；结果 Line58 对当前57；或当前CLM-01、结果CLM-02 | 打开原结果 | 均禁止保存；不能把其他 Line 的 PO 拿来补，不能覆盖已有不同编号。 |
| 状态不可用 | FBP；状态未加载 | Reload Finance status | 未知时不可编辑；恢复为已实施手工状态后依旧只读，不出现短暂可写。 |
| D026-UC04 最后时刻实施 | Ben，编辑后原记录变 Implemented/v8 | Save → Yes → Review latest Finance data → Show latest read-only values | 拒绝；保留未保存输入；按最新只读值展示。View unsaved changes 可查看 Other Matl Cost 和原理由。 |
| 仅版本冲突 | Ben，另一用户已保存 Contracted Raw Materials/v8 | 同上编辑；Save；Review latest → Continue reviewing my changes；再确认 | 不覆盖旧版本；明确审阅后继续保留输入，重新确认保存v9。 |
| 失败 / 未知结果 | Ben；failure / unknown 独立场景 | 编辑后保存；失败可重试；未知点 Check original save result | 已知未提交失败保留v7，重试只到v8；未知禁新保存，回读原意图到v8，不重复审计。 |
| 历史分类停用 | FBP；保存时分类已退役 | 打开 Finance / Reporting | 保留 Historic category (retired)，不替换为当前第一项。只验证候选保存名称，不是生产有效日期映射。 |
| D026-UC05 筛选导出 | Ben，成功保存v8后 | Reporting → Finance Status = Forecast → Export Finance data | 打开CSV，头+1条 MCI-00057；含 Other Matl Cost、GL、CC，不含Implemented的58；清过滤恢复2条。 |

本包的四个分类是已查当前参考名称中的**小型示例子集**，不是对生产完整下拉的替换。候选保留当前源码允许空 Reporting Category 的行为，不借本锁定需求增加新的必填规则；真实引用 ID、权限范围和全部有效选项仍需使用正式配置。

## 7. 给开发的修改范围及影响

| 层 | 需要补什么 | 影响与注意 |
|---|---|---|
| HTML / 前端 | 复用 NEO banner、tokens、AntD 控件、横向tabs和4/2/1字段组；Implemented显示保存值、具体原因；已授权但状态禁用的动作置灰，无权限动作不渲染 | 不恢复 Before 样式；不把所有字段删除或把只读做成空值。实际需覆盖 Summary、Finance edit、Claim edit 及其他入口。 |
| Application / API | 集中读写策略：当前状态、实施历史、批准锁、角色、字段允许表；提交时同事务复核版本；未知结果按原 intent 回读 | 不信任客户端 disabled / role / status；直接 API、批处理和管理员入口也要一致。 |
| DB / 审计 | 沿用原业务字段，保存审计和实施/批准依据；必要时扩展已确认的版本关系 | 不擅自新增具体表名/列名；自动字段补写与业务修改必须分开，不能全对象覆盖。 |
| BPM / 实施 | 将真实实施结果投影到可靠状态；保留自动、手工、应收路径、Dummy等已确认处理 | 本次不改完成条件，不拿 Mark As Complete、PO已建或SAP已过账单独充当实施完成。取消/重开怎么处理待签收。 |
| SAP / Apigee | 原结果查询、Line/Settlement/attempt关联和成功/未知回读 | 核心锁定无新增外部接口必要；补录若现有契约不足，再评估扩展；**不重建 PO**。 |
| Reserve / 报表 | 保留旧分类/映射版本，检查 Reserve Team/Journal及实施报表一致性 | 不将本地“GL未变”当作所有财务报表已对账；跨期间回算/历史映射需 Finance 验收。 |

建议先补集中服务端保护及普通页面，再在业务签收例外字段和人员后实现受控补录/修正。当前独立包不占用这些产品文件，也未合并到并行开发分支。

## 8. 本地验证与退出条件

| 验证层 | 结果 | 证据与范围 |
|---|---|---|
| 实际浏览器交互 | **122 项 PASS** | `PAGE_VISUAL_CHECK.json`：前后状态、保存/取消/回读、角色/只读、状态竞争、版本恢复、失败/未知、原 PO 补录/不覆盖、历史分类、实际导出内容及手机操作。 |
| 候选逻辑 | **104 项 PASS** | `DOMAIN_CHECK.json`：状态/历史保护、越权/字段拒绝、版本、不可变来源、审计、保存意图回读、原结果关联及CSV。内存模型，不是真实服务端。 |
| 响应式 | 六个宽度1920/1440/1024/768/390/360 px；边距32/24/16，无文档横向溢出；CSS200%检查 | 模态框和表格 leading sticky action 在手机实际打开；**原生浏览器200% zoom NOT RUN**。 |
| 视觉 / 产物 | 6张主图+手机图，实际查看；评审HTML嵌入6图 | 最终页面和文件哈希见验证报告；ZIP逐文件回读。 |
| 现有产品 / 真实权限 / API / DB / BPM | **NOT RUN** | 源码观察不是产品回归；没有改分支、数据库或发布流程；未验证真实多用户并发。 |
| SAP、Tax/Finance例外、Reserve/Journal期间对账 | **NOT RUN / 未签收** | 没有真实 PO 查询/补写、财务修正、全量字段允许表和正式批准。 |
| 生产 / 业务验收 | **NOT RUN** | 未部署，不把本地226项检查当作业务全链路通过。 |

**本独立设计包退出条件**：原条目和同号差异明确；现有字段/状态/权限有来源；Implemented不再等同纯UI灰态；补录与改财务分开；六张主图和可操作异常恢复有本地实际证据；源码/测试/来源/ZIP可交付。本轮只完成这个范围。

**正式实现退出条件**：逐字段/角色/时点规则签收；同一正式测试 Line 的自动、手工、应收应付及适用 Dummy 路径验证；所有写入口执行相同状态/版本保护；补录只有已授权字段，原 PO 可可靠查回、不可错配或重复创建；旧版本和历史期间不被静默重写；Reserve/报表与真实来源对账；实际权限/API/DB/BPM/部署版本有证据。当前尚未完成。

## 9. 业务确认问题（讲人话）

以下是本条评审问题，不是新建 QA 缺陷总表。关联既有 FR16-Q08、F1021-09、NQA-133。[S15]

| ID / 优先级 / 责任建议 | 背景和例子 | 建议、影响及可继续工作 |
|---|---|---|
| Q026-01 / P0 / Finance owner | “大部分字段锁定”具体包含哪些？例如实施后还能追加 Remarks、上传支持文件、Add Note、改 Buyer Performance 吗？ | 提供逐字段/动作允许表，区分追加与改旧值；候选暂锁商业/Finance编辑。只读布局和集中策略可继续；例外写入暂不开。关联FR16-Q08。 |
| Q026-02 / P0 / Finance + BPM + SAP | 锁定以哪个真实状态/事件为准？PO已建但等待SAP批准时，是否另有既有锁？ | 保留原批准/Settlement锁；Implemented使用可靠状态/历史，不靠PO编号。需要Finance/Workflow状态ID映射及自动、手工、应收路径样例。 |
| Q026-03 / P0 / Finance + Security | “有限的Senior/Super User”到底是谁、能改什么、谁批准？ | Jack是Super User不代表可改已过账分类。建议具名权限、限定字段/原因/证据，必要时与Tax/SAP修正衔接；候选无通用解锁按钮。 |
| Q026-04 / P0 / GFS + App owner | PO编号补录由谁操作？只能来自系统回读，还是某些手工路径允许人工证明？ | 例：单据已手工实施但PO号晚到。候选Daniel/GFS核对原结果后填空值，权限是建议；不能自动推广给所有GFS/FBP。普通锁定不等待这个决定。 |
| Q026-05 / P0 / SAP + Apigee | NEO没有PO号时，如何按原Line/Settlement/attempt找到原PO？已有不同PO号怎么办？ | 不能靠现有“按PO号查询”就宣布能找回未知号。需lookup/correlation、真实payload/response、超时及查重规则；不同号先对账不覆盖。关联F1021-09。 |
| Q026-06 / P0 / Finance SME | Reporting Category对Reserve Team、Income Statement Account、Associated Cost Centre以及NDPC PO账户，实际分别怎样关联？ | 例：分类改成Other Matl Cost会不会影响Reserve科目，但SAP PO仍是原GL？请确认两条映射和生效版本；本包未编造分类→SAP GL公式。 |
| Q026-07 / P1 / App + Integration owners | 哪些入口今天会修改这些字段，是否含批量导入、Reference更新、定时任务和直接API？ | 只锁P8，另一个Excel导入仍能改分类就无效。建议同一服务策略覆盖全部写入口；开发可先集中校验，入口清单需现有团队补齐。 |
| Q026-08 / P0 / Business + Finance | 已实施后取消、重开或Resume时，允许改原财务数据，还是应走新版本/修正单？ | 例：状态回Forecast是否可以改已过账GL依据？候选保留原实施保护，不自动解锁；具体受控修正链路待定。 |
| Q026-09 / P1 / Reporting + Finance | 分类停用/改名、Teams映射更新后，历史期间用原名称/映射还是当前值？ | 例：去年保存的分类现已退役，不能自动换成下拉第一项。建议保留历史依据并明确报表时点；本包只验证保留值，未重算Reserve/Journal。 |
| Q026-10 / P0 / Finance + QA | 有现网例子和测试账号能证明实施后哪些操作现在允许/拒绝吗？ | 需NDPC应收/应付、手工、POA、Dummy各适用样例及实际角色；当前源码的Settlement锁不等于全部路径已有Implemented锁。先做源规则和独立页面，产品/接口验收另跑。 |

## 10. 交付物与下一项

- `NEO-026_Page_Proposal.html`：独立英文React/AntD页面，16个外部评审场景。
- `NEO-026_Consolidated_CN.html` / `.md`：本方案及6张嵌入图；`OPEN_QUESTIONS_CN.md`：十个业务问题。
- `SOURCE_EVIDENCE.json`：28条来源摘录、定位、原路径、SHA；原文颜色/删除线信息单列，不把失去格式的“黄色只读”清单当已明确。
- `PAGE_VISUAL_CHECK.json`、`DOMAIN_CHECK.json`、`VALIDATION.json`：实际预期/结果、本版页面/模型哈希、未执行层和来源回读。
- `NEO-026_Filtered_Finance_Report.csv`：本轮实际打开核对的合成筛选导出，不是正式报告模板。
- `design-source/`：可编辑页面/模型/theme快照、字体logo、build、tests、README、AntD lint说明。
- `NEO-026_Review_Pack.zip`：全部离线交付物；公共index追加本条。

下一条 **NEO-027：AMM Bulk Upload 的 weights/materials/measures 扩展**，本轮尚未开始。需要独立评估它与既有不恢复旧Parts导入的边界，不能借本包修改现有上传功能。

### 10.1 来源索引

本轮取证 2026-11-13；来源文档的内容日期以原件为准。API 登记 CSV 导出日期为2026-11-09，其中接口行自身记录的更新时间为2025年5月，不能把导出日期当作契约签收日期。完整路径、原文和SHA-256均在 SOURCE_EVIDENCE.json；原文件回读时间及一致性见 VALIDATION.json。

| ID | 原始文件 | 定位 | SHA-256 前12位 |
|---|---|---|---|
| S1 | NEO Business Requirements (added China requirements) 1.xlsx | RTM for Requested Changes row27 (1-based) | b83b74cb3eb2 |
| S1-ID-A | NEO Business Requirements (added China requirements) 1.xlsx | RTM - Archive row29 (1-based) | b83b74cb3eb2 |
| S1-ID-B | NEO Business Requirements (added China requirements) 1.xlsx | NEO RTM row30 (1-based) | b83b74cb3eb2 |
| S2-15 | Material Cost & Inventory - BRD V3.1.docx | Table6 row15 (1-based) | 0d6aedc1538c |
| S2-16 | Material Cost & Inventory - BRD V3.1.docx | Table6 row16 (1-based) | 0d6aedc1538c |
| S2-37 | Material Cost & Inventory - BRD V3.1.docx | Table6 row37 (1-based) | 0d6aedc1538c |
| S2-41 | Material Cost & Inventory - BRD V3.1.docx | Table6 row41 (1-based) | 0d6aedc1538c |
| S2-52 | Material Cost & Inventory - BRD V3.1.docx | Table6 row52 (1-based) | 0d6aedc1538c |
| S2-67 | Material Cost & Inventory - BRD V3.1.docx | Table6 row67 (1-based) | 0d6aedc1538c |
| S2-68 | Material Cost & Inventory - BRD V3.1.docx | Table6 row68 (1-based) | 0d6aedc1538c |
| S2-72 | Material Cost & Inventory - BRD V3.1.docx | Table6 row72 (1-based) | 0d6aedc1538c |
| S3 | NEO User Training.docx | Body375,377,654–663,1375 (1-based); role scope/reference data/completion only | bf942f7a70e6 |
| S4 | NEO_数据字典.xlsx | 字段字典 rows3–10,125–132,282–292,383–392,572–581,681–685,720–750 and selected report fields | 22342fd6253c |
| S5 | story_data.json | ACT004/006/022/041 existing mappings; not Jira writes | a2e47d1cde32 |
| S6 | ClaimFinance.tsx | Numbered source lines (1-based); scoped read-only source inspection, not executed product tests | 3c086ee148e7 |
| S7 | finance.ts | Numbered source lines (1-based); scoped read-only source inspection, not executed product tests | 0492a7b3123e |
| S8 | management.ts | Numbered source lines (1-based); scoped read-only source inspection, not executed product tests | bc861a2194d9 |
| S9 | locks.ts | Numbered source lines (1-based); scoped read-only source inspection, not executed product tests | f29c970d2c72 |
| S10 | runtime.ts | Numbered source lines (1-based); scoped read-only source inspection, not executed product tests | 1cb7b64712d9 |
| S11 | manual-po-form.ts | Numbered source lines (1-based); scoped read-only source inspection, not executed product tests | 0dabc344e4c9 |
| S12 | source-choices.ts | Numbered source lines (1-based); scoped read-only source inspection, not executed product tests | 149edf84489d |
| S13 | index.ts | Numbered source lines (1-based); scoped read-only source inspection, not executed product tests | 82b56dcd8c92 |
| S14 | personas.ts | Numbered source lines (1-based); scoped read-only source inspection, not executed product tests | 9c30e405c28f |
| S15 | review-data.json | Existing FR16-Q08 / F1021-09 / NQA-133; no changes to canonical QA | 8fcbf8fdf490 |
| S16 | scope.json | Existing P6/P6.2/P6.6/P7/P7.6/P8/P20 page IDs | 74aae9869a99 |
| S17 | Integrations - 2026-11-09_0941(Sheet 1).csv | CSV physical rows11/16, register ID5/10; dated API sample only | 5e40049996bb |
| S2-44 | Material Cost & Inventory - BRD V3.1.docx | Table6 row44, FR17.2 (1-based) | 0d6aedc1538c |
| S18 | team-mappings.ts | Numbered source lines; reporting category/Lever to Reserve Team account/cost centre, distinct from SAP PO basis | 8862fba2cfc5 |
