# NEO-028 · NEO Processing Time

## 1. 本条要解决什么

Buyer在RPA Error任务里点Include／Exclude、勾选Plant时，应先看到自己的选择，数据检查与保存结果分别展示。不能让一个未完成的调用把按钮和勾选状态一起卡住，也不能为了“快”而假装保存成功。

来源：RTM for Requested Changes第29行E29、F29、K29、M29、Q29；Proc Triage383第1项，Must。原文报告约5秒延迟，怀疑可能与SAP RFC有关，也可能是别的原因。这不是本轮测得的现网结果，更不是已确认的根因或目标时限。[S1]

本次只交独立交互页和局部验证包；不改现有prototype、产品代码、共享QA或生产。



## 1.1 2026-11-16 更新：沿用 POC 计算三阶段

028 同时处理两件事：勾选／下拉立即响应，以及长计算在后台完成。复用 POC 三步，并增加完成邮件和 Buyer 待办。

选择 Include／Exclude 或 Plant 后立即显示选择，异步检查数据；检查失败保留输入。计算开始后显示进度，Buyer 可以离开继续工作。结果完成后发邮件并生成一条“Review calculation result”待办；两处都打开同一 Claim、同一计算版本。确认结果后再按原流程继续。

| 环节 | 说明 |
|---|---|
| Before | Buyer 等待控件变化或计算结果，不清楚是否仍在处理。约 5 秒卡顿来自需求报告；本轮未作现网计时。 |
| 1 · Calculation running | 显示进度和 Pending 结果；可回 Work queue。重开原 Claim 继续显示同一次计算，重复点击不重新发起。 |
| 2 · Ready reminder | 完成后给 Alice Morgan 一封邮件和一条 Review calculation result 待办，包含 Line ID、描述、计算版本和完成时间；两个入口均打开该结果。邮件失败不丢失结果和待办。 |
| 3 · Completed result | 展示结果、输入和来源版本。Mark as reviewed 只完成这条结果复核待办，不是 Submit、Approve、Mark As Complete 或 Implemented。 |
| 失败与重试 | 计算失败保留 Parts／价格，提供 Retry；不发送成功邮件、不生成 Ready 待办。通知按 Claim＋计算版本去重，失效版本必须提示更新。 |

| 环节 | 说明 |
|---|---|
| 页面／ACT／FR | 保留 P15.19／ACT-064／FR13 的 RPA Error 交互；本轮增加 ACT-001／FR1.6／P2.6.3 Calculation 的三阶段演示，以及现有 Work queue、My tasks 和邮件模板。阶段不是三个新增业务页面。 |
| 主要改动类型 | Application 前后端修改＋现有通知／任务能力复用。UI 进度与选择反馈只是其中一部分；服务端负责后台执行、结果保存、权限和重复控制。 |
| SAP 与依赖 | 不能靠等待动画解决 SAP／数据库慢点。先定位浏览器、API、查询、RFC 时间；复用既有接口需验证，暂不据此新增平台架构。真实邮件渠道、收件人解析和失败重试仍须接入。 |

示例：MCI-00057，Alice Morgan，计算版本 1；(£100−£95)×1,000 + (£50−£47.50)×2,000 = £10,000。此处仅演示流程和输入可追溯，不是 Finance 金额验收。独立页面使用浏览器会话保存与模拟耗时；邮件仅预览，待办仅在该演示中生成。

Reference：NEO-028／Requested Changes 第29行；本轮用户指示（2026-11-16）；V25 #calculation → 1.5 Keep working while a calculation runs → Calculation running / Ready reminder · example / Completed result。已只读核对线上展示；旧提醒截图与计算截图原本是不同 Claim，不作为同单验收证据。

[POC V25 reference](https://jlrappian.nttdatadm.com/before-after/releases/v25-20261011-ec1f8c956141/#calculation)

## 2. 分类、优先级与关联

| 项目 | 结论 |
|---|---|
| 主要改动类型 | Application前端交互及性能；后端性能诊断/调用/查询优化按真实证据决定 |
| UX/UI only？ | 不是只换样式。涉及本地草稿、异步校验、旧响应、保存版本和失败恢复 |
| Integration needed？ | 正式验证需SAP/Apigee、WIPS/Automation Anywhere团队提供追踪和契约；不预设一定要改SAP接口 |
| 现有接口复用 | Part/Price可评估复用MCI_getPartDetails与MCI_getPartPriceDetails；目录不能证明它们就是慢点或已提供全部Plant条件 |
| 新增架构？ | 暂无证据需要新系统/总线。先拆分控件反馈与来源校验，再按诊断优化现有路径 |
| 原始优先级 / 建议 | 原文Must；建议P1、在RPA Error走查前完成。实测若大范围阻断提交，再评估P0；无签核毫秒指标 |
| Epic / ACT | 复用CNP-234 / ACT-064 Buyer Review Required — RPA Error；本轮不写Jira [S4] |
| Related FR | 主FR13，FR14关联手工/异常处理，FR1.6关联Part/Plant参考数据 [S2] |
| UC | 当前映射未找到已签核独立UC编号；本包S1–S6只是场景别名，不冒充BRD UC |
| 页面 | P15.19 Buyer Review — WIPS RPA Error；一张页面的多种状态，不是新增6页 [S5] |

同号NEO-028在Archive第31行是“查看Mandate/Transaction信息”，在NEO RTM第32行是“Part Level Data”。本轮只按Requested Changes第29行分析，不混用。[S1-ID-A、S1-ID-B]

## 3. 基线与差距

Training第1718–1736段：Buyer组处理相关任务，显示Bot返回的错误状态，分价格不一致、Missing Parts、Plant Specific Pricing三类。实际错误码/区块可见性还等WIPS Integration配置。历史图是checkbox和价格等列，不能证明它已经有新需求提到的Include／Exclude、Plant下拉。[S3、S15]

当前BuyerRpaReview.tsx同步patch本地输入和checkbox，Missing Parts只有Part Number、Start Price、Start Price Currency，没有完整的Include／Exclude和Plant选择。buyer-review.ts明确只保存本地review，没有真实Bot重试/结果契约。本地同步代码不能证明历史Appian的5秒延迟已经修复。[S6、S7]

已查Word修订/格式：FR13无划线条款；FR14中划掉的“Transactions Drivers and System to update”不作为本轮活动控件。绿色高亮不等于已批准；现有批注也没有证明5秒延迟的根因或目标。具体记录见SOURCE_EVIDENCE.json。

共享QA的FR16-Q02、F1021-10、NQA-122已记录实际错误码、checkbox语义、提交后RPA重试未定义。本包保留缺口，局部通过不覆盖为现网通过。[S14]

## 4. 页面、字段和接口方案

| 控件/数据 | 交互设计 | 来源/限制 |
|---|---|---|
| Part Number | 只读，按稳定行键定位 | MCI_REF_PART.PART_NUMBER；Claim-Part通过PART_ID关联，显示码不能替代整数外键 [S13] |
| Start Price / Currency | 本页只读，保留金额/币种 | 沿用Training和当前离线样本形状；本需求不重写定价公式 [S3、S8] |
| Include / Exclude | 点击先更新本地草稿，不等待来源检查 | 新需求明确提到；Exclude究竟是排除本次重试还是删除Claim零件，仍未确认 [S1、S14] |
| Plants | Include后启用；选中立即可见 | Claim-Part有PLANT_ID，但字典不提供实际Vendor/Part有效组合，也不能证明允许多选 [S13] |
| Checking part data | 输入继续可用；只接受最新草稿和来源版本的结果 | 本轮建议；计数是本地模拟检查次数，不是真实SAP请求 |
| Retry / Refresh | 失败保留输入；刷新后重查有效性 | 来源为空不能冒充成功，也不能把缓存向所有用户共享 |
| Save review | 校验最新basis后确认，保存时再核Owner/Task/Revision/来源和固定字段 | 本轮内存保存；不关Task、不启动Bot、不显示Implemented |
| Check save result | 未知结果只查原intent，禁止重造一次提交 | 收据查询是本地模型；真实查询/幂等契约未收到，内部intent不是WIPS编号 |

控件反馈表示“我选中了”；检查表示“选择仍有效”；保存收据才表示“这次review已保存”。三者分开，避免慢请求锁住所有输入，也避免把下游未完成说成完成。

**待确认的候选约束：** 初始不默认Include；Include至少选一个Plant；Exclude保存不带Plant；切回Include前暂存原Plant；整批决策完成才保存。这里只为了展示可评审交互，不能当签核业务规则。

| 系统/接口 | 证据 | 复用与边界 |
|---|---|---|
| SAP → Appian，经Apigee，MCI_getPartDetails | CSV第7行GET，Vendor路径和plant/offset/limit，无body [S12] | 可评估按授权Vendor/Part预加载或缓存；响应粒度、有效性、缓存期未收到 |
| SAP → Appian，经Apigee，MCI_getPartPriceDetails | CSV第8行GET，Vendor、plant、materialNumber、offset/limit [S12] | 若确有依赖，价格读取单独异步；保留币种、版本和有效期间 |
| Appian → WIPS，经Automation Anywhere | CSV第18行MCI_raiseWIPSClaim，POST deployments [S12] | 选择动作不直接触发建单/重跑；iStrAppianInputJSON登记示例不是完整业务payload |
| WIPS → Appian API | CSV第22行MCI AA WIPS Response [S12] | 待明确实际错误码、相关ID、成功/失败回执和未知结果查重 |
| 未来应用/Flowable | 迁移背景，不是本需求提供的已部署结果 | 应用保存review及权限版本；只在确认的事件/回执后流转，不因先勾上checkbox就推进流程 |

API目录里的300不得解释成业务SLA、交互目标或本次实测耗时；本轮没有外部HTTP调用。[S12]

## 5. 六张真实候选页截图

以下是本轮独立页、合成用户和数据的浏览器截图，不是原Appian截图，也不是正式验收。原Training图未修改。

### S1 · Missing Parts初始状态

![Initial missing parts](screenshots/01-missing-parts.png)

Alice Morgan为任务Owner，两行尚未决策，Plant和保存未启用。

### S2 · 选择已反馈，校验仍在等待

![Immediate selection while checking](screenshots/02-checking.png)

FX230069AA已Include/PL-SOL，02C2D19768已Exclude；Checking仍显示，没有假装保存。

### S3 · 最新选择检查完成

![Checked selections](screenshots/03-checked-selections.png)

只有当前草稿basis检查完成才可保存；旧响应不能覆盖新选择。

### S4 · 保存后回读

![Saved review](screenshots/04-saved-review.png)

内存回读两行决策与Plant；revision7→8，Task仍Open，不代表WIPS已建单/批准。

### S5 · 来源检查失败

![Reference failure](screenshots/05-reference-failure.png)

错误可见，选择保留，Retry check恢复同一份草稿。

### S6 · 任务并发修改后的恢复

![Conflict recovery](screenshots/06-conflict-recovery.png)

不覆盖并发修改；显式复核最新任务后保留选择重查，revision8→9。

## 6. 数据与操作

| 场景 | 谁/输入 | 操作 | 预期 |
|---|---|---|---|
| 正常 | Alice Morgan；MCI-00057；内部合成Task RPA-028-REVIEW；revision7；PART-PLANT-028-v3 | FX230069AA Include、PL-SOL；02C2D19768 Exclude；等检查后Save review并确认 | 选择即时可见，内存revision8，两行准确，Task仍Open |
| 改选/旧响应 | Part check in progress，模拟900ms校验 | 在校验期间把第二行Include改回Exclude | 最后Exclude保留，旧返回丢弃，只接受当前basis |
| 来源失败/空 | Part data unavailable / No plants returned | Retry check；来源恢复后重查 | 输入保留，失败时不许保存 |
| 来源换版 | Reference version changes | Refresh part data | v4重查，不拿旧v3结果保存 |
| 并发/关闭 | Task changes before save / Task closed before save | 检查后保存 | 冲突要求显式复核；关闭拒绝保存；均保留草稿 |
| 未知结果 | Save result not received / Receipt unavailable | Check save result | 查原intent，不重复提交；读不到继续阻止新保存 |
| 大列表 | 100 parts across pages | 翻页选P28010 | 分页10行；行键稳定；整批校验含屏幕外行 |
| 其他Buyer | Bob Wilson | 打开Alice任务 | 不显示业务数据或编辑控件；真实认证越权仍NOT RUN |

FX230069AA/86.34GBP、02C2D19768/56.89EUR沿用当前离线样本形状；本轮是独立内存对象。PL-SOL/PL-HAL可用组合仅为合成参考，非正式SAP主数据。[S8]

## 7. 开发如何落地

1. **先找慢点。** 用同一任务/请求关联ID记录点击、渲染长任务、重复请求、应用、Apigee、SAP RFC、SQL、Robot日志。先分辨是控件等网络、整表重渲染还是源系统慢，不能先认定SAP RFC。
2. **前端拆状态。** Radio/Select先更新稳定row key的本地草稿；来源检查单独loading；取消/忽略旧响应；限定受影响行重绘。目录缓存必须按授权、Vendor、Part、来源版本隔离并失效。
3. **按证据修应用。** 去重引用请求、按需列/分页、查看SQL计划和索引；保存重查当前权限/状态/版本。不能清空数据掩盖错误，也不能默认放宽来源校验。
4. **接口/BPM沿用已确认契约。** 先确认error→修正→重试事件/回执，再接机器人；未知结果先查原请求，避免重复Claim。只因checkbox选中不得推进状态。
5. **同条件复测。** 以真实规模/并发/网络设备比较优化前后分布及高分位，确认业务结果和权限不变。目标由业务/技术签认，100行fixture和900ms模拟不等于生产容量/SLA。

优先触点：src/views/Tasks/BuyerRpaReview.tsx、src/domain/wips/buyer-review.ts。查明真实调用链后再调整adapter/API/DB；不能直接把多Plant塞进selected:boolean。本包没有修改这些产品文件或合并分支。

## 8. 验证、退出条件与未测范围

79项浏览器检查与42项内存模型检查结果见PAGE_VISUAL_CHECK.json、DOMAIN_CHECK.json，每项包含Expected/Actual。覆盖即时选择、旧响应、权限/任务/版本、固定字段篡改、重复/缺失Plant、确认返回、失败重试、未知收据、分页、键盘与六宽度。

真实检查1920/1440/1024/768/390/360 CSS px，CSS200%另外记录；原生浏览器200% NOT RUN。本地事件到后续requestAnimationFrame耗时保存在PAGE_VISUAL_CHECK.json，只说明合成页本地反馈，未测SAP/网络/服务端，也不以虚构毫秒阈值宣称业务通过。

| 层次 | 结论 | 退出要求 |
|---|---|---|
| 独立页面/内存模型 | 局部执行结果见附件 | 截图与实际HTML同版，选择/保存/失败一致 |
| 当前产品集成 | NOT RUN | 产品实现并复测，独立候选不等于产品已修复 |
| 实际API/DB | NOT RUN | 原子保存、幂等、版本冲突、持久回读通过 |
| SAP/Apigee/RPA性能 | NOT RUN | 追踪确认根因，代表性规模及签核目标达成 |
| BPM/真实WIPS | NOT RUN | 已确认恢复契约、原单关联及状态推进一致 |
| 业务验收/部署 | NOT RUN | Include/Exclude、Plant规则与目标确认，发布另行授权 |

20条来源路径/定位/SHA见SOURCE_EVIDENCE.json，最终回读与文件清单见VALIDATION.json。共享QA只读。

## 9. 业务问题（讲人话）

1. **5秒到底慢在哪？** 请提供一次真实任务的浏览器Trace/请求及关联日志。例：没有网络却5秒才变色，要查前端；发了3次同样SAP请求，要查编排。现阶段不能说SAP已被证实。
2. **Exclude到底排除什么？** 例：排除本次Bot重试，还是从Claim/Settlement删除零件？本轮只保存review决策，不删除业务明细。
3. **Plant能多选吗，范围怎么定？** 例：一个Part可同时选Solihull和Halewood吗？需要实际Vendor/Company/Part组合和response，字典PLANT_ID本身不够。
4. **每次勾选必须问SAP吗？** 例：目录已加载，能否先更新草稿、保存前再验？需明确哪些检查必须实时做，不能为快跳过规则。
5. **来源变版怎么处理？** 例：选择后Plant关系或价格更新，是重查该行还是整批？需要版本、有效期、刷新责任。
6. **保存后谁继续？** 例：自动重跑原Bot，还是Buyer保存后交CBSL/工作流？需真实错误码和恢复事件，保存成功不代表WIPS成功。
7. **结果未知查哪里？** 例：请求超时但其实已保存，用哪个ID回读，何时才准重试？现有目录未提供完整review收据契约。
8. **按多大规模、多少时间验？** 例：普通笔记本正常网络、100/1000个错误零件分别要求多快？业务/技术共同定目标，原文5秒只是症状。

以上关联现有FR16-Q02/F1021-10；本包不新建另一个总问题台账。

## 10. 交付物与下一步

英文独立页、中文HTML/MD、6张实际截图、OPEN_QUESTIONS_CN.md、SOURCE_EVIDENCE.json、局部检查JSON、可编辑TSX/模型/主题快照/build/test、README及完整ZIP。不额外生成Word/PDF或另一份主QA Excel。

下一条NEO-029：NEO Timeout Duration（Requested Changes第30行），涉及会话到期、编辑进度保存及Cyber Security政策；本轮不提前实施。

### 10.1 来源索引

本轮阅读日期2026-11-13；原历史截图拍摄日期未知，不能写成本轮现场验收。完整引文、原路径、SHA及同号差异见SOURCE_EVIDENCE.json。

| ID | 原文件 | 定位 | SHA前12位 |
|---|---|---|---|
| S1 | NEO Business Requirements (added China requirements) 1.xlsx | RTM for Requested Changes row29 (1-based) | b83b74cb3eb2 |
| S1-ID-A | NEO Business Requirements (added China requirements) 1.xlsx | RTM - Archive row31 (1-based) | b83b74cb3eb2 |
| S1-ID-B | NEO Business Requirements (added China requirements) 1.xlsx | NEO RTM row32 (1-based) | b83b74cb3eb2 |
| S2-8 | Material Cost & Inventory - BRD V3.1.docx | Table6 row8 (1-based) | 0d6aedc1538c |
| S2-38 | Material Cost & Inventory - BRD V3.1.docx | Table6 row38 (1-based) | 0d6aedc1538c |
| S2-39 | Material Cost & Inventory - BRD V3.1.docx | Table6 row39 (1-based) | 0d6aedc1538c |
| S3 | NEO User Training.docx | Body1718–1736 (1-based); historical error task, actual integration codes not supplied | bf942f7a70e6 |
| S4 | story_data.json | ACT-064 / CNP-234; read-only mapping, not Jira update | a2e47d1cde32 |
| S5 | scope.json | P15.19 stable existing page ID | 74aae9869a99 |
| S6 | BuyerRpaReview.tsx | Numbered current source lines (1-based); inspection not product execution | e1ecd044cd7a |
| S7 | buyer-review.ts | Numbered current source lines (1-based); inspection not product execution | dddc42f7aa5e |
| S8 | buyer-rpa-sample.ts | Numbered current source lines (1-based); inspection not product execution | f8ace20483c2 |
| S9 | enquiry-parts.ts | Numbered current source lines (1-based); inspection not product execution | 4569f09932f0 |
| S10 | index.ts | Numbered current source lines (1-based); inspection not product execution | 82b56dcd8c92 |
| S11 | personas.ts | Numbered current source lines (1-based); inspection not product execution | 9c30e405c28f |
| S12 | Integrations - 2026-11-09_0941(Sheet 1).csv | CSV physical rows7/8/18/22; existing parts/prices/WIPS deployment/callback directory, not profiling or recovery contract | 5e40049996bb |
| S13 | NEO_数据字典.xlsx | 字段字典 rows318–352 and814–843; Part/Plant/price and Claim-Part storage only | 22342fd6253c |
| S14 | review-data.json | Existing FR16-Q02/F1021-10/NQA-122; original scope/status retained | 8fcbf8fdf490 |
| S15 | before-training-396.png | Historical Training screenshot viewed2026-11-13; original capture date not supplied | 321211f41ade |
| S16 | NEO_UXUI_PRINCIPLES.md | Current project UX reference; entire file read-only | 2722dc05eae2 |
