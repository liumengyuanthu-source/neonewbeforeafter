# NEO-050 · Before / After

050 只修正审批状态：相关审批全部完成，且 FBP 标记 Complete 后，Request 才显示 Approved；此前保持 In Approval。

## Before

需求表记录的问题：一方已批准、另一方仍待批准时，却显示 Awaiting implementation。导览中的 Before 保留当前 NEO 原型截图；该截图本身不证明已重现这项历史问题。

## After

| 条件 | Request 状态 | 处理 |
|---|---|---|
| 相关审批尚未全部完成 | In Approval | 继续等待审批；不显示 Awaiting implementation。 |
| 审批全部完成，FBP 尚未标记 Complete | In Approval | 等待 FBP 完成；不提前显示 Approved。 |
| 审批全部完成，FBP 标记 Complete | Approved | 保存审批结果，并关联本次申请的 Line 和 Parent。 |

同一 Request 的列表、详情及对应 Line／Parent 显示同一审批结果。Clearing House = Complete、Request = Approved、Workflow／Implementation 各自独立；不自动变为 Implemented、Paid 或 Closed。多 Line 部分批准／拒绝沿用 FR10.6，不把整组强制标为 Approved。

例：采购已批准、财务待批准 → In Approval；财务也批准、FBP 尚未完成 → In Approval；FBP 点击 Mark Clearing House complete 并确认 → Approved。此时实施仍可为 Not started。

页面：P4.7 · Update Approval Request／审批详情；P4.1.12 · Each Line Approval/Decline。对应 ACT-017、ACT-019、ACT-024；FR10.2、FR10.6。

本次不改审批路线，也不新增外部接口。修改 Request 状态判断和 Line／Parent 关联显示；尚未完成 FBP Complete 时保持 In Approval，沿用现有独立设计。正式系统保存、并发及跨页回读仍须验证。

## References

- R01 · 8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 2(RTM for Requested Changes)_1113 1400 version.xlsx · NEO Business Requirements (adde!E51 / M51 / Q51
- R02 · 6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx · Table 6, row 33 — FR10.6
