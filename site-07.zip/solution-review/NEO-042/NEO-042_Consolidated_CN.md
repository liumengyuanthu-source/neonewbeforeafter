# NEO-042 · AMM流程与页面设计（2026-11-16修订）

AMM 在这里是 Automaterials 相关的 POA 调价场景：Buyer 为每个 Part 记录材料联动的 Escalator Code，经审批后交 CBSL 更新 WIPS，再由采购经理确认 WIPS 审批。042 要解决的是每个 Part 只能填3条的问题，不是另起一条审批流程。

| 项目 | 说明 |
|---|---|
|Before：历史业务限制|需求原文描述每个 Part 只能提交3个 Escalator Code，多出来的联动信息依赖 complex worksheet 附件。当前 Before 仍显示冻结 NEO prototype 的 Parts 入口；这张图没有完整 AMM 编辑器，不能拿它证明旧系统的3条限制。|
|After：Buyer录入|沿用 P2.6.1 选 Parts、P2.6.2 Part Prices。在选定 Part／Plant 下增加可增减的 Escalator Codes 明细；保留 ATP Reference 和原价格字段。新增第4、第5条不用把剩余明细移到复杂工作表。|
|After：审批与执行|提交时保存本次 Part＋Codes＋ATP Reference 的版本，审批页只读查看；获批后 P15.15 CBSL AMM任务展示同一获批明细。CBSL不能顺手改价或改已批Code；商业内容有变化，退Buyer修正并按既有审批规则处理。|
|After：完成边界|CBSL在WIPS处理完并完成任务后，进入采购经理 P15.9 WIPS Approval Request。Training要求采购经理填写WIPS批准日期并提交，才进入 Implemented – Manual Update；不能把CBSL Complete直接当整单完成。|
|上限与接口|10–15是需求提出的范围。设计用10作边界样例，并可在References测试15；不声称WIPS已支持15。FR14保留CBSL人工实施，现有MCI_raiseWIPSClaim条目不能证明支持AMM可变长度payload；本次不增加自动调用。|
|影响|前端新增可变明细，应用保存及审批快照需要保留每条Code，CBSL交接与导出不得丢失或截断。不是纯UXUI修改；是否扩展机器人接口取决于后续自动化选择，无证据要求新平台。|

## Before / After 流程

**Before**：Buyer建POA／AMM并选择Part → 每Part最多3个Code，更多信息放complex worksheet → 既有Mandate／Settlement审批及GFS检查 → CBSL Manual System Update – AMM → 采购经理WIPS审批确认 → Implemented – Manual Update。

**After**：Buyer建POA／AMM并选择Part → 在同一Part下直接录入全部Code，校验并保存 → 审批人查看冻结明细及支持文件 → CBSL按同一获批明细更新WIPS → 采购经理记录批准日期并确认 → Implemented – Manual Update。


## 示例

例子：Part A需要E01、E02、E03、E04、E05五个Code；Part B只需要E01、E02、E03。Before：A的第4、5条要放到附加工作表。After：A保留5条、B保留3条，各自保存和查看，不能合并成整个Claim共8条后丢掉Part归属。这些是设计测试值，不代表真实材料Code，也不据此计算价格。

## 实施依赖

请WIPS／CBSL确认每Part正式上限及允许的Code／字段，例如第11条能否录入；请AMM业务Owner提供一笔现有ATP，核对Code和Part／Plant的绑定及交接内容。先沿用FR14人工实施，不以现有通用RPA接口冒充AMM接口。

本次是独立设计，主NEO prototype未改。4个页面检查点使用独立示例前置状态，切换不代表真实完成审批或交接。新增Code必填／防重复是建议校验，不是旧BRD已确认规则。原方案的“权重必须100%”、基期和公式输入未获来源确认，已从本次业务界面移除。AMM净重、毛重等字典字段也不能直接当指数权重百分比。

## ACT / FR / 页面

ACT-001 / ACT-004：Create/Update Claim；FR1.2/FR1.6/FR6；P2.6.1/P2.6.2。ACT-025：CBSL Complete Task，FR14，P15.15。ACT-038：采购经理WIPS确认，P15.9；Training WIPS Approval。关联UC-20（AMM/ATP场景）。ACT-026/027仅为相关现有能力，不代表批量导入或自动机器人已支持多Code。

## Sources

- R01 · 8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 2(RTM for Requested Changes)_1113 1400 version.xlsx · NEO Business Requirements (adde!E43 / Q43 · >3 Escalator Codes per Part; requested maximum range10–15; avoid complex worksheet attachments
- R02 · 6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx · Table6 rows4,8,39; FR1.2 / FR1.6 / FR14 · POA transaction breakdown, Parts/Plant/ATP Reference; Automaterials excluded from standard WIPS simulation; AMM manual task assigned to CBSL
- R03 · 6.技术方案/2 - Tech NEO/NEO User Training.docx · Body paragraphs1239–1241; image284.png / rId309 · Manual System Update – AMM: Claim link, Comments, File Upload, Save as Draft and Complete
- R04 · 6.技术方案/2 - Tech NEO/NEO User Training.docx · Body paragraphs1368–1375; image315.png / rId340 · After CBSL ATP/AMM/Resource completion, Purchasing Manager task and email; approval-date submission transitions to Implemented – Manual Update
- R05 · 6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv · Integration12 MCI_raiseWIPSClaim · Generic Automation Anywhere deployment entry only; no verified AMM multi-code schema or capacity
- R06 · 6.技术方案/2 - Tech NEO/NEO_数据库设计.md · MCI_RISK_OPPORTUNITY_PART / AMM_LINKED_VALUE, AMM_MEASURE_UNIT, AMM_TOTAL_WEIGHT, AMM_NET_WEIGHT, AMM_GROSS_WEIGHT · Existing AMM-related attributes; not proof of a variable Escalator Code child table or100% weighting
- R07 · outputs/NEO_143_Page_Screenshots_20261104/scope.json · P15.15 Manual System Update — AMM; P15.9 WIPS Approval Request · Existing page IDs; do not invent a new top-level AMM page
- R08 · outputs/neo-jira-stories-20261111/v3/story_data.json · ACT001,004,025,038; related UC20 in working BRD · Create/Update Claim, Complete Task and Purchasing Manager WIPS Approval
