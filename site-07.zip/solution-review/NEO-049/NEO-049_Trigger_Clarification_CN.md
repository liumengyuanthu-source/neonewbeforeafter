# NEO-049 · 合同任务触发说明（2026-11-16）

049 分两次触发：最后一项适用审批／GFS检查完成后，系统生成 Buyer 合同实施任务；Buyer 核对并确认 Assign to Digitide 后，才把同一实施任务交给 Digitide。

## Before

历史要求中，Trading Division 先由 GFS 检查，再完成适用审批，之后生成 Buyer 的人工实施任务（FR11、FR14）。049 原文指出，任务会停在 Buyer，因为 Buyer 不清楚需要指示 Digitide 建合同。EPMC／BAC 的完整现网路线尚无足够证据，不能把 TD 顺序套给所有分支。当前 Before 图片只证明现有原型的 CBSL 任务入口，未展示完整合同交接。

## After：生成 Buyer 任务的明确条件

### 普通 Line 的 Settlement

Buyer 提交最终 Settlement → 如需要，完成适用 DoA，FBP Mark As Complete；若沿用已有 Mandate，则记录 FBP“无需进一步审批”的决定 → 到达现有日期规则允许的检查时点 → GFS 在该 Line 的检查任务点击 Confirm。最后这个 Confirm 是通常触发合同实施任务的事件。单独批准 Mandate 不触发建合同。

Reference: R02 FR9.1、FR9.4、FR10.6、FR11

### Trading Division

Buyer 提交 TD Request → GFS 检查并确认审批路线 → 相关审批全部完成，适用 Clearing House 项由 FBP Mark As Complete → 生成 Buyer 的人工实施任务。这里最后触发的是审批完成，而不是提前在 GFS Confirm 时建合同；不强制再做一次 GFS 检查。

Reference: R02 FR9.2、FR11、FR11.1、FR14；R03 ¶1429–1430

### 两条路线共同校验

当前有效的获批 Request／Settlement 及范围未被取消、退回或修改；适用 Line 的检查和日期等待已完成；记录已配置为 SAP ECC 容器合同分支。只传递获批范围，不能因 Parent 下部分 Line 获批就整组放行。EPMC／BAC／TD 的实际路由映射由配置决定，不把 EPMC 与 EMC 擅自视为同义。

Reference: R01 E50／Q50；R02 FR10.6、FR11、FR14；本次建议控制

## After：交接及执行

### 1. 生成并打开合同指令任务

P3 · Tasks → P3.5 · Manual implementation task · 系统 → Buyer

最后一个适用前置事件提交成功后，系统检查上述条件，创建一个 Create / progress container contract 工作项，并放入关联 Buyer 的 Tasks。携带 Request／Settlement、适用 Line、批准版本和文件；Buyer 可从通知或任务列表打开。首次任务在 Buyer 名下，尚未分派 Digitide，更未调用 SAP。

### 2. 核对后明确分派

P3.5 · Contract instruction → Assign to Digitide · Buyer

核对供应商、公司／采购组织、适用 Part、批准价格／币种、有效日期、合同指令及必需附件。点击 Assign to Digitide → 确认。提交时再次核对批准版本和权限，只更新同一任务的执行组／责任人并留下审计；重复点击返回已有交接结果，不创建第二个任务。资料缺失时列出缺项，保留输入，暂不分派。具体必填清单需按 SAP 合同模板落实。

### 3. 领取任务，在 SAP 处理合同

P3 / P3.5 · Digitide task → SAP ECC · Digitide

有权的 Digitide 成员在队列领取，按冻结的批准指令进入 SAP ECC 创建或继续处理容器合同。NEO 负责交接和跟踪；本方案由人员操作 SAP，Assign to Digitide 本身不创建 SAP 合同，也不复用 Lump Sum PO 接口冒充合同接口。

### 4. 缺资料时退回，补齐后继续原任务

P3.5 · Return to Buyer → Resubmit to Digitide · Digitide → Buyer → Digitide

Digitide 点击 Return to Buyer，必须列明缺项和原因；原合同实施任务进入等待补件并由 Buyer 处理。Buyer 补齐后点击 Resubmit to Digitide，同一 Task ID 回到原处理人（仍有权限时）或 Digitide 组，保留既有合同号、附件和历史。只补资料不重新建合同；若价格、Part、金额或批准范围改变，则暂停实施，完成适用重审后再继续。SAP 合同被拒绝不是普通补件，不能在此绕过重建／重审要求。

### 5. 登记合同及逐项处理结果

P3.5 · Record contract · Digitide

在 NEO 输入 SAP 合同编号（文字保存，保留前导零）、逐项处理结果、操作时间和证据。仅有合同号时，记录为已创建／待审批处理结果，任务继续跟踪；不把 Request Approved、Task Completed 和 Claim Implemented 合并。

### 6. 确认批准／释放与生效依据

SAP ECC approval / release → P3.5 result confirmation · SAP 合同审批责任人 → Digitide

合同审批责任人在 SAP 按现行权限完成审批／释放。Digitide 在原任务补录实际结果和证据；若仍待批准、有失败／拒绝行或适用日期尚未满足，则保留待处理状态。只有相关范围的实际结果满足该分支实施完成条件，才允许完成任务并按现有流程推进 Implemented；不能因录入编号自动置为已实施、已付款或整单关闭。这里的结果用语是业务展示含义，不冒充已确认的 SAP 状态码。

## 例子

例如：BAC 的 Settlement v3 已批准、FBP 完成适用审批，GFS 为 Line A 点击 Confirm → 系统把合同指令任务交 Buyer。Buyer 确认资料后 Assign to Digitide。Digitide 发现缺签署附件，Return to Buyer；Buyer 只补附件后重提，仍是原任务。SAP 合同 00004567 已创建但未释放时，只登记编号并继续等待；取得该合同相关行的实际批准／释放和适用生效依据后，才推进实施完成。若 Buyer 将批准价格95改成96，则不走普通补件返回，而先处理重审。此为设计例子，不是现网执行记录。

## 实施边界

本次采用 Buyer 核对后明确分派的建议方案，不默认自动跨组分派。正式实施只需补齐两类配置：①各 EPMC／BAC／TD 分支的实际路由及必需合同资料；②SAP 合同审批／释放状态、有效日期和完成证据的对应关系。现有接口资料未证明可自动创建或回读该容器合同，本版保留 Digitide 在 SAP 操作并在 NEO 登记证据。当前修改是说明与设计流程，不代表任务服务或 SAP 已实现。

## References

- R01 · 8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 2(RTM for Requested Changes)_1113 1400 version.xlsx · NEO Business Requirements (adde!E50 / M50 / Q50
- R02 · 6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx · Table6 rows22,23,25,33,35,36,39; FR9.1 / FR9.2 / FR9.4 / FR10.6 / FR11 / FR11.1 / FR14
- R03 · 6.技术方案/2 - Tech NEO/NEO User Training.docx · Body paragraphs1429–1430 (one-based paragraph index, not page number)
- R04 · NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx · UC-18 / UC-20, paragraphs319–325 /333–339 in prior assessment
- R05 · 6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv · Integration directory; no container contract operation established
- R06 · outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/epic-review-035-068-20261113-v1/CNP-234/SOURCE_REGISTER.json · PAGE-P3 / PAGE-P3.5 / PAGE-P3.6 / PAGE-P4.4; NEO-049 source entries
