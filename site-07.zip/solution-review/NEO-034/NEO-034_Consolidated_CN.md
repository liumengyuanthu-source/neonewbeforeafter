# NEO-034 · Reporting Category 与 Lever 组合校验

## 1. 本次结论

这条要解决的是：**两个下拉值各自合法，放在一起却不符合 Finance 的分类要求。** 例如选了某个 Lever，却配上业务不允许的 Reporting Category；目前没有组合限制，后面的准备金／报告就可能分错类。[S1]

建议建立一份由业务签认、带版本的允许组合清单，在两边修改时使用同一校验：**Finance 改 Reporting Category，Buyer 改 Lever，都检查完整配对。** 不能只改一个下拉框，也不能为了纠错让 Finance 任意改 Buyer 的 Lever，或让 Buyer 取得 Finance 字段权限。[S2-4、S2-14、S2-16、S3、S6–S8]

原需求允许“限制有效组合”或“至少弹窗提示”。本独立页面同时提供两种评审情景，推荐限制模式；正式采用哪一种仍需业务确认。**实际允许配对、维护人员和历史处理政策未收到，所有页面配对都是合成示例，不是已批准业务矩阵。** 现有 prototype、共享 QA、配置、数据库和线上数据均未改。

## 2. 来源、改动类型与优先级

| 项目 | 内容 |
|---|---|
| 主记录 | Requested Changes 第35行，NEO-034；Finance / Lump Sum Process；Existing functionality - Update UX / Workflow；L35 Must |
| E35 原意 | 建立 Reporting Category 和 Lever 的 compatibility matrix；当前没有对组合进行检查／限制 |
| P35 原意 | 能维护允许组合；只允许清单内的组合，或至少弹窗提示用户当前组合无效，请重新考虑。原文“level”保留在证据中，结合上下文指 Lever，不是 DoA 级别 |
| 主要改动类型 | **Application 内部前后端＋配置／数据关系**；UXUI 是其中一层，不能仅前端隐藏选项 |
| 内部要改什么 | 两字段联动、保存时重校验、组合配置／版本、权限、审计、失效引用及导入／API 入口一致性 |
| Integration needed | 没有证据要求新增外部系统。业务应用内部读写接口需接入同一校验；如某外部系统消费这些分类，需另核实已有契约，不能推定要改 SAP／WIPS |
| 可复用 | Lever／Reporting Category 参考数据、现有 Finance 和 Update Claim 保存、记录权限、Settlement 锁定、参考维护页面及审计模式 |
| 不能直接等同 | Team Category Mapping 根据 Category＋Lever 决定 Team／科目／Cost Centre。它不是“合法配对清单”，其中空 Lever 也不能自动变成允许任意 Lever 的通配规则 |
| 是否新架构 | 优先在既有应用里补关系配置和统一校验服务；若现表不能表达允许配对及版本，增加适当数据结构。不先引入新平台 |
| Priority | 来源 Must，建议 P1；**P0 前置**是业务提供完整矩阵、范围和限制／提示政策，避免把错误示例发布成全局规则 |

**同编号勿混用：** Archive 第37行 NEO-034 对应取消 Mandate／Settlement、FR10.7；NEO RTM 第38行 NEO-034 对应 All Risks／Opportunities、FR4。本条来源是 Requested Changes35。[S1-ID-A、S1-ID-B]

## 3. Epic、ACT、FR、UC 和页面

| 层次 | 对应 | 影响 |
|---|---|---|
| Epic | CNP-231 建档／编辑／参考数据；CNP-235 Finance／Reserve | 来自既有 story_data，不新增 Jira 写入 |
| ACT-001 Create Claim | FR1.2 | 创建时维护 Lever；Finance Category 尚未分配，不凭本需求新增创建必填字段 |
| ACT-004 Update Claim | FR6 / FR6.1、FR1.2 | Buyer／授权采购用户改 Lever 时，要查已保存 Category；保持原 Buyer Code 范围与锁定 |
| ACT-006 Edit Finance Data | **FR6.2 主关联** | GFS／FBP 改 Reporting Category，不跨权限修改 Lever；保存完整配对 |
| ACT-051 Reference data | FR19.01 / FR19.07 | 两个独立参考目录继续维护；组合关系是本需求新增，不冒充原 BRD 已定义矩阵 |
| ACT-035 Edit Teams | FR17.2 | 检查与 Team／科目映射是否一致，但不把 Team 配置改成合法性清单 |
| ACT-029 Generate Reserve / ACT-041 Finance Claim Report | FR17.3 / FR17.5 / FR20 | 验证分类消费者、当前／历史版本和报告归属；不自动重算或重写 Final Reserve |
| P2.1 / P7.1 | Supplier Claim Details / Update — Supplier Claim Details | 本轮采用现有143页登记表中的编号；只设计受影响字段交互，不替换整个创建向导 |
| **P6.2 / P8** | Finance / Update Finance Data | 主编辑场景，保留 Finance status、Claim number、Reporting Category、Remarks 等原有含义 |
| P17.3 / P17.6 | Lever / Reporting Category 参考页 | 原参考值与活动状态；新组合维护为评审入口别名，没有新造官方页面编号 |
| P22 / P22.1 / P20 | Team Category Mapping / Manage Mapping / Finance Claims | 验证关联影响，当前这些产品页本次未改 |
| UC 场景 | 有效配对、现存无效配对、提示确认、Buyer反向修改、未分配Category、配置改版、保存失败／未知 | S1–S6为本包评审别名，不发明正式 UC 或 ACT 编号 |

BRD FR6.2 和 Training 第654–655段支持 Finance 字段及角色；FR19.01／19.07支持独立参考目录；**新的组合合法性规则来自 NEO-034，不是这些历史 FR 已经规定的事实。** [S2-16、S2-53、S2-59、S3–S5]

## 4. 页面与交互方案

| 条件 | 候选交互 | 保留的边界 |
|---|---|---|
| Finance 编辑 | Lever只读，Reporting Category可选，Remarks／Reason沿用现有保存方式 | 不因新配对要求扩张Finance权限 |
| Buyer 编辑 | Lever可选，已保存Reporting Category和Finance Remarks只读 | 同一配对校验反向生效，不给Buyer新Finance权限 |
| 限制模式 | 不兼容选项置灰；保存仍重新检查 | 直接API或批量入口不能靠前端置灰绕过 |
| 原记录已经不兼容 | 保留原选择并显示明确原因；更换有权限编辑的字段 | 不静默清空另一字段，不自动纠正历史记录 |
| 提示模式 | 允许选择；保存前弹窗显示这两个具体值，要求明确确认 | 候选记录Actor／Reason／规则版本／确认结果；确认不把无效组合变成“有效” |
| Finance Category未分配 | 显示Not assigned；配对为Deferred，不写Valid | 合成初始录入情景仍可保存Lever，不新造Finance创建必填项；正式阶段门槛沿用既有规则 |
| 参考值停用／未知 | 原值仍可见；选择有效替代前不假装校验成功 | 停用规则与历史数据处理待业务签认 |
| 矩阵不可用／无效 | 说明规则不可用，不能把“查不到”当允许所有 | Warning模式也不能绕过没有来源的规则 |
| 配置或参考版本变化 | 旧评审失效，保留输入，按新版本重新评审 | 未确认前不使用旧允许清单保存 |
| 记录修改／新增Settlement锁 | 保存边界再次核验，保留当前真实值与未保存输入 | 不覆盖他人更新，也不以配对校验绕过业务锁 |
| 保存失败／结果未知 | 已知未保存可重试；未知先Check save result查原intent | 未知结果没有第二次写入；Cancel／Back无写入 |

候选以 **Lump Sum** 为主，因为来源分类是 Lump Sum Process；P35 又写“on an ID”，是否扩到 POA／其他交易类型须确认。页面的 POA 情景明确未确认，不把这个候选限制当成新的正式业务规则。

**维护入口：** Jack Edwards 的独立评审情景 → Manage combinations → Add combination／Allowed → Review mapping changes → Confirm mapping。保存产生新版本，旧版本保留，不自动改 Claim／批准快照／Final Reserve／Team映射。Jack 的写权限是合成提案，原 Training 的 Reference／Edit Teams 权限不自动授权新矩阵。

现存无效记录是否允许“只改Remarks”，空字段如何处理，以及发布前是否必须看全量受影响IDs，都需签认。当前限制候选在配对无效时阻止整次保存；这只是供评估的政策选择，不能未经批准推广。

## 5. 字段、关系与接口说明

| 内容 | 已有来源 | 需要补什么 |
|---|---|---|
| Lever参考 | MCI_REF_LEVER，第248–259行；NAME、SHORT_CODE、SUPER／HIGH／MID_LEVEL、IS_ACTIVE | 使用稳定引用ID，不靠显示名称或High／Mid分组猜合法组合 |
| Reporting Category参考 | MCI_REF_REPORTING_CATEGORY，第383–392行；NAME、REASON_CODE、EXCLUDE_INCLUDE_ID、IS_ACTIVE | Include／Exclude控制准备金用途，不等于配对Allowed |
| Claim引用 | MCI_RISK_OPPORTUNITY.LEVER_ID 第706行、REPORTING_CATEGORY_ID 第749行 | 保存时读同一记录的两个值；实际字典为integer引用，候选CAT-*／LEV-*只是合成身份，非生产枚举 |
| Team关系 | MCI_TEAM_CATEGORY_MAPPING，第1795–1810行；Category／Lever加Team／科目等 | 不直接当allowlist；空Lever、优先级、重叠和兜底已有F1021-16缺口 |
| 新组合关系 | 来源明确要求矩阵，但所读字典未确认专用允许组合实体／版本字段 | 候选为Category ID＋Lever ID＋Allowed＋不可变发布版本。实际表名、唯一约束、有效期／范围及审计契约待定 |
| 保存审计 | 现有Finance／Claim保存、原因与版本模式可复用 | 增加实际配对、旧新引用、规则版本、Actor及提示确认；不要只存“用户已看过”的布尔值 |
| 报表／Reserve | 报表Extract第2466／2524行、Reserve report第2622–2625行；FR17.2／17.3／17.5 | 分类关系影响Team、Include／Exclude、科目和报表；需独立Finance回归，不推定金额必然变化 |

现有Finance保存只确认Reporting Category属于活动参考选项，没有联合Lever检查；当前Supplier Claim Details也独立选择Lever。**这是本轮离线源码观察，不是对生产问题的新复现。** [S6–S13]

建议统一校验入口收：Claim身份、预期记录版本、用户有权修改的字段、Reason及原intent；服务端自己解析Actor、读另一个已保存字段及当前矩阵。不要信任浏览器发送的“Valid”或自报角色。配置保存还需基准矩阵／参考版本、关系清单及维护授权。

**COMPATIBILITY_SERVICE_PROPOSAL.json** 仅列候选契约概念，没有发明已存在的HTTP路径或SAP payload。没有收到专门的外部组合数据提供接口；实际责任先落在Finance规则Owner与NEO应用团队。若复用既有配置API，必须扩展前后端及数据约束，不能只增加一张静态表。[S18、S20]

## 6. 六张实际页面截图

NEO theme、JLR Emeric字体、Ant Design 6.7.0；同一32／24／16边距、行前详情图标、表格内横向滚动。业务页没有Pending i或诊断说明，来源放References和本汇总。灰色外部情景栏说明数据与配对均为合成。

### S1 · Finance只编辑自己的字段，非法配对置灰

![Finance restricted combinations](screenshots/01-finance-restricted-combinations.png)

Ben Taylor，FBP Officer；Lever为Currency，只读。示例允许Purchasing Negotiation／Other Matl Cost，不允许Inflation。这里的“允许”仅来自合成矩阵，不能拿去当正式Finance清单。

### S2 · 原来不兼容的值保留可见

![Existing invalid combination retained](screenshots/02-existing-invalid-pair-retained.png)

Inflation＋Currency仍显示原值，说明具体冲突，不能保存；不清空、不偷偷改成另一个Category。Finance可以改成示例允许的Category。

### S3 · 提示模式由用户明确确认

![Warning with explicit acknowledgement](screenshots/03-warning-and-explicit-acknowledgement.png)

弹窗写明这一对值，并提示重新考虑；确认前Save with warning不可用。Back退出不写入，再次评审需要重新确认。保存后审计仍记Invalid／Warning accepted，而不是Valid。

### S4 · Buyer改Lever也检查同一配对

![Buyer Lever edit with same compatibility rule](screenshots/04-buyer-lever-change-same-pair-rule.png)

Alice Morgan可把Currency改为Existing MYAs，Finance Category与Remarks只读。同一参考关系反向起作用，角色权限不因联动而混在一起。

### S5 · 独立组合维护入口

![Manage permitted combinations](screenshots/05-manage-permitted-combinations.png)

Jack在第6行添加Inflation＋Currency，确认后成为Compatibility-v2。旧v1及原Claim保持；没有自动刷新准备金、发邮件或改变现网配置。

### S6 · 保存并回读同一Claim

![Saved Finance values and preserved snapshots](screenshots/06-saved-finance-values-and-audit.png)

MCI-00056从Purchasing Negotiation改为Other Matl Cost，Lever仍Currency；GBP15,000、Finance状态、已批准与Final Reserve快照不变。Activity Log另可看到Ben和实际原因。

## 7. 操作步骤、实际结果与测试边界

| 场景 | 谁、填什么、点哪里 | 本地预期／实际 |
|---|---|---|
| Finance正常修改 | Ben → Reporting Category选Other Matl Cost → Remarks填Classification checked against the current agreement. → Reason填Correct Finance classification. → Review Finance changes → Confirm save | 同一MCI-00056存CAT-OMC／LEV-CUR，revision2；View saved values回读一致；Actor／Reason／规则v1审计存在 |
| 旧无效值 | 选Saved combination is not permitted → 保留Inflation＋Currency | 两值可见，Review禁用；改Purchasing Negotiation后可以评审保存 |
| 警告路径 | Warning policy → 修改Remarks／Reason → Review → 明确勾选确认 → Save with warning | 未确认不允许继续；确认后保存原配对，审计保留Invalid及warningAccepted |
| Buyer路径 | Alice → Lever选Existing MYAs → 填Reason → Review Lever change → Confirm save | 只改变Lever，Category／Remarks不动；初始未分配Category仍为null、Deferred |
| 维护矩阵 | Jack → Manage combinations → 第6行Inflation／Currency → Review mapping changes → Confirm mapping | v2新增关系，旧v1仍5行；原Claim／批准／Reserve／Team不变 |
| 版本冲突 | Rules change after review／Claim changes after review → 评审确认 | 拒绝陈旧保存，保留表单输入；不会覆盖另一Finance用户的真实Remarks |
| 失败／未知结果 | 对应情景→保存；失败重新评审；未知用Check save result | 已知失败无提交可重试；未知查原intent，整条只有一次审计 |
| 全量列表与导出 | 16 mappings → 翻第2页／搜Contracted Raw Materials → Download combinations | 第2页6条；搜Inflation匹配4条Category和另外3条Energy Cost Inflation Lever，搜Contracted Raw Materials为4条；导出仍含全部16，不只当前页 |

**117项实际浏览器检查、115项模型检查通过。** Expected／Actual见PAGE_VISUAL_CHECK.json／DOMAIN_CHECK.json；实际下载的6条v2配对CSV已打开核对并保存为EXPORT_READBACK.csv。另有16条模型CSV例，不能称为正式业务矩阵。

检查包含两角色字段边界、只读／无权／范围外、空字段、历史无效／停用值、两个政策分支、配置发布／重复关系／停用关系、版本冲突、输入保留、幂等和原结果回读、分页与全量导出。检查6种视宽、CSS200%及键盘确认；原生200%缩放、辅助技术认证与实际负载／并发未测。

**NOT RUN：** 真实允许矩阵签认；真实身份／API／DB／导入批量与Memo入口；BPM／审批／DoA／SLA；生产历史数据及配置发布影响扫描；实际Reserve／Team／会计和报告回归；现有prototype全量回归；部署。没有把合成单页或纯模型结果写为业务UAT通过。

## 8. 开发依赖与退出条件

| 顺序 | 谁负责／需要什么 | 退出条件 |
|---|---|---|
| 1 · 业务矩阵 | Finance／业务Owner提供完整有效组合、LSP／其他范围、空值／历史例 | 有签认版本、有效期和反例；不能把本包5个示例当源数据 |
| 2 · 政策与权限 | 业务／Access Owner选限制或提示，明确维护人员、警告确认和适用保存节点 | 不能让终端用户自行切换限制政策；旧记录和在途申请政策清楚 |
| 3 · 关系与服务 | 应用后端／数据团队落实FK／唯一性／版本／审计和所有写入口 | 双向字段校验、服务端权限、CAS、停用引用和未知结果通过；Team映射职责独立 |
| 4 · 前端 | 前端团队在P7.1／P8及配置入口实现本交互 | 角色只改自己的字段，旧值可见，错误／回退／窄屏无数据丢失，遵循NEO设计 |
| 5 · 消费者回归 | QA＋Finance核对Reserve、Team、科目、Include／Exclude和报告 | 同一记录前后分类与源版本可追踪；历史快照不被改写，正式数据出正确结果 |

本包退出条件：独立可操作页面、六图、来源、映射、候选契约、业务问题、实际本地结果、源码／重建说明及ZIP齐全。正式实施退出还需要上面的真实服务与Finance验证；**本包不是“NEO-034已上线”。**

## 9. 待确认问题（讲人话）

| 优先级 | 问什么 | Context和例子 | 建议及影响 |
|---|---|---|---|
| P0 | 完整允许配对是什么，谁签认？ | Currency能配哪些Category？新增Category默认允许还是默认不能用？ | Finance提供按稳定ID／名称核对的清单和反例；不要从名字或Team映射推断 |
| P0 | 用强制限制还是警告？ | Inflation＋Currency不在清单，是否绝不允许保存，还是Finance确认后可保留？ | 推荐限制；如警告，明确谁可确认、哪些步骤、记录什么。候选勾选确认／Reason仍属待签认设计 |
| P0 | 只管LSP还是所有Claim类型？ | 来源归类Lump Sum Process，但正文写on an ID；POA也可能有同样字段 | 先确认适用交易类型／组织／期间，不能从标签自动扩成全量新规则 |
| P1 | 两字段何时必须齐，空值怎么办？ | Buyer先建Claim，Finance还没分配Category，能否继续？历史Line的Lever为空怎么办？ | 不凭此新增创建必填；未齐记Deferred而不是Valid；后续提交／财务关口由业务定义 |
| P1 | 谁维护新矩阵，何时生效？ | Super User能维护Lever，并不必然能更改所有人的配对规则 | 独立授权，带版本、范围和发布确认；实际人员／ID与接口尚未提供 |
| P1 | 旧无效／在途／已批准记录怎么处置？ | 改规则后已有100条不兼容，能否只改Remarks？是否重审，谁纠正哪个字段？ | 发布前评估受影响IDs；不自动批量改值或追溯重写批准／Final快照。当前旧无效阻止保存只是候选 |
| P1 | Team映射与组合清单是否需要一致？ | Team表有Category＋空Lever的兜底，是否表示所有Lever合法？ | 不能直接等同；确认一致性检查和优先级。沿用F1021-16未决项，不消除原问题 |
| P1 | 除页面还有哪些入口和消费者？ | Import、API、Memo或批量更新是否也能写Category／Lever？报表何时看新版？ | 同一服务校验所有适用入口；Finance提供样本验证Team／科目和报告，不能只验两个下拉 |

本包不新建或重写共享QA台账；原FR16-Q08、F1021-16、NQA-73保留其既有证据与边界。缺资料在HTML中黄色突出。

## 10. 交付物与范围

NEO-034_Page_Proposal.html为英文独立交互页；本汇总HTML／MD包含六图、方案与引用；OPEN_QUESTIONS_CN.md便于业务确认；SOURCE_EVIDENCE.json保留原文、完整原路径、定位和SHA；COMPATIBILITY_SERVICE_PROPOSAL.json标明未批准契约；design-source包含可编辑页面／模型、原样NEO主题、字体、构建及验证脚本。

ZIP不带node_modules；可离线浏览，重建需已有或按固定版本安装依赖。Reset／刷新页面会重置内存数据，不是真实持久化。下一项 **NEO-035：Ex Works同口径的£pu与£m显示及导出**，不包含在本条组合校验中。

### 10.1 来源索引

本轮读取2026-11-13。完整原文、原路径、行／表行与SHA见SOURCE_EVIDENCE.json。原Training截图拍摄日和生产配置有效期未推定。当前代码是离线观察，不是本轮生产复现。

| ID | 文件 | 定位 | SHA前12位 |
|---|---|---|---|
| S1 | NEO Business Requirements (added China requirements) 1.xlsx | RTM for Requested Changes row35 (1-based) | b83b74cb3eb2 |
| S1-ID-A | NEO Business Requirements (added China requirements) 1.xlsx | RTM - Archive row37 (1-based) | b83b74cb3eb2 |
| S1-ID-B | NEO Business Requirements (added China requirements) 1.xlsx | NEO RTM row38 (1-based) | b83b74cb3eb2 |
| S1-NEXT | NEO Business Requirements (added China requirements) 1.xlsx | RTM for Requested Changes row36 (1-based) | b83b74cb3eb2 |
| S2-4 | Material Cost & Inventory - BRD V3.1.docx | Table6 row4 (1-based) | 0d6aedc1538c |
| S2-14 | Material Cost & Inventory - BRD V3.1.docx | Table6 row14 (1-based) | 0d6aedc1538c |
| S2-16 | Material Cost & Inventory - BRD V3.1.docx | Table6 row16 (1-based) | 0d6aedc1538c |
| S2-44 | Material Cost & Inventory - BRD V3.1.docx | Table6 row44 (1-based) | 0d6aedc1538c |
| S2-45 | Material Cost & Inventory - BRD V3.1.docx | Table6 row45 (1-based) | 0d6aedc1538c |
| S2-47 | Material Cost & Inventory - BRD V3.1.docx | Table6 row47 (1-based) | 0d6aedc1538c |
| S2-53 | Material Cost & Inventory - BRD V3.1.docx | Table6 row53 (1-based) | 0d6aedc1538c |
| S2-59 | Material Cost & Inventory - BRD V3.1.docx | Table6 row59 (1-based) | 0d6aedc1538c |
| S3 | NEO User Training.docx | Body paragraphs171–185/288–294/344–352/375–383/654–655 (1-based) | bf942f7a70e6 |
| S4 | story_data.json | ACT001/004/006/029/035/041/051 and CNP231/235; not a new official ACT | a2e47d1cde32 |
| S5 | scope.json | P2.1/P7.1/P6.2/P8/P17.3/P17.6/P22/P20; current registry IDs | 74aae9869a99 |
| S6 | ClaimFinance.tsx | Numbered current offline source lines, 1-based; not current live evidence | 3c086ee148e7 |
| S7 | index.tsx | Numbered current offline source lines, 1-based; not current live evidence | f57c3ac67fae |
| S8 | management.ts | Numbered current offline source lines, 1-based; not current live evidence | bc861a2194d9 |
| S9 | source-choices.ts | Numbered current offline source lines, 1-based; not current live evidence | 149edf84489d |
| S10 | reference-catalogue.ts | Numbered current offline source lines, 1-based; not current live evidence | 424b26b032be |
| S11 | team-mappings.ts | Numbered current offline source lines, 1-based; not current live evidence | 8862fba2cfc5 |
| S12 | claim-update-drafts.ts | Numbered current offline source lines, 1-based; not current live evidence | 998fb0e96819 |
| S13 | readiness.ts | Numbered current offline source lines, 1-based; not current live evidence | df3dc292bf35 |
| S14 | locks.ts | Numbered current offline source lines, 1-based; not current live evidence | f29c970d2c72 |
| S15 | References.tsx | Numbered current offline source lines, 1-based; not current live evidence | 7eeeef8ab9b9 |
| S16 | Teams.tsx | Numbered current offline source lines, 1-based; not current live evidence | 22e1f4a850b7 |
| S17 | index.ts | Numbered current offline source lines, 1-based; not current live evidence | 82b56dcd8c92 |
| S18 | NEO_数据字典.xlsx | 字段字典248–259/383–392/706/749/1795–1810/2466/2524/2622–2625; separate reference/claim/team/report fields | 22342fd6253c |
| S19 | review-data.json | Existing FR16-Q08/F1021-16/UI-TEAM-REACT-01 and NQA58/73; keep scope | 8fcbf8fdf490 |
| S20 | Integrations - 2026-11-09_0941(Sheet 1).csv | Full received interface inventory; no identified compatibility-matrix provider contract | 5e40049996bb |
| S21 | NEO_UXUI_PRINCIPLES.md | NEO UI standard: tokens/one-edge/tables/summary section12; independent page only | 2722dc05eae2 |
