# Tom 优先级与既有方案核对

检查范围：最新工作簿的 `RTM for Requested Changes`，不混用 Archive/NEO RTM 中同名编号。原始工作簿未修改。

75条编号需求＋1条AS-IS基线；编号需求为16 Must_Urgent、34 Must、19 Should、3 Could、2 Not Now、1 Non System。AS-IS基线另为Must_Urgent。

**新增编号7个不等于新增主题7个：069–073来自旧主题；074/075为新增主题。060–068共9个编号内容重排，其中060–067为本轮新定义/细化主题，068承接旧061。共10个需新方案或重新定义的主题（060–067、074–075），不等同10个全新功能。**

原Must导览36条中33条继续Must；014、034、056不再Must。当前50条编号Must中17条需补进目录，其中14条编号原已存在、3条新增编号为069/071/072。

建议先做：AS-IS基线与编号冻结 → 002量来源/018及021工厂/032精度 → 003刷新、022并行Claim、030权限、031计算、072可靠性、057状态 → 其余Must。优先级不是排期承诺，数据契约和业务规则仍决定是否可开工。

## 新旧编号对照

| 最新编号 | 旧编号／主题 | 当前联合优先级 | 本轮处理 |
| --- | --- | --- | --- |
| NEO-068 | NEO-061 | Must | 保留旧方案来源，按新编号展示 |
| NEO-069 | NEO-062 | Must | 保留旧方案来源，按新编号展示 |
| NEO-070 | NEO-063 | Not Now | 保留旧方案来源，按新编号展示 |
| NEO-071 | NEO-065 | Must | 保留旧方案来源，按新编号展示 |
| NEO-072 | NEO-066 | Must_Urgent | 保留旧方案来源，按新编号展示 |
| NEO-073 | NEO-068 | Could | 保留旧方案来源，按新编号展示 |
| NEO-051 | 旧NEO-064委托部分 | Must | 转办不自动并入委托 |
| 未找到等价独立项 | 旧NEO-060 Copy | — | 保留既有能力，不按新增Must计数 |
| NEO-055（仅相关） | 旧NEO-067 Claim下载 | Must | Buyer Forecast与通用Claim下载不可直接认定等价 |

## 既有方案的重要缺口

| 需求 | 最新说明与处理 |
| --- | --- |
| NEO-001 | 依赖引用由旧003改为002；Tom建议规则6/7由计算5改指计算6，并复核计算5；先核实当前规则编号。页面不改。 |
| NEO-002 | 从Not Now提升到Must_Urgent；明确E2SC旧源停用，需选新源或移除依赖，并联动001及计算。旧方案不能当成数据已具备。 |
| NEO-003 | 新增提交时价格核查/提醒及末价复核要求；保留当前同页SAP刷新设计，不重做整页。 |
| NEO-004 | 补充月度GR×价差、实施后PPV到财年末、跨财年GR及动态月列；新增报表筛选建议与此前“不改UI”决定有冲突，先保留原页，筛选仅记待确认。 |
| NEO-007 | 联合优先级Must_Urgent；仍需FTO/GR较高值及Settlement补批核验。保持Before/After页面一致。 |
| NEO-011 | 明确Loans/Deposits按到期日分流动/非流动资产、排除AutoPAM，并给半导体科目；恰好一年如何分类尚未说明。旧只含Deposits方案需补Loans。 |
| NEO-014 | 旧Must降为Should；保留既有纪要方案，不继续显示为Must。 |
| NEO-026 | 明确GFS关注点及受控Super User/Senior例外；不得把实施后锁定改成所有人都能解锁。 |
| NEO-034 | 旧Must降为Not Now；最新文指向046的Category驱动Team方案。保留旧兼容矩阵来源，不按Must推进。 |
| NEO-037 | 新增WD1实际汇率、Deleted不记账、预付款BS独立列、其他Memo可记账；基础矩阵不匹配改为保存确认，不再静默不记账。这是规则变化。 |
| NEO-039 | 新增FX转换后可由Buyer修正其他起始价差的说明；仍受价格来源和批准版本控制。 |
| NEO-040 | 升为Must_Urgent；Run Out/Date/ATP是否删除仍需确认，不能按优先级自动删字段。 |
| NEO-043 | 升为Must_Urgent；CO2和最小文字长度为明确审查项，历史字段保留和适用例外待确认。 |
| NEO-046 | 明确Category单独决定Team/会计及切换时旧Category＋Lever映射；关联041，多选Lever不能继续驱动旧会计映射。 |
| NEO-051 | 升为Must；补充支持台/Super User代办OoO委托入口和控制。旧064委托主题与其部分重叠，转办不能自动当作同一需求。 |
| NEO-055 | 升为Must；明确Buyer级下载及格式改进。旧067通用Claim下载字段不能自动判为已被完整覆盖。 |
| NEO-056 | 旧Must降为Should；只降增强优先级，AS-IS必需DoA控制不能被删除。 |
| NEO-058 | 从未填升为Must；强化批准前识别源系统差异、实施错误恢复及避免孤儿单。已有页面演示不证明接口链已完成。 |
| NEO-010 | Should针对审计改进，最新文明确现有Audit Log必须保留，不能误认为基础审计可推迟。 |
| NEO-009 | 明确当前RMA已关闭Part明细要求、人工入SAP；原接口集成方案仍需详细发现，不等于新增接口已签收。 |
| NEO-036 | 标N/A—Non System；进入RACI/运营工作，不伪造新页面。 |

## 原系统基线 {#baseline}

AS-IS功能和配置整体迁移；即使增强项Should/Not Now，原有审计、DoA、Copy等基础能力不因降级删除。来源：最新表M2:S2。没有现网验收证据，不能说迁移已完成。

## NEO-060 · 自动匹配有效工厂

联合优先级：Must。Epic建议：CNP-231；类型：集成＋应用修改。

| 项目 | 说明 |
| --- | --- |
| Before | 当前零件选择页可选择工厂；不能据此证明已按最新来源限制全部有效组合。 |
| After建议 | 选择 Supplier＋Part 后取回有效 Plant 清单，只允许有效组合；缺失或查询失败时保留已选数据并显示重试。提交时服务端再次校验。 |
| 影响 | 影响筛选、批量导入及 WIPS/S4 路由；不能把无返回当作所有工厂均有效。 |
| 例子（示例） | V002＋P2001 返回 Solihull 和 Halewood；其他工厂不能选择。 |
| 依赖／给业务的一句话 | SAP Owner：确认当前接口是否返回完整有效组合、失效标记及 S4 范围。 |
| 接口 | 候选复用 MCI_getPartDetails（接口目录第7行，Vendor＋plant过滤）；能否枚举有效工厂尚无契约证据。 |
| ACT | ACT-001 / ACT-026 |
| FR | FR1.6 / FR6 |
| 页面（沿用业务别名） | P2.6.1 Select Parts |
| UC | UC-04 / UC-06 |
| 验收设计（NOT RUN） | 有效两厂可选择；非法厂提交被拒绝；超时不清除原选择。 |
| 直接需求来源 | /Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements.xlsx ／ RTM for Requested Changes!M39:T39 |

## NEO-061 · 没有零件也能先建未来年度机会

联合优先级：Should。Epic建议：CNP-231；类型：应用内部前后端/数据/流程。

| 项目 | 说明 |
| --- | --- |
| Before | 现有建单支持 Draft；尚无证据证明未来年度无 Part/FTO 的完整生命周期。 |
| After建议 | 允许保存真实的未来年度 Opportunity 和估算依据，零件与量暂缺；后续补齐并重算，同一 Line 延续，不用假零件。 |
| 影响 | 影响草稿完整性、Forecast 标识和提交校验；不自动放宽正式审批/实施前置。 |
| 例子（示例） | FY28/29 先记 GBP100,000 机会，Part 待补；补齐后保留原 Line。 |
| 依赖／给业务的一句话 | Finance/Buyer：哪些预测报表可纳入未具备零件的估算；正式提交最低数据。 |
| 接口 | 无新增外部系统要求；补量仍依赖已确认的 FTO/预测来源。 |
| ACT | ACT-001 / ACT-004 |
| FR | FR1 / FR6 |
| 页面（沿用业务别名） | P2.2 Supplier Claim Details；P2.6.1 Parts |
| UC | UC-02 / UC-03；需补未来年度延后补量场景 |
| 验收设计（NOT RUN） | 无Part可保存草稿；估算与计算分开；正式提交缺必要数据仍被拦截。 |
| 直接需求来源 | /Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements.xlsx ／ RTM for Requested Changes!M65:T65 |

## NEO-062 · 同步供应商资料变更

联合优先级：Must。Epic建议：CNP-231；类型：集成＋应用修改。

| 项目 | 说明 |
| --- | --- |
| Before | 现有页面显示供应商名称和代码；展示值不能证明源系统改名已同步。 |
| After建议 | 按稳定 Vendor Code 同步最新名称，显示来源时间；历史批准快照保留提交时名称，当前主数据展示最新值。 |
| 影响 | 影响搜索、Claim显示及报表；改名不能换Vendor身份或静默重写审批证据。 |
| 例子（示例） | V002 从 Demo Motion UK 改名为 Motion Components UK，原申请仍能回查当时名称。 |
| 依赖／给业务的一句话 | SAP Owner：增量/全量机制和币种等商业属性变更边界。 |
| 接口 | 候选复用 MCI_getVendorDetails（接口目录第9行）；增量通知和变更时间字段未确认。 |
| ACT | ACT-001 / ACT-004 / ACT-040 |
| FR | FR1.2 / FR6 / FR19 |
| 页面（沿用业务别名） | P2.2 Supplier Claim Details；P1.1 Summary |
| UC | UC-02 / UC-05；补供应商资料刷新场景 |
| 验收设计（NOT RUN） | 改名后新选择及当前详情一致；批准快照不被覆盖；失败保留旧值并提示。 |
| 直接需求来源 | /Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements.xlsx ／ RTM for Requested Changes!M49:T49 |

## NEO-063 · 一个商业协议包含多个供应商代码

联合优先级：Should。Epic建议：CNP-231；类型：数据模型＋应用＋集成契约评估。

| 项目 | 说明 |
| --- | --- |
| Before | 当前建单以单一Vendor为主；Parent关联多条Line不等于一个Claim支持多个Vendor。 |
| After建议 | 同一商业协议、供应商主体和生效日下列出多个 Vendor Code；金额、Part及实施单据按代码分配，汇总审批仍保留明细。 |
| 影响 | 需要一对多供应商模型、币种及公司范围检查；下游不能把多个Vendor挤进单Vendor字段。 |
| 例子（示例） | 同一协议 V002/V003 各 GBP60,000/40,000，审批看 GBP100,000 且能追至各外部单。 |
| 依赖／给业务的一句话 | Buyer/SAP：同一供应商主体的识别依据；跨币种是否允许；按Vendor拆单策略。 |
| 接口 | 现有建PO接口示例为单vendor；只能列为拆分调用候选，不能声称支持多vendor payload。 |
| ACT | ACT-001 / ACT-002 / ACT-012 |
| FR | FR1.2 / FR2 / FR9.1 / FR12 |
| 页面（沿用业务别名） | P2.2 Supplier Claim Details；P2.6.1 Parts；P4.3 Settlement |
| UC | UC-02 / UC-18；需补跨Vendor分配及实施 |
| 验收设计（NOT RUN） | 不满足同主体/生效日的组合被拒；分配合计等于总额；部分实施不显示全单完成。 |
| 直接需求来源 | /Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements.xlsx ／ RTM for Requested Changes!M67:T67 |

## NEO-064 · 批量移除 POA 零件

联合优先级：Must。Epic建议：CNP-231；类型：应用内部前后端修改。

| 项目 | 说明 |
| --- | --- |
| Before | 当前价格页已有选行与逐行删除；尚不能将它等同本条批量移除控制。 |
| After建议 | 勾选待移除行，显示数量并确认；移除后重新校验和计算，保留活动记录。已锁定商业版本不能直接删除。 |
| 影响 | 影响Part集合、金额、审批版本及导入行；删除不删源系统Part。 |
| 例子（示例） | 8行选2行，确认后剩6行，原计算显示待重算。 |
| 依赖／给业务的一句话 | 业务需确认已提交/退回状态下可编辑范围，沿用现有Claim锁定规则。 |
| 接口 | 应用内部数据修改；无需新增外部删除接口。 |
| ACT | ACT-001 / ACT-004 / ACT-026 |
| FR | FR1.6 / FR6 |
| 页面（沿用业务别名） | P2.6.1 Select Parts；P2.6.2 Part prices |
| UC | UC-04 / UC-05 / UC-06 |
| 验收设计（NOT RUN） | 取消不改变数据；确认只删选中行；刷新回读一致；锁定版本拒绝。 |
| 直接需求来源 | /Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements.xlsx ／ RTM for Requested Changes!M48:T48 |

## NEO-065 · 自动计算 Gross Claim Value

联合优先级：Must。Epic建议：CNP-231；类型：计算＋应用修改。

| 项目 | 说明 |
| --- | --- |
| Before | 当前有Gross Claim及计算输出；字典字段存在不代表自动派生公式已确认。 |
| After建议 | POA按选定零件的用量与价格数据计算Gross Claim Value，并显示计算依据；输入变化后重算，缺量不显示零。LSP金额录入逻辑保持独立。 |
| 影响 | 影响Claim金额及下游审批/报告；不能直接拿Annual Forecast或GBP审批值替代。 |
| 例子（示例） | 演示口径为(100−95)×10,000=GBP50,000；这是示例，不是签署公式。 |
| 依赖／给业务的一句话 | Finance：签收Gross公式、符号、期间、币种和精度；是否覆盖LSP单独决定。 |
| 接口 | 候选复用零件价格及既有量来源；不新增系统，但量/价格契约与版本仍需确认。 |
| ACT | ACT-001 / ACT-004 / ACT-008 |
| FR | FR1.2 / FR1.6 / FR7 / FR8 |
| 页面（沿用业务别名） | P2.2 Supplier Claim Details；P2.6.3 Calculation |
| UC | UC-07；补Gross与Forecast独立核对 |
| 验收设计（NOT RUN） | 输入修改使旧结果失效；缺量显示待补；Gross、Forecast和DoA金额逐项核对。 |
| 直接需求来源 | /Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements.xlsx ／ RTM for Requested Changes!M51:T51 |

## NEO-066 · 校验并建议 Reporting Category

联合优先级：Should。Epic建议：CNP-231；类型：应用内部规则及配置修改。

| 项目 | 说明 |
| --- | --- |
| Before | 当前可选Reporting Category；不证明存在自动匹配和完整兼容性校验。 |
| After建议 | 按已批准的交易特征映射规则推荐分类；唯一匹配可自动带出，多解由Buyer选择，无解转异常处理。与046一致由Category驱动Team。 |
| 影响 | 影响Team、会计科目和报告；不是恢复已标Not Now的034 Lever兼容矩阵。 |
| 例子（示例） | LSP＋NDPC命中一个分类则带出；两项匹配时要求选择，不能任取第一项。 |
| 依赖／给业务的一句话 | Finance：给交易类型→Category→Team规则；边界例外交谁处理。 |
| 接口 | 内部规则配置；复用现有参考数据渠道，未发现新增外部接口要求。 |
| ACT | ACT-001 / ACT-004 |
| FR | FR1.2 / FR6 / FR19 |
| 页面（沿用业务别名） | P2.2 Supplier Claim Details |
| UC | UC-02 / UC-05；补规则唯一/多解/无解 |
| 验收设计（NOT RUN） | 唯一匹配正确；多解/无解有明确入口；已实施Category仍锁定。 |
| 直接需求来源 | /Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements.xlsx ／ RTM for Requested Changes!M66:T66 |

## NEO-067 · 合并收集 Mandate 与 Settlement 审批

联合优先级：Should。Epic建议：CNP-233；类型：工作流＋应用修改。

| 项目 | 说明 |
| --- | --- |
| Before | 当前Mandate与Settlement为不同请求/阶段，不能只因人员相同就视为同一批准。 |
| After建议 | 若两类申请资料均完整、范围金额版本相同且政策允许，为同一组审批人一次呈现两项决定；分别保存Mandate与Settlement结果。条件不符仍分开。 |
| 影响 | 影响请求关系、签署文件、DoA、撤销与补批；一次操作不能丢失两类法律/业务含义。 |
| 例子（示例） | 同一GBP100,000最终协议同时满足两项前置时一轮处理；金额变化则重新核验。 |
| 依赖／给业务的一句话 | Finance/FBP：签字和协议何时已具备，允许合并的请求范围。 |
| 接口 | 应用工作流变更；未提出新外部接口，实施仍依原路由。 |
| ACT | ACT-010 / ACT-012 / ACT-019 / ACT-024 |
| FR | FR9 / FR9.1 / FR10 |
| 页面（沿用业务别名） | P4.2 Mandate；P4.3 Settlement；P4.1 Approval |
| UC | UC-12 / UC-14 / UC-18；新增同轮双决定场景 |
| 验收设计（NOT RUN） | 仅相同审批人但Settlement证据缺失不能合并；两个决定均可追溯；拒绝/撤销分别控制。 |
| 直接需求来源 | /Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements.xlsx ／ RTM for Requested Changes!M70:T70 |

## NEO-068 · 快速筛选零件

联合优先级：Must。Epic建议：CNP-231；类型：应用＋集成查询评估。

| 项目 | 说明 |
| --- | --- |
| Before | 复用旧061的筛选方案；Before已有零件筛选，不把它写成从零新增。 |
| After建议 | 保留现有选择页，补齐Supplier、Plant、Base Part、Commodity/CPCSII、Vehicle Line过滤；跨页保留选择并显示已选数。 |
| 影响 | 影响大数据分页、筛选性能及有效工厂限制；与060共用主数据规则。 |
| 例子（示例） | 先按V002和Solihull过滤，再按base part找零件；换页已选保持。 |
| 依赖／给业务的一句话 | SAP Owner：Commodity/Vehicle Line等字段和服务端过滤是否可供；不可把示例列表当全量。 |
| 接口 | MCI_getPartDetails已有vendor/plant/offset/limit；其他过滤参数/返回字段未确认。 |
| ACT | ACT-001 / ACT-026 |
| FR | FR1.6 / FR19.13 |
| 页面（沿用业务别名） | P2.6.1 Select Parts |
| UC | UC-04 / UC-06 |
| 验收设计（NOT RUN） | 组合过滤正确；跨页不丢选；缺服务端字段明确未支持而非空结果。 |
| 直接需求来源 | /Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements.xlsx ／ RTM for Requested Changes!M40:T40 |

## NEO-069 · 看懂价差与金额来源

联合优先级：Must。Epic建议：CNP-231；类型：应用内部前后端修改。

| 项目 | 说明 |
| --- | --- |
| Before | 本主题来自旧062；Before已有计算结果和POC Insight，仍需补逐行输入及问题追溯。 |
| After建议 | 在现有Calculation打开计算明细，显示价格、量、币种、期间、汇率及来源版本；Buyer可带上下文向Finance发起核对。 |
| 影响 | 提高解释和纠错能力，不开放Buyer直接覆盖SAP价格/正式公式。 |
| 例子（示例） | 某行有价格但无量，金额显示待补而非0；核对请求带Part＋Plant＋计算版本。 |
| 依赖／给业务的一句话 | Finance：最终公式与缺数定义；数据Owner提供各输入版本和更正责任。 |
| 接口 | 复用价格/量/FX输入；若现有API无来源版本，需要扩展响应契约，不能断言无需改接口。 |
| ACT | ACT-008 / ACT-042 |
| FR | FR7 / FR8.1 / FR20.4 |
| 页面（沿用业务别名） | P2.6.3 Calculation；P1.1.2 Calculations；P9.2 |
| UC | UC-07 / UC-24 |
| 验收设计（NOT RUN） | 缺失与真实0区分；明细与总额一致；核对意见关联原Line/版本。 |
| 直接需求来源 | /Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements.xlsx ／ RTM for Requested Changes!M41:T41 |

## NEO-070 · 审批链外追加评审人

联合优先级：Not Now。Epic建议：CNP-233；类型：工作流＋权限修改。

| 项目 | 说明 |
| --- | --- |
| Before | 本主题来自旧063；本轮联合优先级Not Now，保留方案但不放入Must实施范围。 |
| After建议 | 复用已有Add Before/After建议：填写额外评审人和原因，收集意见并保留记录；额外评审不取代正式DoA。 |
| 影响 | 涉及非采购/财务角色访问权限和前后依赖；不得绕过保密及职责分离。 |
| 例子（示例） | 审批人邀请工程同事说明技术影响，正式DoA仍由有权人完成。 |
| 依赖／给业务的一句话 | 跨部门可见范围及加签拒绝效果；以既有FR22已确认规则为基础。 |
| 接口 | 内部用户目录候选复用；跨部门身份供给范围需确认。 |
| ACT | ACT-018 / ACT-019 / ACT-024 |
| FR | FR10.6 / FR22.3 / FR22.5 |
| 页面（沿用业务别名） | P4.1.11 Approval task actions |
| UC | UC-16 / UC-14 |
| 验收设计（NOT RUN） | 无权人看不到敏感数据；正式决定依赖加签完成；意见可追溯。 |
| 直接需求来源 | /Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements.xlsx ／ RTM for Requested Changes!M76:T76 |

## NEO-071 · 在案例中与 Digitide 协作

联合优先级：Must。Epic建议：CNP-234；类型：应用内部前后端/数据/流程。

| 项目 | 说明 |
| --- | --- |
| Before | 本主题来自旧065；已有任务和Notes不等于可随组接手的完整案例对话。 |
| After建议 | 在原Task增加Conversation并关联NEO Line；Buyer与授权Digitide成员回复、附件及状态均留在同案例，换人后继续看到历史。 |
| 影响 | 影响组权限、领取/转办、未读提醒和审计；讨论不自动完成实施任务。 |
| 例子（示例） | 处理人休假后另一CBSL成员接手，看到此前缺资料问题和Buyer回复，无需找邮件。 |
| 依赖／给业务的一句话 | CBSL/Buyer：当前NEO外的协作有哪些，哪些需补任务路由；保留期限。 |
| 接口 | 主要为NEO内部协作；邮件仅通知，不假定接入共享邮箱或新工单平台。 |
| ACT | ACT-020 / ACT-021 / ACT-025 / ACT-056 / ACT-061 |
| FR | FR5.1 / FR10.4 / FR13 / FR14 / FR15 |
| 页面（沿用业务别名） | P3 Tasks；P3.1 Enquiry；P3.4 WIPS/S4；P1.1.10 Notes |
| UC | UC-17 / UC-19 / UC-20；新增共享队列沟通场景 |
| 验收设计（NOT RUN） | 组成员交接保留上下文；非成员无权读取；回复不改变批准价格；重试不重复发文。 |
| 直接需求来源 | /Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements.xlsx ／ RTM for Requested Changes!M52:T52 |

## NEO-072 · 大量零件处理不丢提交

联合优先级：Must_Urgent。Epic建议：CNP-231；类型：性能＋前后端可靠性修改。

| 项目 | 说明 |
| --- | --- |
| Before | 本主题来自旧066；沿用028运行/完成提醒设计，但这条还覆盖大批零件和提交未知结果。 |
| After建议 | 服务端分页及批处理，计算持续显示状态；提交采用稳定请求标识，超时先查原结果，再允许安全重试，恢复到同一Line。 |
| 影响 | 覆盖加载、校验、计算、保存及提交整链；不能仅加loading动画作为性能修复。 |
| 例子（示例） | 5,000行仅为演示规模；提交超时但后台已成功时，回读原Line而非再建一笔。 |
| 依赖／给业务的一句话 | 需要真实最大零件量、并发及基线；SAP批量限制/超时/幂等支持待确认。 |
| 接口 | 复用分页parts/price API候选；需联调限流、批大小及失败恢复，无证据需新平台。 |
| ACT | ACT-001 / ACT-026 |
| FR | FR1.6 / FR6 / FR7 / NFR performance |
| 页面（沿用业务别名） | P2.6.1–P2.6.3 Parts；P2.6.5 Submit |
| UC | UC-04 / UC-06 / UC-08 |
| 验收设计（NOT RUN） | 大数据规模实测；重复点击仅一笔；刷新恢复；失败定位行；超时回读原结果。 |
| 直接需求来源 | /Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements.xlsx ／ RTM for Requested Changes!M12:T12 |

## NEO-073 · 一次维护多年生产率协议

联合优先级：Could。Epic建议：CNP-231；类型：数据模型＋工作流＋集成契约评估。

| 项目 | 说明 |
| --- | --- |
| Before | 主题来自旧068，当前Could；旧方案逐年审批不能冒充新文要求的一次跨年交易。 |
| After建议 | 建立一份协议下的年度价格/期间表，按政策批准整体与年度明细；实施按生效计划派发并保留子结果，不要求Buyer复制多笔独立Claim。 |
| 影响 | 跨财年金额、DoA、重复期间、Reserve及SAP/WIPS生效日均受影响。 |
| 例子（示例） | FY27/28和FY28/29两期条款，同一协议一次维护，年度财务影响分开。 |
| 依赖／给业务的一句话 | Finance/SAP：多年授权口径和未来价格排程支持；一期不默认承诺。 |
| 接口 | SAP/WIPS是否支持多个未来有效期未确认；不预先宣布新增架构或已有接口足够。 |
| ACT | ACT-001 / ACT-012 / ACT-029 / ACT-050 |
| FR | FR1 / FR9.1 / FR17 / FR18 |
| 页面（沿用业务别名） | P2.2 Supplier Claim Details；P2.6.2 Prices；P4.3 Settlement |
| UC | UC-02 / UC-18 / UC-23 / UC-24；新增跨年协议场景 |
| 验收设计（NOT RUN） | 期间重叠拦截；年度总额对账；修改未来一期不改历史已实施项。 |
| 直接需求来源 | /Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements.xlsx ／ RTM for Requested Changes!M74:T74 |

## NEO-074 · 解释 NEO 与 Tableau 的差异

联合优先级：Should。Epic建议：CNP-235；类型：数据集成＋计算＋报表修改。

| 项目 | 说明 |
| --- | --- |
| Before | 现有截图不能证明NEO和Tableau有可比同版本数据；最新需求明确预测量与实际量不同。 |
| After建议 | 同一NEO ID/期间并列Forecast与Actual并列出量、价、FX、范围差异；展示可对账桥接，允许合法差异，不强行改到相等。 |
| 影响 | 影响财务口径和数据血缘，关联035 £pu及002预测来源；不直接从Tableau界面抓数。 |
| 例子（示例） | 预测10,000件×GBP5=50,000；实际8,000件×GBP5=40,000；差10,000来自量。 |
| 依赖／给业务的一句话 | Finance/BI：权威数据集、刷新时点、粒度和对账容差；是否可复用现有数据平台。 |
| 接口 | 需Finance/BI数据契约；现有目录不能证明有Tableau反向读取API，来源和接口待确认。 |
| ACT | ACT-008 / ACT-041 / ACT-050 |
| FR | FR7 / FR8 / FR18 / FR20.1 |
| 页面（沿用业务别名） | P1.1.2 Calculations；P6.1 Finance Claims；P6.7 Auto PAM |
| UC | UC-07 / UC-24；新增同期间跨报表核对 |
| 验收设计（NOT RUN） | 同期间同范围对比；过期/缺失实际值显示待更新；导出包含差异原因。 |
| 直接需求来源 | /Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements.xlsx ／ RTM for Requested Changes!M61:T61 |

## NEO-075 · 非 BOM 的直接采购 Claim

联合优先级：Should。Epic建议：CNP-231；类型：数据模型＋应用＋SAP契约评估。

| 项目 | 说明 |
| --- | --- |
| Before | 现有LSP表单可录金额，但不证明支持Non-BOM分类和采购绩效排除。 |
| After建议 | 在Risk/Opportunity中标记Non-BOM直接采购，填写软件/许可等明细及LSP财务编码；沿用审批和SAP付款链，同时明确排除采购绩效。 |
| 影响 | 影响分类、科目、税/服务标识、报告和SAP请求；不等于纳入Indirect采购全部流程。 |
| 例子（示例） | 软件许可GBP120,000作为Risk LSP获批并建PO；采购绩效不计入，财务账仍保留。 |
| 依赖／给业务的一句话 | Buyer/Finance/SAP：Non-BOM定义、Goods/Services与科目映射、绩效排除字段。 |
| 接口 | MCI_raiseLumpSumPO可作候选（目录第19行）；需验证软件/许可明细、服务标识和财务编码，不能断言可直接复用。 |
| ACT | ACT-001 / ACT-010 / ACT-012 / ACT-025 |
| FR | FR1.2 / FR1.6 / FR9 / FR9.1 / FR12 |
| 页面（沿用业务别名） | P2.2 Supplier Claim Details；P2.6.4 Lump Sum；P4.3 Settlement |
| UC | UC-09 / UC-12 / UC-18 / UC-21；新增Non-BOM场景 |
| 验收设计（NOT RUN） | Non-BOM可完成草稿及审批前置；财务与绩效分别核对；下游未知结果不标完成。 |
| 直接需求来源 | /Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements.xlsx ／ RTM for Requested Changes!M68:T68 |

## 证据与边界

- 页面/ACT/UC参考：`act001-mapping-two-columns/review-all64/all64-payload.json`；旧分析：`epic-review-035-068-20261113-v1/CONSOLIDATED_ASSESSMENT.json`。页面编号为既有业务别名，不能混为另一个143页清单的通用编号。
- 接口参考：`6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` 第7/8/9/19行；登记名和路径不证明返回字段、性能、权限或当前环境可用。
- 原型Before仍为既有冻结快照；After为独立交互建议。未修改NEO产品、未部署、未创建线上业务单。
- 设计交互检查不等于集成/性能/业务验收；所有正式验收仍NOT RUN。
