'use strict';
// Independent review adapter. The frozen product bundle and its source remain unchanged.
// Every page gets its own in-memory fixture; product/review localStorage is never written.
(async () => {
  const params = new URLSearchParams(location.search);
  const id = params.get('id'), side = params.get('view') === 'after' ? 'after' : 'before';
  const stateKey = { 'NEO-001': 'auto-pam', 'NEO-003': 'prices-edit', 'NEO-004': 'naf-pin-gfs', 'NEO-007': 'approval-detail' }[id];
  if (!stateKey) throw Error('Unknown comparison page.');
  const state = window.BEFORE_MAP.states[stateKey];
  const response = await fetch(state.state);
  if (!response.ok) throw Error('The captured mock data could not be loaded.');
  const data = new Map([['neo.full.react.antd.20261106.v1', await response.text()]]);
  const memoryStorage = {
    getItem: key => data.get(String(key)) ?? null,
    setItem: (key, value) => data.set(String(key), String(value)),
    removeItem: key => data.delete(String(key)),
    clear: () => data.clear(),
    key: index => [...data.keys()][index] ?? null,
    get length() { return data.size; }
  };
  Object.defineProperty(window, 'localStorage', { value: memoryStorage, configurable: false });
  document.title = `NEO · ${id} · ${side === 'after' ? 'After' : 'Before'}`;
  document.body.dataset.requirement = id;
  document.body.dataset.side = side;
  document.body.dataset.persistence = 'memory-only';
  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  const until = async predicate => {
    for (let i = 0; i < 160; i++) {
      const result = predicate();
      if (result) return result;
      await wait(100);
    }
    throw Error('The captured page could not be opened.');
  };
  const visible = element => element.getClientRects().length > 0;
  const findButton = text => [...document.querySelectorAll('button')].find(element => visible(element) && element.textContent.trim().replace(/\s+/g, ' ') === text);
  history.replaceState(null, '', location.pathname + location.search + '#' + state.launchRoute);
  const bundle = document.createElement('script');
  bundle.src = 'before-source/app.js';
  bundle.onerror = () => { document.body.dataset.error = 'Product copy unavailable'; };
  document.body.append(bundle);
  await until(() => document.querySelector('main'));
  for (const step of state.steps || []) {
    if (step.route) { location.hash = step.route; await wait(800); continue; }
    const button = await until(() => findButton(step.name));
    button.click();
    await wait(600);
  }
  await until(() => id === 'NEO-001' ? document.querySelector('[aria-label="File information"]') :
    id === 'NEO-003' ? findButton('Select all rows') :
    id === 'NEO-007' ? findButton('Approval Check') : findButton('Generate report') || findButton('Generate Report'));

  function decorate() {
    // Apply the approved report breadcrumb to BOTH sides; the file rows and their i icons stay native.
    if (id === 'NEO-001' && location.hash.includes('auto-pam')) {
      const home = [...document.querySelectorAll('a[href="#/work-queue"]')].find(link => link.textContent.trim() === 'NEO' && link.nextElementSibling?.textContent.trim() === '/');
      const flex = home?.parentElement;
      if (flex) flex.dataset.reviewBreadcrumb = 'true';
      if (flex && !flex.querySelector('[data-review-reports]')) {
        const reports = document.createElement('a');
        reports.href = '#/reporting';
        reports.textContent = 'Reports';
        reports.dataset.reviewReports = 'true';
        const slash = document.createElement('span'); slash.textContent = '/'; slash.setAttribute('aria-hidden', 'true');
        flex.insertBefore(reports, flex.lastElementChild);
        flex.insertBefore(slash, flex.lastElementChild);
      }
    }
    if (id === 'NEO-003' && side === 'after' && location.hash.startsWith('#/parts/prices') && !document.querySelector('#refresh-sap-prices')) {
      const preview = findButton('Preview');
      if (!preview) return;
      const button = document.createElement('button');
      button.id = 'refresh-sap-prices';
      button.type = 'button';
      button.className = preview.className;
      button.textContent = 'Refresh prices from SAP';
      button.setAttribute('aria-haspopup', 'dialog');
      button.addEventListener('click', () => openRefresh(button));
      // Append to the existing bulk-action row. Do not replace any fields, rows or editing controls.
      preview.after(button);
    }
  }

  function openRefresh(trigger) {
    if (document.querySelector('#sap-refresh-dialog')) return;
    const dialog = document.createElement('dialog');
    dialog.id = 'sap-refresh-dialog';
    dialog.setAttribute('aria-labelledby', 'sap-refresh-title');
    dialog.setAttribute('aria-describedby', 'sap-refresh-copy');
    dialog.innerHTML = '<h2 id="sap-refresh-title">Refresh prices from SAP</h2><p id="sap-refresh-copy">Retrieve the latest start prices for these parts. Your entered new prices will be kept.</p><div class="dialog-actions"></div>';
    const actions = dialog.querySelector('.dialog-actions');
    const cancel = document.createElement('button');
    cancel.type = 'button'; cancel.className = trigger.className; cancel.textContent = 'Cancel';
    const refresh = document.createElement('button');
    refresh.type = 'button'; refresh.className = trigger.className; refresh.textContent = 'Refresh';
    cancel.onclick = () => dialog.close();
    refresh.onclick = () => {
      // There is no SAP connection in this independent design. Never fake a successful retrieval.
      dialog.querySelector('#sap-refresh-copy').textContent = 'SAP is not connected in this design preview. No prices have changed.';
      dialog.querySelector('#sap-refresh-copy').setAttribute('role', 'status');
      refresh.remove(); cancel.textContent = 'Close'; cancel.focus();
    };
    actions.append(cancel, refresh);
    dialog.addEventListener('close', () => { dialog.remove(); trigger.focus(); });
    document.body.append(dialog);
    dialog.showModal(); cancel.focus();
  }
  decorate();
  const observer = new MutationObserver(decorate);
  observer.observe(document.querySelector('#root'), { childList: true, subtree: true });
  document.body.dataset.ready = 'true';
})().catch(error => {
  document.body.dataset.error = error.message;
  const message = document.createElement('p');
  message.id = 'comparison-loading'; message.setAttribute('role', 'alert');
  message.textContent = error.message;
  document.body.prepend(message);
});
