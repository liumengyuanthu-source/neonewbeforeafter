# NEO-001 汇总版 · AutoPAM 年末结转规则修正

版本 V1 · 2026-11-12 · 第 1 / 68 条 · 独立方案评审，未修改 NEO prototype。

## 本轮界面修订：NEO design system

按用户 12 Nov 2026 确认的项目默认规则，页面已统一使用当前 NEO React theme、JLR Emeric 字体及真实 Ant Design 6.7.0 组件。桌面边距32px、中屏24px、手机16px；表格横向滚动、黑色主按钮、蓝色链接、状态色、下拉、弹窗和校验沿用 NEO。仅展示本条涉及的交互，未连接的导航与最终业务提交禁用。

Reference：`NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/theme/index.ts`、`src/layouts/BasicLayout/`、`src/styles/` 和 `NEO_FULL_OFFLINE/skills/jlr-frontend-ux/references/NEO_UXUI_PRINCIPLES.md`。theme 原文件与只读快照 SHA 一致，详见交付包 `design-source/SOURCE_MANIFEST.json`。配套布局是独立评审页的适配，不是新增产品 design system。

当前本地页面检查见 `PAGE_VISUAL_CHECK.json`；接口、后台、流程、权限和业务验收仍为 NOT RUN。旧截图及旧检查数不作为本版验收依据。此修订没有改写业务范围或原 prototype。

## 1. 结论与追溯

保留现有 AutoPAM 报表页面，重点修正后台“选择哪条规则、使用哪个计算公式”。先确认当前规则版本，再以 Finance 的标准样例验证结果；不能用下载成功证明金额正确。

| 项目 | 汇总结果 |
|---|---|
| 原需求 | RTM for Requested Changes / NEO-001，原表第 2 行。[S1] |
| 主要改动类型 | **APP — 应用内部功能 / 计算逻辑修改**。不是 UX/UI only。 |
| 次要影响 | 现有 GCP 输出回归；**候选复用**现有契约，尚未确认需要修改或新增接口。 |
| Epic | **CNP-235 — NEO Epic 4 - Finance and continuity**；沿用本地故事映射，本轮未查询线上 Jira。[S4] |
| User Story | **ACT-050 — Auto PAM Report**。现有范围侧重报表文件访问，需要补年末结转计算场景。[S4] |
| 直接影响 FR | **FR18 — Forecast Reporting Calculations and Output**。[S3] |
| 条件关联 FR | **FR1.6 — Parts / Calculation**，仅当 NEO-002 / NEO-003 联动改变输入或页面计算时另行评估；不算本条已确定修改范围。 |
| UC | 沿用已有 UC-24 文件回读关联；补充计算、年末结转与对账场景，正式新增 UC 编号待登记。[S6] |
| 页面 | **P6.7 — Auto PAM Report**，沿用现有页面登记。[S6] |
| Priority | 原表 Finance = **Must**，Procurement 空白。实施建议 **P0：财务计算正确性前置**，尚非业务批准的排期。 |
| 当前状态 | 页面方案可评审；计算规则和联调待确认；产品功能验收全部 **NOT RUN**。 |

## 2. 用户要解决什么

原需求中的 Procurement Analyst 希望 AutoPAM 正确处理年末结转、P0 adjustments 和刷新后的 Claim 计算，以便预测采购 P&L 并核对实际值。[S1:E2]

例子：一条 Claim 跨到新财年后，即使用户仍从同一个 AutoPAM 页面下载文件，后台选错计算公式，文件中的预测金额也可能不正确。这里的 P0 adjustments 是原文业务术语，其具体含义待 Finance 确认，**不是上表的实施优先级 P0**。

## 3. 页面方案：P6.7 Auto PAM Report

![P6.7 Auto PAM Report 页面方案](NEO-001_Page_1440.png)

| 页面元素 / 操作 | 建议 |
|---|---|
| 入口 | 保留 Reports → Auto PAM Report。 |
| File、Created On | 保留两列及现有文件历史结构，不为后台规则修正增加无依据的字段。 |
| 点击文件 | 正式实现沿用现有下载交互；应取得按已确认规则生成的输出。 |
| 新增页面 / 控件 | **本条不新增规则编辑页、手工重算按钮或审批节点。** |
| 页面权限 | 沿用已确认的角色访问规则；不能因为原需求写 Procurement Analyst 就自动授予 Buyer 新权限。现有故事中的权限仍须对照当前配置确认。[S4] |
| 评审信息 | 分类、Epic、FR、依赖及 reference 放在本汇总文档，不塞进业务页面。 |

图中姓名、文件名和日期沿用现有原型的历史 Training 示例，不是本轮产生或验证的报表。独立 HTML 为静态页面方案，文件下载及业务导航未接入；References 可展开说明。[S5]

## 4. Solution、Change 和 Impact

| 层面 | 建议 solution / change | Impact / 边界 |
|---|---|---|
| 规则与计算 | 核实当前编号后，将确认适用的规则 6、7 从计算 5 改指计算 6；计算 5 本身是否修改另行确认。[S1:P2] | 影响采购 P&L 预测和实际值核对；公式未取得前，不编造计算结果。 |
| 数据与追溯 | 保留触发的 ruleset；建议同一批次记录其 Claim、FTO、期间及输入版本。[S3] | 需要核对现有字段能否承载；本轮未确认需要新增哪些数据库列。批次版本方案属于设计建议。 |
| 输出核对 | 按 Finance 标准样例核对每条 Line、Summary 和 PAM Full。[S3] | 金额、单位、精度与容差必须有业务依据；异常结果不能作为成功文件交付。 |
| UI | 复用 P6.7 文件列表与下载入口。 | 当前没有新增字段或页面的充分依据；页面方案不代表计算已经实现。 |
| BPM / 调度 | 核验现有日调度及失败处理，沿用业务编排。 | 不新增审批链；历史每月标记重置是否保留仍待确认。 |
| Integration | 核验既有 GCP 文件输出格式、传输和回执，优先复用。[S3] | 这是现有接口回归范围，**不是已确认新增接口**。契约不兼容时才另列变更。 |
| 新架构 | 当前不提出新平台或新组件。 | NEO-002 数据源替换和 NEO-003 SAP 价格刷新分别评估，不能混算成本。 |

本条不自动授权重算已冻结期间，也不自动修改已批准 Claim、DoA 或 Settlement。历史重算范围与输入刷新时点须由 Finance 明确。

## 5. 必须先说清楚的版本差异

| 证据 | 资料怎么说 | 怎么处理 |
|---|---|---|
| 最新 NEO-001 / P2 | 如实施 NEO-003，规则 6、7 改用计算 6；当前编号还需核实。 | 作为最新变更意图，不直接假定是当前实际编号。 |
| 历史 CR3.1 / D2 | 规则 4 调整 implemented year；规则 14 调整 Likelihood。 | 确认已生效、已替代还是仍需修改，不自动与最新规则合并。 |
| 历史 CR3.1 / P2 | POA 计算更新标记为 True 时应用变化；每月第一天重置。 | 确认触发参数、适用范围和时间规则。 |
| NEO-002 / P3 | 移除生产计划数据管道的方案也依赖 NEO-001。 | 确认与 NEO-003 是两个场景依赖，还是文档引用需要纠正。 |
| 历史 CR3.1 / R2、T2 | 曾记录 TEST 测试完成，另记录已开发后回滚。 | 不计作当前实现或验收通过。 |

另外，最新表 G2 为 No，但 D2 标为既有功能逻辑修正。需确认缺的是哪一版修正，不能据此判断整个 AutoPAM 没有实现。[S1、S2]

## 6. 待确认清单

| 问题 | 需要的材料 / 决定 | 建议确认方 |
|---|---|---|
| 现在究竟改哪些规则？ | 生效决策树、计算 5/6、此次 spec；规则 4/14 是否仍适用；P0 adjustment 的定义。 | Finance 规则负责人 + 现有 NEO 维护团队 |
| 和 NEO-002 / 003 怎么关联？ | 刷新 SAP 价格、移除生产计划两个场景是否都需要本条；分别何时触发。 | Finance + 采购业务负责人 |
| 哪些历史结果可以重算？ | Claim / 财年范围、冻结及覆盖规则、每月重置标记是否保留。 | Finance + 报表运营负责人 |
| 如何证明金额和输出正确？ | 跨年标准样例及预期金额、当前 Summary / PAM Full 文件、GCP 契约与回执。 | Finance 提供预期；NEO / GCP 团队提供契约 |

历史表提到 Dan Yielder，仅作为历史线索，不视为已确认的当前负责人。[S2:M2]

## 7. 验收要点与退出条件

| 场景 | 预期结果 | 实际结果 / 状态 |
|---|---|---|
| 规则 6、7 | 经确认的输入命中计算 6；记录规则/公式版本，金额与 Finance 样例一致。 | 未执行 / NOT RUN |
| 其他规则 | 非本次修改分支保持一致；规则 4/14 按确认范围回归。 | 未执行 / NOT RUN |
| 财年与 P0 边界 | 遵守实际财年设置及 P0 定义，不自设日期或金额。 | 未执行 / NOT RUN |
| 计算更新及月初处理 | 若标记仍适用，触发、重置和批次顺序可追踪。 | 未执行 / NOT RUN |
| 明细 / 汇总 | Summary 和 PAM Full 对账一致；缺输入、异常值能识别。 | 未执行 / NOT RUN |
| 重跑 / 历史 | 按批准范围重算，不重复输出或静默覆盖冻结结果。 | 未执行 / NOT RUN |
| 下载 / 输出 | 权限、文件内容、日调度和 GCP 成功/失败回执符合现行契约。 | 未执行 / NOT RUN |

**设计进入开发的条件：**第 6 节中的生效规则、依赖和重算范围已确认，取得可验算的 Finance 样例与现有输出契约。

**功能验收条件：**在指定环境和版本执行上述适用场景，保存输入、公式版本、金额对账及输出证据。当前仅完成独立页面的排版检查，不满足功能退出条件。

## 8. Reference


- **S1** 原始新需求工作簿：`/Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx`，`RTM for Requested Changes!A2:R2`。依赖对照 `E3/P3`（NEO-002）、`E4`（NEO-003）。本轮只读核对主 Sheet 共 68 条。SHA-256：`b83b74cb3eb2107d7128ba6ed4cce620fe51a985dafa885719b126d4ae840974`。
- **S2** 同一工作簿，`P1 CR clean!A2:Y2`，重点 `D2/P2/R2/T2/W2`。历史 Jira 链接保留在原表 U2；本轮未查询 Jira 的当前状态。
- **S3** `/Volumes/KIOXIA/JLR Appian/6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx`，第 6 个表、第 51 行、FR18（表/行均从 1 开始）。该条指向 Appendix L / M / N；当前生效公式与本次 spec 尚未据此确认。未虚构 Word 页码。
- **S4** `/Volumes/KIOXIA/JLR Appian/outputs/neo-jira-stories-20261111/v3/story_data.json`，entries 中 `ACT-050`；该故事追溯 Training 段落 1925–1938。本轮引用现有故事登记，不宣称已重新确认生产权限。
- **S5** `/Volumes/KIOXIA/JLR Appian/NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Reporting/auto-pam-data.ts`，第 2–13 行，本轮本地只读检查；不是线上部署证据。
- **S6** `/Volumes/KIOXIA/JLR Appian/outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/analysis.json`，NEO-001 现有分析及 trace；ACT / UC / 页面号属于既有追溯登记，来源级别低于原始 BRD。


## 9. 交付范围

本汇总版整合前面的页面评审和方案说明，作为 NEO-001 的统一阅读入口。原分析和流程图仅保留作过程文件；本次以第 3 节的业务页面图为评审对象。

- NEO-001_Consolidated_CN.html：单文件汇总页面，内嵌页面图，可独立转交。
- NEO-001_Consolidated_CN.md：可编辑文本汇总。
- NEO-001_Page_Proposal.html：独立静态页面方案；不连接 prototype 或业务系统。

产品代码、数据、Jira 和部署均未修改。
