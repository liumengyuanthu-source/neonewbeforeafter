# NEO-015 · 预付款准备金逻辑修正

<!-- FLOW-REVIEW-20261116 -->
## 16 Nov 2026 · 流程评审补充

[中英文 Before / After 流程](NEO-015_Before_After_Flow.html) · [流程说明 MD](NEO-015_Before_After_Flow_CN_EN.md)

按最新修订要求，实施前套用普通负向 LSP Reserve 逻辑，并核对 AutoPAM 不受影响。

本轮为流程说明补充；原交互页面、问题及历史证据保留。正式实施前需补齐：Finance 给出跨实施月的期初／变动／期末金样，并确认原文“结算且资产建立”与最新 Implemented 控制点的关系。
<!-- /FLOW-REVIEW-20261116 -->

独立页面方案，沿用 NEO 的主题、字体及 Ant Design 交互。当前产品、共享 QA、真实 Reserve、SAP 与 Auto-PAM 均未修改。页面金额是固定审阅样例，用来说明时点和交互；不是 Finance 签收的 golden case，也不是当前生产计算结果。来源原文、准确位置和 SHA-256 见 SOURCE_EVIDENCE.json。

## 1. 原需求与关键分歧

NEO-015 说明：现有预付款在付款前没有计提准备金，付款月份出现大额追补，导致损益确认时点不正确。要求交易开始后计提，直到已结算且相应预付款资产已经建立才释放。修订列又写：Non-standard transaction flag 为 Prepayment 的 ID，在 Implemented 前应用普通 negative Lump Sum 准备金逻辑，并确保 Auto-PAM 不受影响。[S1/S2]

建议把“交易开始、付款、Settlement、Implemented、资产建立”作为不同事实读取。付款不是唯一确认开关；Implemented 与结算及资产建立是否完全同步，目前不能凭需求文字假设。

| 来源 | 内容与边界 |
|---|---|
| RTM for Requested Changes 第16行 | 正确的 NEO-015；Finance Must，Procurement 优先级空白。[S1] |
| P1 CR clean 第36行 CR31-New | 原预付款准备金问题；标记为FR17详细需求。[S2] |
| RTM - Archive 第18行 | 同ID实际为 FR6.1 Add Lump Sum Data，不能拿它替代本条。[S1-ID-A] |
| NEO RTM 第19行 | 同ID为FR1.2汇率及Likelihood，亦非本条。[S1-ID-B] |
| BRD FR17.5 | 已有Lump Sum准备金计算描述、期间明细及生成时快照要求；最终符号、端点日期、精度和预付款释放仍需确认。[S3-47] |
| CR14 / Revaluation of the Prepayments | 是另一个汇率重估问题。本条不顺便修改FX或Memo规则。[S2-CR14] |

## 2. 改动分类、优先级及关联

| 项目 | 评估 |
|---|---|
| 主要改动类型 | Application内部前后端修改，以后台财务计算／取数／版本为主，前端提供解释、异常和对账。不是UX/UI only。 |
| Integration needed | 如NEO已有可靠的Settlement与资产建立证据，可复用内部数据；如缺少资产证据，则需与负责资产的源系统／财务团队集成或受控导入。不能直接认定现有PO状态接口已经满足。 |
| 跟谁对接 | NEO/未来目标应用的Reserve计算、Settlement与实施服务；SAP财务／预付款资产负责团队提供确认来源；Auto-PAM／EDW/GCP输出负责团队提供独立回归基线。实际owner和端点待确认。 |
| 是否复用现有接口 | 已登记 MCI_getPurchaseOrderDetails（CSV记录11，接口ID5）用于SAP PO状态／Implemented；MCI_raiseLumpSumPO（记录16，ID10）用于建PO。两者的登记描述不能证明返回资产创建凭证或结算事实。先查payload，再决定复用／扩展／新增。[S6] |
| 是否新增架构 | 暂不建议新增平台；先复用NEO月度Reserve和计算服务。若需补充资产回执，属于数据契约／适配扩展；没有契约前不画成已连通的新接口。 |
| 建议优先级 | P0财务逻辑确认与golden case，随后开发。Finance原表为Must；P0是本轮建议，不是已批准排期。 |
| Epic | 建议沿用 CNP-235 / Finance；来自既有ACT-029/030/039/050/052的Epic关联。[S8] |
| User Story | 主ACT-029 Generate Reserve；关联ACT-030 Edit Reserve Data、ACT-039 Actual Reserves filters、ACT-052 Team Level View；ACT-050 Auto PAM Report为不受影响的回归范围。不要把ACT-050改成驱动Reserve计算。 |
| FR | 直接FR17、FR17.1、FR17.3、FR17.5；关联FR1.2/FR6.3的Prepayment字段，FR17.8 Journal；FR18保持Auto-PAM口径。 |
| 页面 | 复用P16 Monthly List、P16.1 Reserve Claims、P16.3 Generate New Reserve；P16.1.1 Data Checks、P16.2 Teams及P20.5 Auto PAM关联。新增弹窗／比较tab为本次候选设计，无正式新页面编号。[S15] |

| 本轮临时场景 | User Story／页面 | 要看什么 |
|---|---|---|
| D015-UC01 付款前计提 | ACT-029 / P16.1 | 交易已开始、未付款、未Implemented，按普通负LSP基准展示候选准备金。 |
| D015-UC02 付款不是释放开关 | ACT-029 / P16.1详情 | 付款证据变Confirmed，但Settlement和资产条件未齐。 |
| D015-UC03 释放 | ACT-029 / P16.1详情及预览 | 已结算、资产已确认，显示准备金释放的审阅样例。 |
| D015-UC04 缺证据／计算依据 | ACT-029 / P16.1 | Implemented与资产证据冲突、公式依据缺失；显示Unavailable并阻止预览。 |
| D015-UC05 保留Final | ACT-029 / P16.1 | Final版本只读；本条不自动追溯改账。 |
| D015-UC06 Auto-PAM不受影响 | ACT-050 / 比较tab | 展示独立回归对照位置，不代替真实Auto-PAM计算和输出验收。 |

以上是方案内部UC，不替换BRD既有UC编号，也未写入Jira。

## 3. 已有实现与待补齐

当前代码有月度Reserve、Draft／Final、Reserve Claims、Team汇总、Memo、Journal及快照类型。periods.ts 的 PeriodPack 包含预先给定的 results，并明确 illustrative；training-sample.ts 的Prepayment行是培训／合成数据。因此“页面有Prepayment数据”不能证明CR31公式已经实现。[S9–S12]

当前Auto-PAM页面的数据文件注明历史Training mock file copy。现有QA NQA-131也保留了正式计算列、GCP传输和生命周期待验的边界。本轮不能把比较tab中固定相同的数值称为真实Auto-PAM回归通过。[S13/S16]

| 缺口 | 正式开发前处理 |
|---|---|
| Prepayment的字段含义 | 页面Non-standard Transaction Flag、主表NON_STANDARD_ACCOUNTING_ID、Reserve Finance Status及长短期资产分类不是同一个字段。须确认引用ID和映射，不能按同名词直接连。 |
| 释放条件分歧 | 需求正文“settled + asset set up”与修订列“prior to Implemented”并存。请业务确定权威触发事件及顺序。 |
| 普通negative LSP基准 | 符号、交易起止日、月末cutoff、预算／实际汇率、精度、取整、分类与科目需Finance golden case；固定示例不能签收公式。 |
| 真实资产回执 | 本轮资料尚未建立“资产已建立”字段、API、凭证号、日期及NEO Line关联的完整契约。PO获批、计划Payment Release Date均不能替代。 |
| Final历史 | 已Final期间不能原地重算覆盖；历史更正、调整期间和批准权限待定义。 |
| Auto-PAM依赖 | 相同Claim字段可被两套计算读取；需隔离Reserve规则变更，并对PAM完整列、百分比／规则及输出集合做真实回归。 |
| 自动停止 | Scheduler列表有12个月Automatic Reserve Stop；与预付款尚未释放时的优先顺序需确认，不能让老调度静默覆盖新规则。[S7] |

## 4. 页面和交互

### 4.1 月度Reserve明细

![付款前计提](NEO-015_Overview.png)

现有Reserve语境下显示Saved Reserve、Revised Reserve、Movement和Review basis。Search与Prepayment筛选只影响列表，底部明确是Full Reserve population，避免将局部列表当期间总额。Actions在首列，查看原Line、状态和证据。

### 4.2 分开看付款、结算及资产

![Line详情](NEO-015_Detail.png)

详情保留起止日、期间末、来源Claim版本、Workflow Status、Payment evidence、Settlement evidence、Prepayment asset evidence及普通negative LSP计算基准。页面上的证据字段为新增投影建议，尚未声称已存在同名DB列。没有资产证据时不能从Implemented反推资产已经创建。

### 4.3 先预览，再按现有受控流程实施

![修订准备金预览](NEO-015_Preview.png)

预览显示完整4条Line的旧额、新额及变化，可以下载审阅Excel。关闭预览或取消关闭均不修改保存的v2；本次没有造一个可过账的按钮。正式保存新Draft／复核／Final应接入现有受控Reserve流程，需后端和Finance规则完成后再开发。

### 4.4 释放前提齐备

![结算及资产确认](NEO-015_Release.png)

固定样例中MCI-00101原Reserve为-3,000，结算和资产均Confirmed后候选为0，Movement为+3,000。它只演示释放和变化展示，不证明真实方向或会计分录。

### 4.5 Implemented有了，但资产证据不明

![证据冲突](NEO-015_Unknown.png)

Revised Reserve显示Unavailable而不是0，阻止生成。补齐证据或确认规则之后才能继续。本方案也有Calculation basis missing、Final只读、生成失败重试和Buyer权限场景。

### 4.6 Auto-PAM独立比较

![Auto-PAM对照](NEO-015_AutoPAM.png)

提供每条Line的Baseline、Comparison和Difference位置。演示固定两列相同，说明期望变化为0；未执行真实PAM公式、日调度、复制或GCP输出。正式回归需同一输入版本、同一规则版本和完整真实输出，而非抄同一个样例到两列。

## 5. 审阅数据与具体操作

用户：Grace Foster／GFS Officer；期间：31 Oct 2026；Saved v2；Source Claim v4。均为本包合成身份及数据，不是实际业务记录。

| Line | 情况 | Saved GBP | Revised GBP | 说明 |
|---|---|---:|---:|---|
| MCI-00101 | Prepayment，01 Oct 2026开始，未付款 | 0 | -3,000 | 普通negative LSP基准固定为-3,000，演示付款前确认；无获批公式推导。 |
| MCI-00102 | Prepayment，01 Dec 2026才开始 | 0 | 0 | 在本次期间之后开始的样例。 |
| MCI-00103 | 普通negative LSP | -2,400 | -2,400 | 不应因Prepayment变更改变原普通LSP处理。 |
| MCI-00104 | Loans | -500 | -500 | 其他Non-standard类型保持原样。 |
| 全量合计 | 4条 | -2,900 | -5,900 | Movement -3,000，仅对固定样例求和。 |

操作：打开独立页面 → Review MCI-00101 → 查看三个独立证据状态 → 关闭 → Preview revised Reserve → Download review。Excel包含Reserve review、Auto-PAM comparison、Scope三张sheet。导出的Scope明确固定样例边界。

外部Design scenario可切换：Before payment、Payment received、Settled and asset confirmed、Implementation / asset conflict、Calculation basis missing、Final Reserve、Preview generation failed、Purchasing access。场景控制在业务页外，不会修改产品或线上数据。

## 6. 字段、系统和接口

| 页面／逻辑输入 | 已有证据 | 来源／接口结论 |
|---|---|---|
| 起止日 | MCI_RISK_OPPORTUNITY.TRANSACTION_START_DATE/END_DATE，第700–701行。[S5] | NEO Claim录入；需保存为本期快照，勿以当前日期替代期间末。 |
| Prepayment选择 | 主表NON_STANDARD_ACCOUNTING_ID第742行；引用表MCI_REF_NON_STANDARD_ACCOUNTING第301–309行。[S5] | NEO参考数据；实际Prepayment枚举ID和与页面Flag映射待核对。 |
| Workflow／实际Implemented | WORKFLOW_STATUS_ID第685行、IMPLEMENTED_DATE第761行。[S5] | NEO流程／实施回执；预计IMPLEMENTAION_DATE第708行和PAYMENT_RELEASE_DATE第707行不等于实际结果。保留原拼写。 |
| 期内准备金及Movement | MCI_RESERVE_RISK_OPPORTUNITY第1391–1399行。[S5] | NEO Reserve计算输出；CAL_A/B存在不代表预付款正确公式已实现。 |
| 预付款和损益分类 | LUMP_SUM_VALUE、DAILY/TOTAL_UNWIND、TOTAL_PREPAYMENT、INCOME_STATEMENT、短长期开支第1403–1413行。[S5] | 存储容器已存在；计提准备金与已建立预付款资产不能简单写进同一个TOTAL_PREPAYMENT数值而不定分类。 |
| Payment／Settlement证据 | 本轮未建立完整字段→来源→契约映射 | 需定义实际付款和业务Settlement事实、日期、撤销、部分金额、Line关联；既有计划日期不能作为证据。 |
| Asset evidence | 未在本轮选定材料中建立可确认的实际资产回执字段／payload | 由现网资产负责团队确认是否SAP、哪个接口或受控文件；不能凭SAP PO存在判断资产已入账。 |
| SAP PO状态 | MCI_getPurchaseOrderDetails，接口ID5；建PO为ID10。[S6] | 可调查复用，但登记表未证明包含预付款资产与Settlement语义。 |
| Auto-PAM | MCI_REF_AUTO_PAM_RULE第92行；MCI_STG_AUTO_PAM_REPORT字段及FR18。[S3-51/S5] | 使用自身规则及输入版本；Reserve规则修正不得无依据修改它的百分比和公式。 |
| 复制／调度 | Integration ID25 Qlik：Appian MariaDB→EDW；Scheduler ID1 Auto Pam每日17:00。[S6/S7] | BRD/Training写GCP与一周保留，不能据此忽略现行登记路径；需确认实际链路及正式输出。 |

不写虚构REST路径或payload。正式契约至少要能关联Line、期间、源业务版本、事件／凭证、实际时间和状态，并支持缺失、部分、撤销和重试；这是建议契约要素，不是已收到字段清单。

## 7. Change 与 Impact

| 层 | 需要修改／验证 | 主要影响 |
|---|---|---|
| UX/UI | 在现有P16.1显示计提依据、独立状态、异常和新旧变化；补审阅预览 | 不另建重复预付款录入页；保留原字段和Finance权限。 |
| Application后端 | 根据已确认Prepayment规则计算；来源一致读取；保持Final不可覆盖、期间对账、幂等及审计 | 时间判断和释放错误会改变损益／准备金；必须用签收golden case覆盖。 |
| 数据库 | 复用现有金额／引用；缺失时补充可审计的结算／资产关联和来源版本 | 不根据截图猜新列；先查实际schema、回执及归档。 |
| BPM | 不为了生成Reserve重新发起采购DoA；如释放证据异常，可接既有Finance检查／补正路线 | 是否人工确认及责任人需业务决定；无依据不新增自动过账流程。 |
| Integration | 确认资产及实际结算来源；有足够现行接口则复用，否则扩展／新增适配 | PO状态接口不能冒充资产确认；真正接口工作量待payload核实。 |
| 财务下游 | 月度汇总、准备金分类、损益、Journal、Reserve报表及历史调整 | 新Draft可以比较；Final／已过账期间改正路径另行批准。 |
| Auto-PAM | 独立完整回归，同一基线／规则／全量输入输出对比 | 固定fixture不证明回归；现有Training文件也不算正式PAM结果。 |

## 8. 待业务确认（人话＋例子）

| ID | 问题 | 例子及建议 |
|---|---|---|
| Q01 | 到底什么时候释放：Implemented，还是已结算且资产已建立？ | 系统显示Implemented，但SAP资产晚一天创建，准备金能否先释放？建议明确事件顺序，不把几个状态等同。 |
| Q02 | “settled”具体是什么意思？ | 是Settlement获批、实施成功、实际付款，还是结算已完成？请给现网字段／凭证例子。 |
| Q03 | 哪个字段决定这是Prepayment？ | Claim的Non-standard Flag与Finance的Non-standard Accounting可能两处维护。请确认权威字段、枚举ID及矛盾处理。 |
| Q04 | 普通negative LSP究竟怎么算？ | 一笔跨月12,000的预付款，开始日和月末当天如何计日，结果正负如何显示？请Finance提供付款前、开始日、跨月、结束日和释放时点的golden case。 |
| Q05 | 什么证据证明资产真的建好了？ | 有PO编号或已付款是否够，还是必须有资产／会计凭证？请提供源系统字段、日期、Line关联及实际payload。 |
| Q06 | 部分付款、部分结算或部分建立资产怎么办？ | 12,000中只确认6,000，是部分释放还是整笔等待？请确认金额粒度及防重复释放规则。 |
| Q07 | 已Final、已过账的旧月份要不要追溯改？ | 十月已关账，十一月才启用新逻辑。建议按Finance确认的调整期间／审批处理，不能覆盖历史Final。 |
| Q08 | 怎么证明Auto-PAM没受影响？ | Reserve改了-3,000，但PAM应保持多少、哪些百分比和行不能变？请提供当前完整输出、规则版本及对照数据。 |
| Q09 | 12个月自动停提与新规则谁优先？ | 超过一年资产仍没建立，自动停止是否允许？请确认例外、审批及告警；不直接停用现有scheduler。 |
| Q10 | 预付款计提应进什么分类和科目？ | 付款前计提的准备金不一定是已确认的Prepayment资产。请确认Accrual/Provision、长短期、损益／资产科目及与CR14重估问题的边界。 |

缺资料：Finance golden case与符号／期间／精度规则；Prepayment配置与映射；Settlement及资产证据／payload；Final调整规则；正式Auto-PAM全量基线；自动停提优先规则。

## 9. 验证结果和退出条件

58 项页面交互／布局检查、12 项导出回读检查已通过。具体预期与实际值见 PAGE_VISUAL_CHECK.json / EXPORT_READBACK.json。

执行覆盖：4条固定样例及全量合计；Prepayment筛选、搜索空态及恢复；付款确认后不自动释放；结算与资产确认后的释放样例；缺证据不显示0；缺基准阻断；Final只读；预览取消／关闭不改变Saved v2；生成失败重试；Buyer无财务数据；六种宽度、390px弹窗、CSS200%缩放；真实Excel下载后回读三张sheet、完整行数、金额合计、普通LSP和Loans不变及错误单元格检查。

**这些是设计交互和固定样例对账通过，不是财务公式或Auto-PAM实际回归通过。** 原生浏览器缩放、真实API／DB／流程、持久化、真实资产回执、SAP过账、全量性能、生产部署与Finance验收均NOT RUN。样例只有4条，不能推断大规模性能。

本轮退出条件：原需求及差异可追踪；独立页面能操作；六张主要截图及移动图；实际导出可回读；问题和限制明确；ZIP完整性及文件SHA校验通过。

正式开发退出条件：Q01–10的适用规则确认；Finance golden cases独立签收；权威源数据／回执接通；开始前、开始日、月末、付款、部分及全量结算、资产建立／撤销、Implemented错位、Final调整全部验证；月度Reserve、Journal和期间对账一致；真实Auto-PAM完整输出无非预期变化。不能用本包预览通过替代这些条件。

下一项：按原表继续NEO-016，仍采用独立方案包。

## 10. 来源索引

| Source | 文件及定位 |
|---|---|
| S1/S2 | NEO Business Requirements (added China requirements) 1.xlsx：RTM for Requested Changes第16行；P1 CR clean第36行CR31-New。 |
| S1-ID-A/B | 同工作簿RTM - Archive第18行、NEO RTM第19行；用于排除同ID异义。 |
| S2-CR14 | P1 CR clean第25行；仅保留FX重估独立边界。 |
| S3-4/17 | Material Cost & Inventory - BRD V3.1.docx，Table6行4/17，FR1.2/FR6.3。 |
| S3-42/43/45/47/50/51 | 同BRD Table6，对应FR17/17.1/17.3/17.5/17.8/18。FR17.1所提取文本为空，不代表公式不存在；未据此编造会计公式。 |
| S4 | NEO User Training.docx，正文段落1739–1783（Generate Reserve）及1925–1931（Auto PAM）；均为1-based段落。 |
| S5 | NEO_数据字典.xlsx，字段字典：原行号及字段全文已保留于证据JSON。 |
| S6 | Integrations - 2026-11-09_0941(Sheet 1).csv；记录11/16/29，ID5/10/25。全表保留以便检查接口边界。 |
| S7 | Scheduler Processes - 2026-11-09_0944.xlsx，Sheet1行18/19，ID16/1。 |
| S8 | outputs/neo-jira-stories-20261111/v3/story_data.json，ACT-029/030/039/050/052，Epic CNP-235。 |
| S9/S10 | app/src/views/Reserve/Worklist.tsx、MonthlyList.tsx；行号存证。 |
| S11/S12 | app/src/domain/p05/periods.ts、domain/features/reserve-views/training-sample.ts；预设结果／样例边界。 |
| S13/S14 | app/src/views/Reporting/auto-pam-data.ts、src/theme/index.ts；历史Training文件及主题版本。 |
| S15/S16 | 143页面scope.json；唯一QA模型review-data.json中的NQA-117/131；只读引用。 |

完整绝对路径、原文、物理定位和来源SHA均在 SOURCE_EVIDENCE.json。SOURCE_MANIFEST.json保留未修改主题及依赖版本。
