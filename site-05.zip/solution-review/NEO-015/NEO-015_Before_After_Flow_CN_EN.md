# NEO-015 · Before / After process

Priority: Must (Procurement: —; Finance: Must)

ACT-029 / ACT-030 / ACT-039 / ACT-050 / ACT-052 · FR1.2 / FR6.3 / FR17 / FR18

## 预付款实施前计提

按最新修订要求，实施前套用普通负向 LSP Reserve 逻辑，并核对 AutoPAM 不受影响。

### Before · 现有路径

1. **FBP · 保存 Prepayment 与日期** — 现有字段支持分类、开始日期及相关金额；当前原型有月度 Reserve。
2. **历史需求记录 · 存在实施前计提缺口** — 早期原文描述未付款时不计提、付款月补计；最新 N／P 列改为实施前应用普通负向 LSP 逻辑。两种表述不能混为一个已确认规则。

### After · 建议路径

1. **计算服务 · 识别分类、期间及独立状态** — 读取 Prepayment、日期、实施、付款／结算及资产建立证据，保留各自含义。
2. **计算服务 · 实施前按普通负向 LSP 计算** — 使用已有并获确认的期间算法，不另发明预付款比例；将结果进入当期 Draft。
3. **Finance · 核对实施后的处理** — 是否转入实施后预付款基础或释放，必须符合确认的结算／资产条件；未实施逻辑不能直接延伸成“实施即清零”。
4. **Finance · 对账与 Final，检查 AutoPAM** — 保留期初、变动、期末及历史版本；相同输入的 AutoPAM 结果应保持原规则。

### 例子

按期间确认费用，而不是等付款时补记。下面用同一笔 GBP 10,000 说明。

交易开始后，即使尚未付款、尚未 Implemented，Prepayment 也要按普通负向 Lump Sum 的规则计提，避免等到付款月才一次性补记费用。Auto-PAM 计算保持不变。

沿用 FR17.5：开始日期晚于本月时为 0；交易期间按“已过天数 ÷ 交易总天数 × Calendarised Lump Sum GBP 金额绝对值”计算；当前日期超过结束日期时取全额。天数边界、正负号和期间口径沿用已确认规则。

示例：Calendarised Lump Sum GBP 金额绝对值为 GBP 10,000、交易期 100 天。以下展示计提金额的绝对值，假设仍未付款、未实施；30／60 天按同一已确认天数口径计算。数字用于解释，不是 Finance 金样。

| 时点 | Before：需求描述的旧问题 | After：普通负向 LSP 规则 |
| --- | --- | --- |
| 开始日期尚未到 | GBP 0 | GBP 0 |
| 已过 30 天，未付款／未实施 | GBP 0 | 10,000 × 30 ÷ 100 = GBP 3,000 |
| 已过 60 天，未付款／未实施 | GBP 0 | 期末 GBP 6,000；较上次增加 GBP 3,000，不再额外加一次 GBP 6,000。 |
| 后续付款 | 付款月才补记此前未确认的费用。 | 此前费用已按期间计提；付款记录本身不触发全部清零。 |
| 结算完成且预付款资产已建立 | 原需求未给出完整的旧释放公式。 | 核对并释放实施前计提，衔接资产处理；不冲掉已确认的费用，也不把所有预付款余额置零。 |

- 影响：费用按交易发生期间确认；Reserve 生成、明细、汇总及使用该金额的导出要一致，保留期初／变动／期末。主要是应用内计算修改，沿用现有页面及审批入口。
- 释放控制：付款、Implemented、结算完成、资产建立是不同事实。原文 E16 要求“结算且资产建立”；N16／P16 要求实施前适用普通负向 LSP。必须以实际证据衔接，不能直接写成“Implemented 即清零”。
- Auto-PAM：同一输入版本和期间的结果应保持原规则，单独做回归；不能因演示列显示相同数值就认定通过。
- 与 008 的边界：015 管实施前计提；008 管实施后的非 GBP 预付款固定实施月汇率。015 不等待未来实施月汇率才开始计算，也不能与实施后金额重复计提。

Before 数字仅说明需求中报告的历史问题，不代表已实测当前 prototype 或生产系统。Finance 仍需确认跨实施月金样及释放条件；本说明未执行正式财务验收。

Reference: 1113 14:00 RTM · NEO-015 · E16 / N16 / P16; Material Cost & Inventory – BRD V3.1 · FR17.5 (Table 6, row 47) / FR18 (Table 6, row 51).


### 保留控制

- 008 管实施后的固定汇率基础；015 管实施前计提，避免重复计提。
- 状态或资产证据缺失时保留待核对项；不修改旧 Final，不改变普通 LSP 规则。

### 正式实施前补齐

- Finance 给出跨实施月的期初／变动／期末金样，并确认原文“结算且资产建立”与最新 Implemented 控制点的关系。

## Accrue prepayments before implementation

Apply the usual negative-LSP Reserve logic before implementation, as revised in the latest request, and verify AutoPAM is unaffected.

### Before · Existing path

1. **FBP · Save Prepayment and its dates** — Existing fields support classification, start date and amounts, with monthly Reserve views in the current prototype.
2. **Historical requirement · Reported gap before implementation** — The earlier text reports no accrual before payment and a later catch-up. Revised N / P columns specify ordinary negative-LSP logic before Implemented; these are not interchangeable rules.

### After · Proposed path

1. **Calculation service · Read classification, period and separate states** — Read Prepayment, dates, implementation, payment / settlement and asset-setup evidence as distinct facts.
2. **Calculation service · Apply normal negative-LSP logic before implementation** — Reuse the agreed period algorithm rather than inventing a prepayment percentage, and include the result in the period Draft.
3. **Finance · Review post-implementation treatment** — Moving to the implemented-prepayment basis or releasing the Reserve requires agreed settlement / asset conditions; do not infer that Implemented means zero.
4. **Finance · Reconcile and Finalise; check AutoPAM** — Retain opening, movement, closing and historical versions; AutoPAM keeps its existing rule for unchanged inputs.

### Example

Recognise expense by period instead of catching up on payment. The same GBP 10,000 example follows.

Once the transaction has started, accrue a Prepayment using the usual negative Lump Sum rules before it is Implemented, even if payment has not been made. Avoid a catch-up expense in the payment month. Auto-PAM calculations remain unchanged.

Reuse FR17.5: zero where the start date is after the current month; during the term, elapsed days ÷ total transaction days × the absolute Calendarised Lump Sum GBP value; the full amount once the current date is after the end date. Retain the agreed day boundaries, signs and period conventions.

Example: an absolute Calendarised Lump Sum GBP value of GBP 10,000 over 100 days. Amounts below are accrual magnitudes, assuming the claim is still unpaid and not implemented. Use the same agreed day-count convention for 30 / 60 elapsed days. These are illustrations, not Finance golden cases.

| Point in time | Before: reported historical problem | After: usual negative-LSP rule |
| --- | --- | --- |
| Before the start date | GBP 0 | GBP 0 |
| 30 days elapsed; unpaid / not implemented | GBP 0 | 10,000 × 30 ÷ 100 = GBP 3,000 |
| 60 days elapsed; unpaid / not implemented | GBP 0 | Closing GBP 6,000; movement of GBP 3,000 since the previous example, not another GBP 6,000. |
| Later payment | Previously unrecognised expense catches up in the payment month. | Expense has already accrued by period; a payment record alone does not clear every balance. |
| Settled and the prepayment asset is established | The request does not specify the complete old release formula. | Reconcile and release the pre-implementation accrual into the asset treatment; do not erase recognised expense or set all prepayment balances to zero. |

- Impact: recognise expense in the transaction period. Reserve generation, details, totals and exports using the amount must agree, with opening / movement / closing retained. This is principally an internal calculation change using existing pages and approval entry points.
- Release control: payment, Implemented, settlement and asset setup are distinct facts. E16 requires settlement and asset setup; N16 / P16 require the usual negative-LSP rule before implementation. Reconcile those facts using actual evidence; do not define Implemented as automatic zero.
- Auto-PAM: retain the existing result for the same input version and period and run a separate regression. Matching demonstration values do not establish a pass.
- Boundary with 008: 015 covers accrual before implementation; 008 fixes the implementation-month FX basis for non-GBP prepayments after implementation. Do not wait for a future implementation FX rate to calculate 015, or accrue the same amount twice.

Before figures illustrate the historical problem reported in the request; they are not a fresh test of the current prototype or production. Finance must confirm the cross-implementation-month golden case and release conditions. This explanation is not executed Finance acceptance.

Reference: 1113 14:00 RTM · NEO-015 · E16 / N16 / P16; Material Cost & Inventory – BRD V3.1 · FR17.5 (Table 6, row 47) / FR18 (Table 6, row 51).


### Controls retained

- 008 covers the fixed FX basis after implementation; 015 covers accrual before implementation. Avoid double counting.
- Keep unresolved status / asset evidence visible; do not overwrite old Finals or change ordinary LSP rules.

### Production dependencies

- Finance supplies a cross-implementation-month golden case and resolves how the original settlement-and-asset wording relates to the revised Implemented control point.

## Sources

- **R-1113** NEO Business Requirements (added China requirements) 2(RTM for Requested Changes)_1113 1400 version.xlsx · NEO Business Requirements (adde!E16,N16,P16,Q16; priorities K16:L16
- **S1** NEO Business Requirements (added China requirements) 1.xlsx · RTM for Requested Changes row 16
- **S3-4** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 4 (1-based)
- **S3-17** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 17 (1-based)
- **S3-42** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 42 (1-based)
- **S3-43** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 43 (1-based)
- **S3-47** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 47 (1-based)
- **S3-51** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 51 (1-based)
- **S4** NEO User Training.docx · Body paragraphs 1739–1783 and 1925–1931 (1-based)
- **S2** NEO Business Requirements (added China requirements) 1.xlsx · P1 CR clean row 36

Before: frozen prototype `3ff8bc0b158ba08f2302e7404bb6185a553088c78614051451e6b5137a26802e`. Historical problems are labelled separately. After is a proposal; numerical examples are illustrative. Production execution: NOT RUN.
