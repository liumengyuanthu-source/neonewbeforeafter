# NEO-020 · Bulk Upload保留Part Number前导零

<!-- FLOW-REVIEW-20261116 -->
## 16 Nov 2026 · 流程评审补充

[中英文 Before / After 流程](NEO-020_Before_After_Flow.html) · [流程说明 MD](NEO-020_Before_After_Flow_CN_EN.md)

零件编号始终按文本处理；发现字符已丢失时回到原始资料更正，不自行补零猜测。

本轮为流程说明补充；原交互页面、问题及历史证据保留。正式实施前需补齐：确认完整号候选列／正式模板版本及真实编号样例；SAP／Apigee 提供字符串 payload 证明和下游回读样例。
<!-- /FLOW-REVIEW-20261116 -->

本包为独立英文页面和Excel候选模板，沿用NEO theme／Ant Design。未修改现有prototype、共享QA、数据库、流程或线上系统；已退役的产品导入入口未恢复。所有Part、价格、组合和人员为合成审阅数据，本地Apply只改变当前页面内存。

## 1. 原需求、痛点和reference

用户本来输入了正确的Part Number，但Excel的General格式或NEO读取方式把编号改了，导致找不到零件。例如Base应为01758，落到上传文件时却成了数字1758。[S1]

| 来源 | 能证明什么／不能证明什么 |
|---|---|
| 新需求工作簿，RTM for Requested Changes，第21行NEO-020 | CR-2026-1557 \| 2；Procurement Must；原分类Existing functionality - Update UX / Workflow。提出改模板格式，或增加Material／Full Part Number并核对Prefix＋Base＋Suffix。[S1] |
| 原文痛点及目标 | Part numbers entered correctly, then upload incorrectly and aren't recognised；目标是模板和上传不能改掉正确输入。[S1] |
| Training正文P518–550；P533内嵌image95 | 历史上传模板有PART_PREFIX、PART_BASE、PART_SUFFIX等11个header，没有FULL_PART_NUMBER。本包新增的全号字段是候选变更，不冒充已有字段。[S3/S3-V] |
| BRD Table6第8行FR1.6 | Part从reference data检索；同一Part要保留Plant和价格语境。[S2-8] |
| BRD Table6第20行FR8.1 | 展示Prefix前4、Base后5、Suffix末2，并保留Part Number as entered。该显示拆分不能未经确认当成所有白件／彩件／外部物料的通用补零规则。[S2-20] |
| BRD Table6第65行FR19.13 | Production Part Numbers从SAP取得，包含White／Coloured Part Numbers；不能根据文本相似度随便挑一个Part。[S2-65] |
| 同ID异义 | RTM - Archive第23行NEO-020是FR8.1计算展示；NEO RTM第24行是Inflation字段。它们不是本条Bulk Upload新需求。[S1-ID-A/B] |

技术背景：Microsoft说明Excel可能将数字式标识转换成数值、科学计数法或日期，数值还受15位有效数字精度限制；后改格式不会恢复已丢失内容。因此这里需要保存真实文本值，不能只给数字套一个显示补零格式。该依据不决定NEO业务编号规则。[Microsoft Support](https://support.microsoft.com/en-us/excel/keeping-leading-zeros-and-large-numbers)。[S13]

## 2. Solution、主要改动类型与Priority

保留原来的Prefix／Base／Suffix，三段及新增FULL_PART_NUMBER都使用Text；上传时读取原始单元格类型和值，逐字核对三段拼接、完整编号、当前Part reference及Part／Plant组合。数字类型、丢零、错段和不存在的编号都定位到具体行／单元格，不能静默修正。

| 项目 | 结论 |
|---|---|
| 主要改动类型 | Application内部前后端修改：模板、parser、字段／类型校验、reference匹配、错误反馈与应用边界。前端看起来是模板优化，但只改UXUI不能解决落库／接口转换丢零。 |
| Integration needed | 原则上复用现有SAP Part catalogue。登记ID1 MCI_getPartDetails为经Apigee从SAP取得Part details；它只证明已有接口登记，不能证明实际JSON字段类型、前导零和分段均正确。[S12] |
| 新增还是复用 | 优先修NEO的模板与消费端；若现有provider已经把Part编号转成数字或缺分段／完整号，需要源系统／集成团队确认并扩展原合同。当前没有证据要求新平台或新架构。 |
| Priority | 原表Procurement Must；建议P1，并作为Bulk Upload上线前的数据完整性条件。不是为了恢复当前已退役入口而单独开通。 |
| Epic | 关联现有CNP-231 Claims and data，不新增虚构Jira ID。[S5] |
| ACT／User Story | 主ACT-026 Bulk Upload Parts；Create／Update Claim为上下文，不能用本包替代它们全量验收。[S5] |
| FR | 主FR1.6；reference关联FR19.13；FR8.1计算展示／导出需保留相同编号；FR13下游只作关联回归，不在上传时触发WIPS。[S2/S5] |
| 页面 | 现有P2.6 Parts Data — create POA；候选Bulk Upload／验证结果／Part Number详情／确认交互。未分配新的正式Page编号。[S11] |
| UC | D020-UC01–08为本轮临时设计场景，不冒充已签收UC ID。 |

## 3. 方案取舍和范围

| 方案 | 取舍 |
|---|---|
| 仅把列改成Text | 改动最小，但不能发现粘贴覆盖格式、数字类型或分段错误。只做这一项不足以证明导入正确。 |
| 仅保留Full Part Number | 减少重复输入，但移除Training原有分段列，影响较大，不作为本轮默认。 |
| 本包建议：Text＋分段／全号核对 | 保留原字段并增加显式FULL_PART_NUMBER，能在预览前发现不一致；代价是模板版本及用户操作需变更，是否全号必填仍须业务确认。 |

本候选针对Standard同币种改价，保留Training原11个字段并新增全号，不覆盖NEO-016的Resource／currency template建议。正式交付须统一016、019、020的模板合同；本包12列不能直接替换现网合同，也不是已批准唯一格式。

NEO-019的Plant代码／名称和组合校验继续保留。NEO-021的S4流程、完整价格／FTO计算及WIPS建单不是本轮新增范围。未知编号不会自动创建新Part，也不会改动旧Claim／已批准版本。

## 4. 字段、数据字典及接口

| 页面／模板字段 | 字典证据及设计约束 |
|---|---|
| PART_PREFIX | MCI_REF_PART.PREFIX，第321行，varchar(50)。保留文本，不用Number、parseInt或数值单元格；50是存储上限，不是批准的业务格式。 |
| PART_BASE | MCI_REF_PART.BASE，第322行，varchar(50)。01758和1758不是可随意互换的值；00000也不等于空白。 |
| PART_SUFFIX | MCI_REF_PART.SUFFIX，第323行，varchar(50)。04必须保留两字符，不改成数字4。 |
| FULL_PART_NUMBER（新增候选header） | 对应含义为MCI_REF_PART.PART_NUMBER，第324行，varchar(255)。既有数据库有完整编号，但不证明历史上传模板已有这个列名，也不证明某接口JSON同名。 |
| White／Coloured变体 | WHITE_COLOURED_PREFIX／BASE／SUFFIX／PART_NUMBER，第326–329行；不能把两组字段混用。需要确认按哪个实际物料标识做匹配。 |
| Claim Part关联 | MCI_RISK_OPPORTUNITY_PART.PART_ID，第816行，指向MCI_REF_PART.PART_ID。这个整数外键可以是数字，业务Part Number必须仍为文本；二者不要混淆。 |
| Provider／Consumer | SAP提供Part reference，NEO消费，登记经Apigee。接口实际payload是否string、完整编号与分段如何命名、是否有前导零转换，未取得样例，不能标成已核实。 |
| 下游消费 | 计算表、导出、FTO／GR关联、WIPS／S4请求都要沿用同一已确认身份。修上传并不代表这些链路已实测。 |

以上字典位置见S4；原接口登记见S12。当前旧import/schema.ts已有“必须text cell”的校验，但它是15列illustrative格式且入口已退役。存在保护代码不等于当前业务上传已可用，也不能直接把旧格式当Training模板。[S6/S10]

## 5. 页面和交互

### 5.1 下载Text格式模板

![Text模板和示例](NEO-020_Template.png)

Grace Turner／CBSL打开Supplier Negotiations的POA。模板A:D预设Text，包含三段与全号的Stop校验，保留Plant下拉。没有文件时Apply禁用。这里的样例数据用于解释格式，不是从SAP读取的真实记录。

### 5.2 一眼看到前导零有没有保住

![分段与完整编号](NEO-020_Validated.png)

示例1：MP9X＋01758＋AA＝MP9X01758AA。示例2：0001＋00123＋04＝00010012304。上传后两组显示值必须原样一致；不按数值排序／转换身份，也不把00前缀当多余字符。

### 5.3 查看只读文本值

![Part Number详情](NEO-020_Detail.png)

行首View打开同一条Part，Full／Prefix／Base／Suffix显示为文本输入框。Base的01758不会因为打开详情变成1758；这仍是当前内存候选的显示，不是数据库刷新回读。

### 5.4 数字单元格明确退回

![数字单元格错误](NEO-020_NumberError.png)

错误定位到B2／PART_BASE，显示实际收到的1758，并要求设Text后重新输入原编号。数字1758套00000显示格式也被拒绝；不能用显示字符串“01758”伪装为已保存的真实文本。

### 5.5 三段与全号不一致不能继续

![分段不匹配](NEO-020_Mismatch.png)

三段拼成MP9X01758AA，但Full写成MP9X1758AA时定位D2。页面指出不一致，但不会替用户选哪份正确。需要回到原始Part资料核对后重新上传。

### 5.6 确认后保留准确身份

![确认后的编号](NEO-020_Applied.png)

取消不应用；显式确认后显示两条已应用的完整号和分段，内存Claim v7→v8，重复Apply禁用。没有生成审批／WIPS单／财务实施状态；重载页面会重置本包模型。

## 6. 场景与具体操作

| 项目 | 本包输入／前提 |
|---|---|
| User | Grace Turner／CBSL，合成人员；Alice Morgan／Buyer在限制场景，正式权限仍需确认。Training矩阵与正文不同。[S3/S5] |
| Claim | MCI-00057，POA，Supplier Negotiations，Vendor V002 Demo Motion UK，Company GB01，v7。 |
| 有效行1 | PART_PREFIX MP9X；PART_BASE 01758；PART_SUFFIX AA；FULL_PART_NUMBER MP9X01758AA；CURRENT_PRICE 100；NEW_PART_PRICE 95；Currency GBP；signed change -5；PL-HAL · Halewood Assembly；RUNOUT No；Date／ATP空。 |
| 有效行2 | 0001；00123；04；00010012304；50；45；GBP；-5；PL-SOL · Solihull Assembly；No；Date／ATP空。 |
| 全零Base | AB12；00000；BC；AB1200000BC；200；190；GBP；-10；PL-HAL；No。00000是有效fixture文本，不能当作空值。 |
| 文件 | NEO-020_Part_Number_Template_Candidate.xlsx为空白候选；design-source/fixtures/valid.xlsx是有两行的测试文件，另有all-zero-base.xlsx。测试文件不是正式模板。 |
| 候选边界 | .xlsx、2MB、1,000行、价格最多5位小数和本包Standard同币种校验均为审阅合同。没有据此限制生产全量交易／币种，也没有替代Resource方案。 |

| 临时UC | 操作 | 预期 |
|---|---|---|
| D020-UC01 | CBSL下载、以Text录入两行，再Choose file | 预览逐字保留Prefix／Base／Suffix／Full，匹配到准确Part／Plant。 |
| D020-UC02 | Base／Prefix／Suffix／Full存为numeric，含00000显示格式或长数值 | 指明单元格并拒绝；不恢复丢失字符，不按显示格式或相似Part补零。 |
| D020-UC03 | 三段与Full不一致、带空格／大小写差异或未知编号 | 错误可定位；不trim／uppercase／fuzzy match，也不自动建Part。 |
| D020-UC04 | Base 00000；或长numeric-like文本 | 前者准确保留；后者保持原文本但若未在reference中则拒绝，不能把文本保真当成业务编号合法证明。 |
| D020-UC05 | Cancel／Confirm／重复点击Apply | Cancel保持候选，Confirm只应用一次，内存结果中的编号与验证时一致。 |
| D020-UC06 | reference在验证后变更；Refresh后Validate file again | 旧验证失效；当前版本重核对后才能应用。本包v5仍为同一组fixture，未模拟所有真实改名／撤销。 |
| D020-UC07 | reference不可用、Active approval、Buyer权限未确认 | 禁止相应下载／上传／应用；失败可重试，不以空reference放行。 |
| D020-UC08 | 错header、公式／链接、混合正确错误行、超限或应用被拒绝 | 整份不部分应用，明确错误；确定拒绝后候选保留。结果未知时先回读的真实机制尚未实施。 |

## 7. 修改影响与开发任务

| 层 | 应完成什么／当前缺什么 |
|---|---|
| 模板 | Text格式覆盖所有可填写标识单元格；三段校验ISTEXT，Full使用EXACT对照拼接。复制粘贴可绕过Excel验证，所以仍须上传校验。模板版本、历史11列／新12列及Resource合同需一起签收。 |
| 前端 | 保持NEO／Ant Design；行首View固定，文本不转number；展示错误行／cell／field／supplied value及原因，保留文件供重传，取消、恢复和窄屏可用。 |
| 服务端 | 重新检查真实单元格类型，精确比较身份和reference版本、Vendor／Company／Part／Plant、权限／状态；独立生成预览和幂等应用回执。前端PASS不能替服务端PASS。 |
| 数据库 | 优先使用现有varchar字段及Part_ID关联。复核ORM／DTO／SQL／去重键不将Part Number转数字；已有错误不能直接全库补零，需源数据逐项核实和另行授权修复。 |
| API／集成 | 从SAP实际response到NEO再到WIPS／S4，逐字段检查string、零和大小写。若provider已丢失字符，消费端不能可靠补回；需provider原数据／合同修复。接口登记没有提供这项证明。 |
| 流程 | 不改变审批、Settlement或实施时点；Supplier Negotiations上传门槛与真实角色另验证，不能因处理格式而跳过审批。 |
| 回归 | NEO-016模板类型、019Plant、Calculation／FTO／GR lookup、导出再上传、WIPS／S4 payload和历史记录保护。只修显示而关联不到原Part仍是失败。 |

## 8. 测试、实际结果和退出条件

PAGE_VISUAL_CHECK.json逐条记录expected／actual／status；本地133项浏览器检查通过。WORKBOOK_NATIVE_STRUCTURE_CHECK.json中10项OOXML检查通过。此结果仅适用于本包版本和合成数据。

| 检查组 | 实际执行及边界 |
|---|---|
| Excel结构／渲染 | A:D第2／501／1001行的Text样式已回读；分段／Full custom Stop验证、Plant list、无宏／外链／单元格公式、ZIP结构检查通过。两个sheet的三个范围已渲染并查看。 |
| 字符保真 | 正常01758、全零00000、完整数字式00010012304、Suffix04，验证／详情／内存Apply均独立检查实际文本。 |
| 错误拒绝 | numeric四字段、自定义00000显示掩码、长numeric精度风险、长文本／科学记号文本、段／全号不符、空白／空格／大小写、未知Part、错误Plant、duplicate、错误价格／币种／日期、混合正确错误行均实际执行。 |
| 文件／恢复 | 公式、链接、隐藏sheet、合并、错header／version／sheet、坏文件、错扩展名、超行数／体积、reference变更／不可用、确定拒绝重试、状态／角色门槛已检查。 |
| UXUI | 1920／1440／1024／768／390／360，32／24／16页面边距、表格横向滚动、行首View、详情／确认按钮、Cancel／Escape、CSS200%、无外部HTTP请求或runtime error已检查。CSS缩放不是原生zoom。 |
| 规模 | 1,000行duplicate-heavy fixture验证并分页，耗时保留在JSON，仅作本地观察，未与生产SLA比较。 |
| NOT RUN | Microsoft Excel真实输入／粘贴／保存／关闭／重开及版本兼容性；真实主数据／API字段类型；数据库保存／刷新回读、实际权限／并发／幂等／安全；源系统修复；导出／接口／计算关联全链；部署和业务UAT。 |

本轮退出：独立页面、六张主图、候选Excel、38份输入fixture、来源和问题、实际检查、可编辑ZIP及汇总入口齐备。没有把候选本地结果写成现有产品PASS，也未创建第二份QA总表。

正式开发退出：真实Excel输入后所有编号逐字符一致；后台保存／重开及准确Part关联一致；对应计算、export和下游payload同值；numeric／版本／权限等错误不能落库；实际环境版本和回执可追踪；业务确认模板及兼容规则。

## 9. 讲人话的问题清单

| 编号 | Context／例子 | 建议和影响 |
|---|---|---|
| Q020-01 | 是否接受在原11列里加FULL_PART_NUMBER，并要求它与三段同时填写？ | 本包推荐加，能早发现丢零；但需要改模板版本、parser和用户培训。若只改Text，应另有可信全号校验，不能假装两方案相同。 |
| Q020-02 | Prefix／Base／Suffix是否所有Part都固定4／5／2？White／Coloured和外部物料有没有例外？ | FR8.1有展示拆分，字典长度更宽。请采购／SAP给真实例子和格式规则；不要统一padStart补成5位。 |
| Q020-03 | 12345本来没有零，但Excel把它存成number，是否也拒绝？ | 候选统一要求标识为Text，避免分支猜测。若需短期兼容数字输入，必须有明确范围和不会丢精度的证据。 |
| Q020-04 | 如果Base1758和01758各自都是真实Part，应怎样选？ | 以原始文本＋完整编号准确匹配，不能猜近似值。请提供带前导零和不带零的对照主数据，防止关联错零件。 |
| Q020-05 | White／Coloured字段分别对应哪套实际上传编号？ | 需SAP／业务明确哪列是外部物料身份及替代关系；不要把两套号拼成一套。 |
| Q020-06 | 现在SAP／Apigee的Part字段是JSON string还是number？完整号和分段叫什么？ | 请接口团队提供实际response和成功／失败样例；登记表本身不能证明编号未被转换。 |
| Q020-07 | 旧11列模板是否继续收，xls／CSV是否继续支持，过渡多久？ | 推荐显式版本／迁移窗口；当前候选只演示.xlsx新12列。Training许可xls/xlsx，不能据此宣称CSV现已支持。[S3-V] |
| Q020-08 | 一行编号错，整份退回还是应用正确行？ | 候选整份拒绝，便于核对；若要部分成功，需要逐行回执、重传和幂等规则。 |
| Q020-09 | 已上传错／已批准的历史编号如何处理？ | 不自动改历史或冻结审批。先用SAP原资料确认对应记录，再另行批准修复、重算和审计范围。 |
| Q020-10 | 谁上传、在哪个入口、使用哪些Excel版本？ | Training正文写CBSL，矩阵有Buyer；当前产品上传已退役。入口恢复、角色及Mac／Windows／web Excel测试都要确认，不以本包替代批准。[S3/S10] |

## 10. 交付与下一步

- NEO-020_Page_Proposal.html：独立英文页面，六个外部审阅场景，无外网依赖。
- NEO-020_Part_Number_Template_Candidate.xlsx：Text／Stop／Full cross-check的原生候选模板，非生产认可文件。
- NEO-020_Consolidated_CN.html／本MD：方案、六图、Epic／ACT／FR／UC、字段／接口、影响、问题及验收边界。
- OPEN_QUESTIONS_CN.md：10项讲人话的问题和例子。
- SOURCE_EVIDENCE.json：17条本地来源摘录／locator／SHA和1条Microsoft官方技术参考。source-assets只保留一张内部Training来源证据，不另做Before页面汇总。
- PAGE_VISUAL_CHECK.json、WORKBOOK_NATIVE_STRUCTURE_CHECK.json、WORKBOOK_AUTHORING.json、VALIDATION.json：实际检查和文件完整性；design-source保留TSX、theme、builder、fixtures、verify、README和manifest。

下一条NEO-021为S4专属工厂POA／S4H Task及BP–GSDB映射；本包不提前修改或声称其已经实现。
