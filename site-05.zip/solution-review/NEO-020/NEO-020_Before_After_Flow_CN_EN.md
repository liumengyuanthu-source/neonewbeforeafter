# NEO-020 · Before / After process

Priority: Must (Procurement: Must; Finance: —)

ACT-026 · FR1.6 / FR8.1 / FR19.13

## 上传全过程保留零件编号前导零

零件编号始终按文本处理；发现字符已丢失时回到原始资料更正，不自行补零猜测。

### Before · 现有路径

1. **当前原型用户 · 查看现有 Part Number** — 当前页面展示参考零件编号；通用 Excel 上传已退役，旧 parser 有文本检查也不等于该链路已开放。
2. **历史需求记录 · 模板转换导致编号失真** — 新需求指出正确录入的编号被模板修改；应从文件格式、读取到匹配全链路保护。

### After · 建议路径

1. **有权上传用户 · 下载文本格式模板** — Prefix／Base／Suffix 按文本录入；Full Part Number 为现设计新增的校验候选列。
2. **上传用户／校验服务 · 原样读取，不做数值转换** — 保留 01758、04、00000。数字单元格、公式或已失真的编号报出具体单元格。
3. **校验服务／用户 · 按真实身份核对** — 核对分段、完整号及 Part／Plant 组合，不按相似文字补零或自动新建零件。
4. **上传用户 · 确认后沿用同一编号** — 预览后显式应用。之后的明细、导出和接口沿用已确认编号；源版本变化先重新验证。

### 例子

示例：Base“01758”必须仍是“01758”，不能变“1758”；Suffix“04”不能变“4”。两者可能对应不同实际零件，系统不能统一补零猜回原值。

### 保留控制

- 业务编号是文本，PART_ID 整数外键仍可为数字，不要混淆。
- 不自动修复已批准历史记录；字符保真也不代表业务编号一定存在。

### 正式实施前补齐

- 确认完整号候选列／正式模板版本及真实编号样例；SAP／Apigee 提供字符串 payload 证明和下游回读样例。

## Preserve leading zeros throughout part upload

Treat part identifiers as text throughout. If characters are lost, correct from the source rather than guessing by padding zeros.

### Before · Existing path

1. **Current prototype user · View existing part numbers** — Current pages display reference identifiers. Generic Excel upload is retired; text checks in an old parser do not establish an active upload flow.
2. **Historical requirement · Template conversion can corrupt an identifier** — The request reports correctly entered numbers being modified by the template; protect formatting, parsing and matching together.

### After · Proposed path

1. **Authorised uploader · Download a text-formatted template** — Enter Prefix / Base / Suffix as text; Full Part Number is an additional validation column proposed by the existing design.
2. **Uploader / Validation service · Read exactly without numeric conversion** — Preserve 01758, 04 and 00000. Identify numeric cells, formulas or damaged identifiers by their cell location.
3. **Validation service / User · Match the actual identifier** — Validate segments, full number and Part / Plant combination; do not pad, fuzzy-match or automatically create a part.
4. **Uploader · Confirm and retain the same identifier** — Explicitly apply after preview. Details, exports and interfaces retain the confirmed identifier; revalidate first if the source version changes.

### Example

Example: Base “01758” must remain “01758”, not “1758”; Suffix “04” must not become “4”. These may identify different parts, so the system cannot guess the original by padding.

### Controls retained

- Business identifiers are text; the integer PART_ID foreign key can remain numeric.
- Do not automatically repair approved history; preserving characters does not prove that the part exists.

### Production dependencies

- Confirm the proposed full-number column, production template version and real identifiers; SAP / Apigee supplies string payloads and downstream readback samples.

## Sources

- **R-1113** NEO Business Requirements (added China requirements) 2(RTM for Requested Changes)_1113 1400 version.xlsx · NEO Business Requirements (adde!E21,N21,P21,Q21; priorities K21:L21
- **S1** NEO Business Requirements (added China requirements) 1.xlsx · RTM for Requested Changes row 21 (1-based)
- **S2-8** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 8 (1-based)
- **S2-20** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 20 (1-based)
- **S2-65** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 65 (1-based)
- **S3-V** NEO User Training.docx · NEO User Training.docx, body paragraph 533 / rId120 / word/media/image95.png; visual header list
- **S4** NEO_数据字典.xlsx · 字段字典; original row numbers retained
- **S6** schema.ts · Numbered source lines (1-based)
- **S12** Integrations - 2026-11-09_0941(Sheet 1).csv · Header plus Part-detail interface register records; not a payload contract

Before: frozen prototype `3ff8bc0b158ba08f2302e7404bb6185a553088c78614051451e6b5137a26802e`. Historical problems are labelled separately. After is a proposal; numerical examples are illustrative. Production execution: NOT RUN.
