# NEO-016 · Before / After process

Priority: Should (Procurement: Should; Finance: —)

ACT-026 · FR1.6

## 按用途拆分上传模板

普通改价与 Resource／币种变更使用各自模板；不显示与该用途无关的必填项。

### Before · 现有路径

1. **当前原型用户 · 使用 Select Parts** — 当前产品通用 Parts Excel import 已退役并转向选零件页；不能把旧模板当当前可操作 Before 页面。
2. **Training／历史需求 · 共用模板产生无关字段** — 历史上传流程及需求记录指出 Resource／币种场景不适合沿用所有价格差额字段。

### After · 建议路径

1. **有权上传用户 · 选用途并下载相应模板** — 选择 Resource／币种变更或普通改价；只显示该用途的字段。角色与入口按确认结果启用。
2. **上传用户 · 填表并暂存** — Resource 保留 Part、Plant、New Price 和 Currency；普通改价保留适用差额校验。文件暂存后先移除再换用途。
3. **校验服务／用户 · 核对原价与逐行问题** — 原价来自参考数据。跨币种不直接做减法；错误明确到行和字段，本候选不部分应用。
4. **上传用户 · 确认后应用到 Claim** — 预览目标 Claim 与行数；取消保留暂存。确认只更新本次明细，不提交审批。

### 例子

示例：100 GBP → 95 EUR 的 Resource 行，不要求填写“差额 -5”；差额与百分比显示 —。50 GBP → 48 GBP 的同币种行，差额 -2、比例 -4%。

### 保留控制

- 普通改价校验继续生效；不因 Resource 场景全局关闭价格校验。
- 独立候选页应用只在内存中；原产品入口未恢复，数据库持久化未验收。

### 正式实施前补齐

- 确认上传入口／角色及正式模板；跨币种业务算法和整批事务策略由业务与开发签收。

## Split upload templates by purpose

Use separate templates for ordinary price changes and Resource / currency changes, avoiding irrelevant required fields.

### Before · Existing path

1. **Current prototype user · Use Select Parts** — The current product’s generic Parts Excel import is retired and routes to part selection; the legacy template is not a live Before page.
2. **Training / Historical request · Shared templates contain irrelevant fields** — Historical upload guidance and the request show that Resource / currency scenarios cannot reuse every price-difference field.

### After · Proposed path

1. **Authorised uploader · Choose the purpose and download its template** — Choose Resource / currency change or ordinary price change and expose relevant columns only. Enable the entry and roles when confirmed.
2. **Uploader · Complete and stage the file** — Resource keeps Part, Plant, New Price and Currency; ordinary changes retain applicable delta checks. Remove a staged file before switching purpose.
3. **Validation service / User · Review reference prices and row errors** — Read start prices from reference data. Do not directly subtract different currencies; locate errors by row and field. This proposal applies the file atomically.
4. **Uploader · Confirm and apply to the Claim** — Preview the target Claim and row count; cancellation retains staged data. Confirmation updates the details without submitting approval.

### Example

Example: Resource from 100 GBP to 95 EUR must not require a -5 difference; difference and percentage remain unavailable. A same-currency change from 50 GBP to 48 GBP gives -2 and -4%.

### Controls retained

- Keep ordinary price validation; do not disable all checks for Resource scenarios.
- The independent candidate applies in memory only; the product entry is not restored and database persistence is not accepted.

### Production dependencies

- Confirm the upload entry, roles and production templates; obtain agreement on cross-currency calculation and batch-transaction policy.

## Sources

- **R-1113** NEO Business Requirements (added China requirements) 2(RTM for Requested Changes)_1113 1400 version.xlsx · NEO Business Requirements (adde!E17,N17,P17,Q17; priorities K17:L17
- **S1** NEO Business Requirements (added China requirements) 1.xlsx · RTM for Requested Changes row 17
- **S3-8** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 8 (1-based)
- **S4** NEO User Training.docx · Body paragraphs 518–550; matching action-matrix row (1-based)
- **S7** PartPrices.tsx · Numbered source lines
- **S8** fr1-prices.ts · Numbered source lines
- **S9** schema.ts · Numbered source lines
- **S2** NEO Business Requirements (added China requirements) 1.xlsx · P1 CR clean row 37

Before: frozen prototype `3ff8bc0b158ba08f2302e7404bb6185a553088c78614051451e6b5137a26802e`. Historical problems are labelled separately. After is a proposal; numerical examples are illustrative. Production execution: NOT RUN.
