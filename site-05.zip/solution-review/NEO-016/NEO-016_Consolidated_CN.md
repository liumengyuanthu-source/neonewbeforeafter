# NEO-016 · 按用途拆分批量模板，修正换币种校验

<!-- FLOW-REVIEW-20261116 -->
## 16 Nov 2026 · 流程评审补充

[中英文 Before / After 流程](NEO-016_Before_After_Flow.html) · [流程说明 MD](NEO-016_Before_After_Flow_CN_EN.md)

普通改价与 Resource／币种变更使用各自模板；不显示与该用途无关的必填项。

本轮为流程说明补充；原交互页面、问题及历史证据保留。正式实施前需补齐：确认上传入口／角色及正式模板；跨币种业务算法和整批事务策略由业务与开发签收。
<!-- /FLOW-REVIEW-20261116 -->

本轮为独立页面提案，没有恢复现有产品已停用的 Parts Excel 导入入口，没有修改 prototype、共享QA或业务记录。界面英文，方案中文。模板、人员、价格和主数据为审阅用候选契约及合成数据；不冒充已收到的现网模板或已批准业务规则。

## 1. 原需求

Resource变更有时会更换零件结算币种。原价100 GBP、新价95 EUR时，直接相减没有明确业务含义；原批量模板却要求填写Price Change。NEO-016要求修正这个校验，并按不同用途拆分模板，只保留适用字段。[S1/S2]

本次方案：Resource／换币种模板直接录入New Part Price和New Part Price Currency，不含Absolute Part Price Change；普通改价模板保留该列及一致性校验。跨币种行的差额和百分比显示“—”，不是0，也不自动套一个FX汇率。Resource模板内同币种行仍可显示直接价格差额。

| 来源 | 结论与边界 |
|---|---|
| RTM for Requested Changes第17行 | 正确NEO-016；Procurement Should，Finance优先级空白。[S1] |
| P1 CR clean第37行CR32 | 原始换币种Price Change校验问题，注明关联CR15批量能力。[S2] |
| P1 CR clean第23行CR15 | AMM列和批量能力为另一个关联范围。本条不声称已补齐AMM的全部模板和业务规则。[S2-CR15] |
| BRD FR1.6 | Resource/Currency允许直接输入新价和新币种；一般差额／百分比及WIPS分支另有条件，Resource等不进入普通WIPS模拟路径。[S3-8] |
| Training Bulk Upload Parts | 正文518–550中第520段写CBSL only；角色矩阵列有Buyer。权限存在差异，不能擅自扩大。[S4/S6] |
| 项目约束 | 现行UX标准明确不要恢复Parts Excel导入；QA也保留retired upload边界。本独立提案没有改变该决定。[S13/S14] |
| 同ID异义 | RTM - Archive第19行NEO-016为Finance Data；NEO RTM第20行为预测金额。均不作为本条需求。[S1-ID-A/B] |

## 2. 主要改动类型、优先级及关联

| 项目 | 评估 |
|---|---|
| 主要改动类型 | Application内部前后端修改＋模板UX。前端按用途提供字段／模板，后端按交易类型和币种组合校验，保存不可比差额的空值。仅删Excel必填标记不够。 |
| Integration needed | 本条上传本身不要求新增外部接口。优先复用现有零件／工厂／供应商／价格主数据校验；后续计算、实施是否接受新币种和null差额须核实。 |
| 跟谁对接 | NEO Claim／Parts服务、主数据／价格服务、计算服务；如影响下游，再与对应WIPS／SAP或其他实施通道owner确认。上传不能自动触发建单／审批。 |
| 是否可以用现有接口 | 需要核查现行payload是否同时支持Current Value Currency和New Part Price Currency，以及可空delta。已有接口登记表不等于收到该上传契约。[S16] |
| 新增架构 | 暂不需要新增平台。可在NEO内部扩展带版本模板和条件校验。真实大批量解析、事务、并发、重复提交及审计需现有服务支持或补齐。 |
| 建议Priority | P1，保持Procurement原Should。权限、模板及下游空值／币种契约是开发前置；不得通过删除全部校验来赶进度。 |
| Epic | CNP-231 / Claims and data，沿ACT-026现有Epic建议挂接；本轮没有Jira写入。[S6] |
| User Story | 主ACT-026 Bulk Upload Parts；关联Create／Update Claim的Parts场景。Buyer诉求需要纳入权限确认，不能把Training正文差异当作已批准放权。 |
| FR | 直接FR1.6；关联FR6的更新及FR13实施边界。CR32／CR15扩展是本条需求依据，不能说基础BRD已定义完整拆分模板。 |
| 页面 | 当前P2.6 Parts Data相关；历史目录P7.5.1 Upload Parts Data仅作旧位置参考。本提案D016-P01上传、D016-P02校验、D016-P03确认是临时标识，未给产品恢复路由或登记正式新Page ID。[S12] |

## 3. 当前实现与Gap

当前PartPrices.tsx已有Resource／Currency直接录入和跨币种差额不可用的提示；fr1-prices.ts对跨币种固定值／百分比改价拒绝，要求直接录入新价。此方向可以沿用。[S7/S8]

源码仍有旧import/schema.ts和xlsx.worker.ts，但旧schema以单个Currency字段及固定15列作校验，不能当作本条完整跨币种模板实现，也不能凭文件存在判断当前入口启用。当前项目明确保留retired upload状态，本轮没有恢复。[S9/S10/S13/S14]

| Gap | 为什么重要 |
|---|---|
| 没有已签收的现网模板文件及版本清单 | 候选四列／五列不能冒充原模板准确还原；缺少模板owner及旧文件兼容策略。 |
| Buyer和CBSL权限冲突 | 需确认谁上传、谁应用、哪个阶段允许；演示以CBSL为可操作角色，Buyer显示待确认。 |
| 两个币种与差额可空 | 一处设空，后续API／DB若又默认0或强制必填，会再次出错或生成错误金额。 |
| “Resource”的实际代码与适用范围 | 需确定Claim字段／枚举及是否允许同一文件混合币种；不能只凭文件名判断。 |
| 上传字段对照 | Part/Plant是业务文本代码，最终需映射到PART_ID/PLANT_ID；不能直接把P2001塞入integer外键。 |
| 主数据与版本 | 原价从权威价格数据读取，上传文件不能覆盖；价格变更后应重新核对，而不是继续按旧预览提交。 |
| 事务和幂等 | 本提案整文件一起应用是候选控制；正式全量／部分成功策略、操作ID、未知结果回读、重试和回滚需契约。 |
| 全量模板范围 | CR15提及AMM，本轮仅示范Resource与普通改价，不宣称所有用途模板已完成。 |

## 4. 页面与交互

### 4.1 选用途、下载相应模板

![用途与模板](NEO-016_Template.png)

沿用NEO顶栏、字体、表格和Ant Design间距。顶部保留Line、Description、POA、阶段、Vendor、Buyer、Claim版本和价格源版本。文件在暂存时锁定Change type，先Remove file才能换类型，避免用Resource文件按另一套规则解释。

### 4.2 读取真实Excel并校验

![上传校验](NEO-016_Validation.png)

候选模板均有Metadata和Parts两个sheet。Resource为Part Number、Plant、New Part Price、New Part Price Currency四列；普通改价另有Absolute Part Price Change。原价、原币种从本包合成主数据读取，不让上传者覆盖。

跨币种行：100.00000 GBP → 95.00000 EUR；差额／百分比均“—”。同币种Resource行：50.00000 GBP → 48.00000 GBP；显示-2.00000及-4.00000%。这不是汇率换算或整笔Claim影响计算。

### 4.3 具体确认，取消仍保留预览

![确认应用](NEO-016_Confirm.png)

确认显示本次2个parts、目标MCI-00057，并明确整份文件一起应用，不提交审批。Keep reviewing／Escape保留暂存。正式事务策略仍待业务确认。

### 4.4 应用结果

![已应用](NEO-016_Applied.png)

提案页内存中从Claim v7变为v8，显示2个parts；应用后禁用重复应用。刷新页面会重置。这只能证明设计内的操作结果，不是数据库保存、服务端回读或刷新持久化通过。

### 4.5 错误指向文件行和字段

![文件问题](NEO-016_Errors.png)

缺新价、缺币种、重复Part/Plant、无效组合、错误模板、公式、超精度等都列出行号、字段和问题。只要存在问题，整批没有可应用行；不悄悄跳过错误行。更正文件后重新上传。

### 4.6 普通改价保留校验

![普通改价模板](NEO-016_Standard.png)

普通改价95 GBP对原价100 GBP，delta需为-5。填+5会报错；0仍是有效的0。用普通模板换成EUR会要求使用Resource模板。本轮没有把所有Price Change校验全局关闭。

## 5. 审阅数据与操作

默认示例用户Grace Turner／CBSL，Buyer为Alice Morgan；Claim MCI-00057，POA，Supplier Negotiations，Saved v7，Source price v4。全部为独立合成上下文；不是对现网人员或记录的重新授权。

| 文件 | 核心输入 | 预期 |
|---|---|---|
| test-data/Resource_valid.xlsx | P2001/PL02，95 EUR；P2002/PL02，48 GBP | 两行校验通过；跨币种差额为空，同币种为-2和-4%。 |
| test-data/Standard_valid.xlsx | P2001，95 GBP，delta -5；P2002，50 GBP，delta0 | 普通改价一致；0保留。 |
| Resource_missing_price／missing_currency | 缺必要的新价或币种 | 无可应用行，指出缺失字段。 |
| Resource_duplicate／bad_plant | 重复键、P2001/PL99 | 拒绝，不能凭Part Number忽略Plant。 |
| Resource_formula／precision | 公式价格、6位小数 | 拒绝；不执行公式、不静默取整。 |
| Resource_legacy_delta／Standard_cross_currency | Resource多出delta；普通模板换币种 | 要求正确版本／用途模板。 |
| Standard_wrong_delta／Resource_empty | delta方向不一致、空表 | 拒绝并说明。 |
| Resource_large_text／large_numeric | 文本12345678901234.12345；大额数值单元格 | 文本精度保留，过大的数值单元格要求以文本存储，避免既有舍入无法恢复。 |

页面操作：Download template → Choose file选择Resource_valid.xlsx → 查看Validated parts → Apply 2 parts → Keep reviewing或Confirm apply。实际模板下载文件也在交付包根目录。

额外场景：Active approval阻止上传／应用；Source price changed时阻止旧预览，Refresh source后重新上传，读取v5原价101；Apply rejected时保留已验证数据且无成功消息，允许明确拒绝后的重试。未知提交结果不在本轮已实现范围，正式系统须按原操作ID回读，不能照此拒绝场景直接重发。

## 6. 字段、来源和下游

| 字段／能力 | Source / Reference | 结论 |
|---|---|---|
| Part Number、Plant、原价及币种 | BRD FR1.6；MCI_REF_PART / MCI_REF_PART_PRICE；字典Claim明细814–819行。[S3-8/S5] | 模板传业务代码，NEO服务校验授权的供应商／工厂／零件组合并解析外键；原价权威来源不由文件覆盖。 |
| New Part Price／Currency | 字典NEW_PART_PRICE第825行、NEW_PART_PRICE_CURRENCY第826行。[S5] | 本次Claim的新商业条件；不覆盖主数据Current Value Currency。 |
| Absolute／Price／Percent Difference | 字典824、827、828行，可空结构；FR1.6及当前跨币种处理。[S5/S7/S8] | 跨币种不可比时存／传null，不设0，不把两个币种直接相减。实际后端语义待契约确认。 |
| 同币种差额 | 当前fr1-prices与decimal工具。[S8/S15] | 设计沿用新价减原价的当前NEO展示习惯；与原BRD按Risk/Opp预填sign的差异不在本条重定规则，最终值须核对已确认价格方向。 |
| 模板用途及版本 | 本包NEO-016-CANDIDATE-1，Metadata | 新增候选协议，不是原数据库已有列、API规范或正式模板号。需模板owner签收。 |
| 并发与保存版本 | 当前Claim／价格上下文，本提案v7→v8 / v4→v5 | 服务端需再次校验记录状态、权限和源版本；当前内存结果不能替代接口并发控制。 |
| WIPS | FR1.6及FR13，接口登记仅供核查。[S3/S16] | Resource/Currency不自动进入普通WIPS价格模拟路径；上传成功不代表WIPS建单、审批或实施。 |
| 计算和FX | BRD分支及当前跨币种直接录入 | 本条不新增FX换算。后续Claim影响需要哪个币种、汇率及计算版本仍要独立核对；不可比差额不能流成0金额。 |

数据库decimal(19,5)并不意味着Excel数值单元格能完整表示所有19位。提案复用独立复制的现有十进制工具保留文本；候选解析对高额数值输入要求文本。正式服务端仍需统一价格类型、精度、符号及所有边界校验。

## 7. Change / Impact及开发准备

| 层 | 变更 | 影响和前置 |
|---|---|---|
| UX/UI | 用途化模板、条件字段、行级错误、两币种对照、确认和可恢复异常 | 保持当前After界面，不恢复Before样式或已停用产品入口。 |
| Application前端 | 按模板版本解析／校验；保留文件与暂存；确认后应用 | 本包2MB、1,000行是审阅容量限制，不是正式业务上限。真实批量需worker／后台处理及性能实测。 |
| Application后端 | 按交易Driver＋币种组合独立校验；主数据匹配；空差额；版本／锁／事务／幂等／审计 | 不信任只删必填的Excel，不允许绕过后端。字段类型和回执payload仍需确认。 |
| DB | 复用已有不同币种和可空差额列；检查正式schema与映射 | 不无依据新增表；允许空列不等于所有场景可空。 |
| BPM | 录入／上传本身不提交审批或实施 | 是否需另设CBSL复核，以及何时锁定Parts，按现行流程和业务确认。 |
| Integration | 优先复用主数据／价格服务；下游验证币种和null支持 | 本条不自动新建外部接口；现有不支持时再评估扩展，不能凭登记表声称已兼容。 |
| 回归 | 同币种普通改价、Resource同币种、跨币种、空值／0、锁／权限、错误／重试 | 明确源字段、预期、实际及保存回读。正式Auto-PAM／Reserve／WIPS结果不在本轮验证。 |

## 8. 业务确认问题（人话＋例子）

| ID | 问题 | 举例与建议 |
|---|---|---|
| Q01 | 谁可以上传和应用：Buyer、CBSL还是两者？ | 新诉求以Buyer描述，Training正文却写CBSL only。建议先确定权限和是否需CBSL复核，不能只给前端放开按钮。 |
| Q02 | Resource／Currency由哪个字段认定？ | 同样95 EUR，是普通价格修改还是Resource？建议使用Claim中已确认的Driver代码，而非让文件名决定。 |
| Q03 | 拆成哪些正式模板？ | 本次只示范Resource和普通改价；CR15还包含AMM。请给现有文件、版本及完整用途清单。 |
| Q04 | 是否允许同一Resource文件混合同币种和跨币种行？ | 第一行GBP→EUR，第二行GBP→GBP。本方案支持，仍按每行判断差额是否可比，请确认。 |
| Q05 | 旧模板里用户已经填了跨币种Price Change怎么办？ | 要忽略并给警告，还是拒绝要求换新模板？建议明确迁移期，不静默接受一个可能影响后续金额的值。 |
| Q06 | 出错时整批不应用还是只应用正确行？ | 100行中1行币种没填，本提案整批阻止。若要部分成功，需逐行回执和防重规则。 |
| Q07 | 当前价格的权威版本是什么？ | 文件审阅时原价100，应用时变成101。建议重新验证并显示差异；是否允许有理由覆盖原价需另按已批准规则。 |
| Q08 | 新币种后续怎么计算、怎么实施？ | GBP换EUR，Reserve、审批金额和下游应使用哪个币种／汇率版本？本条不自动FX；请确认既有契约是否支持。 |
| Q09 | 正式文件容量及数值精度怎么定？ | 实际可能几万行、高精度价格或大额文本。请提供最大规模、允许格式、模板小数位及服务端处理目标，本次限额仅用于审阅。 |
| Q10 | 本批量需求如何与已停用入口衔接？ | 当前产品不再提供Parts Excel导入。请确认是新受控入口、后台CBSL操作还是别的上传通道，再决定正式接入；本轮保持独立。 |

## 9. 本地验证及退出条件

67 项浏览器交互／布局检查、12 项实际下载模板回读检查通过。记录见PAGE_VISUAL_CHECK.json及TEMPLATE_READBACK.json；预期与实际逐项保留。

已执行：真实Resource／普通模板下载、真实XLSX读取；跨币种不减价／不做FX；同币种差额／百分比、0；缺价格／币种、重复Part/Plant、错误Plant、公式、6位小数、错误列／用途、空文件；大额文本精确保留；确认取消、应用及防重复；已进入审批的锁；Buyer待确认无入口；源价变化刷新重验；明确拒绝后重试；六宽度、手机确认／Escape、CSS200%布局及无外部HTTP／运行错误。

未执行：原产品已停用路由、真实服务端权限、真实数据库保存／刷新回读、事务原子性／并发／未知结果、真实接口、生产文件安全与压缩攻击测试、Excel原生打开、大规模性能、后续GBP影响／Reserve／Auto-PAM／WIPS结果和业务验收。不得把提案内存Apply成功写成整条ACT-026或产品功能PASS。

本轮退出条件：原文／源定位可追踪；独立页面可操作；六张截图＋移动图；候选模板实际可下载且结构可回读；源代码／测试／限制齐全；ZIP内容和哈希核验。

正式开发退出条件：权限、入口、正式模板和适用范围确认；完成前后端／DB／流程变量映射；后端对全部输入独立校验；已保存数据可回读；测试新币种／空差额在后续计算与实施中正确；完成真实规模、权限、版本冲突及防重验收。未收到的材料和未执行项保持Pending／NOT RUN。

下一项按原表继续NEO-017。

## 10. Source / Reference

| Source | 文件与定位 |
|---|---|
| S1/S2 | NEO Business Requirements (added China requirements) 1.xlsx：RTM for Requested Changes第17行，P1 CR clean第37行CR32。 |
| S2-CR15 | 同工作簿P1 CR clean第23行CR15；关联AMM批量能力。 |
| S1-ID-A/B | RTM - Archive第19行、NEO RTM第20行；只用于排除同ID异义。 |
| S3-8/38 | Material Cost & Inventory - BRD V3.1.docx，Table6行8／38，FR1.6／FR13。 |
| S4 | NEO User Training.docx，正文518–550及包含Bulk Upload Parts的角色矩阵原表行；1-based精确位置在证据JSON。 |
| S5 | NEO_数据字典.xlsx，字段字典，MCI_REF_PART、MCI_REF_PART_PRICE、MCI_RISK_OPPORTUNITY_PART，原行号保留。 |
| S6 | story_data.json，ACT-026 / CNP-231及已记录权限问题。 |
| S7/S8 | 当前PartPrices.tsx、domain/p03/fr1-prices.ts，跨币种直接价格和差额约束；代码行号保留。 |
| S9/S10 | domain/p03/import/schema.ts、xlsx.worker.ts，旧固定列／单Currency契约和worker，不是产品入口启用证据。 |
| S11/S12 | src/theme/index.ts；143页面scope.json的P2.6及历史P7.5.1。 |
| S13/S14 | 唯一QA模型NQA-104/133；NEO_UXUI_PRINCIPLES.md §1.2，不恢复Parts Excel导入。 |
| S15 | domain/p03/decimal.ts，未修改复制到独立design-source，十进制文本运算。 |
| S16 | Integrations - 2026-11-09_0941(Sheet 1).csv，接口登记全表；未据此推定跨币种上传payload已确认。 |

各来源的完整绝对路径、原文／代码行、SHA在SOURCE_EVIDENCE.json；主题及依赖版本在design-source/SOURCE_MANIFEST.json。
