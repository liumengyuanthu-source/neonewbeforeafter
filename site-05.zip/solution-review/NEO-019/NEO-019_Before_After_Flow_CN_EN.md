# NEO-019 · Before / After process

Priority: Must (Procurement: Must; Finance: —)

ACT-026 · FR1.6 / FR19

## 上传模板提供有效工厂下拉

模板帮助用户选对工厂，上传时仍按当前参考数据复核，不把 Excel 下拉当作最终校验。

### Before · 现有路径

1. **当前原型用户 · 使用当前选零件页** — 当前产品通用上传入口已退役；Before 展示真实的选零件页，不伪造旧上传页。
2. **Training／需求记录 · 人工录入工厂可能出错** — Training 有 Bulk Upload Parts；新需求要求 Plant Code 可从下拉选择，减少无效输入。

### After · 建议路径

1. **有权上传用户 · 下载带版本的模板** — 模板含当前可用 Plant code＋name 及参考版本；按确认的供应商／公司范围生成。
2. **上传用户 · 选择工厂并上传** — 从下拉选择准确标签；粘贴的数据同样需校验，不能绕过有效组合检查。
3. **校验服务／用户 · 逐行核对 code 与组合** — 按当前版本解析规范 code；拼写错误、停用工厂或无效 Part／Vendor／Plant 明确到行。
4. **上传用户 · 复核并确认应用** — 参考数据变化后重新校验；取消保留候选。确认只应用 Claim 明细，不创建 WIPS 单或提交审批。

### 例子

示例：选择“PL-HAL · Halewood Assembly”解析为规范 PL-HAL。手填“Halewod”时定位该行错误，不做模糊匹配；PL-HAL 是本设计的示例代码。

### 保留控制

- 候选方案一行错误则整份暂不应用；这不是已批准的生产批处理规则。
- 保留原手工选择零件功能；新增模板与入口需独立实施。

### 正式实施前补齐

- 提供正式 Plant 清单、有效组合和更新机制；确认恢复上传的入口及 Buyer／CBSL 权限。

## Provide valid plant dropdowns in upload templates

Help users select the right plant in the template, then validate against current reference data at upload; Excel validation is not the final control.

### Before · Existing path

1. **Current prototype user · Use current part selection** — The generic upload entry is retired; Before shows the real part-selection page rather than a fabricated legacy upload screen.
2. **Training / Requirement · Manual plant entry can be incorrect** — Training includes Bulk Upload Parts; the request adds a plant-code dropdown to reduce invalid entries.

### After · Proposed path

1. **Authorised uploader · Download a versioned template** — Include valid plant codes and names with a reference version, scoped by the agreed supplier / company rules.
2. **Uploader · Select a plant and upload** — Select the exact label; pasted values require the same checks and cannot bypass valid-combination rules.
3. **Validation service / User · Validate codes and combinations per row** — Resolve the canonical code against the current version; identify misspellings, inactive plants and invalid Part / Vendor / Plant combinations by row.
4. **Uploader · Review and confirm application** — Revalidate after reference changes; cancellation preserves the candidate. Confirmation applies Claim details without creating WIPS claims or submitting approval.

### Example

Example: selecting “PL-HAL · Halewood Assembly” resolves to canonical PL-HAL. “Halewod” produces a row error rather than fuzzy matching. PL-HAL is a design fixture code.

### Controls retained

- The candidate holds the entire file if any row is invalid; this is not a signed production batch policy.
- Keep existing manual part selection; the new template and entry require separate implementation.

### Production dependencies

- Supply the production plant list, valid combinations and update mechanism; confirm the restored upload entry and Buyer / CBSL permissions.

## Sources

- **R-1113** NEO Business Requirements (added China requirements) 2(RTM for Requested Changes)_1113 1400 version.xlsx · NEO Business Requirements (adde!E20,N20,P20,Q20; priorities K20:L20
- **S1** NEO Business Requirements (added China requirements) 1.xlsx · RTM for Requested Changes row 20 (1-based)
- **S2-8** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 8 (1-based)
- **S2-52** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 52 (1-based)
- **S3** NEO User Training.docx · Body paragraphs 518–550 (1-based)
- **S3-R** NEO User Training.docx · Tables with Bulk Upload Parts role rows
- **S6** SelectParts.tsx · Numbered source lines (1-based)
- **S7** selection.ts · Numbered source lines (1-based)

Before: frozen prototype `3ff8bc0b158ba08f2302e7404bb6185a553088c78614051451e6b5137a26802e`. Historical problems are labelled separately. After is a proposal; numerical examples are illustrative. Production execution: NOT RUN.
