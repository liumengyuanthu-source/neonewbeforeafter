# NEO-019 · Bulk Upload的工厂下拉和校验

<!-- FLOW-REVIEW-20261116 -->
## 16 Nov 2026 · 流程评审补充

[中英文 Before / After 流程](NEO-019_Before_After_Flow.html) · [流程说明 MD](NEO-019_Before_After_Flow_CN_EN.md)

模板帮助用户选对工厂，上传时仍按当前参考数据复核，不把 Excel 下拉当作最终校验。

本轮为流程说明补充；原交互页面、问题及历史证据保留。正式实施前需补齐：提供正式 Plant 清单、有效组合和更新机制；确认恢复上传的入口及 Buyer／CBSL 权限。
<!-- /FLOW-REVIEW-20261116 -->

本包是独立页面及Excel候选模板，未修改现有NEO prototype、共享QA、接口、数据库或线上系统。页面英文，分析中文。工厂、人员、零件、价格及版本均为合成审阅数据。现有产品已停用的导入入口仍然停用。

## 1. 原需求与来源

用户在Excel里手输Plant时，容易拼错或用到与NEO不一致的描述，上传后识别不了。要求在Excel模板加入下拉和校验，使用NEO中的准确工厂描述。[S1]

| 项目 | 原始证据及解释 |
|---|---|
| 主需求 | 新需求工作簿，RTM for Requested Changes，第20行NEO-019；CR-2026-1557 \| 1。Procurement Must；Finance优先级为空，不替业务补填。[S1] |
| 原始痛点 | “Incorrect plant codes /typos don't get recognised”；目标为“plant codes can be selected from a drop down”。[S1] |
| 原BRD | Table 6第8行FR1.6要求Plant下拉使用reference data，包含plant code、GSDB、Name；第52行FR19列有Plant／Plant Name。不能只靠手写名称猜工厂。[S2-8/52] |
| 当前After交互参考 | SelectParts.tsx第21行：value使用plantCode，label为plantCode + “ · ” + plantName；本包沿用这一显示方式。原BRD还提GSDB，上传按Claim Vendor范围校验，不把GSDB文字拼进Plant code。[S6] |
| 同ID异义 | RTM - Archive第22行的NEO-019是FR8 Finance计算；NEO RTM第23行的NEO-019是附件字段。均不属于本条Plant模板改进。[S1-ID-A/B] |
| 未收到 | CR独立详情／签收的模板合同、现行生产Plant清单及适用组合、认可的Excel版本和最终上传角色。工作簿的文字不是这些文件的替代品。 |

## 2. Solution、分类与Priority

让用户从准确的工厂列表选择，不再自己打字；上传时再用当前可信参考数据检查一遍。Excel下拉帮助减少错误，后端校验负责拦住错误，不能因为Excel里选得到就认定业务上能用。

| 项目 | 结论 |
|---|---|
| 主要改动类型 | Application内部前后端修改为主，包含Excel模板生成、上传解析／校验、前端预览和错误定位；不是UXUI only。 |
| Integration needed | 若NEO已有完整Plant reference和Vendor／Company／Part／Plant关系，复用即可；本条本身没有要求新增外部系统。若现有接口不提供完整工厂码、状态或组合，才需要扩展原主数据供给；实际provider、endpoint、payload未确认。 |
| 新增架构 | 目前没有证据需要新平台。需要把“显示标签、NEO主键、SAP／WIPS等系统码”映射清楚，不能把标签当外部系统ID。 |
| Priority | 原表Procurement Must；建议P1，随Bulk Upload恢复／交付前完成。现有导入未启用时，本提案不是恢复入口的批准。 |
| Epic | 关联现有CNP-231，Claims and data；不虚构新增Epic编号或写入Jira。[S5] |
| ACT／User Story | 主ACT-026 Bulk Upload Parts；Create／Update Claim仅为上下文，不另外扩成新的正式ACT。[S5] |
| FR | 主FR1.6，参考数据关联FR19；FR13为后续实施关联，不因模板选Plant立即调用WIPS。[S2/S5] |
| 页面 | 现有目录P2.6 Parts Data — create POA。候选子交互为Bulk Upload／Plant下拉预览／验证／确认；没有新分配正式三级Page编号。[S12] |
| UC | 本包D019-UC01–08是临时设计场景，待与正式UC目录合并，不冒充已批准UC编号。 |

## 3. Before、After与数据含义

| 对象 | Before证据／当前边界 | 候选After |
|---|---|---|
| Excel Plant输入 | 原需求说明存在typos；未收到现行真实模板，不能声称逐单元格复刻过。 | 下载的候选.xlsx在B2:B1001使用NEO_Plant_Labels命名区域；原生list validation、Stop错误提示。 |
| Plant显示 | 原BRD要求reference data；当前After页面已使用“代码 · 名称”。 | 下拉采用同一格式；预览同时显示原输入、resolved code、Plant name。 |
| 上传校验 | 当前产品导入已退役，不能把旧parser存在当功能可用。 | 以当前可信catalogue及适用组合校验，不信任工作簿自带的名单，也不模糊匹配／自动纠错。 |
| 保存／实施 | 选Plant不等于批准或外部实施。 | 上传→预览→显式确认；本包只演示内存v7→v8，没有数据库保存或WIPS调用。 |

| 字段 | 字典／代码 | 设计约束 |
|---|---|---|
| NEO Plant身份 | MCI_REF_PLANT.PLANT_ID，第361行；Claim明细PLANT_ID，第817行。[S4] | 显示的PL-HAL等fixture code不是数据库整数主键。正式由解析服务映射PLANT_ID，不直接把标签存进去。 |
| 名称 | MCI_REF_PLANT.NAME，第362行。[S4] | 名称相同不等于同一个Plant；本包PL-OLD与PL-SOL同名，但前者停用，不能替换。 |
| 各系统工厂码 | SAP_POA_PLANT_CODE、SAP_LUMP_SUM_PLANT_CODE、WIPS_PLANT_CODE、WERS_PLANT_CODE、MPL_CODE，第363–367行。[S4] | 不能未经确认选一个字段当通用上传码；实施时按实际系统和交易类型取对应码。 |
| 状态及S4 | IS_S4_APPLIED第368行；IS_ACTIVE第374行。[S4] | 不把S4标志当Plant身份。本包只模拟active筛选，真实配置和生效日期待确认。 |
| Part／Plant组合 | 当前occurrence身份包含Vendor、Company、Plant、Part及sourceVersion。[S7] | 合法工厂也可能不适用于这条Part／Supplier／Company，必须再校验组合。 |

## 4. 页面与交互

### 4.1 下载模板，看当前可用工厂

![模板与当前工厂](NEO-019_Template.png)

Grace Turner／CBSL打开MCI-00057，Supplier Negotiations，POA。提供下载、下拉预览和Choose file。没有文件时Apply禁用。当前展示两条有效Plant；停用项不出现在可选列表。

### 4.2 选择准确的代码和名称

![工厂下拉预览](NEO-019_Dropdown.png)

浏览器弹窗是候选下拉内容预览，不伪称Microsoft Excel截图。真正下载的文件也有原生数据验证；命名区域存放在Plant reference页，不靠逗号拼成长字符串。用户可以键盘选择，值解析为规范Plant code。

### 4.3 验证后明确显示解析结果

![验证结果](NEO-019_Validated.png)

原输入PL-HAL · Halewood Assembly解析到PL-HAL，而不是按文字近似猜测。显示文件行、Part、原Plant标签、解析后的code、name、价格、币种和实际校验reference version。

### 4.4 错误说明具体哪一行

![错误定位](NEO-019_Errors.png)

Halewod拼错、仅填PL-SOL等都指出行号与问题。任意行错误时，本候选方案整份文件不应用，避免用户以为全部成功。批量部分成功是否允许，列为业务确认，不擅自确立规则。

### 4.5 数据变化后重新检查

![版本变化](NEO-019_Stale.png)

验证后reference version发生变化，确认被拒绝；先刷新，再显式Validate file again。本包v5的两条可用标签与v4相同，以演示旧文件经当前数据重新检查后可继续；不意味着所有旧模板或改名工厂都可继续。候选下载固定为本包v4，生产动态生成最新参考清单未实现。

### 4.6 显式确认后应用

![确认后结果](NEO-019_Applied.png)

取消保持候选，不改Claim；确认后内存中应用两行、显示v8，重复Apply禁用。没有提交审批、创建WIPS Claim或改变财务状态。拒绝演示会保留候选供重试；真实请求结果未知时必须先回读，不能盲目重放。

## 5. 可操作数据与场景

| 数据／角色 | 本包值及边界 |
|---|---|
| 主角色 | Grace Turner／CBSL，合成人员；Buyer Alice Morgan放在独立限制场景，权限待确认，不冒充真实授权。 |
| Claim | MCI-00057，Vendor V002 Demo Motion UK，Company GB01，POA，Supplier Negotiations，v7。 |
| 合法行1 | P2001；PL-HAL · Halewood Assembly；95；GBP。 |
| 合法行2 | P2002；PL-SOL · Solihull Assembly；45；GBP。 |
| 候选数据来源 | 两个Plant显示名称沿用当前demo-data.ts的fixture；Part与组合、价格和版本是本包合成安排，不是SAP实际主数据。[S8] |
| 模板文件 | NEO-019_Plant_Template_Candidate.xlsx；Parts + Plant reference两页；B2:B1001 list validation／Stop。Pale yellow标输入区，数据表主键按text保留。 |
| 限制 | .xlsx、2MB、1,000行、价格最多5位小数、GBP／EUR仅为本包测试合同；非原BRD已签收的全量文件和币种限制。 |

| 临时场景 | 谁／怎么操作 | 预期 |
|---|---|---|
| D019-UC01 | CBSL下载模板；Excel选Plant；上传两条合法行 | 解析到两个不同Plant，预览后才能确认。 |
| D019-UC02 | 粘贴错名、仅code、大小写／空格差异或篡改模板参考页 | 不信任文件名单，不自动修正；指出错误，不部分应用。 |
| D019-UC03 | 有效Plant配了错误Part、已停用Plant或重复组合 | 按具体字段／行阻止，不因在全局工厂名单里就放行。 |
| D019-UC04 | 验证后参考版本变；刷新并重验证 | 旧验证不能直接用；当前名单及组合再检查后才可确认。 |
| D019-UC05 | 参考数据不可用；点击Retry Plant reference | 下载／上传先禁用，恢复后可操作；不发空白工厂名单当正常结果。 |
| D019-UC06 | Cancel／Confirm；确认后再次点击 | 取消不应用；首次确认v8；后续Apply禁用。 |
| D019-UC07 | Active approval／Buyer access pending | 受状态和角色限制，不能更新。原生服务端权限仍待开发。 |
| D019-UC08 | 错模板、公式、链接、隐藏sheet、合并、超限及应用被拒绝 | 明确错误；候选数据保留／重新上传，未出现虚假成功。 |

## 6. 开发工作拆分与影响

| 层 | 交付／需要验证什么 |
|---|---|
| UX／前端 | 保持当前NEO theme与Ant Design间距；展示文件行、原Plant输入与解析结果；加载、无数据、失败、重新验证、取消、重复提交和窄屏。正式页面不得夹入设计解释或业务Pending小图标。 |
| 模板服务 | 从同一可信Plant catalogue生成.xlsx和命名区域，含模板ID／参考版本。完整名单、超过Excel下拉字数的处理、版本和维护负责人需确认。本包静态候选不等于生产生成服务。 |
| 上传／应用服务 | 按当前Vendor／Company及Part范围解析到Plant身份；检查active、组合、版本、权限、状态和重复；服务端原子应用并回读。不能相信浏览器验证或工作簿reference页；幂等和未知结果查重另实现。 |
| 数据库 | 优先复用现有MCI_REF_PLANT及Claim Part关联；确认具体code字段／crosswalk，不因新增一个下拉就凭空新增实体。 |
| 平台／流程 | 继续既有Supplier Negotiations权限／状态门槛；选工厂不启动审批或下游流程。若实际阶段允许范围不同，由业务确认后调整。 |
| Integration | 先确认现有catalogue是否完整；有缺字段再明确实际provider、现有接口扩展或新合同。当前未取得可证明完整Plant payload的接口契约，不编造URL／字段名。 |
| 回归 | NEO-016交易类型模板、017/018工厂与S4主数据、每Plant价格及后续实施路由；不得重新引入退役入口或覆盖其他开发分枝。 |

NEO-020的Part前导零、NEO-021的S4专门行为及全量价格／WIPS计算不是本次新增范围。本包保留文本身份，不声称已完成这两条需求。

## 7. Test cases与实际结果

实际浏览器检查记录在PAGE_VISUAL_CHECK.json；每条含expected／actual／status；本地共102项浏览器检查及13项Excel OOXML结构检查通过。不是业务或线上通过。

| 组 | 实际结果与边界 |
|---|---|
| 模板结构 | 原生list验证、Stop、命名区域、正确1,000行范围、不允许空值的默认值、下拉未隐藏、无宏／外链／公式、两sheet已回读。文件渲染两sheet已人工查看。 |
| 下载／浏览器 | 下载字节与模板SHA一致；下拉标签与规范code对应；键盘选择、显式取消／应用、重复操作限制已检查。浏览器下拉不等于Excel原生操作实测。 |
| 文件／业务组合 | 拼写、code-only、空值、停用、大小写空格、数字code、错误组合、未知Part、duplicate、篡改名单、字段格式、额外列／错误sheet、公式／链接／隐藏／合并／损坏／超限均做拒绝验证。 |
| 恢复 | 新版本要求刷新重验证；reference失败恢复；明确拒绝后重试；无成功回执的真实未知结果未模拟为“可盲目重试”。 |
| UXUI | 1920／1440／1024／768／390／360宽度、页面边距、横向表格、移动确认操作、CSS200%及无外部请求／运行错误。CSS缩放不是原生浏览器zoom。 |
| 规模观察 | 1,000行duplicate-heavy合成文件已验证并分页；计时在原始测试JSON。不是生产容量、真实并发或服务端性能基线。 |
| NOT RUN | Microsoft Excel原生打开／选择／粘贴／保存／关闭兼容性；真实SAP／WIPS主数据及接口；正式角色／权限／状态；后端持久化及回读、幂等、恶意压缩包安全／大文件／并发；生产模板生成；正式价格／金额计算；部署及业务UAT。 |

## 8. 退出条件与后续

本轮退出：独立英文交互页面、原生候选.xlsx、六张主要页面图、来源摘录／SHA、中文分析和问题清单、测试实际记录及可编辑ZIP齐备。只声明本地提案检查完成。

正式开发前：确认上传是否恢复／放在哪个入口、角色、Plant code字段、实际名单／组合、旧模板政策和部分失败处理；确定模板与服务端同一参考数据版本。真实服务与Excel兼容性完成后，再进行同Claim端到端应用及下游路由回归。

下一条NEO-020：Part Number前导零／文本格式。本轮不继续处理，等待下一次逐项推进。

## 9. 讲人话的问题清单

| 编号 | 要确认什么／例子 | 建议及影响 |
|---|---|---|
| Q019-01 | Excel到底选哪种工厂码？字典同时有SAP POA、SAP LSP、WIPS等字段。例如同一Solihull在不同系统的code不一样。 | 用NEO规范身份＋显示名，服务端按业务路线映射外部code；先由主数据／采购确认。缺这个无法落地字段映射。 |
| Q019-02 | 当前页面是“代码 · 名称”，是否就是最终Excel格式？BRD还写了GSDB。 | 沿用当前After显示，Vendor／GSDB在Claim范围检查；若必须显示GSDB，需重新确认唯一性和名单长度。 |
| Q019-03 | 工厂改名后，旧模板里仍是老名称还能不能用？ | 推荐当前参考数据重校验，不能凭旧名单直接放行。是否保留旧标签兼容别名必须明确，不能模糊猜。 |
| Q019-04 | 名单要显示全部工厂还是只显示这家Vendor／Company／Part适用工厂？例如P2001只能去Halewood。 | 上传必须检查组合；模板至少按Vendor／Company过滤。是否按每行Part联动下拉，需真实数据和Excel版本验证。 |
| Q019-05 | 已停用工厂能否用于历史修正？ | 新增默认不允许；历史更正若例外应单独规定，不能借模板恢复已停用工厂。 |
| Q019-06 | 一千行里只有一行工厂错，是整份退回还是部分成功？ | 候选整份不应用并列错行，最易核对。若要部分成功，需回执、幂等和重传规则。 |
| Q019-07 | 当前完整工厂名单由谁维护，从哪个现有接口来，包含哪些码和active／生效日期？ | 请原系统／主数据团队提供清单、payload和owner；不能拿本包两个fixture当正式主数据。 |
| Q019-08 | Buyer能上传还是仅CBSL？Training角色矩阵和正文不同。 | 先不开放未确认角色；本包演示CBSL。角色必须服务端实施，不能靠藏按钮。[S3/S5] |
| Q019-09 | 已退役的入口是否计划恢复？还是只在新Parts页面提供？ | 先确认发布范围和依赖，NEO-019不能单独推翻入口退役决定。[S11] |
| Q019-10 | 用户用哪些Excel版本？是否允许粘贴整列、Mac Excel、web Excel？ | 至少用实际目标版本测下拉、粘贴绕过、保存再上传。2MB／1,000行也要正式确认，本包只是候选限制。 |

## 10. 交付及reference定位

- NEO-019_Page_Proposal.html：独立英文页面，React／Ant Design及字体已打包，无外网依赖。
- NEO-019_Plant_Template_Candidate.xlsx：一个候选模板，不是生产认可文件；源builder在design-source/create-template.mjs。
- NEO-019_Consolidated_CN.html／本MD：来源、方案、六图、影响、问题和验收边界。
- OPEN_QUESTIONS_CN.md：上述10项可直接向业务确认的问题。
- SOURCE_EVIDENCE.json：16条实际来源，原文／locator／原文件SHA。不同sheet的NEO-019不混用。
- PAGE_VISUAL_CHECK.json、WORKBOOK_NATIVE_STRUCTURE_CHECK.json、WORKBOOK_AUTHORING.json、VALIDATION.json：实际检查、Excel结构／渲染及交付完整性。
- design-source：TSX、NEO主题、样式、字体、build、template bytes、fixture生成器／文件、verify脚本、README、依赖及manifest。未在另一台电脑重建验证。

来源路径保留在JSON；没有收到的原始工厂名单、接口payload、native Excel兼容性或业务规则不会被标成已确认或已通过。
