# NEO-021 · 同一POA支持S4与WIPS工厂及正确任务分流

独立英文页面，沿用NEO theme和Ant Design；分析中文。未修改现有prototype、共享QA、实际BPM、数据库或线上系统。Part、工厂代码、BP、价格、任务、版本和人员均为本包合成审阅数据。创建／完成任务只发生在当前页面内存，不是实际SAP、WIPS或Flowable执行。

## 1. 原需求与证据

同一Part可能同时在WIPS工厂和S4工厂使用。新工厂只在S4运行时，不能为了让POA继续就借用WIPS工厂码或编造WIPS Claim。用户应在同一Claim里处理这些Part／Plant组合，批准后分别把正确的工厂及供应商身份交到正确系统／任务。[S1]

| 来源 | 结论／证据边界 |
|---|---|
| RTM for Requested Changes第22行NEO-021 | CR-2026-1557 \| 3，Procurement Must、Finance Must。原分类为Existing functionality - Update UX / Workflow，Exists标No。原文提Halewood、Halewood KD、Nitra KD及BP–GSDB映射。[S1] |
| 原需求目标 | 同一Claim可有S4和legacy工厂Part；批准后产生正确系统的tasks/actions；S4 supplier code与legacy GSDB并列，更新源系统使用正确身份。[S1] |
| BRD Table6第38行FR13 | 原路径以已批准的POA及预先建立的WIPS Claim为基础，需要WIPS Buyer和Manager的实际批准确认。标题包含S4 in Future，不能据此宣称S4-only完整接口已定义。[S2-38] |
| Training P1644／1646／1650 | CBSL管理；POA到Data Posted Manually／Automatically - Awaiting Approval、有S4 parts时触发S4任务；任务只显示S4相关Part。[S3] |
| Training P1656 | 可以为每条Part添加ATP Reference。没有在该文字中声明ATP必须填写，本包不凭空把它设为必填。[S3] |
| Training P1705–1709 | WIPS审批RPA失败的PM任务，需要没有S4 parts或CBSL S4任务已完成等前置。现有本地PM代码也使用s4Ready门槛；这不是所有生产分支均已验证的证据。[S3/S8] |
| 同ID异义 | Archive第24行NEO-021是FR9 Request for Mandate；NEO RTM第25行是CO₂字段，与本条新需求不同。[S1-ID-A/B] |

## 2. 与NEO-017／018怎么衔接

| 条目 | 负责哪段 | 本轮不重复算什么 |
|---|---|---|
| NEO-017 | 从有效源数据识别完整Part／Supplier／Plant范围及S4属性，避免漏工厂。 | 不再声称本轮新增了一套自动识别／订单源接口。 |
| NEO-018 | S4 Supplier／Part Price／Vehicle Line／GR等源数据接入，BP与GSDB身份输入。 | 四份FS未收到的Gap继续保留；本轮页面不算这些接口通过。 |
| NEO-021 | 用已确认范围和映射，支持混合工厂及S4-only的POA实施任务，保留各系统身份和结果。 | 不是再做一个S4入口，也不是把现有CBSL任务全算成新开发。 |

017／018的准确原文在同一工作簿第18／19行。[S1-017/018] 同一依赖应只安排一次，并让021消费它的版本化结果。

## 3. Solution、分类、Priority与关联

建议保持一份商业Claim／批准范围，按Part＋Plant＋组织分流实施。S4行保留BP及正确S4工厂码，WIPS行保留GSDB和WIPS工厂码。路由数据不完整时明确阻断，不按工厂名字硬编码，不用GSDB直接冒充BP。

| 项目 | 评估 |
|---|---|
| 主要改动类型 | Application前后端＋BPM流程／任务路由为主，依赖主数据／身份映射及接口回执；不是UXUI only。 |
| 与谁integration | 消费NEO-018的S4／SAP主数据和BP输入；关联现有WIPS／RPA建单与审批结果；CBSL／S4团队确认手工实施及实际回执。 |
| 能否复用 | 复用现有CBSL S4任务、WIPS任务、权限／审计及SAP主数据供给形状。现有登记不能证明S4 BP或S4-only事件已支持；需真实payload确认。[S6–S8/S13] |
| 是否新增架构 | 暂不建议新平台。需补应用层统一实施handoff、分系统路由／状态及BP crosswalk。若仍由CBSL在S4手工变价，本条没有自动授权新增直接S4写API；自动写回属于另行确认的实施范围。 |
| Priority | 原表采购／财务均Must；建议P0，避免S4-only工厂不能做POA或更新到错误系统。实际排期依赖018和配置就绪。 |
| Epic | 输入关联CNP-231；实施主关联CNP-234。没有新增虚构Jira编号。[S5] |
| ACT／User Story | 主ACT-062 CBSL S4 Hana Task；ACT-001／004输入；ACT-023／027 WIPS建单和ACT-063 WIPS RPA失败任务为关联回归。Training自己的S/N与ACT编号不同，不混用。[S5] |
| FR | 直接FR1.6、FR13；关联FR19.13 reference、FR9.4授权、FR14手工任务、状态／审计。新BP映射和S4-only触发不能说成旧BRD已完整定义。[S2] |
| 页面 | P2.6 Parts Data；P15.11 CBSL S4 HANA Task。新增候选是实施路由／身份检查视图，不擅自分配正式Page ID。[S12] |
| UC | D021-UC01–08是本轮设计场景，待映射正式UC；不是已签收的新编号。 |

## 4. 当前已有能力与真正Gap

当前S4代码已具备CBSL task、S4筛选、ATP、Enquiry／Reply、完成与审计；不能说现有产品完全没有S4任务。NQA-120／121记录的通过只限其各自旧版本本地模拟，不是021新范围验收。[S6/S7/S11]

| 发现 | 修改／保留方式 |
|---|---|
| S4识别来自rowMetadata.s4Hana===true | 这是offline adapter marker，正式Plant旗标和映射仍未确认。用受控Plant来源／路由版本替代人工marker，未知不能默认为No。[S6/S9/S11] |
| S4任务从已有posting集合派生 | 原路径以posted状态为前置；不能证明S4-only工厂已有不依赖WIPS的有效handoff。应统一实施交接模型，而不是为无WIPS工厂编造编号。 |
| 字典已有IS_S4_APPLIED及多套Plant代码 | MCI_REF_PLANT第361–374行含SAP_POA、SAP_LUMP_SUM、WIPS、WERS等；这些不是一个可互换的code。[S4] |
| BP–GSDB映射未收到 | 本轮按BUSINESS_PARTNER／BP_CODE／BP_ID等字段名检索，未找到可确认的专用crosswalk定义；不等于其他系统绝对没有。需要实际映射表、owner、粒度及生效规则。[S4] |
| 混合Plant不能按Part Number去重 | P3001在3个工厂有3组身份／价格；跨系统可以相同Part，不代表同一次实施操作。 |
| 任务完成不等于整体Implemented | S4任务结束、WIPS批准、源系统成功、财务Implemented分别取证。不能仅凭ATP／按钮点击，把剩余路径都标成功。 |

## 5. 页面与交互

### 5.1 同一Part，三个工厂分别保留

![同一Claim的工厂与身份](NEO-021_Overview.png)

同一P3001同时用于Halewood KD／Nitra KD／Solihull。前两行走S4，第三行走WIPS；GSDB与BP分列，并可查看当前组织／Plant码／mapping version。Supplier Negotiations期间不创建实施任务。

### 5.2 混合工厂进入各自路线

![混合实施路由](NEO-021_Routes.png)

在合成posted-awaiting-approval场景中，一条S4任务覆盖本Line的两个S4组合，WIPS行保留独立审批阶段。重复Refresh只读取同一任务，不制造重复任务。本轮采用“一Line／handoff一个S4 task”的粒度是提案，跨公司／团队是否拆任务仍待确认。

### 5.3 BP缺失或不唯一时不猜

![BP映射缺口](NEO-021_Mapping.png)

保留源BP 0000567800，显示Unmapped或Ambiguous；不能只按名字／Claim Vendor选第一个映射。候选按整条Line阻断实施，部分行是否可先处理列为业务问题。未知路由单独显示Blocked，不能被当成无S4任务。

### 5.4 CBSL只处理S4范围

![CBSL任务范围](NEO-021_Task.png)

任务表保留Part／Plant身份、下游Plant code、NEO GSDB、S4 BP、GBP价格和ATP；横向滚动仍能看到身份列。排除Solihull WIPS行。ATP可以填写，未凭空设为必填；Submit→No／Escape不完成，Yes才在本页内存完成。

这是P15.11的新增路由／身份范围提案，不是替换整个任务页：原有Attachments、价格细项、Raise Enquiry／Buyer Reply及权限必须保留。本包未重复实现或复验这些完整既有交互。

### 5.5 S4-only不用伪造WIPS Claim

![只有S4的工厂](NEO-021_S4Only.png)

Nitra KD单独成为S4路线，WIPS Claim Number显示Not applicable，无WIPS审批步骤。场景里的S4-READY-021-01是候选统一handoff事件，**不是现网已确认事件或状态枚举**。建议在必要授权／检查完成、批准范围冻结后发出；确切发出节点和producer需业务／流程团队签收，不能简单把Mandate approved当作实施触发。

Training已有混合路径的posted触发继续保留；新的S4-only路径需要明确接入这个实施边界，避免等一个永远不会产生的WIPS结果。

### 5.6 任务完成后仍等真实实施结果

![任务完成与剩余路径](NEO-021_Completed.png)

记录Grace Turner及实际本地完成时间，禁止重复Submit。混合路径的WIPS阶段变为候选Ready for WIPS approval，但本包不会执行它。整体Implementation result仍待确认，绝不自动把Claim／Finance设为Implemented。纯S4路径也同样等待认可的完成证据。

## 6. 字段／系统／接口映射

| 字段或事实 | 来源／当前证据 | 应如何使用 |
|---|---|---|
| Part／Plant／供应商组合 | 已批准Claim范围；BRD FR1.6和NEO-017／018输入 | 业务scope和route projection分别版本化，同Part跨Plant不合并；不是靠新任务现场自由换零件。 |
| NEO Plant ID及各系统code | MCI_REF_PLANT第361–368行 | 引用身份与SAP_POA／WIPS码分开。S4与哪一列或crosswalk对应需确认，不能把H01K等示例当实际码。 |
| NEO Vendor／GSDB | MCI_REF_VENDOR及Claim供应商；字典SHIP_FROM_GSDB第743行是不同语境 | 保留完整vendor身份及组织范围；不能把Ship-from字段未经确认当成BP mapping。 |
| S4 BP | 新需求明确需要；实际payload／映射数据未收到 | S4或约定主数据团队提供原BP；NEO／映射owner维护受控crosswalk。按供应商、公司／采购组织、Plant／地点及生效期间等实际grain确认，不强行假设一对一。 |
| Mapping／route版本 | 当前提案的受控引用版本 | 保存本次任务使用的身份和有效版本；显示改名不应偷偷换供应商／法律实体。具体数据库和API字段名尚未确定。 |
| WIPS Claim Number | MCI_RISK_OPPORTUNITY.WIPS_CLAIM_NUMBER，第736行，varchar(20) | 仅在有WIPS分支时按真实回执保存；S4-only不要求假值，也不能用BP替代。 |
| ATP Reference | 字典ATP_REFERENCE文本列及Training P1656 | 绑定准确S4 Part／Plant，255字符限制沿用当前实现；本包不把ATP文字当成SAP成功回执。[S4/S6] |
| 工作流／Implemented | WORKFLOW_STATUS_ID第685行；IMPLEMENTED_DATE第761行 | 各系统完成条件满足后按签收规则更新，不与Task Complete自动等同。 |
| 上游接口 | 登记ID1/2/3等SAP数据经Apigee；018的S4 FS依赖 | 先确认现有接口是否已提供S4 BP／Plant／组织，不重复创建同一集成。登记不证明payload正确。 |
| 下游实施 | WIPS／RPA现有结果；CBSL在S4的实施证据 | NEO应记录系统、scope、请求／回执、外部编号和结果。谁提供回调、poll还是人工确认、失败重试及未知结果查重规则未收到，不编造接口。 |

本包没有收到可完整签收的BP crosswalk、S4-only触发契约、直接S4改价API或实际completion receipt，不以UI字段／fixture补这些合同。

## 7. 可操作数据与场景

| 输入 | 本包值及边界 |
|---|---|
| Buyer／CBSL | Alice Morgan／Grace Turner，合成人员；CBSL操作限制场景由Buyer打开时拒绝。实际成员和权限未查生产。 |
| Claim | MCI-00057，POA，V002 Demo Motion UK；已批准scope v7。所有场景相互独立，切换会重置内存。 |
| H01K | P3001，Halewood KD，GB01，GSDB V002，BP 0000123400，候选下游码S4-HKD，100→95 GBP。 |
| N01K | P3001，Nitra KD，SK01，GSDB V002，BP 0000567800，候选码S4-NKD，110→105 GBP。 |
| S01 | P3001，Solihull，GB01，GSDB V002，WIPS候选码W-SOL，50→45 GBP。 |
| Handoff／Task | 混合示例POST-021-01／S4H-021-01／WIPS-0042；纯S4用S4-READY-021-01且无WIPS号。ID与码均为合成，没有生产格式／登记证据。 |
| 版本／时间 | MAP-v4、ROUTE-v4、approved v7；冲突模拟current v8。审计时间在浏览器实际生成，以Asia/Shanghai显示；没有伪造外部处理时间。 |

| 临时UC | 谁／怎么点 | 预期 |
|---|---|---|
| D021-UC01 | Alice，Supplier Negotiations，Parts and suppliers→View source N01K | 3个组合、原BP前导零、GSDB／Company／Plant码分开；无任务。 |
| D021-UC02 | Authorised · handoff pending | 仅授权不产生任务；等待正式实施边界。 |
| D021-UC03 | Grace，Mixed Plants · posting received→Implementation routes→Open S4H task | S4 task仅2行，WIPS保留1行；重复Refresh不重复派本地任务。 |
| D021-UC04 | 填ATP-HKD-021、ATP-NKD-021；Submit→No／Escape，再Yes | 否定操作不完成且保留输入；Yes记录实际actor／time，只完成NEO task，仍无外部成功。 |
| D021-UC05 | S4-only Plant · handoff received | 1个Nitra KD S4组合、1个task，无WIPS步骤和伪造WIPS号；这是候选新handoff演示。 |
| D021-UC06 | BP missing／ambiguous、route unknown、code unavailable | 明确阻断、不默认No、不选第一个BP；未知组合保留。 |
| D021-UC07 | Approved scope changed；填写KEEP-ATP-021后确认 | 拒绝旧范围提交，保留ATP、无completion事件，等待重新审核，不自动切换批准scope。 |
| D021-UC08 | source unavailable→Retry；LSP或Buyer task access | 恢复后按POA范围派一次；LSP不套此流程，Buyer不能提交CBSL任务。 |

## 8. 开发拆分、测试及退出条件

| 工作 | 应交付什么 |
|---|---|
| 页面 | 复用当前NEO Parts／Task组件，补原系统身份和路由；保留原任务附件／Enquiry、字段和权限，不能把本包缩略表直接替换完整任务。 |
| 应用／数据库 | 版本化Part／Plant scope、BP crosswalk、按系统的实施分支、请求／回执关联与审计；复用已有字段，缺的映射／route entities需正式设计，不冒充现有表。 |
| BPM／Flowable | 在签收的实施handoff创建正确任务；维护混合依赖、S4-only分支、幂等、取消／重审／变更、失败和未知结果。现有层满足的只验证兼容性，不能只改前端。 |
| Integration | 依赖018上游数据；确认WIPS／S4回执和人工凭证规则。真实API／回调／source checks未收到前，不能报告端到端完成。 |
| 回归 | S4-only、全WIPS、混合、未知Plant、重复handoff、过期映射、批准范围变化；不破坏原WIPS建单／审批失败PM、Enquiry／Reply和Finance状态。 |

本轮实际：81项浏览器检查、20项候选路由领域检查通过，每条expected／actual／status保留在JSON。修正了候选对空Part scope的错误就绪判定；没有修改现有产品。主图六张，补充身份、冲突和mobile截图。

| 检查组 | 已执行／边界 |
|---|---|
| 范围／身份 | 同Part三个Plant不去重；两条S4 BP原样保留；GSDB及下游code分开；S4任务排除WIPS；S4-only不要求WIPS字段。 |
| 门槛 | 谈判、仅授权、缺／歧义BP、未知／矛盾route、缺code、空scope、版本冲突、source失败、LSP和Buyer权限拒绝。 |
| 任务／审计 | 创建一次、刷新不重复；No／Escape不完成；ATP非臆造必填；确认后一个completion及实际actor；WIPS依赖候选就绪但未执行；整体结果不自动Implemented。 |
| UXUI | 六宽1920／1440／1024／768／390／360，32／24／16边距，表内滚动／身份列、modal／移动操作、Tab溢出菜单、CSS200%、无HTTP写入或runtime错误。CSS缩放不是原生browser zoom。 |
| NOT RUN | 真实BPM／DB持久化／刷新回读／并发／durable幂等；实际SAP／S4／WIPS／RPA、BP/Plant mapping及回执；全部Enquiry／附件／PM失败分支回归；容量／安全／SLA／通知；财务Implemented规则、部署、跨机器和业务UAT。 |

提案退出：独立英文页面、六图、来源／SHA、中文方案／问题、源码／实际测试和ZIP齐备。不是现有系统或FR62全量通过。

正式退出：签收S4-only实施边界、实际Plant及BP映射、任务粒度和owner；同一真实授权记录走完混合／S4-only，持久化和回执逐步对账；错误／重试不会漏派、重复或更新错系统；Implemented有认可的完整证据。

## 9. 讲人话的问题清单

| 编号 | Context／例子 | 建议及影响 |
|---|---|---|
| Q021-01 | 只有S4的Nitra KD没有WIPS建单结果，究竟哪一步通知NEO可以创建S4任务？ | 推荐一个不依赖WIPS的统一实施handoff，放在必要授权／检查和范围冻结后。谁发、具体节点和状态码必须签收，不能凭Mandate通过就直接变价。 |
| Q021-02 | 一条Line同时有Halewood KD和Nitra KD，CBSL是一个任务做两地，还是每地一个？ | 本包暂用一个task覆盖S4行；跨公司／团队可能要拆。请业务确认，影响task key、分派、部分完成和SLA。 |
| Q021-03 | 同一GSDB在不同公司／工厂对应不同BP，如何唯一匹配？ | 按真实组织／地点／时间粒度查crosswalk；给出一对多及失效例子。不能只按供应商名称或第一个匹配。 |
| Q021-04 | CBSL与Digitide是谁负责S4变价，任务派哪个真实组／人员？ | 明确组、覆盖工厂、授权／代办和负责人。Training的CBSL不能直接等同新需求中的其他团队。 |
| Q021-05 | 两条S4行有一条BP不明，WIPS或另一工厂能否先做？ | 本包保守按Line阻断；若允许部分实施，需明确分支批准scope、完成汇总、失败和撤销规则。 |
| Q021-06 | BP mapping在批准后改了，是技术码更新还是换了供应商身份？ | 保留原批准版本，先核对商业影响；何时需Buyer／FBP重审由政策确定，不能静默换到新BP。 |
| Q021-07 | 何种凭证说明S4已成功变价？ATP、S4 document还是系统回读？ | 明确外部编号和核对字段，区分Task Complete与Implemented。ATP可空或仅备注时不能自动认定成功。 |
| Q021-08 | 混合POA里，WIPS审批是否必须等全部S4工厂完成？有失败／部分完成时怎么办？ | Training和当前local ready存在依赖；请确认生产实际串并行和例外，避免凭本包界面扩大规则。 |
| Q021-09 | S4独有Plant究竟使用哪个实际code？NEO／SAP POA／WIPS列如何映射，历史切换如何生效？ | 提供受控配置及effective dates；本包H01K／S4-HKD等绝非真实码。未知不能默认非S4。 |
| Q021-10 | handoff／任务提交超时后如何查到原操作？取消、重提、重审是否重用同一任务？ | 需要真实operation key、状态回读和审计规则；先查原结果，再决定重试，不能盲目再建任务。 |

## 10. 交付物及后续

- NEO-021_Page_Proposal.html：独立英文页面，12个外部场景；业务区没有Pending的i说明。
- NEO-021_Consolidated_CN.html／本MD：六图、分类／priority／Epic／ACT／FR／page／UC、字段／集成和影响。
- OPEN_QUESTIONS_CN.md：10项问题、业务例子和建议。
- SOURCE_EVIDENCE.json：21条实际本地来源及准确locator／原文／SHA，不把旧局部结果重新标为新验收。
- PAGE_VISUAL_CHECK.json、DOMAIN_CHECK.json、VALIDATION.json：实际本地执行与交付完整性。
- design-source：TSX、纯route model、NEO theme、样式、字体、build／verify／plan／README／manifest；无生产配置、payload或真实凭证。

本轮先完成021的独立评审包；下一条按原需求目录继续，未提前开发其他条目。
