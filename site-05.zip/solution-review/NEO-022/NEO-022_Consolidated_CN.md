# NEO-022 · 同一物料多笔Claim并行时的价格冲突控制

独立英文交互页，复用当前NEO theme、JLR字体和Ant Design。本文为中文评审稿，未修改现有prototype、共享QA、Jira、数据库、真实流程或线上系统。人员、Line／Request、价格和版本均为本包合成数据。保存、读取与提交只在当前页面内存中运行，刷新后重置。

## 1. 原需求与来源

这条需求处理的是：同一Part同时出现在几笔Claim里，前一笔先实施了价格，后一笔仍拿旧起始价继续审批和实施，造成错误价格或RPA报错。需求明确允许Part继续用于多笔Forecast；限制发生在进入审批时，不应把建Claim、保存Forecast和申请Mandate混为一件事。

| 来源 | 原文／证据与边界 |
|---|---|
| S1：新需求工作簿 RTM for Requested Changes 第23行 | NEO-022，Procurement / POA Input，New functionality，CR-2026-1557 / 4。采购Must，财务优先级为空，Alignment N。 |
| S1：问题 | “Multiple NEO Requests are submitted for the same materials in parallel.” 前一笔实施改变starting price，但后续Claim没有反映。 |
| S1：期望 | “prevent (or flag)”另一笔同Part进入审批，并说明已在审批中；“Should still be able to add the parts to claims in forecast just not send for approval.” |
| S1：实施风险 | “incorrect prices implemented”及“RPA errors”。还要求training/process帮助顺序批准及完成，系统控制不能替代业务培训。 |
| S2-8：BRD Table6 第8行 FR1.6 | Part、Plant、当前价格及币种来自参考数据；不能只按页面显示的价格认为始终有效。 |
| S2-14：Table6 第14行 FR6 | 有权限的Buyer／PM／SPM可更新FR1信息，改金额或Confidence须说明原因并审计；active或approved Settlement会限制修改。 |
| S2-21/22/25：FR9、FR9.1、FR9.4 | 建Claim、Mandate／Guidance／Review、Settlement是不同动作；历史批准能否复用仍由适用规则及FBP判断，不能自动复用。 |
| S2-38：FR13 | WIPS需要实际Buyer及Manager批准确认，后者可能隔数小时／数日。NEO批准不等于外部价格已更新。 |
| S3：Training正文604–653段 | 提供Update Claim／Submit Claim的历史入口及权限语境；不是本次并行锁规则的独立证明。 |
| S1-ID-A/B：同ID不同含义 | Archive第25行NEO-022是FR9.1；NEO RTM第26行NEO-022是FR1.6慢SAP／缺FTO等问题。不能因为编号相同就认成这条新需求。 |

每份来源的完整路径、原文／坐标与SHA在SOURCE_EVIDENCE.json。本文引用的是文件内容，不是现网部署或已签收政策。

## 2. Solution、主要改动类型与优先级

建议采用“允许Forecast并行、正式审批前检查冲突、提交时再次校验、源价格变化后明确复核”的方式。同一已确认价格范围正在审批或等待实施时，候选方案先硬阻断另一笔正式审批；不同Plant是否也冲突，先保留待确认，不自行判定为安全。

| 项目 | 评估 |
|---|---|
| 主要改动类型 | Application前端＋后端＋工作流状态控制。不是UXUI only。前端说明冲突与复核价格；后端负责跨Claim查询、最终校验、原子占用和权限裁剪；流程负责占用／释放时点。 |
| Integration needed | 需要可信的SAP／S4价格回读、有效期和版本，以及适用WIPS／RPA实施结果。跨Claim占用在NEO应用内处理，不需要把它放到SAP里做。 |
| 现有接口可否复用 | S11登记1 MCI_getPartDetails、2 MCI_getPartPriceDetails，SAP经Apigee向Appian提供数据；迁移后由Flowable应用消费。WIPS登记12建单、13审批、16回调可关联结果，但登记不证明已有价格版本、查重、结果回读及幂等完整契约。 |
| 哪方提供 | SAP／Apigee团队提供准确Part／Vendor／Plant价格和生效信息；WIPS／Automation Anywhere提供真实建单、审批及处理确认；NEO／Flowable应用提供跨Claim校验、占用及Request快照。不是Flowable自行提供SAP主数据。 |
| 新增架构？ | 暂不建议新增平台。优先扩应用域服务和现有数据库事务／约束、版本化快照与流程事件；是否需额外队列／中间件由实际并发、来源能力及性能基线决定。 |
| Priority | 原采购Must；建议P0，因为会导致错价实施及RPA失败。P0是本轮风险建议，不替代正式排期。 |
| Epic | CNP-231 Claims and data；CNP-233 Authorisation为主要关联；CNP-234下游实施关联回归。未新建Jira。 |
| ACT / User Story | ACT-001 Create Claim、ACT-004 Update Claim、ACT-010 Request For Mandate；关联ACT-005 Submit Claim、ACT-012 Settlement、ACT-013 Approval Check、ACT-027 Create WIPS Claim。[S5] |
| FR | 直接FR1.6、FR6、FR9；关联FR9.1、FR9.4、FR13。注意原BRD的FR6.1是Lump Sum，不能把POA复核全部写成FR6.1；现有ACT-004映射的此处颗粒度需保留差异。[S2-14/15] |
| 页面 | P2.6 Parts Data — create POA；P12 Create Mandate / Guidance / Review Request；P12.1 Create Settlement Request。Update Claim复用FR6入口，不自行补正式Page ID。[S10] |
| UC | 本次D022-UC01–10是独立评审场景编号，待并入正式UC。没有收到已经签收的独立“并行Claim占用”UC，不虚填既有UC编号。 |

<!-- NEO022_EXPLANATION_START -->
### 2.1 Before / After 与影响

同一个零件可以同时用于多笔谈判／Forecast，但不能让这些申请拿着过期的起始价，乱序审批和实施。022 要同时解决处理顺序和价格基础更新。

#### Before：申请各自前进，价格基础没有同步

| 时点 | Claim A | Claim B |
| --- | --- | --- |
| 两笔同时准备 | 起始价 £100，拟改为 £95 | 起始价 £100，拟改为 £90 |
| 两笔进入审批 | 按 £100 → £95 审批 | 按 £100 → £90 审批 |
| A 先实施 | 外部系统价格已变成 £95 | 仍保存起始价 £100 |
| B 继续实施 | A 的价格已经生效 | 实际起始价为 £95，但申请仍依据 £100，可能造成计算偏差、错价实施或 RPA 错误。 |

#### After：允许并行准备，按顺序审批和实施

| 环节 | 建议的 After 行为 |
| --- | --- |
| 创建／保存 Forecast | 允许 A、B 使用同一零件继续准备；不因另一笔申请存在就禁止建单。 |
| 提交正式审批 | 检查另一笔 Claim 是否正在审批或等待实施。冲突时建议阻止第二笔提交，保留输入，并说明原因及授权可见的关联申请。 |
| A 已批准、尚未实施 | B 继续等待。NEO 批准不代表 SAP／WIPS 价格已更新。 |
| A 实施完成 | 取得可信外部结果并重读适用价格。B 对比保存起始价 £100 与最新 £95，进入 Buyer 复核。 |
| Buyer 复核 B | 明确保留哪种谈判结果，重算影响，保存原因及新版本；不能悄悄覆盖 Buyer 的目标价。 |
| B 再提交／实施 | 最终提交再查冲突与价格，实施前核对获批版本。商业条件变化时按适用规则决定是否重新审批，保留旧批准快照。 |

A、B 都可准备 Forecast → A 进入审批，B 等待 → A 完成外部实施 → B 刷新起始价、复核并重算 → B 再进入审批和实施。

原文 Q23 保留 Forecast 的同零件使用能力，审批控制写的是“prevent (or flag)”。硬阻断及等待外部实施完成是建议方案，尚不是已签收规则。冲突范围需核对 Part、Supplier、Plant、价格有效期等维度，不能只按 Part Number 全局锁住。按另一笔 Claim 判断，不能误拦同一 Claim 的 Mandate → Settlement 正常衔接。

#### 更新起始价后，确认谈判意思

| B 原本谈的是什么 | 起始价变成 £95 后 | 影响 |
| --- | --- | --- |
| 最终价格就是 £90 | 保留新价 £90，单价减少 £5 | 原来按 £100 算的 £10 降幅已不适用，影响金额需要重算。 |
| 在起始价上再降 10% | 业务确认沿用该约定时，新价为 £85.50 | 这是不同的最终价格，不能由系统自动替 Buyer 决定。 |

#### 影响范围

| 范围 | 需要改变什么 |
| --- | --- |
| Buyer／采购流程 | 安排冲突申请的先后顺序，前单完成后复核后单，并同步培训。 |
| 页面 | Parts／改价页展示旧价、最新价及复核入口；申请处展示冲突原因。沿用现有页面和 After UX/UI。 |
| 应用后端／工作流 | 跨 Claim 查冲突，最终提交时可靠控制，防止两人同时提交均通过；明确等待、退回、取消及异常时如何保持或解除限制。 |
| 金额和审批 | 起始价变化影响价差、计算结果，可能影响审批金额及原批准复用；不能直接覆盖原批准版本。 |
| SAP／WIPS／RPA | 需要可信价格及实施结果。超时／未知结果不能当作已完成，也不能直接放行后单。 |

已有 MCI_getPartPriceDetails（接口目录编号 2）可作为价格读取的复用基础；WIPS 编号 12／13 为建单／审批调用，16／17 为各自回调。仍需确认适用价格、生效时间和可关联的真实处理结果；接口登记不等于完整能力已验证。跨 Claim 控制主要在 NEO 应用内，暂不据此新增平台架构。

#### 与 003 的区别

003 刷新这一笔的起始价；022 管多笔申请之间的顺序和冲突。可以复用价格刷新能力，但 022 还要补跨申请控制。

示例假设是同一供应商、工厂、适用价格范围；金额仅说明单价变化，全年影响按已确认数量、期间、汇率及公式计算。Before 依据需求描述的历史问题，并非本次现网实测；After 是建议流程。本次仅补说明，没有执行新的业务验收。

Reference: NEO Business Requirements (added China requirements) 2 (1113 14:00) · NEO Business Requirements (adde · NEO-022 · E23 / M23 / Q23 / X23; Integrations – 2026-11-09_0941(Sheet 1).csv · IDs 2, 12, 13, 16, 17.

<!-- NEO022_EXPLANATION_END -->

## 3. 当前已有能力与差距

本轮只读核对指定源文件，不把“没在这几个文件里找到”说成全产品绝对没有。

| 已有证据 | 可复用与真正需要补的部分 |
|---|---|
| p03/selection.ts 第3、10–14行[S6] | occurrenceKey含Vendor、Company、Plant、Part、Vehicle Line、MY及sourceVersion；已有单Claim源数据更新／保留失配行机制。它不是跨Claim审批占用证明。 |
| 同一sourceVersion变更 | UI行key可以随sourceVersion变化，但审批冲突key不能把sourceVersion／Claim ID当成隔离维度，否则刷新一次价格就可绕开另一笔占用。最终价格范围粒度须业务确认。 |
| p04/approval-check.ts 第20、26、35行[S7] | 已校验保存版本／快照及既有Mandate引用；可以接入价格范围与来源版本校验。不能因原快照校验存在，就认为跨Claim并发已解决。 |
| p04/settlement.ts 第151行[S8] | Mark Complete生成handoff-prepared，和实际源系统实施结果仍分开。本需求释放占用不能只看按钮成功。 |
| 缺少签收规则 | prevent还是flag、哪些请求／状态占用、何时释放、不同Plant／日期如何判重、FBP如何批准商业修正，均待确认。当前页面是候选控制，不是新业务规则已获批准。 |

## 4. 字段、数据和接口契约

| 页面／后台用途 | 已有字典对应[S4] | 本次补充／待确认 |
|---|---|---|
| Part及Plant身份 | MCI_RISK_OPPORTUNITY_PART.PART_ID / PLANT_ID，第816–817行 | 与Vendor／Company／有效期一起定义价格范围；不能仅凭名称去重。 |
| Claim原始起始价 | CURRENT_VALUE、CURRENT_VALUE_CURRENCY、EFFECTIVE_DATE_FROM/TO，第818–821行 | 保留本笔保存时的值，不能查询到新价就无痕覆盖。 |
| 起始价修正标记与原因 | IS_CURRENT_VALUE_CHANGED、CURRENT_VALUE_CHANGE_REASONING，第822–823行 | 理由必须随修订保存并可回读；字典不直接证明全部触发规则。 |
| 新价和改价幅度 | ABSOLUTE_PART_PRICE_CHANGE、NEW_PART_PRICE、NEW_PART_PRICE_CURRENCY、PRICE_DIFFERENCE、PERCENT_DIFFERENCE，第824–828行 | 本包只演示单位价格差，非全年影响／DoA／Reserve公式。需确认各change字段正式符号语义及计算精度。 |
| 参考价 | MCI_REF_PART_PRICE 第339–352行：CURRENT_VALUE/CURRENCY、生效区间、IS_IN_USE等 | 刷新时间不自动等于源系统版本。需价格版本／有效时点、完整身份和可信回读契约。 |
| 审批占用及Request快照 | 现有来源未给出可确认的本条专用全局占用契约 | 候选需保存priceScope、占用Request/Line、状态、原价／目标价／来源版本、revision和幂等intent。字段名为概念设计，未宣称数据库已有。 |
| SAP价格输入 | MCI_getPartPriceDetails，GET；Vendor、Plant、Material等query参数；无request body[S11] | 当前登记没给本条需要的完整签收response schema和版本原子性。不能凭接口名填造JSON payload。 |
| WIPS结果输入 | MCI_raiseWIPSClaim / MCI_approveWIPSClaim / MCI AA WIPS Response[S11] | 需关联原外部编号、建单／审批／已实施结果；超时或未知结果时不释放后续占用，不重新盲建。 |

NEO应用需要暴露给前端的候选语义是：此范围是否冲突、授权可见的冲突摘要、当前价格／币种／有效期／来源版本、复核后的保存版本及提交receipt。这里只定义语义，不冒充已存在API路径或实际payload。

## 5. 页面图与交互

### 5.1 另一笔正在审批：可存Forecast，不可再申请审批

![另一笔审批占用同一Part](NEO-022_Overlap.png)

Alice Morgan打开MCI-00058；同一合成P3001 / V002 / GB01 / H01已在MCI-00057、Request46审批中。保留Save forecast，停用Request for Mandate。行首查看入口说明冲突对象；无权读取另一笔时，只显示Restricted与联系FBP，不暴露其Line／Request ID。

### 5.2 批准了，但还没实施，不立即放行

![查看相关审批请求](NEO-022_Related.png)

相关请求是只读摘要。另一个评审场景可查看“Approved · implementation pending”；仅NEO审批结束不能证明源价格已更新。本轮建议继续占用直到可信实施确认；实际释放条件待业务签收。

### 5.3 前一笔实施后，本笔起始价变旧

![起始价格100与最新95分开显示](NEO-022_StalePrice.png)

旧保存价100.00000 GBP / PRICE-v4与最新95.00000 / PRICE-v5同时显示，不自动覆盖。新价90.00000仍保留，等待Buyer复核。

### 5.4 明确选择商业意图

![复核时选择目标价格或原百分比](NEO-022_ReviewPrice.png)

保留目标价90：新基准95，变化−5.00000，−5.26316%。保留原−10%：新基准95，新价85.50000，变化−9.50000。两种结果不同，不能由程序默默选择。必须填Reason，Apply只更新待保存修改。

### 5.5 保存后再进入审批

![复核并显式保存后](NEO-022_Saved.png)

View saved forecast可读取当前页内存保存的原价、新价、原因与版本。Apply后、Save前仍能读取旧保存值100 / PRICE-v4；Save后才变95 / PRICE-v5和Claim v8。刷新后的持久化不在本包实现范围。

### 5.6 最后一次提交再检查

![提交后保留价格和来源版本](NEO-022_Submitted.png)

确认提交产生本包内存Request47，锁定本次已保存价格范围。Race场景会在确认时模拟另一笔抢先占用，拒绝本次提交，保留Forecast，不产生本笔新Request。没有调用真实审批路线、SAP或RPA。

## 6. 场景与演示数据

| 场景 | 用谁／怎么点／数据 | 预期行为 |
|---|---|---|
| D022-UC01 并行审批 | Alice；默认场景，Approval readiness → 查看Request46；Save forecast | 能保存，不能Request for Mandate；按Description区分本笔，冲突有授权可见的Line／Request。 |
| D022-UC02 等待实施 | 外部评审栏选择Approved · implementation pending | 批准不自动释放，仍阻断正式审批。 |
| D022-UC03 保留目标价 | Previous Claim implemented → Review latest price → Keep negotiated target；原因“Keep the negotiated target after the earlier Claim was implemented.” → Apply → Save | 100→95基准，新价保持90；保存后v8／PRICE-v5，才可申请。 |
| D022-UC04 保留百分比 | 同场景选择Keep original adjustment −10% | Preview新价85.50000；保存前不可申请。 |
| D022-UC05 确认／取消 | 可用范围 → Request for Mandate → No或Yes | No不产生请求；Yes在当前内存产生47，保持已保存价格与来源版本；不能重复提交。 |
| D022-UC06 并发到达 | Another request submits concurrently → 确认提交 | 最终检查发现新占用，拒绝新申请，保留90的目标价和Forecast。纯同步内存模拟，不是分布式并发证明。 |
| D022-UC07 规则未知 | Same Part · different Plant | 不擅自认定可并行，说明需FBP确认；Forecast可保存。 |
| D022-UC08 跨权限 | Conflict outside readable scope | 冲突仍可阻断；无可读权限不显示另一笔ID／处理入口。实际服务端权限未测。 |
| D022-UC09 来源失败／锁定 | Current-price source unavailable → Retry；或Active Settlement | 失败时不能审批，已有Forecast可保存；本笔被Settlement锁定时不可改价保存。 |
| D022-UC10 二次变价 | Price changes again → 输入原因并Apply；95又变94 → Review latest source → Apply → Save | 首次阻断，保留选择和原因；显式复核后保存94 / PRICE-v6；不能拿95的复核确认套用94。 |

有效期、币种、Plant／Vendor组合均是评审夹具，不可拿本包数据作为生产Setup或Finance golden case。P3001等编号与NEO-021同字面不表示跨包共享状态。

## 7. 开发影响与建议落地顺序

| 层 | 需要做什么 | 依赖／退出条件 |
|---|---|---|
| UXUI | Part prices、Request入口、冲突摘要、价格对比与原因；保留当前After组件和权限信息 | 可保存Forecast、看懂阻断原因、明确复核商业意图；不恢复Before旧样式。 |
| 应用后端 | 跨全部有效请求查重；按已签收范围执行check-and-reserve；同intent重试返回原receipt；价格／revision冲突保留输入 | 最终提交不能只信前端可用按钮；权限裁剪由服务端执行；多Part一次提交全量原子成功或整体回滚。 |
| 数据 | 保存来源价、拟价、来源版本、保存revision及历史Request快照；必要占用索引／约束 | 保留旧批准版本，不反向覆盖；冲突key不含sourceVersion。具体表／DDL待实现设计。 |
| BPM／审批 | Mandate／Settlement入口接统一检查，明确占用、纠正、取消、失败／未知、实施确认后的释放 | Guidance／Review是否占用、退回是否释放、取消时外部单已存在怎么办，必须业务确认。 |
| Integration | 复用已验证价格／实施回执入口；实施前再次核对价格和已批准商业范围 | 真实当前价和结果可回读；未知结果先查原单；不直接新增未经批准的SAP／WIPS写口。 |
| 测试／性能 | 按有效并发与全量请求规模验证数据库约束、批量冲突查询、重试及权限；无N+1查询 | 本包无规模／并发基线，不承诺臆造毫秒值。真实多会话／多实例测试不可由内存First-wins替代。 |

建议先确认冲突范围及生命周期，再接NEO-017／018的主数据和价格来源。与NEO-021复用实施确认信息；避免每条需求独立开发一份价格版本／回执机制。训练材料同时说明按顺序完成已占用交易、后续Claim重新核算。

## 8. 实际验证与退出条件

本包79项浏览器检查＋29项纯领域检查通过；每项expected／actual／PASS在PAGE_VISUAL_CHECK.json和DOMAIN_CHECK.json，不使用未测通过。页面SHA、实际Chrome版本、合成actor／record与运行时间写入报告。AntD lint无弃用／可访问性／usage错误，仅10个固定场景Select关闭virtual的性能提醒，限定为外部评审栏，不是海量业务下拉方案。

| 范围 | 本轮结果 | 不能据此声称什么 |
|---|---|---|
| 本地页面交互 | PASS：冲突时保存／阻断、原因必填、Cancel／No、价格两种选择、显式保存和页内回读、提交防重复、提交时竞争、权限摘要、来源Retry、Settlement锁、二次变价 | 不是完整FR9表单、真实审批人／DoA路线或整个NEO流程已验收。 |
| 价格及占用模型 | PASS：5位定点价格、目标价／百分比差异、非法数字／零源价拒绝、内存占用／同intent／不同payload冲突、版本变化不能绕开原占用 | 不是生产金额符号、货币精度、汇率／FTO／Reserve规则或真实数据库事务测试。 |
| 布局 | PASS：1920／1440／1024／768／390／360无页面横溢、边距32／24／16、手机价格对话框与确认；CSS200%无横溢 | CSS200%不等同操作系统或浏览器原生缩放认证；原生200% NOT RUN。 |
| 后端／真实权限／持久化 | NOT RUN | 刷新即重置；服务端未接入；Request47不是现网业务记录。 |
| 数据库与真实并发／多Part事务 | NOT RUN | 本包只有单Part夹具，未做多进程、数据库锁、死锁恢复、全批回滚或生产负载测试。 |
| SAP／S4／WIPS／RPA | NOT RUN | 无真实价格回读、回调、未知结果查重或外部实施；不发邮件／通知。 |
| 业务签收／部署 | NOT RUN | 硬阻断、粒度、释放规则尚未签收；未部署。 |

独立评审包退出：来源可查、候选交互可操作、6张图可看、108项本地检查有实际结果、问题明确、源码和ZIP可回读。正式开发退出另需：范围／状态规则签收、接口／数据库契约确定、所有正式入口及多Part原子性落实、真实环境同记录正常／异常／恢复整链取证。

## 9. 待业务确认的问题（讲人话）

| 优先级 | 要确认什么／建议 | 例子与影响 |
|---|---|---|
| P0 | 同Part另一笔审批时，禁止还是只提醒？建议正式审批硬阻断，Forecast允许。原文“prevent (or flag)”尚非唯一确定规则。 | A正审批，B点提交：只提醒仍可继续，会再次承担错序风险；若允许override，谁有权、记录什么理由？ |
| P0 | “同一材料”到底按什么判重？需要Part＋哪些Vendor／Plant／Company／有效期维度？ | P3001在Halewood与Solihull可能是两套价格，也可能共用价格；不能由开发猜。 |
| P0 | 哪类请求／状态占用？建议至少正式Mandate／Settlement；Guidance／Review另确认。 | 两笔仅做Guidance是否应该互相阻断？退回Buyer修正时是否继续占用？ |
| P0 | 什么时候释放？建议可信源实施确认后，而不是NEO批准时。 | A已批准、WIPS PM还未批；这时B若按旧价申请，后面仍会冲突。 |
| P0 | 前一笔实施后，后一笔默认保留哪个价格意图？建议显式选择，不能自动。 | 原来100→90是约定90，还是约定减10%？现在95，结果分别是90与85.5。 |
| P0 | 修正基准／目标价后，原批准哪些还能用？需要FBP和正式DoA／金额规则。 | 95→90后影响额缩小，不代表商业条件、文件和旧批准一定可直接复用。 |
| P0 | 取消／超时但外部单可能已建立，谁查到原结果后释放？ | NEO取消了，但WIPS已接单；直接放B进入会出现两个实施动作。 |
| P0 | 当前价和完成结果的权威来源／版本是什么？请SAP、WIPS／RPA团队给真实样例。 | “刚刷新页面”不是源版本；只有建单成功回调，也不一定等于价格已生效。 |
| P1 | 没权限看另一笔，谁负责排解冲突？建议FBP／指定团队，有不泄密的摘要。 | Buyer只看到此Part被占用，不应该为了排查而获得其他组织的Claim金额与人员。 |
| P1 | 多Part有一行冲突时整体停止还是允许拆单？建议一次提交全成或全不成，拆分须显式确认。 | 20行中1行冲突，不能暗中只提交19行，也不能只锁了一半。 |

以上都是候选建议；未收到业务答复的项保持待确认，不凭本次页面按钮成功变成已签收。

## 10. 交付物和下一步

- NEO-022_Page_Proposal.html：独立可操作英文页面，10个外部评审场景。
- NEO-022_Consolidated_CN.html／.md：本文、6张真实本地截图、来源与方案。
- OPEN_QUESTIONS_CN.md：可单独转给业务的10个问题。
- SOURCE_EVIDENCE.json：19条证据，完整路径／坐标／摘录／SHA；原始文档没有被复制成新的业务规则。
- PAGE_VISUAL_CHECK.json／DOMAIN_CHECK.json／VALIDATION.json：实际本地结果、版本、边界及文件校验。
- design-source：React／AntD源码、定点价格／内存占用模型、原theme快照、字体、build及可复跑tests／README。
- NEO-022_Review_Pack.zip：版本化独立完整交接包；旧包及产品不变。

下一项继续按原工作簿顺序审阅NEO-023，本包不自动开启下一条开发。
