# NEO-014 · Clearing House 会议纪要汇总

<!-- FLOW-REVIEW-20261116 -->
## 16 Nov 2026 · 流程评审补充

[中英文 Before / After 流程](NEO-014_Before_After_Flow.html) · [流程说明 MD](NEO-014_Before_After_Flow_CN_EN.md)

将已有申请纪要、逐 Line 结果和行动项汇成一份场次报告；首选下载后人工发邮件。

本轮为流程说明补充；原交互页面、问题及历史证据保留。正式实施前需补齐：业务确认会议场次范围、纪要必填内容和报告模板；逐 Line 结果须由现有审批记录提供。
<!-- /FLOW-REVIEW-20261116 -->

本轮交付为独立页面方案；未修改现有 NEO prototype、共享 QA、业务数据或线上系统。页面英文，评估中文。所有人员、场次、申请版本及结果为合成示例；不是正式会议记录。来源原文、定位和 SHA-256 在 SOURCE_EVIDENCE.json。

## 1. 需求是什么

原需求：按某次 Clearing House 汇总审批 ID，生成准确、完整的会议纪要，让相关人员看到每个讨论事项的批准／拒绝结果和 Minutes。来源明确允许两种方式：生成报告后人工附到邮件，或系统直接生成并发送邮件。不是两条路都必须同时开发。[S1]

本次建议先完成“选场次 → 看事项及 Minutes → 生成完整报告 → 下载”的主路径。沿用各申请上的正式 Minutes 和审批结果，不在报告页另造一套批准、拒绝或 Mark As Complete 操作。邮件直发作为可选扩展，与 NEO-013 共用已确认后的发送能力。

| 项目 | 来源与判断 |
|---|---|
| 本条来源 | RTM for Requested Changes 第15行 NEO-014；关联 P1 CR clean 第34行 CR21。[S1/S2] |
| Finance 优先级 | 原表为 Must；Procurement 优先级空白，不能补写为已确认。 |
| 历史情况 | CR21 记载每条 Claim 已有 CH 历史及审批，但汇总功能为 backlog；这不等于逐申请没有 Minutes。[S2] |
| 原 BRD | FR10.1 有 Minutes、Agenda Date & Time、Actions、审批信息和 Transaction History；FR10.2 规定 FBP 维护 Minutes。[S3-28/29] |
| ID 防混淆 | RTM - Archive 第17行 NEO-014 是 Edit Claim；NEO RTM 第18行是 Maturity/Currency。均非本轮需求。[S1-ID-A/B] |

## 2. 分类、优先级及关联

| 维度 | 结论 |
|---|---|
| 主要改动类型 | Application 内部前后端修改。前端新增会议纪要视图；后端需按授权范围取会议记录、形成一致版本报告、导出和审计。不是 UX/UI only。 |
| Integration needed | 基础报告不需要新增 SAP、WIPS、FTO 或 FX 调用。源数据来自 NEO 内部申请、Line、审批及 Actions。直发邮件才涉及身份／邮箱与邮件服务。 |
| 可复用能力 | 当前 FBP Minutes 维护、Request/Line 查询、角色和记录权限、NEO 主题；Agenda/outbox 可复用部分发送设计，但当前本地 outbox 不是生产邮件契约。[S8–S11/S13] |
| 新增架构 | 不建议新增独立平台。建议在 NEO 内扩展报告投影和快照；是否需新增会议实体／历史关联表，取决于现有会议和版本模型，待确认。 |
| 建议交付顺序 | P1：基础报告；优先解决场次识别、历史版本和权限。可选直发邮件后置。这是技术排期建议，不替换 Finance Must。 |
| Epic | 建议挂既有 CNP-233 / Authorisation，依据 ACT-017、ACT-057 的既有 Epic；不是新 Jira 写入。[S7] |
| User Story | 主关联 ACT-017 Update Approval Request-FBP（Minutes 来源）；ACT-057 Clearing House Agenda Email 只关联邮件复用，不能说它已覆盖会后纪要。新增汇总能力需补 story 范围或另建 story，编号待管理方分配。 |
| 影响 FR | 直接 FR10.1、FR10.2；关联 FR5、FR5.1 的审批请求纪要展示。完成通知边界参考 Training Table8；不在本条重定义 FR10.6 的审批完结。[S3/S4] |
| UC 场景 | 下文 D014-UC01–06 为本方案临时场景标识，不占用正式 BRD UC 编号。 |
| 页面 | 沿 P11 Approval Requests 进入新会议纪要页；P13 Approval Request Summary 是既有来源页。P11.1 是议程邮件，不覆盖它。新页用临时 D014-P01，正式页面编号待登记。[S12] |

| 临时 UC | 用户与操作 | 页面／范围 |
|---|---|---|
| D014-UC01 | Ben Taylor／FBP，选 13 Nov 2026 上午场次，查看4条申请 | D014-P01 会后事项列表 |
| D014-UC02 | 打开 Request48，分别看到两条 Line 的批准和拒绝 | D014-P02 只读申请详情弹窗；不改变原 P13 |
| D014-UC03 | 生成4条申请、5条 Line 的完整报告并下载 | D014-P03 报告预览及下载 |
| D014-UC04 | Request46 缺 Minutes，看到具体缺口，阻止生成 | 同页缺失态；实际补录仍在现有 FBP 更新流程 |
| D014-UC05 | 来源版本变化或生成失败后，重新读取／生成 | 同页异常恢复，不自动覆盖旧报告 |
| D014-UC06 | Buyer 无生成权限；邮件未配置不能直发 | 同页权限态／邮件选项弹窗 |

## 3. 现有实现与缺口

已读取当前 React 的 FinanceRequestUpdate.tsx：有 Clearing House Status、Forum、Agenda、Date Closed、Presenter、Minutes 和确认提交；不能把它说成尚无纪要维护。[S8] 已读取 Agenda.tsx 和 outbox.ts：现有能力围绕会前议程邮件，不能把它算作本条会后会议纪要报告。[S9/S10]

在本轮审查的 Approval 文件和143页目录中，未识别到可证明已完成“按会议汇总结果及纪要并导出”的页面。这个结论限于已审源码与目录，不是对生产系统全量不存在的证明。

| 缺口 | 影响与处理 |
|---|---|
| 一个日期可能多场会议 | 不按日期直接合并。设计中上午、下午分开；正式场次唯一键、Forum、时区和关联方式待确认。 |
| 现有字典只确认 Request 的 Forum/Agenda 字段 | 尚不能证明存在可追溯的会议实例 ID；临时 am/pm fixture 键不是正式接口字段。 |
| 改期或 Minutes 后改 | 当前字段可能覆盖历史值。必须明确“这次会议当时”的关联和版本来源；不能事后用最新 Agenda 日期重建历史纪要。 |
| Request 部分批准 | 保留 Request 汇总结果及每条 Line 的决定。示例状态为展示用，不冒充已经确认的枚举值或计算规则。 |
| Minutes 长度不一致 | 字典 MCI_REQUEST.MINUTES 为 varchar(2000)，当前编辑控件 maxLength=4000。正式开发前确认，不在报告里静默截断。[S5/S8] |
| 审批完结有既有未决项 | QA TRN-AR-CLOSURE-01 记录完结条件和 Buyer 通知问题；本次导出不解决也不掩盖该问题。[S13] |
| 真实权限、归档和邮件契约 | 前端隐藏入口不足以验收；服务端读数／下载仍需校验授权并保存真实版本和审计。 |

## 4. 页面与交互

### 4.1 按场次查看会议事项

![会议纪要列表](NEO-014_Overview.png)

保留 NEO 顶栏、字体和 Ant Design 样式。列表依次为 Actions、Request ID、类型、Description、Decision、Clearing House Status、Line IDs、Buyer、Minutes。没有强制选择框：会议报告默认包含所选场次全部可访问事项，避免漏选。Search／Decision 仅筛选屏幕列表；生成按钮明确为 Generate full-session report，并提示筛选不影响报告范围。

### 4.2 看清部分批准

![申请及Line详情](NEO-014_Detail.png)

Request48 的 MCI-00059 为 Approved，MCI-00060 为 Rejected；不以 Request 状态把全部 Line 都标成批准。详情为只读，不允许修改审批决定。

### 4.3 生成整场报告

![报告预览](NEO-014_Report.png)

报告保留场次、时区、生成时间、准备人、报告版本、每条申请来源版本、Decision、Clearing House Status、Request status、Minutes、Line 决定、Action／Owner／Due date。当前演示没有跨币种金额汇总，避免无依据增加金融口径。数据保存在本页内存快照，刷新页面会重置；正式后台快照与持久化待实施。

### 4.4 缺纪要时说清是哪条

![缺Minutes](NEO-014_Missing.png)

Request46 缺 Minutes：保留该条记录，并显示去 Approval Request 补录的原因，生成按钮禁用。这是建议的完整性控制；能否允许带缺口的草稿纪要，由业务确认。本页不添加另一份可独立编辑的 Minutes，也不触发 Mark As Complete。

### 4.5 报告生成后来源变化

![来源更新](NEO-014_Stale.png)

演示 Request46 从 version2 变成 version3。当前预览停止下载，用户 Refresh source 后重新生成 version2 报告。旧快照不被悄悄改写。正式系统需服务端一致读取和下载前校验；本设计只演示交互。

### 4.6 先导出，直发邮件另走配置

![邮件选项](NEO-014_Email.png)

Download report 真实下载自包含 HTML 文件，可打开核对。HTML 是本次审阅载体，不代表客户已确认最终 Word／Excel／PDF 模板。Email options 提示人工附邮件；直接 Send email 禁用，未伪造发送成功。后续如启用直发，需要确认发件人、会后收件人、CC、保密权限、失败和查重契约，不能自动套用会前 Agenda 的收件人。

## 5. 数据、系统和接口

| 页面字段／对象 | 已有来源定位 | 正式开发要明确 |
|---|---|---|
| Request ID、Request Type、Request Status、Approval Status | MCI_REQUEST 第1203–1206行。[S5] | ID、枚举与显示文案；CH Status 与 Request/Approval Status 不可混用。 |
| Forum、Agenda Date & Time | MCI_REQUEST.FORUM_ID / AGENDA_DATETIME，第1236–1237行。[S5] | timestamp without time zone 不能提供原始时区；同日多场、改期、历史参与记录与稳定会议键。 |
| Date Closed、Presenter、Minutes | 第1238–1240行；MINUTES varchar(2000)。[S5] | 展示正式保存内容；没有值不能生成假纪要；长文本不截断。 |
| Request → Lines | MCI_REQUEST_RISK_OPPORTUNITY，第670–680行。[S5] | 一对多关系、保留前导零；该表的 REJECTION_COMMENT 不等于完整逐 Line 决定。逐 Line 决定的权威来源需追溯审批记录。 |
| Action、Owner、Due Date、Completed | BRD FR10.1 已要求这些字段。[S3-28] | 本轮未建立完整 Action 表／接口逐字段映射；不可称 payload 已齐。 |
| Minutes 历史 | MCI_REQUEST_ARCH.MINUTES，第1308行。[S5] | 有归档列不代表每次会议有不可变快照，须确认归档及版本语义。 |
| 报告版本、生成时间、源版本集合 | 本条可靠性设计建议 | 本轮不是已存在数据库列或已批准 API；需后端定契约、保存／读取／审计及授权检查。 |
| 纪要报告读取／导出 | NEO 内部业务服务；未来由目标应用提供 | 不需要 SAP／WIPS 数据新接口；建议输入场次标识与访问上下文，输出授权申请、Lines、结果、Minutes和Actions；路径、payload和认证均待接口评审。 |
| 邮件 | 身份／邮箱及邮件服务；NEO 组织发送内容 | 可考虑复用 NEO-013 的发件通道和幂等机制；现有 outbox 是本地实现，不证明可复用生产 API。接口表未提供足以验收本条发送的契约。[S6/S10] |

## 6. Change 与 Impact

| 层 | 变更 | 不应产生的副作用 |
|---|---|---|
| 前端 | 新增会议纪要列表、只读明细、报告预览、空态／缺失／过期／生成失败状态 | 不重写现有 Minutes，不更改审批结果或业务状态。 |
| 后端 | 授权查询、会议历史关联、完整报告生成、版本快照和下载审计 | 不以浏览器过滤后的子集代替完整会议；不泄露其他权限范围记录。 |
| 数据库 | 先复用已证实 Request／Lines／Minutes；根据会议及版本缺口确认是否新增关联／快照存储 | 不为了报告猜测现有表结构，不把新 DTO 名称当历史字段。 |
| BPM | 本条报告不启动或结束审批流程；只读取已确认的处理结果 | Generate／Download 不等于 Mark As Complete、Implemented 或已发送通知。 |
| Integration | 基础版无新增外部调用；邮件直发按配置复用或补充内部通知服务 | 不新增未经要求的 SAP/WIPS 调用，不自动群发会后纪要。 |
| QA | 检查多场次、多个Line／部分批准、空态、缺纪要、源变化、导出对账、权限与UI | 独立设计测试不回填成现有产品通过，不替代既有审批完结问题验收。 |

## 7. 业务确认问题（人话＋例子）

| ID | 要确认什么 | 举例及建议 |
|---|---|---|
| Q01 | 什么算“同一场会议”？ | 同一天9点和14点两场，不能合并。建议用稳定会议标识＋Forum＋时间／时区；请提供现网定义或会议模板。 |
| Q02 | 纪要是否包含拒绝、退回及未决定事项？ | Request49没有结论也参加了会议。需求有“all items discussed”；建议保留并写明 Pending，不只列批准单。 |
| Q03 | 部分批准按什么粒度记？ | Request48有两条Line，一批一拒。建议逐Line保留决定，不把整条申请当全部通过；正式状态字典请确认。 |
| Q04 | Minutes空白能否出报告？ | Request46已批准但未写纪要。建议补完再生成；如业务要草稿导出，须明确草稿标识和不可作为执行依据。 |
| Q05 | 纪要后来改了，旧报告怎么办？ | 昨天发了v1，今天更正一个结论。建议保留旧版、生成新版并按批准流程通知；更正人和重发规则待确认。 |
| Q06 | Minutes到底允许多少字？ | 字典2000，当前控件4000。请确定数据库／接口／控件统一上限；已有超长数据不能截断。 |
| Q07 | 谁能生成和看整场纪要？ | 一场会议含多个CoC或保密单，普通FBP能否看到全部？管理员是否是新权限？建议使用明确授权的会议范围，不按角色名放开全部数据。 |
| Q08 | 最终导出格式和模板是什么？ | 本次提供可打开的HTML示例；请确认Word、Excel或PDF和必备栏目，以及是否要签字／审核后发布。 |
| Q09 | 会后发给谁，是否沿用议程名单？ | 会前邀请的人不一定有权限看全部会后决定。建议单独确认会后分发规则，不自动继承Buyer/PM/SPM及固定CC。 |
| Q10 | 改期后如何还原原会议？ | 同一申请先在13日讨论、16日再议，当前Agenda只剩16日。请确认从哪份历史记录取得13日结果，不能从最新日期猜。 |

## 8. 本地验证及退出条件

53 项本地检查通过，明细见 PAGE_VISUAL_CHECK.json（实际输入、预期、观察结果、浏览器、版本及时间）。验证对象仅是此独立合成页面。

已执行：上午4条／下午1条分离；搜索空态和恢复；Approved筛选仍生成整场4条／5 Lines；部分批准细分；拒绝／Pending保留；真实文件下载、打开并核对全部申请／Line／Minutes／Action／版本；缺Minutes阻断；过期阻断和重新生成；失败重试；无记录恢复；Buyer无入口和无表格；六种屏幕宽度、390px报告及弹窗、CSS 200%缩放、无外部网络请求和无页面运行错误。

尚未验证：真实业务规则、真实服务器鉴权和保密范围、存储／刷新恢复、事务一致性、正式会议／版本模型、真实邮件与回执、打印/Office格式、并发大数据性能、生产部署和业务UAT。CSS缩放不是原生浏览器缩放验收。当前4条会议数据不足以证明大规模性能。

本轮设计包退出条件：来源可追踪；独立页面可审阅；6张桌面图＋移动图；测试有实际结果；ZIP可解压且校验文件哈希。正式开发退出条件另需Q01–10的适用规则和契约确定；在真实权限／历史会议数据下完成读取、导出、回读及审计端到端验收。邮件扩展另验收，不因报告可下载就算发件通过。

下一项按原需求表进入 NEO-015；本轮不自动修改现有产品，也不把建议当已确认范围。

## 9. 来源索引

| Source | 文档／代码及定位 |
|---|---|
| S1/S2 | NEO Business Requirements (added China requirements) 1.xlsx：RTM for Requested Changes第15行；P1 CR clean第34行。 |
| S1-ID-A/B | 同工作簿 RTM - Archive第17行、NEO RTM第18行；只用来排除同ID异义。 |
| S3-12/13/28/29 | Material Cost & Inventory - BRD V3.1.docx：Table6行12/13/28/29，即FR5/5.1/10.1/10.2；均为1-based物理表行。 |
| S4 | NEO User Training.docx：正文段落980–1003，FBP/Finance Approver维护；Table8行3/5/6，Minutes与完结条件及Buyer通知。 |
| S5 | NEO_数据字典.xlsx，字段字典：670–680、1203–1254、1308；SOURCE_EVIDENCE逐行保留。 |
| S6 | Integrations - 2026-11-09_0941(Sheet 1).csv，全表注册信息；不是纪要生成或发件payload契约。 |
| S7 | outputs/neo-jira-stories-20261111/v3/story_data.json，ACT-017、ACT-057，Epic CNP-233。 |
| S8 | app/src/views/Approvals/FinanceRequestUpdate.tsx：financeSummaryFields及Minutes控件，原始行号保存在证据JSON。 |
| S9/S10 | app/src/views/Approvals/Agenda.tsx；app/src/domain/features/agenda-email/outbox.ts。 |
| S11 | app/src/theme/index.ts；独立包沿用未修改主题快照，哈希和依赖版本见design-source/SOURCE_MANIFEST.json。 |
| S12 | outputs/NEO_143_Page_Screenshots_20261104/scope.json，P11/P11.1/P13。 |
| S13 | 唯一现有QA模型 review-data.json，NQA-94/NQA-114及TRN-AR-CLOSURE-01；只读引用，没有写入或改变历史结果。 |

以上 source 路径均在 SOURCE_EVIDENCE.json 中保存为实际绝对路径及SHA；引用旧材料不等于确认当前生产实现。
