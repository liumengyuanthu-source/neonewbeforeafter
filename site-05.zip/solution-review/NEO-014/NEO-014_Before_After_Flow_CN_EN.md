# NEO-014 · Before / After process

Priority: Must (Procurement: —; Finance: Must)

ACT-017 / ACT-057 · FR5 / FR5.1 / FR10.1 / FR10.2

## 导出完整的 Clearing House 会议纪要

将已有申请纪要、逐 Line 结果和行动项汇成一份场次报告；首选下载后人工发邮件。

### Before · 现有路径

1. **FBP · 维护各申请的会议结果** — 当前已有 Request 纪要、状态及审批历史；不应再建一份重复录入的纪要表。
2. **会议组织人 · 汇总并分发** — 需求要求将分散的纪要与批准／拒绝结果汇成完整报告。

### After · 建议路径

1. **有权 FBP／组织人 · 选择完整会议场次** — 加载该场次全部授权 Requests、Lines、决定、纪要及行动负责人／日期。
2. **组织人 · 补齐缺失纪要** — 缺哪项就提示哪条 Request，并链接现有编辑页；不伪造缺失内容。
3. **NEO／组织人 · 生成并预览版本化报告** — 保留逐 Line 批准／拒绝和行动项。屏幕搜索筛选不能悄悄缩小整场报告。
4. **组织人 · 下载并人工分发** — 生成后若来源变化，先刷新重生成；下载当前版本后可按现有方式作为邮件附件。

### 例子

示例：Request 48 中 Line 59 批准、Line 60 拒绝，报告必须分开列出，不能把整个 Request 写成 Approved。Request 46 缺纪要时，应先返回补齐。

### 保留控制

- 报告不执行审批或 Mark As Complete；来源记录决定状态。
- 先交付报告下载，不把直接发送邮件当作必需的新集成。

### 正式实施前补齐

- 业务确认会议场次范围、纪要必填内容和报告模板；逐 Line 结果须由现有审批记录提供。

## Export complete Clearing House minutes

Combine existing request minutes, line-level outcomes and actions into a session report; start with download and manual email attachment.

### Before · Existing path

1. **FBP · Maintain each request’s meeting outcome** — The current design already has request minutes, states and approval history; avoid a second minutes-entry form.
2. **Meeting organiser · Compile and distribute** — The requirement asks to consolidate distributed minutes and approved / rejected outcomes into a complete report.

### After · Proposed path

1. **Authorised FBP / Organiser · Select the full meeting session** — Load all authorised session requests, Lines, decisions, minutes and action owners / dates.
2. **Organiser · Resolve missing minutes** — Identify the request with missing content and link to its existing editor; do not invent missing minutes.
3. **NEO / Organiser · Generate and preview a versioned report** — Preserve line-level decisions and actions. Screen filters must not silently reduce the full-session report.
4. **Organiser · Download and distribute manually** — If sources change after generation, refresh and regenerate. Download the current report and attach it using the existing email process.

### Example

Example: Request 48 has Line 59 approved and Line 60 rejected. Show both outcomes rather than labelling the whole request Approved. Resolve missing minutes on Request 46 before completing the report.

### Controls retained

- The report does not approve or Mark As Complete; source records determine status.
- Deliver report download first; direct email is not a mandatory new integration.

### Production dependencies

- Business owners confirm session scope, mandatory minutes and the report template; line-level outcomes must come from existing approval records.

## Sources

- **R-1113** NEO Business Requirements (added China requirements) 2(RTM for Requested Changes)_1113 1400 version.xlsx · NEO Business Requirements (adde!E15,N15,P15,Q15; priorities K15:L15
- **S1** NEO Business Requirements (added China requirements) 1.xlsx · RTM for Requested Changes row 15
- **S3-12** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 12 (1-based)
- **S3-13** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 13 (1-based)
- **S3-28** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 28 (1-based)
- **S3-29** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 29 (1-based)
- **S4** NEO User Training.docx · Body paragraphs 980–1003; Table 8 rows 3,5,6 (1-based)
- **S6** Integrations - 2026-11-09_0941(Sheet 1).csv · All CSV records; report/mail contract not established by this register
- **S8** FinanceRequestUpdate.tsx · Numbered source lines
- **S2** NEO Business Requirements (added China requirements) 1.xlsx · P1 CR clean row 34

Before: frozen prototype `3ff8bc0b158ba08f2302e7404bb6185a553088c78614051451e6b5137a26802e`. Historical problems are labelled separately. After is a proposal; numerical examples are illustrative. Production execution: NOT RUN.
