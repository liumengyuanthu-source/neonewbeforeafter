# NEO-013 · Before / After process

Priority: Should (Procurement: —; Finance: Should)

ACT-057 / ACT-017 · FR10.1 / FR10.2

## 完整的 Clearing House 议程邮件

沿用现有 Agenda Email，补齐议程内容与收件人检查；不新增会议日历流程。

### Before · 现有路径

1. **FBP／有权组织人 · 选择 Requests** — Training 和当前页面已有选申请、Next、收件人、主题与正文步骤。
2. **FBP／有权组织人 · 提交 Agenda Email** — 当前原型保存本地 Outbox；存在按钮不等于公司邮件已送达。

### After · 建议路径

1. **FBP／有权组织人 · 选场次和需讨论的申请** — 核对会议日期、每项时间、申请、Lines 和所需 GSPM 信息。
2. **NEO／组织人 · 解析并核对收件人** — 沿用授权的 Buyer／PM／SPM、额外收件人和固定 CC 规则；缺人员映射就提示对应申请。
3. **组织人 · 预览完整议程** — 同一预览展示时间、申请、Lines、主题、正文与收件人；信息变化后重新预览。
4. **邮件服务／组织人 · 提交并跟踪发送结果** — 以同一发送编号入队；区分 Queued、Sent、Failed／Unknown，未知结果先查再重发。

### 例子

示例：Request 46 安排 10:00、Request 47 安排 10:15。预览应包含各自 Lines、时间和所需人员，而不是只有两个申请编号。

### 保留控制

- GSPM 信息不自动等于新增收件人；依原收件人规则。
- 发送失败保留内容；Agenda Email 不批准申请，也不创建日历邀请。

### 正式实施前补齐

- 确认议程模板必填项及当前团队映射；IT 提供发件人、通道和发送回执契约。

## Complete Clearing House agenda emails

Keep Agenda Email and complete its content and recipient checks; do not add a calendar workflow.

### Before · Existing path

1. **FBP / Authorised organiser · Select Requests** — Training and the current page already provide request selection, Next, recipients, subject and body.
2. **FBP / Authorised organiser · Submit the agenda email** — The current prototype stores a local Outbox entry; the button does not prove delivery through corporate email.

### After · Proposed path

1. **FBP / Authorised organiser · Select the session and requests** — Review meeting date, item time, requests, Lines and required GSPM information.
2. **NEO / Organiser · Resolve and review recipients** — Retain authorised Buyer / PM / SPM, additional-recipient and fixed-CC rules; identify the affected request when a mapping is missing.
3. **Organiser · Preview the complete agenda** — Preview item times, requests, Lines, subject, body and recipients together; refresh the preview after a source change.
4. **Email service / Organiser · Submit and track the send result** — Queue under one send reference; distinguish Queued, Sent and Failed / Unknown, and check an unknown outcome before resending.

### Example

Example: Request 46 is scheduled for 10:00 and Request 47 for 10:15. The preview includes each request’s Lines, time and required people, rather than just two request numbers.

### Controls retained

- GSPM information does not automatically create an additional recipient; retain the agreed recipient rule.
- Keep content after send failure; an agenda email neither approves requests nor creates a calendar invitation.

### Production dependencies

- Confirm required agenda fields and current team mappings; IT supplies the sender, channel and send-receipt contract.

## Sources

- **R-1113** NEO Business Requirements (added China requirements) 2(RTM for Requested Changes)_1113 1400 version.xlsx · NEO Business Requirements (adde!E14,N14,P14,Q14; priorities K14:L14
- **S1** NEO Business Requirements (added China requirements) 1.xlsx · RTM for Requested Changes!A14:Y14
- **S3-27** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 27 (1-based)
- **S3-28** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 28 (1-based)
- **S3-29** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 29 (1-based)
- **S3-CR22** Material Cost & Inventory - BRD V3.1.docx · Table 8 row 2 (1-based)
- **S4** NEO User Training.docx · Body paragraphs 1504–1532 (1-based)
- **S6** Integrations - 2026-11-09_0941(Sheet 1).csv · All CSV records; no explicit agenda-mail contract found
- **S9** Agenda.tsx · Numbered source lines
- **S10** outbox.ts · Numbered source lines
- **S2** NEO Business Requirements (added China requirements) 1.xlsx · P1 CR clean!A33:Y33

Before: frozen prototype `3ff8bc0b158ba08f2302e7404bb6185a553088c78614051451e6b5137a26802e`. Historical problems are labelled separately. After is a proposal; numerical examples are illustrative. Production execution: NOT RUN.
