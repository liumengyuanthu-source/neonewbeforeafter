# NEO-013 · Clearing House 议程邮件

<!-- FLOW-REVIEW-20261116 -->
## 16 Nov 2026 · 流程评审补充

[中英文 Before / After 流程](NEO-013_Before_After_Flow.html) · [流程说明 MD](NEO-013_Before_After_Flow_CN_EN.md)

沿用现有 Agenda Email，补齐议程内容与收件人检查；不新增会议日历流程。

本轮为流程说明补充；原交互页面、问题及历史证据保留。正式实施前需补齐：确认议程模板必填项及当前团队映射；IT 提供发件人、通道和发送回执契约。
<!-- /FLOW-REVIEW-20261116 -->

## 1. 需求与已有基础

FBP 或 Clearing House Administrator 希望从 NEO 生成完整、准确的议程邮件，让相关人员知道讨论哪些 Request、何时讨论、谁需要参与。[S1]

本条锁定新需求文件 **RTM for Requested Changes 第14行**，关联 **P1 CR clean 第33行／CR22／APPIAN-17170**。CR22明确指出邮件缺少时间、GSPM等必要字段，当前依赖人工填写议程。原表写 Should；“In Dev / Test”“部分开发、未部署”和“功能不工作”是来源记录，不代表本轮对现网的诊断。未访问 Jira，未测试现网邮件。[S1、S2]

其他Sheet中的NEO-013分别是Line详情和建单字段，不属于这项议程邮件需求；不能按编号直接合并。[S1-ID-A／B]

Training已经有“选多个Request → Next → 查看Buyer／PM／SPM及增加邮件地址 → 编辑Subject／Body → Submit”。BRD FR10.1还要求包含Line Items、关联Buyer／PM／SPM邮件及固定CC。当前React源码已有两步表单、地址校验、权限、版本检查和本地Outbox；本条应补齐缺口，不再另造一套审批流程。[S3-28、S4、S9、S10]

## 2. 分类、优先级与追踪

| 项目 | 结论 | 依据及边界 |
| --- | --- | --- |
| 主要改动类型 | Application内部前后端：议程读取、模板、身份解析、收件人校验、发件记录及结果回读；附带UXUI | 不只是调整邮件样式 |
| UXUI only | 否；字段显示可以先独立评审，实际发信仍依赖后端和邮件通道 | 当前本地Outbox不是真实邮件服务 |
| Integration needed | 邮件发送服务；用户身份／邮箱来源；固定CC配置 | 具体是现有JLR邮件通道、连接器或其他方式，现有材料未确认 |
| 现有接口复用 | 现有Appian发送能力可作为迁移调查起点；已收到的Integration登记未提供本功能邮件契约 | 不能凭“23个接口”认定已包含邮件发送；不编造Graph／SMTP实现 |
| 新架构 | 无依据要求新平台；优先复用已批准身份和通知服务，补队列／幂等／状态回读能力 | 如无现成能力，再评审新增服务或连接器；不自动采购或接外部平台 |
| Priority | 原表Should；建议P0确认模板与角色邮箱，P1修复生成和分发链路 | ACT-057旧Story标Must，保留差异，不静默改成统一已批准优先级 |
| Epic | CNP-233 · Authorisation | S8本地Story定义，不代表本轮写入Jira |
| User Story | 主ACT-057 Clearing House Agenda Email；关联ACT-017 Update Approval Request-FBP | ACT-017负责原Request议程时间维护，本页不代替改原Request |
| FR | 主FR10.1及BRD附录CR22；关联FR10列表、FR10.2议程维护 | 邮件不增加审批级别、不触发批准、不改变实施状态 |
| UC场景 | 选议题、核对内容与收件人、提交、失败恢复／结果查重 | 沿用ACT-057；未找到本子场景已批准的独立UC编号，不新造正式编号 |
| Page | P11 Approval Requests — List → P11.1 Create Email Clearing House Agenda | 选单与内容是同一功能的两步；预览是核对视图，不新增三级页面编号 |
| 交付范围 | 独立合成页面、评估、来源、问题、截图及本地检查 | 没有修改NEO prototype、共享QA或生产；没有发送邮件 |

## 3. 已确认什么，尚缺什么

| 主题 | 有证据的内容 | 需要确认／当前边界 |
| --- | --- | --- |
| 入口与两步 | Approval Requests中的议程邮件入口；FBP组；先选单，再编辑邮件 | 新需求增加Administrator称谓，具体Group及授权未给出。样例仅演示FBP和无权限Buyer |
| 多条Request | Training允许多选Request；BRD要求邮件展示所含Line | 跨CoC、跨Forum、机密Request能否同发，需要权限与信息披露规则 |
| 时间 | FR10.1已有Agenda Date & Time；CR22明确缺time | 字典AGENDA_DATETIME没有时区，不能默认为UK；样例Europe/London不是签收配置 |
| 未设时间 | NQA-114明确：不按日期筛选时，空日期也可选择 | 保留这个行为；是否发送前必须补齐日期，以及跨日期邮件政策待确认 |
| 人员 | Training显示Buyer／Purchasing Manager／Senior Purchasing Manager；BRD自动收件人和固定CC | CR22的GSPM是否等于Training的SPM没有明确依据；姓名、邮箱、委托和生效时点均须提供 |
| 当前实现 | 本地prepareAgenda解析关系，saveAgenda校验版本／收件人并写workspace agenda-outbox | 写本地Outbox、在Notifications看到内容，不能证明邮件已经发出或到达 |
| 邮箱 | 本地源码使用example.test字典，对未知人员存在拼接example.test的fallback | 正式开发必须用真实受控身份解析，缺失即明确处理，不能拼一个邮箱假装可用 |
| 邮件状态 | 需要可靠记录发信结果 | 已收资料没有provider receipt、delivery／bounce、超时回读及重试契约；本页结果均为演示状态 |

NQA-114是已存在的确认及历史本地验证，本包只读引用，不重写它，也不把它当作当前端到端邮件验收。[S14]

## 4. 页面与操作

沿用NEO主题、JLR Emeric、Ant Design，以及32／24／16px页边距。保留两步，收件人信息逐Request展示；来源和未决政策放在评估中，不塞进日常页面说明。顶部独立评审条可切换七个合成场景。

### 4.1 选择议题

Ben Taylor／FBP Officer进入P11.1，默认查看13 Nov 2026。勾选Request 46、47，再点Next。表格前部为Select、Actions、Request ID，眼睛图标查看详细内容。列包含类型、时间、描述、Line、人员、金额、版本，以及Background、Problem Statement、Request Details、Risks／Opportunities、Buyer Code。

![选单与议程时间](NEO-013_Page_Overview.png)

按指定日期筛选时，其他日期和空日期不可选且说明原因；切换日期清空旧选择并提示。选All dates时保留空日期可选择的既有行为；预览会提醒缺日期，不自行补一个时间。Cancelled不能选择，沿用所查当前源码边界。选择取消、机密和无权限请求的最终规则仍须服务端验证。日期控件、日期切换处理属于本轮建议，不冒充旧截图已有交互。

### 4.2 核对收件人、编辑邮件

第二步显示每条Request的Buyer、Purchasing Manager、Senior Purchasing Manager及Additional E-mail。固定CC独立显示。可修改Email Subject／Email Body，Previous保留内容和选择，Cancel经确认后丢弃未提交内容。

![邮件内容与收件人](NEO-013_Page_Content.png)

使用alice.morgan@example.test、bob.wilson@example.test等合成邮箱，不发送。输入not-an-email会阻止预览。附加邮箱支持空格／逗号／分号分隔。对同一个邮箱去重，固定CC不重复进入To。正式身份、邮箱语法、外部域名、代理和机密权限策略待确认；示例邮箱校验并非完整生产安全校验器。

### 4.3 预览实际要提交的内容

点击Preview email核对To、固定CC、Subject、正文和完整议题表。Agenda Date、Time、人员及Line必须来自所选Request，不手工另抄。横向滚动可查看全部字段，包括单独的GSPM列。

![邮件预览](NEO-013_Page_Preview.png)

GSPM展示Eva Brooks、SPM展示David Hughes，仅用来说明两者可以是不同字段，**不是确认这两个人的实际职责或批准新的映射**。GSPM在本例中只作为议题信息，没有自动加入收件人。是否应参与收件、GSPM与SPM是否同义，必须确认后再绑定。

页面保留完整议题字段以便评审；最终邮件在Outlook等客户端的布局、是否附Excel／PDF和每行字段模板还未签收。本包没有生成真实邮件／附件，没有验证邮件客户端显示。邮件不创建日历邀请、会议链接或RSVP，不把“通知正确的人”扩成已授权的Calendar集成。

### 4.4 缺信息时保留内容，指出具体Request

Recipient missing场景下，Request 46的SPM邮箱缺失，页面直接说明，阻止预览。Fixed CC unavailable场景也保留内容，不默默漏掉CC。正常操作不会自动编造缺失邮箱。

![缺失收件人的定位](NEO-013_Page_Missing.png)

这是建议控制；正式系统由身份／配置维护入口处理，不在本页伪造一个Override审批按钮。管理员具体角色及豁免是否允许，见问题清单。

### 4.5 提交未知结果先查，再决定是否重发

Submit经确认后，正常场景显示Queued；这只表示已接收，不等于Delivered。Submission rejected表示模拟明确未受理，可Retry，保留原Subject和内容。Submission result unknown禁止再次Submit，使用同一个Submission reference执行Check submission status，样例回读Queued。

![结果未知时避免重复发送](NEO-013_Page_Unknown.png)

这只是内存状态演示：没有实际邮件供应商、幂等键服务、后台队列或真实回调。刷新页面会重置。生产必须先按同一operation ID查询，查清失败后才重试；不得凭页面超时新建一封邮件。部分收件人失败、退信及跨刷新恢复尚未实现或验证。

### 4.6 提交留痕与版本检查

正常结果显示Submission reference、提交人、Request IDs、内容和Queued状态，Submit禁用，避免重复点。Request changed after preview场景先拒绝提交，Refresh and review后显式显示Request 46版本3，再允许重新核对提交。

![已接受但未确认送达](NEO-013_Page_Queued.png)

实际实现还应保留原Request版本、Line范围、收件人及配置版本、模板版本、内容hash、提交时间、provider message ID和每个收件人的结果。不能在人员或议程时间变化后静默发送旧预览。这些是设计建议，不是当前数据字典已有全部字段。

## 5. 字段与系统接口

| 字段／信息 | 当前来源定位 | 建议链路／缺口 |
| --- | --- | --- |
| Request ID、类型、状态 | MCI_REQUEST，字段字典1203–1206行 | 沿用授权Request；保留正式ID与内部key区别 |
| Background／Problem Statement／Details | MCI_REQUEST，1208–1210行 | 生成模板读取；不可因邮件简化删掉必要信息 |
| Request Value／Risks／Opportunities | MCI_REQUEST，1211–1213行 | 读取已确认币种及版本，不在邮件端重算审批金额；样例全GBP |
| Agenda Date & Time、Forum、Presenter | MCI_REQUEST，1236–1239行 | 由FR10.2维护；AGENDA_DATETIME为无时区timestamp，需补明确显示和转换契约 |
| Buyer／PM／SPM关系 | MCI_BUYER_CODE 1738–1745行；MCI_COC_USER_MAPPING 1772–1781行；MCI_PM_CODE 1782–1789行；SPM表见S5 | 从业务关系解析到用户身份，再取邮箱；字典没有提供实际成员／邮箱配置 |
| GSPM | CR22要求该字段；MCI_REQUEST.IS_GSPM第1241行是tinyint标志 | 不能把IS_GSPM布尔值当姓名或邮箱；GSPM身份映射待确认 |
| Line IDs与一请求多Line | BRD FR10.1；当前outbox使用request.snapshot.lineRefs | 原字典关联键、版本粒度与目标DTO须结合schema核定，不凭显示列表猜物理外键 |
| 固定CC／额外邮件 | BRD固定CC；Training Additional E-mail | CC配置、生效范围、域名限制、信息披露权限；不是直接允许任意邮箱读取机密信息 |
| Subject／Body | Training可编辑；当前代码255／4000字符 | 本页沿用当前代码限制，不称为已签收业务上限；模板版本待提供 |
| 发件主体／通道 | BRD说Appian可生成邮件；现有Integration目录无明确议程邮件契约 | 确认当前Appian邮件设施及目标平台如何复用，不虚构接口URL和payload |
| 排队、投递、失败 | 当前本地outbox receipt | 需补服务端operation ID、状态、provider ID、错误与重试契约；Queue不等于Delivery |

建议应用请求应包含：operation ID、actor、所选Request IDs和已核对revision、agenda scope及timezone、subject、body、每条附加收件人。服务端重新校验授权、人员、固定CC及内容版本，再固化实际To／CC、模板／内容和请求快照。客户端传入邮箱不能直接替代服务端权限检查。

建议返回submission ID、Accepted／Rejected／Unknown等状态及可回读标识；邮件供应商字段、接口路径、枚举和重试码均待契约确认。日历、SAP、WIPS不应因本需求新增业务调用。Scheduler材料只提供已有调度信息，不能据此断言议程邮件由某个SLA Job发送。[S5–S7、S10]

## 6. 修改与影响

| 层 | 需要做什么 | 验证重点 |
| --- | --- | --- |
| UXUI | 复用两步、显示时间／GSPM、预览To与CC、具体缺失提示、提交结果 | 原字段完整；Previous／Cancel／筛选／窄屏；没有诊断文案堆在业务页 |
| 应用前后端 | 同一读取模型生成预览与邮件；实际权限复核；快照及版本冲突 | 预览和发送内容一致；不能发送不可见Request；取消不发送 |
| 身份与配置 | Buyer／PM／SPM／GSPM、Administrator、固定CC、委托和邮箱 | 不拼接未知邮箱；跨CoC／停用／无邮箱有可理解错误 |
| 通知基础能力 | 复用现有通道，提供受理、回执、失败与回读 | 超时不重复、部分失败不全量误重发、邮件不等于Calendar |
| 数据与审计 | 保存请求／配置／模板版本、实际收件人和发送事件 | 访问和保留策略；历史邮件不随主数据变化重写 |
| 流程影响 | 议程沟通辅助Clearing House | 不改变DoA、审批结果、SLA或Claim实施状态 |

## 7. 讲人话的问题清单

| ID／优先级 | 要确认什么，举个例子 | 建议／影响 | 谁来确认 |
| --- | --- | --- | --- |
| Q01 P0 | 请给一份现在发出的议程邮件和期望版本，具体缺哪些列？例如09:00是会议开始时间还是每个议题时间？ | 按原版差异修补，避免把会议时间和议题时间混用 | Linda Dawson／FBP／Clearing House负责人 |
| Q02 P0 | CR22的GSPM和Training的SPM是同一个角色吗？如果是不同人，GSPM只是显示还是也要收邮件？ | 不用IS_GSPM布尔值推一个姓名；样例分开显示不代表已定规则 | 采购／FBP及身份维护团队 |
| Q03 P0 | Clearing House Administrator属于哪个现有Group？可以跨CoC发邮件吗？ | 默认仅已有授权FBP；新角色权限确认后再开放 | 业务Owner／安全权限团队 |
| Q04 P0 | 固定CC名单是什么？人员从哪套名册取邮箱，缺一个人时能否继续发送？例如PM停用但替代人未维护。 | 建议缺必要映射先阻止，不生成假邮箱；豁免须业务明确 | Clearing House管理员／身份团队 |
| Q05 P0 | 一封邮件是否只能一个日期／Forum？空日期Request能否发？13日和16日的两条Request能否同发？ | 保留All dates可选空日期；若要求限制发送，应另签收规则 | FBP／会议管理员 |
| Q06 P0 | 邮件通过什么通道发送，怎样知道已受理／送达？提交超时后用什么编号查询？ | 复用受控通道；未知先查，不重新生成重复邮件 | 现Appian团队／目标平台与邮件团队 |
| Q07 P0 | 额外邮箱是否允许外部人员或其他CoC？如一条含机密供应商价格，能否发给不在该Request权限里的经理？ | 提交时校验信息披露；默认不扩展记录访问授权 | 业务Owner／安全／数据保护负责人 |
| Q08 P1 | “邀请正确的人”是否要求真正Outlook日历邀请、Teams链接和RSVP？ | 本条先按证据做邮件；如需日历，单独确认接口及增量范围 | Clearing House负责人／协作平台团队 |
| Q09 P1 | 时间按哪个时区？英国与中国同一会议怎样显示？邮件中的金额用哪个已批准币种？ | 模板明确时区／币种，不能从浏览器地区或示例推规则 | FBP／Finance |
| Q10 P1 | 已发议程后Request时间、金额或人员变了，要重发修订版吗？部分人员退信怎么处理？ | 保留原版本，显式生成修订；重试只针对允许的失败范围 | FBP／邮件运维／审计 |

问题未签收不影响独立页面评审，但会影响真实权限、完整模板、接口及业务验收。

## 8. 本地检查与退出条件

68 项本地交互／布局检查实际通过；预期和实际逐项保存在PAGE_VISUAL_CHECK.json。包含选择资格、两步回退、附加邮箱去重、固定CC、字段校验、预览、取消、已受理与未送达区分、未知结果查重、明确拒绝后重试、版本变化重审，以及六种宽度和200% CSS缩放。浏览器请求监测未发生HTTP／HTTPS外部请求。

| 场景 | 输入／操作 | 预期与观察 |
| --- | --- | --- |
| 正常邮件 | Ben Taylor；46＋47；附加ALICE.MORGAN@example.test、analyst@example.test及固定CC同址 | To为5个唯一地址；CC1个；含09:00／09:30、Line及GSPM列；提交后Queued而非Delivered |
| 缺失邮箱 | Request46缺SPM邮箱 | 指出Request46；保持内容、不进入可提交预览 |
| 固定CC缺失 | CC unavailable | 明确提示；不静默漏发 |
| 未知结果 | Submit后模拟未知；Check submission status | 重发禁用；同一AGENDA-EXAMPLE-001回读Queued |
| 版本变化 | 预览v2，提交时发现变化 | 拦截；Refresh and review后v3重新预览 |
| 无权限 | Alice Morgan／Buyer | 无Request列表和发送操作 |
| 空日期 | All dates选择49 | 保留可选；不虚构日期，预览显示提醒 |

记录、时间、姓名、To／CC、队列结果均为合成fixture。GSPM展示映射、邮箱语法、时区、接收人信息披露规则及完整邮件模板尚未签收。本地权限检查不能代表服务端安全；版本变化和未知回读使用显式评审场景，不代表真实并发、持久化或网络故障已验证。

未执行：真实身份接口、真实邮件／日历发送、收件箱／退信回执、部分失败、机密内容泄漏测试、跨刷新去重、完整历史查询、生产性能、邮件客户端渲染及业务验收。发信Outbox的实际持久化仍需与主项目实现对接。本包不更新原产品的PASS状态。

设计退出：需求、字段、现有代码差异、页面、问题和来源可核对。正式实现退出：业务签收模板及角色；取得邮箱与邮件契约；同一Request版本从预览到发送内容一致；完整接收人、To／CC、未知／失败／重复／权限及审计有实测；邮件服务结果与业务期望通过后才称端到端完成。

下一条：NEO-014，继续按原需求Sheet顺序独立评估。

## 9. Reference

| ID | 精确位置 | 用途 |
| --- | --- | --- |
| S1 | 新需求Workbook，RTM for Requested Changes!A14:R14 | NEO-013原需求、Should |
| S2 | 同Workbook，P1 CR clean第33行，A33=22、D33、M33–Y33 | CR22缺time／GSPM、历史状态与Linda／Jira线索 |
| S1-ID-A／B | RTM - Archive第16行；NEO RTM第17行 | 排除重名编号的其他需求 |
| S3-27／28／29 | Material Cost & Inventory - BRD V3.1.docx，表6第27／28／29行（1-based） | FR10／10.1／10.2；固定CC和议程邮件描述 |
| S3-CR22 | 同BRD，表8第2行（1-based） | Clearing House Agenda Emails变更描述 |
| S4 | NEO User Training.docx，正文段落1504–1532（1-based） | 选单、收件人、校验、编辑、Previous／Cancel／Submit |
| S5 | NEO_数据字典.xlsx，字段字典；具体行号见第5节及JSON | Request／组织字段；IS_GSPM不可当姓名 |
| S6 | Integrations - 2026-11-09_0941(Sheet 1).csv，完整登记 | 未提供本功能邮件契约；不能证明不存在未登记通道 |
| S7 | Scheduler Processes - 2026-11-09_0944.xlsx，Sheet 1 | 已有调度，非议程邮件接口依据 |
| S8 | outputs/neo-jira-stories-20261111/v3/story_data.json，ACT-057／017 | Epic／ACT／FR |
| S9／10／11 | 当前React src/views/Approvals/Agenda.tsx；domain/features/agenda-email/outbox.ts；views/Approvals/RequestList.tsx | 逐行当前代码：两步、local outbox、入口；未重新验收整个产品 |
| S12 | 当前React src/theme/index.ts | 原样复用主题 |
| S13 | NEO_143_Page_Screenshots_20261104/scope.json，P11／P11.1 | 原有页面编号 |
| S14 | 原QA review-data.json，NQA-114 | 用户已确认的两步、字段与空日期行为；历史本地验证边界 |

SOURCE_EVIDENCE.json保留19条来源记录的原文、绝对路径、定位及SHA。不同版本Training的段落号不混用：本轮直接提取上述技术包Word的1504–1532；NQA-114中的另一段落定位保留为其历史来源，不改写。
