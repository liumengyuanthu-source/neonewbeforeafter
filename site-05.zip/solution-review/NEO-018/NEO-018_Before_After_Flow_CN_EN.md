# NEO-018 · Before / After process

Priority: Must (Procurement: Must; Finance: Must)

ACT-001 / ACT-004 / ACT-029 / ACT-041 / ACT-062 · FR1.6 / FR8 / FR13 / FR17.5 / FR19.13 / FR19.14

## 接入 S4 供应商、价格和收货数据

保留 Buyer 的选零件和 Finance 的 Reserve 链路；补齐其依赖的 S4 数据，不让页面自行猜来源。

### Before · 现有路径

1. **Buyer／Finance · 使用现有零件与计算页面** — 当前原型使用示例主数据；有价格、FTO、GR 和汇率结构，不证明 S4 接口已经接通。
2. **历史需求记录 · S4 工厂数据覆盖不足** — 需求指出旧 ECC 数据不能满足 S4 工厂的当前价格和收货计算；已有 S4 下游任务不补足上游数据。

### After · 建议路径

1. **S4／集成服务 · 接收四类数据** — 按待确认 FS 接收供应商、Part／Price、Vehicle Line、GR；记录批次、期间和来源。
2. **集成／数据服务 · 映射身份并校验** — 保留 S4 BP 与 NEO GSDB 的独立身份；核对组织、工厂、UOM、币种和有效期。异常隔离，不覆盖有效数据。
3. **数据服务 → Buyer／Finance · 发布可信版本供既有页面使用** — 按已确认来源规则合并 S4 与旧工厂范围。价格供起始价与影响计算，GR 供适用 Reserve 计算。
4. **审批／实施流程 · 批准后走对应实施路线** — 沿用授权；按工厂／交易类型送往对应下游，读取回执后更新结果。

### 例子

示例：Halewood 的当前价格由 S4 提供，Solihull 仍取其有效来源。同一 Claim 可包含两者，但不能把同一笔收货的 ECC 与 S4 数据重复相加。

### 保留控制

- GR 不等于 E2SC 未来预测，也不替代 FTO；读取失败不等于零数量。
- 接口目录和 FS 标题不证明 payload、认证、增量和冲销规则已确认。

### 正式实施前补齐

- 取得 S2P-I034／035／036／037 正文及样例；确认 BP–GSDB 映射、价格单位、GR／SBI／冲销与切换期去重。

## Ingest S4 supplier, price and goods-receipt data

Keep the Buyer’s part-selection and Finance Reserve journeys; provide their S4 data rather than guessing its source in the UI.

### Before · Existing path

1. **Buyer / Finance · Use existing part and calculation pages** — The prototype uses fixture master data with price, FTO, GR and FX structures; these do not establish a live S4 integration.
2. **Historical requirement · Reported S4 plant coverage gap** — The request identifies ECC data gaps for S4 prices and receipts; an existing downstream S4 task does not fill the upstream gap.

### After · Proposed path

1. **S4 / Integration service · Receive the four data sets** — Receive supplier, Part / Price, Vehicle Line and GR data under the agreed FS contracts, with batch, period and source lineage.
2. **Integration / Data service · Map identities and validate** — Keep S4 BP and NEO GSDB identities distinct; validate organisation, plant, UOM, currency and validity. Quarantine exceptions without overwriting valid data.
3. **Data service → Buyer / Finance · Publish a reliable version for existing pages** — Combine S4 and legacy plant coverage under the agreed source rules. Prices feed start-price and impact calculations; GR feeds applicable Reserve calculations.
4. **Approval / Implementation flow · Use the corresponding route after approval** — Retain authorisation and route by plant / transaction type, updating outcomes after confirmed receipts.

### Example

Example: S4 supplies the current Halewood price while Solihull keeps its valid source. One Claim can include both, but the same goods receipt must not be counted from both ECC and S4.

### Controls retained

- GR is not E2SC future forecast and does not replace FTO; a failed read is not zero volume.
- Interface listings and FS titles do not establish payload, authentication, delta or reversal rules.

### Production dependencies

- Obtain S2P-I034 / 035 / 036 / 037 specifications and samples; confirm BP–GSDB mapping, price units, GR / SBI / reversals and cutover deduplication.

## Sources

- **R-1113** NEO Business Requirements (added China requirements) 2(RTM for Requested Changes)_1113 1400 version.xlsx · NEO Business Requirements (adde!E19,N19,P19,Q19; priorities K19:L19
- **S1** NEO Business Requirements (added China requirements) 1.xlsx · RTM for Requested Changes row 19
- **S3-8** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 8 (1-based)
- **S3-19** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 19 (1-based)
- **S3-38** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 38 (1-based)
- **S3-47** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 47 (1-based)
- **S3-65** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 65 (1-based)
- **S3-66** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 66 (1-based)
- **S6** master-data.ts · Numbered source lines
- **S8** calculation.ts · Numbered source lines
- **S14** Integrations - 2026-11-09_0941(Sheet 1).csv · All CSV records; IDs1–4 / SAP via Apigee do not establish S4 FS payloads
- **S2** NEO Business Requirements (added China requirements) 1.xlsx · P1 CR clean row 40

Before: frozen prototype `3ff8bc0b158ba08f2302e7404bb6185a553088c78614051451e6b5137a26802e`. Historical problems are labelled separately. After is a proposal; numerical examples are illustrative. Production execution: NOT RUN.
