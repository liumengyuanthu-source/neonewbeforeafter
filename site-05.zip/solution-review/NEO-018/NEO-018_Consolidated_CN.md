# NEO-018 · S/4HANA供应商、零件价格、车型和收货数据接入

<!-- FLOW-REVIEW-20261116 -->
## 16 Nov 2026 · 流程评审补充

[中英文 Before / After 流程](NEO-018_Before_After_Flow.html) · [流程说明 MD](NEO-018_Before_After_Flow_CN_EN.md)

保留 Buyer 的选零件和 Finance 的 Reserve 链路；补齐其依赖的 S4 数据，不让页面自行猜来源。

本轮为流程说明补充；原交互页面、问题及历史证据保留。正式实施前需补齐：取得 S2P-I034／035／036／037 正文及样例；确认 BP–GSDB 映射、价格单位、GR／SBI／冲销与切换期去重。
<!-- /FLOW-REVIEW-20261116 -->

本轮是独立页面及集成方案，未修改现有NEO prototype、共享QA、接口、数据库或线上系统。页面英文，评估中文。代码、价格、BP、订单／收货数量及版本均为合成审阅数据，不是从SAP读取的结果；未执行财务计算、Reserve生成或下游任务派发。

## 1. 原需求与证据

Halewood转到S4后，继续依赖ECC的旧价格／收货数据会使起始价格和Actual Financial Impact、Reserve输入不完整。需求要求从S4取得Supplier、Part／Price、Vehicle Line、GR，并处理S4 BP与NEO GSDB的对应；同一Claim应可以包含S4和其他legacy工厂的零件，后续按正确系统实施。[S1/S2]

| 来源 | 结论 |
|---|---|
| RTM for Requested Changes第19行NEO-018 | Both；Procurement Must、Finance Must；类型为New Integration & Workflow。[S1] |
| P1 CR clean第40行CR35-New | 写明RICEFW已提交并获资金，但仍需NEO侧集成。这是原材料中的项目状态，未核验当前资金、交付或上线情况。[S2] |
| 四份FS | S2P-I-034 Vendor；035 Part & Price；036 Vehicle Line；037 Goods Receipt。现阶段收到的是需求中的名称，不是FS正文／payload。 |
| Confluence链接 | 已尝试读取需求指定pageId=708275590，工具返回不可访问，未取得正文。只记录可追踪链接，不捏造内容。 |
| 本地检索边界 | 本轮未在检索到的本地文件名／文本和两个ZIP目录名中找到四份具名FS；没有据此断言其他位置绝对不存在。 |
| 同ID异义 | RTM - Archive第21行NEO-018是FR7 Buyer Performance；NEO RTM第22行是附件上传审计，均非本条。[S1-ID-A/B] |

## 2. Solution、主要改动类型及Priority

建议先建立NEO可消费的、带来源和有效版本的统一视图：保留S4 BP／原系统Supplier ID，映射到NEO GSDB；按Plant、Part、Supplier、币种、单位和生效条件读取正确价格；收货数据保留来源、凭证、期间及版本。前端显示两个系统并存，不强迫Buyer手工造Part或依赖上传补缺。

| 项目 | 评估 |
|---|---|
| 主要改动类型 | Integration needed为主，伴随Application前后端、数据库／主数据映射、实际财务输入及实施路由。不是UXUI only。 |
| 与谁integration | SAP S/4HANA／S4集成团队，需求提及TTL；NEO接口／主数据／计算团队，涉及既有SAP ECC、网关／集成平台及Finance。具体组织和负责人待确认。 |
| 新增还是复用 | 现有接口登记ID1–4分别为Part、Price、Vendor、GR，Appian→SAP经Apigee；不证明它们已支持S4 BP和四份FS。先评估适配／扩展，再决定新接口，不能直接写“全部可复用”。[S14] |
| 新架构影响 | 需要更新集成设计、字段映射、来源选择、跨系统身份及收货追溯。暂不建议新增独立平台；是否沿用Apigee、推送／拉取／文件、认证、调度及重试均待FS和架构团队确认。 |
| Priority | 原表Both Must；建议P0，因为源数据缺失直接影响选件、价格和财务输入。技术排期须以依赖就绪为前提。 |
| Epic | 建议建立S4 Integration工作包，正式Epic ID待分配；现有功能关联CNP-231（Claim／数据）、CNP-234（实施）、CNP-235（Finance）。没有虚构新的Jira编号或写入Jira。 |
| ACT／User Story | 主ACT-001 Create Claim、ACT-004 Update Claim；ACT-029 Generate Reserve、ACT-041 Finance Claim Report受数据输入影响；ACT-062 S4任务关联实施；ACT-050 Auto-PAM需回归。新接口交付不应仅塞进UI story。[S5] |
| FR | 直接FR1.6、FR19.13 Production Part Numbers、FR19.14 Supplier；关联FR19 Vehicle Line、FR8实际／预测影响、FR17.5 Reserve、FR13实施。[S3] |
| 页面 | P2.6 Parts Data、P6.1 Calculations / Financial Impact、P16.1 Reserve Claims、P15.11 CBSL S4 Task。本提案在现有Parts语境补来源／数据检查，不擅自增加正式Page编号。[S12] |

## 3. 四份FS如何拆工作

| FS／源需求名称 | NEO需要使用什么 | 现有接口候选 | 当前证据及Gap |
|---|---|---|---|
| S2P-I-034 Vendor | S4 BP／Supplier、NEO GSDB、名称、币种、状态及适用范围 | ID3 MCI_getVendorDetails | 只有名称和旧登记；BP→GSDB的基数、有效日期、公司／采购组织维度和实际payload未收到。 |
| S2P-I-035 Part & Price | Part／Supplier／Plant、有效价格、币种、价格单位／数量单位及有效期间 | ID1 MCI_getPartDetails、ID2 MCI_getPartPriceDetails | 标题不证明按Plant取价、价格单位换算和完整性已定义。 |
| S2P-I-036 Vehicle Line | Vehicle Line与Plant、相关财务编码／引用 | 本轮登记未确认一条完整对应接口 | BRD和字典有车型引用，FS实际字段及供给方式未收到。 |
| S2P-I-037 Goods Receipt | 收货凭证／项目／期间、Part／Supplier／Plant、数量／单位、冲销及增量更正 | ID4 MCI_getGoodsReceiptDetails | 不能从标题推断SBI、退货、历史回补、切换去重和成功／失败回执。 |

FS名称中的“S4 to Appian”描述数据流向，现有登记的“Appian to SAP”可能描述调用方向，两者不能单凭文字视为矛盾。正式文档应分别记录provider、consumer、调用发起方和业务数据方向。

## 4. 已有能力与缺口

当前master-data代码使用fixture supplier catalogue；Part occurrence中有Vendor／Company／Plant／来源版本；calculation.ts包含receipts、weekly、FTO和rates的输入结构；这说明已有应用内接口形状，不证明S4四份接口已接通。[S6–S8]

当前S4任务和培训样例能演示部分本地实施流，但QA明确正式源标志和接口映射未确认。不能把旧S4任务存在当成上游价格／GR集成完成。[S9/S13]

| Gap | 影响及处理 |
|---|---|
| 四份FS正文及样例未收到 | 无法定实际endpoint、payload、字段语义、认证及增量机制；必须补齐，不编造API。 |
| BP与GSDB不是同一字段 | 源编码、NEO身份、映射版本分别保留。不能去前导零、按名称猜或把BP直接覆盖GSDB。 |
| 一对多／有效范围 | 同一BP可能在不同组织／供应商地点有不同对应；需实际业务规则，样例一对一不代表全局一对一。 |
| 价格语义 | 需要确认币种、有效日期、价格单位／UOM、供应商和工厂粒度。单价100不一定就是每EA100。 |
| 历史切换 | 同一Plant可能ECC历史＋S4新交易并存，不能把“使用S4”理解成删除全部ECC历史，也不能两边直接相加。 |
| 缺数据与真实零 | 读取失败、无覆盖、未同步和已完整返回零必须区分；否则可能把缺失GR误算成零Reserve。 |
| GR／SBI／冲销 | 原文提GRs/SBIs，但037标题仅GR；哪些数据用于数量／财务、如何避免重复、是否含冲销需FS／Finance确认。 |
| Forecast不是GR | 需求提实际／历史需求；FR8的未来forecast另来自E2SC weekly volumes。不能未经确认把S4历史收货当未来需求，也不能取代FTO。[S3-19] |
| 多系统路由 | 数据从S4来不等于可以跳过审批或直接更新S4；仍须适用Plant配置、交易类型和实施状态。NEO-017的正式标志／任务映射依赖继续保留。 |

## 5. 页面与交互

### 5.1 同一Claim并存S4和ECC

![混合来源零件](NEO-018_Overview.png)

使用当前NEO样式。列表保留Part／Plant、Source system、NEO GSDB、原系统Supplier／BP、Current Price、Currency、Vehicle Line和Price version。来源是只读事实，Buyer不靠手动切源来补空值。

### 5.2 看清四类数据的来源和版本

![来源及编码映射](NEO-018_Source.png)

详情保留BP文本0000123400、GSDB V002、映射版本、价格版本、车型版本及GR版本。示例版本可以不同；正式要记录实际输入集合，不能假设四个系统数据都有同一个更新时间。

### 5.3 BP未映射，不能猜供应商

![BP映射缺失](NEO-018_Mapping.png)

显示Unmapped并指出具体BP；阻止使用该候选数据确认Parts。不会按名称猜一个GSDB，也不偷偷用ECC供应商代替。

### 5.4 缺GR，不等于0

![收货缺失](NEO-018_MissingGR.png)

S4 receipt coverage为Unavailable，ECC数据仍保留；Actuals输入审阅禁用。价格／Supplier／Vehicle等齐备时仍允许确认Part准备工作，不把初期Claim建档与正式Actuals／Reserve输入完整性混为一关。这个分阶段门槛是设计建议，须按正式提交阶段验证。

### 5.5 ECC和S4历史重叠，先处理再计算

![切换重叠](NEO-018_Overlap.png)

保留潜在重叠行并说明原因，阻止直接使用这批收货数据。不会按相同数量自动去重，也不把两边相加得出假需求量；真正历史切换规则待FS／Finance确认。

### 5.6 为正确系统保留实施路线

![系统实施路由](NEO-018_Routing.png)

本包示例S4工厂显示CBSL S4路线、ECC示例显示既有WIPS／ECC路线；只是两个已知fixture路线的投影，不是生产路由引擎。正式依据仍须由Plant配置、交易类型和审批／posting条件决定，而非仅看Source system文字。确认数据时不创建实施任务。

## 6. 场景与可操作数据

用户Alice Morgan／Buyer，MCI-00057，POA，Supplier Negotiations；Effective 01 Nov 2026，As of 13 Nov 2026，Claim v7。H01／S01、BP、订单／凭证及车型均为本包合成数据，不是正式工厂码或真实SAP记录。

| 临时UC | 输入／操作 | 预期 |
|---|---|---|
| D018-UC01 | 同一Claim含P3001/Halewood/S4和P4001/Solihull/ECC | 原系统身份与统一GSDB同时保留，两个来源不能互相覆盖。 |
| D018-UC02 | 查看Source、确认或取消；刷新同版本再确认 | 取消保留候选；首次确认内存v8；刷新不把版本退回v7，同一来源重复确认不制造新版本。 |
| D018-UC03 | BP未映射或S4价格缺失 | 明确缺口，不猜映射、不用ECC／0替代S4价格。 |
| D018-UC04 | S4 GR缺失；或完整GR结果为0 | 前者Unavailable并阻止Actuals输入，后者保留真实0且可审阅；二者不同。 |
| D018-UC05 | ECC历史中出现Halewood重叠记录 | 保留重叠并阻断使用，等待切换／去重规则。 |
| D018-UC06 | 来源变化或S4暂时失败 | 旧数据不能直接确认；显式刷新后重新审阅；失败可重试，ECC数据不被当S4 fallback。 |
| D018-UC07 | 查看系统路由／无权Buyer | 只有预期路线、无提前任务；无权者不暴露数据或确认入口。 |

| 示例 | S4行 | ECC行 |
|---|---|---|
| Part／Plant | P3001／H01 | P4001／S01 |
| 原系统Supplier／BP | 0000123400 | 0000055000 |
| NEO GSDB | V002 | V002 |
| Current Price／Currency | 100.00000 GBP | 50.00000 GBP |
| Price version | S4-PRICE-4 | ECC-PRICE-7 |
| Vehicle Line／dataset | VL-H／S4-VEHICLE-3 | VL-S／ECC-VEHICLE-6 |
| GR document／item | 0000000011／0001 | 0000000022／0001 |
| GR quantity／unit | 120.00000 EA | 80.00000 EA |
| GR dataset | S4-GR-4 | ECC-GR-7 |

页面Actuals calculation inputs只展示输入，不计算Financial Impact、Reserve或Journal。真实零场景把S4数量改为0且覆盖Complete；来源变化场景把S4单价改为101、版本5，ECC保持原价。未使用这组fixture金额充当Finance golden case。

## 7. 页面／数据字典／系统字段

| 字段／对象 | 已有来源 | Gap与所需契约 |
|---|---|---|
| NEO Vendor | MCI_REF_VENDOR第582–595行：VENDOR_CODE、NAME、Currency及状态。[S4] | 本轮选定供应商表未看到已确认BP-GSDB crosswalk；需映射基数、范围、版本及状态。 |
| Part／Price | MCI_REF_PART318–338、MCI_REF_PART_PRICE339–352。[S4] | 需S4原始物料／供应商／Plant／单位／生效价到NEO引用的契约；已有表并不证明价目组合完整。 |
| Plant | MCI_REF_PLANT361–374，有各系统代码和IS_S4_APPLIED。[S4] | 不能假设S4 Plant代码等于WIPS或NEO内部Plant ID，正式启用范围还需NEO-017确认。 |
| Vehicle Line | MCI_REF_VEHICLE_LINE572–581，含PLANT_ID、COST_CENTER_ID。[S4] | 036实际字段、代码和财务关联尚未收到；不因表存在就视为数据齐全。 |
| Goods Receipt | MCI_GOODS_RECEIPT1321–1340：Vendor／Part／FY／Plant，DOCUMENT_NO、MOVEMENT_TYPE、PSTNG_DATE、QUANTITY、B_UNIT、ITEM。[S4] | 原始source system、业务幂等键、document year、冲销和跨源重叠规则需确认；不能假设DOCUMENT_NO独立全局唯一。 |
| GR aggregation | MCI_GOODS_RECEIPT_AGGREGATION。[S4] | 汇总前须先确定来源／期间／单位及更正集合，保留回钻和源版本；汇总表本身不能补齐遗漏的S4数据。 |
| Calculation输入 | 当前CalculationSources有receipts／weekly／FTO／rates及版本。[S8] | 仍需生产适配、identity和完整性；结构中已有receipts不证明S4实际接入。 |
| Reserve输入快照 | BRD FR17.5要求生成时的GR和Price Change快照。[S3-47] | 新源不能事后覆盖旧已批准／Final输入；重算／期间调整需Finance规则。 |

建议契约要素包括：Source system、原始BP/Supplier/Part/Plant、NEO身份映射、有效期、单位／币种、来源版本／批次、完整性、增量／更正／冲销及可回读凭证。以上是待评审要素，不是四份FS已经提供的payload字段。物理表名、REST路径、推拉方式、消息中间件均未擅自定义。

## 8. Change / Impact及实施准备

| 层 | Change | Impact／前置 |
|---|---|---|
| UX/UI | 双来源并存、编码／版本详情、来源缺失／重叠及两类门槛 | 不让用户手工造Part补齐上游问题；仍保留初期Claim估算与正式财务完整性的阶段差异。 |
| Application前后端 | 统一查询／映射；按Plant和有效时间取价／GR；保存版本；完整性／失败／陈旧／未知状态 | 服务端权限、缓存／重试、限流、分页全量及刷新冲突需正式实现，不能仅前端拼表。 |
| DB | 原始数据、crosswalk、源版本及归档追溯 | 先复用经确认结构；缺口再设计扩展，不能把本文逻辑对象当既有DDL。 |
| Integration | 四类S4数据和NEO适配，跨BP/GSDB与ECC/S4历史 | 需要FS、API／文件规范、认证、环境、数据样例、增量／回执和错误契约；S4侧有开发不代表NEO侧完成。 |
| BPM／实施 | 保留按Plant／交易／状态的各系统路线 | 不因为选中S4数据就绕过审批或直接建任务；NEO-017及既有CBSL触发边界继续适用。 |
| Finance | FR8实际影响、Reserve、报表及Auto-PAM回归 | 必须以签收的该期间完整数据范围、单位、FX和金标准核对；本轮不改公式，不把GR缺失当0。 |
| 运维／切换 | 历史回补、增量、补跑、重放、防重、对账和监控 | ECC/S4切换日期及历史修正归属需确认；不自动停掉ECC或删除其历史。 |

## 9. 业务确认问题（人话＋例子）

| ID | 问题 | 例子及建议 |
|---|---|---|
| Q01 | 四份FS和实际接口材料能否提供？ | 目前只有034–037名称。需要当前版本、字段、样例、成功／失败及认证／联调说明，确认哪部分由S4/TTL、哪部分由NEO实现。 |
| Q02 | 一个BP如何对应GSDB？ | 同一BP跨公司或供应商地点是否映射多个GSDB？请给真实组合和有效日期，保留原码／前导零，不按名称猜。 |
| Q03 | “当前价”按什么条件取？ | 同Part不同Plant、采购组织、价格单位或未来生效价可能不同。请给取价优先级、币种／UOM和实际样例。 |
| Q04 | ECC到S4历史如何分界？ | Halewood旧收货在ECC、新收货在S4，切换期间是否重叠？请确认每Plant／对象的cutover、历史范围和重放去重。 |
| Q05 | 退货、冲销、补记和SBI怎么算？ | 037只写Goods Receipt，原文又提SBI。哪些是数量依据，哪些只用于财务，如何防重复？请给实际案例和凭证关联。 |
| Q06 | 完整的“0”与“没同步到”怎么区分？ | 查询成功但0行与接口失败必须有不同状态；请确认完整性／截止时点、更新频率、重试和补跑回执。 |
| Q07 | 混合工厂如何分派和确认完成？ | 同一Claim含ECC及S4 Plant，需要哪些任务／owner／完成回执？请沿NEO-017确认的Plant标志和实施阶段，不只按数据源名称路由。 |
| Q08 | 实际历史需求与未来预测如何衔接？ | S4收货是已发生量，FR8未来量来自E2SC，FTO又是另一输入。请确认新数据替换哪一段、哪些保持原来源。 |
| Q09 | 用哪些Finance golden cases验收？ | 至少包含混合来源、真0、缺失、冲销、切换重叠和迟到更正；价格／GR／Reserve／报表／Auto-PAM要能对同一版本，而非只看页面有数字。 |
| Q10 | 当前交付状态、环境及owner是谁？ | 需求记载“RICEFW已funded”是历史描述。请确认034–037实际完成度、NEO侧待办、非生产访问／样例及上线切换安排；不自动扩成部署授权。 |

## 10. 验证与退出条件

74 项本地页面交互／布局检查通过。预期／实际、浏览器和页面SHA见PAGE_VISUAL_CHECK.json。

执行覆盖：同Claim双来源；BP及凭证／项目前导零；Supplier、Price、Vehicle、GR分别保留来源版本；确认／取消／刷新不回退版本和无变化确认；BP缺映射、价格缺失不fallback；缺GR阻止Actuals而不阻止完整Parts准备；完整0可审阅；ECC/S4重叠阻断；源变化重审、源失败重试；两条预期实施路线且无提前任务；无权Buyer无数据；六宽度、手机GR／路由、手机溢出菜单切tab、长详情操作和CSS200%布局；无外部HTTP／运行错误。

**未执行**：四份实际接口、真实BP映射、源价格／GR正确性和全量完整性、单位换算、跨源cutover／去重／冲销、真实数据库保存／刷新回读、前后端权限、生产调度／性能、安全、Financial Impact／Reserve／Journal／Auto-PAM计算及业务验收、真实任务／SAP更新、部署。本次Actuals输入齐备只指fixture，不等于财务结果已通过。CSS200%不是原生浏览器缩放验收。

本轮退出条件：来源及缺失材料明确；独立页面可操作；六张主要截图及补充GR／Inputs／手机图；接口工作拆解、问题、源码和测试可交接；ZIP完整性及SHA校验通过。

正式开发退出条件：四份FS／契约签收；双方环境和权限齐备；供应商映射和各Plant切换规则确定；全量／增量／补跑可对账且更正可追溯；各页面和后端消费正确数据；Finance golden cases及完整期间对账通过；实施路由和真实回执验证；部署／切换另按授权。页面展示通过不能代替这项集成验收。

下一项按原表继续NEO-019。

## 11. Source / Reference

| Source | 文件及定位 |
|---|---|
| S1/S2 | NEO Business Requirements (added China requirements) 1.xlsx：RTM for Requested Changes第19行、P1 CR clean第40行CR35-New。 |
| S1-ID-A/B | RTM - Archive第21行、NEO RTM第22行，仅排除同ID异义。 |
| S3-8/19/38/47 | Material Cost & Inventory - BRD V3.1.docx：Table6的FR1.6／FR8／FR13／FR17.5。 |
| S3-52/65/66 | 同BRD的FR19 Vehicle Line／FR19.13 Parts／FR19.14 Supplier。 |
| S4 | NEO_数据字典.xlsx，字段字典；上述原表行号及原值保留。 |
| S5 | story_data.json，ACT-001/004/029/041/050/062及现有Epic。 |
| S6/S7 | domain/p02/master-data.ts；domain/p03/selection.ts，fixture与occurrence匹配边界。 |
| S8/S9 | domain/p03/calculation.ts；domain/wips/s4-hana.ts。 |
| S10/S11 | domain/offline/parts-calculation-sample.ts（明确合成样例）；src/theme/index.ts。 |
| S12/S13 | 143页面scope.json；唯一QA模型NQA-120/121，既有本地S4范围与正式接口未确认。 |
| S14 | Integrations - 2026-11-09_0941(Sheet 1).csv，完整登记及ID1–4。 |
| S15-1/2 | NEO TECH.zip和Appian Integration Architecture.zip，仅检索目录文件名，未假称阅读了不存在的具名FS。 |

准确绝对路径、原文／行号、SHA及链接读取失败记录在SOURCE_EVIDENCE.json；主题及依赖版本在SOURCE_MANIFEST.json。没有修改或重新认定既有QA结果。
