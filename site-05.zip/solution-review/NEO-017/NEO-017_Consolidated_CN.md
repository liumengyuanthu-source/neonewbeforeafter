# NEO-017 · 自动识别相关工厂，避免漏派 S4 更新任务

<!-- FLOW-REVIEW-20261116 -->
## 16 Nov 2026 · 流程评审补充

[中英文 Before / After 流程](NEO-017_Before_After_Flow.html) · [流程说明 MD](NEO-017_Before_After_Flow_CN_EN.md)

先根据有效订单识别 Part／Supplier／Plant，让 Buyer 确认范围；到既有实施控制点再创建 S4 任务。

本轮为流程说明补充；原交互页面、问题及历史证据保留。正式实施前需补齐：确认 Halewood、Halewood KD、Nitra KD 的实际代码／生效版本及 CBSL–Digitide 团队映射；若要改 Training 的任务触发点，作为单独流程变更确认。
<!-- /FLOW-REVIEW-20261116 -->

独立设计提案，未修改现有 NEO prototype、共享QA或实际流程。页面沿用NEO主题和Ant Design。人员、订单、工厂代码、版本及任务都是合成审阅数据；没有调用SAP/S4/FFP，也没有创建实际CBSL任务。来源原文、准确位置和SHA在SOURCE_EVIDENCE.json。

## 1. 需求与方案

问题：如果POA零件没有Plant，系统可能识别不到S4工厂，漏派CBSL／Digitide的S4更新任务，最终WIPS变价了但S4没更新。原描述提出Plant必填；同一需求的期望结果进一步要求根据有效订单识别相关工厂，让Buyer查看／确认，尽量避免人工查找和输入。[S1/S2]

建议流程：选Part及Supplier → 从权威订单／主数据取得相关Plant组合和S4属性 → Buyer核对完整范围 → 带着Plant进入Part prices → 到既有实施触发点时，仅把S4零件交给相应任务。缺Plant、缺S4属性、源数据不可用或版本变化均有明确处理。

| 证据 | 如何使用 |
|---|---|
| RTM for Requested Changes第18行NEO-017 | Procurement Must；Finance优先级空白。目标提及Halewood、Halewood KD、Nitra KD。[S1] |
| P1 CR clean第39行CR34-New | 原问题写“currently only Halewood”，且标记possible extension。与目标的三个工厂范围不同，应核实当前生效配置。[S2] |
| BRD FR1.6 | 原Part输入有Plant及按Plant细分价格的要求，不等于已经定义本条完整有效订单识别接口。[S3-8] |
| Training第1646段 | POA进入Data Posted Manually／Automatically - Awaiting Approval且有S4 parts时，触发CBSL S4任务。选件阶段不是任务创建时点。[S4] |
| Training第1650、1705–1708段 | S4任务只显示S4零件；S4处理与后续WIPS审批失败任务存在依赖，不能仅修选件UI而漏掉实施门槛。[S4] |
| 其他sheet同ID | Archive第20行是FR6.3 Reserve；NEO RTM第21行是Attachment Upload。本条不混用它们。[S1-ID-A/B] |

## 2. 主要改动类型、Priority与关联

| 项目 | 结论 |
|---|---|
| 主要改动类型 | Application前后端＋数据／接口契约＋流程路由。Plant必填只是最后一道检查；核心是取得完整正确的Part/Supplier/Plant范围和S4属性。不是UXUI only。 |
| Integration needed | 自动从有效订单识别，需要权威源数据供给；需求列SAP/S4/FFP等为候选来源，尚未决定具体由谁提供。NEO负责匹配、展示、版本和校验；来源系统负责订单／Plant事实。 |
| 现有接口能否复用 | 登记有MCI_getPartDetails（ID1）、MCI_getPartPriceDetails（ID2），但没有证明payload包含有效订单、完整多Plant覆盖、时效和S4属性。需对照真实契约后决定复用、扩展或新增。[S15] |
| 新架构判断 | 暂不建议新增平台。可在NEO／目标应用的主数据适配和既有CBSL任务流程中扩展；如没有所需源数据，补适配／接口是实际前置，不能靠手填一个代码声称完成自动识别。 |
| 建议Priority | P0：防止漏实施；原表为Procurement Must。优先确认源数据、S4有效工厂配置、触发点及实际团队映射；这是本轮建议，不是已批准排期。 |
| Epic | 输入／编辑范围关联CNP-231；实施任务关联CNP-234。来自ACT-001/004/026/062既有映射，不新增Jira记录。[S6] |
| User Story | 主ACT-001 Create Claim、ACT-004 Update Claim的POA输入；ACT-026仅为批量输入关联；ACT-062 CBSL S4 Hana Task接收已确定的S4范围。 |
| FR | 直接FR1.6；关联FR6更新、FR13实施，ACT-062关联FR14手工任务。不能把该新需求说成基础BRD已完整实现。 |
| 页面 | P2.6 Parts Data；历史P7.5.1 Upload Parts Data仅是批量入口参考；P15.11 CBSL S4 HANA Task。当前停用的Excel导入不恢复，本条继续采用正常POA页面提案。[S13/S14] |

## 3. 当前实现／字典与Gap

字典有MCI_REF_PLANT.IS_S4_APPLIED，第368行；同一Plant还分别有SAP_POA、SAP_LUMP_SUM、WIPS、WERS等系统代码。当前原型S4识别却读取rowMetadata.s4Hana===true；contracts.ts及QA NQA-120明确它是offline adapter marker，正式映射未确认。[S5/S9/S11/S14]

当前S4任务代码已经有posting关联、CBSL任务、仅S4零件、Enquiry／Reply和完成逻辑；不能说整个S4任务不存在。但本轮源码审查不能证明新需求要求的有效订单自动匹配已实现。[S9/S10]

| Gap | 需要补什么 |
|---|---|
| 工厂旗标映射未接通 | 确认Plant引用ID、IS_S4_APPLIED、行级任务判别三者的输入输出及有效版本；不要长期依赖人工设置的布尔marker。 |
| 不知道不等于No | 字典字段可空、默认0。源缺字段时不能因默认值把未知转换为非S4；应有读取状态／来源证据。 |
| 现有代码的缺省风险 | s4Parts仅筛true，ready在没有筛中行时可返回true。这只是当前本地实现观察，提示必须区分明确非S4与尚未判定；不是对生产缺陷的复现。[S9/S16] |
| 有效订单与多Plant范围 | MCI_REF_PART中有Vendor和Part，价格表有价格／币种，但这些提取字段没有证明完整的有效订单—工厂关系。不能用“有Part和Plant表”代替关系契约。[S5] |
| 三类工厂范围差异 | 当前描述只有Halewood，目标又列Halewood KD、Nitra KD。应使用已批准的Plant配置，而不是把三个名字硬编码为生产规则。 |
| CBSL／Digitide关系 | Training写CBSL，目标写Digitide users。要确认实际用户组／分派规则，不能直接把两个名字当一个组。 |
| 新旧版本与审批冻结 | Buyer确认后改订单、增删Plant或旗标变化，何时刷新、是否影响已批准范围需规则；不能悄悄换掉冻结版本。 |
| 对比报告不是预防控制 | 原需求说S4 System Comparison Report部署后可发现差异；本轮没有该报告已上线证据，也不能用它替代正确的前置识别和任务分派。 |

## 4. 页面与交互

### 4.1 从源数据带出工厂

![自动识别工厂](NEO-017_Overview.png)

顶部保留Line、Supplier、Buyer、POA、阶段、Claim版本和来源版本。表格按Part / Supplier / Plant组合展示。P2001同时用于两个工厂，保留两行，不按Part Number误合并。S4属性只读；Buyer不勾选“是否S4”，也不用手输工厂代码。

### 4.2 Buyer确认完整范围

![确认范围](NEO-017_Confirm.png)

确认弹窗显示全部组合和来源版本，明确本次不创建S4任务、不提交审批。Keep reviewing／Escape保留原范围；Confirm and continue在本页内存中保存v8，并进入Part prices承接视图。该视图只验证Plant信息带入，不重新实现完整价格编辑和计算。

### 4.3 缺工厂不能继续

![工厂缺失](NEO-017_Missing.png)

保留P2002／V002未匹配行，说明需要解决源数据。不能因为空Plant被跳过，就让Claim继续。

### 4.4 工厂找到了，但S4属性未知

![S4属性缺失](NEO-017_Unknown.png)

P2002／H01已识别工厂，但旗标Unavailable；同样阻止继续。不能把它当No。路由页显示Cannot determine，避免错误地得出“不需要S4任务”。

### 4.5 在正确阶段判断任务

![实施路由](NEO-017_Routing.png)

Supplier Negotiations时显示S4范围，但Eligible now为No，没有任务。它解决的是早期识别，不提前执行CBSL实施流程。只有全部工厂明确非S4时才显示额外S4任务Not required；未知数据不走这个分支。

### 4.6 进入实施阶段后的任务范围

![CBSL S4任务](NEO-017_Task.png)

外部场景切到Implementation posting received，示范一条Line对应一个CBSL任务投影，包含两条S4组合，排除Solihull非S4行。任务详情只读，不伪造SAP更新或完成。这不是实际任务派发，也不替代P15.11已有完整Enquiry／完成交互的验收。

## 5. 场景、输入和操作

| 临时UC | 用户及起点 | 操作与预期 |
|---|---|---|
| D017-UC01 | Alice Morgan／Buyer；MCI-00057，POA，Supplier Negotiations；Claim v7／源v4 | 查看3条组合；P2001的两个工厂均保留，不能直接进入Part prices。 |
| D017-UC02 | 同上 | 查看Source order and plant；确认Vendor、Order、Plant和S4属性；确认后进入Part prices，显示Claim v8。 |
| D017-UC03 | 缺Plant／未知S4 | 保留具体Part并禁用继续；无自动No或空值默认通过。 |
| D017-UC04 | 源版本在确认前变化 | 拒绝旧范围确认；显式Reload and review后查看v5的新范围并重新确认。 |
| D017-UC05 | 源不可用／全部非S4 | 前者无假数据、可重试；后者在明确判定后不需要S4额外任务。 |
| D017-UC06 | Grace Turner／CBSL；已有实施posting场景 | 路由显示1条任务、2条S4组合；不能编辑已posted范围，详情不含非S4零件。 |
| D017-UC07 | Emma Reed／其他Buyer scope | 无权看该Claim，页面不暴露零件及确认入口。 |

默认合成数据：

| Part | Supplier | Plant code／名称 | S4 | 源订单 |
|---|---|---|---|---|
| P2001 | V002 | H01／Halewood | Yes | ORDER-101 |
| P2001 | V002 | S01／Solihull | No | ORDER-102 |
| P2002 | V002 | H01／Halewood | Yes | ORDER-103 |

H01、S01及ORDER编号仅为本包合成数据，不是正式SAP/WIPS工厂码。来源变化场景把P2002转为S01非S4，Buyer重验后S4范围从2条变1条。有效订单查询、真实性、时点和完整性没有实际接口验证。

## 6. 字段、系统和接口

| 字段／能力 | 来源与reference | 对接结论 |
|---|---|---|
| Part、Supplier | MCI_REF_PART第318–338行含PART_ID、VENDOR_ID、PART_NUMBER；FR1.6。[S5/S3-8] | 选择后的业务代码需解析引用ID并校验授权，不能只按Part名称模糊匹配。 |
| 相关Plant组合 | 需求要求按live orders的Part/Supplier/Plant确定。[S1] | 由确认的订单源提供；SAP/S4/FFP谁权威、接口还是文件待定。NEO负责范围匹配／版本记录，不自行造订单关系。 |
| Plant ID／系统代码 | MCI_REF_PLANT第361–367行。[S5] | Plant内部ID与SAP_POA／WIPS／WERS等代码分开；不可把一个外部代码通用于所有系统。 |
| S4属性 | MCI_REF_PLANT.IS_S4_APPLIED第368行。[S5] | 需确认配置owner、生效日期和映射。当前rowMetadata.s4Hana是本地适配标记，不能当生产字段。[S9/S11] |
| Claim零件的Plant | MCI_RISK_OPPORTUNITY_PART.PLANT_ID第817行。[S5] | 每个保存的Part occurrence带Plant；同Part多Plant不能只保存一个。 |
| S4供应商编码 | MCI_RISK_OPPORTUNITY.S4_HANA_SUPPLIER_CODE第738行。[S5] | 供应商映射也是实施前置；仅补Plant不代表S4所需所有字段完整。 |
| Part／价格接口 | Register ID1 MCI_getPartDetails，ID2 MCI_getPartPriceDetails，Appian→SAP经Apigee。[S15] | 可评估复用，但登记描述不证明含有效订单、所有Plant和S4属性；无payload不宣称已经足够。 |
| 来源版本／完整性 | 本包v4/v5、订单Open状态均为建议投影 | 正式要定义有效／取消／过期订单、查询截止时点、分页完整性、查询失败／陈旧与更新时间。 |
| S4任务触发 | Training1646；现有posting关联store。[S4/S9] | 由NEO／目标BPM在适用实施状态编排，按已确认范围分派；不在Buyer选件时直接调用S4建单。 |
| 后续PM失败分支 | Training1705–1708；pm-approval.ts的s4Ready依赖。[S4/S16] | 必须保留现有顺序，S4未知或未完成时不能误当“没有S4部分”放行。具体真实状态／回执需流程契约。 |
| S4实际更新结果 | 本轮未取得 | 需CBSL/源系统确认外部操作和结果依据；任务出现或本地complete不自动等于S4价格已更新。 |

不虚构REST路径或payload字段。建议契约至少能表达Part/Supplier/Plant组合、各系统代码映射、订单有效性、S4属性的明确Yes/No/Unknown、来源版本和完整性；这些是待契约评审要素，不是已收到的规范。

## 7. Change / Impact

| 层 | 修改方向 | 影响与限制 |
|---|---|---|
| UX/UI | 自动带出组合、只读S4属性、可追溯来源、确认及缺失／失败／变化处理 | 保持After设计；不只给Buyer新增必填手输框。没有恢复已停用批量入口。 |
| Application前端 | Part occurrence保留Plant；继续前检查完整性；保留未确认范围；显式刷新 | 本轮只在独立内存中演示。正式流程仍需服务端重复校验，不能仅禁用按钮。 |
| Application后端 | 权威源匹配、版本及范围保存、无数据／未知状态、查重和审计 | 不拿参考表存在证明有效订单齐全；不能从default0推断No。 |
| DB | 复用Plant引用、IS_S4_APPLIED和Claim PART/PLANT关联；按缺口补快照／来源元数据 | 不无依据新建数据库模型；先核实实际关系、历史版本及生效策略。 |
| BPM | 在现有posting条件下生成S4任务，保留关联、分派和完成门槛 | 重复事件、取消重开、部分posting及多Plant任务粒度需契约。输入确认不创建任务。 |
| Integration | 复用或扩展订单／主数据接口，匹配真实Plant编码和S4分类 | 若既有API不含所需粒度／完整性，需新契约／适配；不能用模拟接口响应算集成通过。 |
| 数据与运维 | 配置实际S4工厂、CBSL/Digitide用户组、缺失数据处理和对比报告接续 | 对比报告是补充检测，不替代预防漏派。真实邮件／提醒范围另验。 |

## 8. 业务确认问题（人话＋例子）

| ID | 问题 | 例子及建议 |
|---|---|---|
| Q01 | 当前哪些工厂真的属于S4？ | 原描述只有Halewood，目标又有Halewood KD、Nitra KD。请给正式Plant ID、各系统代码、生效日期及S4配置owner；不按名称硬编码。 |
| Q02 | 从哪个系统拿“有效订单”？ | 同一Part在SAP/S4/FFP可能覆盖不同工厂。请确认权威源、接口／文件及实际payload，避免只返回一部分。 |
| Q03 | 有效订单如何定义？ | 已取消、未来生效、已收完但未关单的订单是否算？请确认截止时点及期间条件，否则自动带出的Plant仍可能错。 |
| Q04 | 多个相关工厂是否必须全部带入？ | P2001在Halewood和Solihull都有有效订单。建议不默认选一个；若允许排除，需要什么理由／权限？ |
| Q05 | 源数据缺失时谁处理？ | P2002没匹配到Plant，或有Plant但没S4旗标。建议先修源／主数据，不让Buyer自行勾选非S4绕过。请确认例外流程。 |
| Q06 | 何时锁定工厂范围，后续变化怎么办？ | Buyer确认后新开了Nitra KD订单。审批前可重验；审批后是否补审批或新增实施任务，需明确。 |
| Q07 | CBSL和Digitide在系统里是什么关系？ | 来源分别写两个名字。请给正式用户组和任务分派；Grace Turner仅为本包示例，不能当生产owner。 |
| Q08 | S4任务按Line、Plant还是posting建？ | 一条Line有两个S4工厂，是一个任务含两工厂还是两个任务？本提案沿现有本地posting聚合方式展示，不作为新规则签收。 |
| Q09 | 如何保证不漏派也不重复？ | 同一posting回调来两次、部分成功或取消重开，应如何关联与查重？请给事件／结果样例及现网任务关联规则。 |
| Q10 | 对比报告是否已上线、发现差异谁补？ | 原文说报告部署后可发现S4与WIPS不一致。请给当前报告、字段和处理owner；报告尚未确认时不能把它当已存在兜底。 |

## 9. 验证与退出条件

63 项本地页面交互／布局检查通过，预期与实际逐条见PAGE_VISUAL_CHECK.json。验证对象是此独立合成提案。

覆盖：3个组合、多Plant不合并；Source详情；Buyer不能直接改S4标志／手输Plant；确认取消与进入下一步；提前阶段无任务；缺Plant／未知旗标阻断；版本冲突保留原范围并刷新重验；源失败重试；明确非S4无额外任务；posting场景只投影1条任务且仅包含S4部分；posted只读；无权Buyer无数据；六宽度、手机弹窗／Escape及CSS200%布局；无外部HTTP请求和运行错误。

**未执行**：实际SAP/S4/FFP源读取、有效订单全量完整性、真实IS_S4_APPLIED映射、前后端鉴权／DB保存回读、跨窗口并发、真实posting事件和BPM派单、任务幂等／重试／取消重开、手工posting支路、真实Digitide分派、S4更新结果、邮件、对比报告、全量性能与业务UAT。重新打开页面仍显示同一条合成任务，只证明投影稳定，不证明真实任务创建幂等。CSS缩放不等于原生浏览器缩放验收。

本轮退出条件：原需求／现有能力／待确认边界明确；独立页面可操作；六张主要截图及Source／手机图；源码、测试和来源齐全；ZIP解压及哈希校验通过。当前产品保持独立。

正式开发退出条件：Q01–10适用规则和契约确认；完整有效订单集合、Plant及S4旗标可靠取数；保存和继续的前后端校验一致；任务在正确阶段、正确owner、正确S4范围生成且不重不漏；全非S4与未知有不同处理；取消／重开／重复事件／源变更／审批快照及下游更新链路有实际证据。选件页绿色不等于这条全流程通过。

下一项按原表继续NEO-018。

## 10. Source / Reference

| Source | 文件及定位 |
|---|---|
| S1/S2 | NEO Business Requirements (added China requirements) 1.xlsx：RTM for Requested Changes第18行、P1 CR clean第39行CR34-New。 |
| S1-ID-A/B | RTM - Archive第20行、NEO RTM第21行；只排除同ID异义。 |
| S3-8/38 | Material Cost & Inventory - BRD V3.1.docx，Table6行8／38，FR1.6／FR13。 |
| S4 | NEO User Training.docx，正文1642–1709；CBSL S4 task、仅S4 parts、Enquiry及后续PM失败条件。 |
| S5 | NEO_数据字典.xlsx：字段字典MCI_REF_PLANT361–374、MCI_REF_PART318–338、价格表339–352、Claim Part814–843及S4供应商738；原行号保留。 |
| S6 | story_data.json，ACT-001/004/026/062及CNP-231／234关联。 |
| S7/S8 | app/src/views/Parts/SelectParts.tsx、domain/p03/fr1-parts.ts。 |
| S9/S10 | domain/wips/s4-hana.ts、views/Tasks/S4HanaTask.tsx，posting关联／仅S4部分和当前任务交互；不是生产验收证明。 |
| S11/S12 | domain/p03/contracts.ts的offline marker声明；src/theme/index.ts。 |
| S13/S14 | 143页面scope.json的P2.6/P7.5.1/P15.11；现有QA NQA-120/121/132/133，保留正式S4映射和停用上传的边界。 |
| S15/S16 | Integration CSV全表，ID1/2候选数据接口；domain/wips/pm-approval.ts的s4Ready依赖。 |

SOURCE_EVIDENCE.json保存全部绝对路径、原文／代码行及SHA；SOURCE_MANIFEST.json记录主题及依赖版本。本轮没有改动或重新认定任何历史QA结果。
