# NEO-017 · Before / After process

Priority: Must (Procurement: Must; Finance: —)

ACT-001 / ACT-004 / ACT-026 / ACT-062 · FR1.6 / FR13 / FR14

## 识别 S4 工厂并在正确阶段发任务

先根据有效订单识别 Part／Supplier／Plant，让 Buyer 确认范围；到既有实施控制点再创建 S4 任务。

### Before · 现有路径

1. **Buyer · 按 Company／Plant 选零件** — 当前原型有工厂筛选和 Part／Plant 明细；已有 S4 任务是另一阶段的能力。
2. **CBSL／实施流程 · 按现有触发条件处理 S4** — Training 将 S4 任务放在相应实施状态后，不能把价格录入等同于立即派任务。

### After · 建议路径

1. **数据服务 · 取得有效工厂范围与标志** — 按 Part／Supplier／Plant 的有效订单组合带出工厂及来源版本，保留同一零件多个工厂。
2. **Buyer · 确认完整范围后改价** — Buyer 查看并确认，不手填 S4 标志；工厂或标志未知时暂停相关组合继续。
3. **Buyer → 审批流程 · 保留工厂范围完成授权** — 改价、计算及适用审批沿用同一范围；此时不提前产生实施任务。
4. **实施流程 → CBSL／Digitide · 到控制点仅发送 S4 范围** — 先沿用 Training：POA 进入 Data Posted Manually / Automatically - Awaiting Approval 且包含 S4 Parts 时触发。只发送 S4 行给已映射团队，保存任务及完成结果。

### 例子

示例：同一 Part 同时供应 Solihull 与 Halewood，保留两条组合。Supplier Negotiations 时不派任务；到实施触发点后，只把已确认的 S4 组合交 CBSL／Digitide。

### 保留控制

- Unknown 不等于非 S4；源数据缺失不能使任务被漏掉。
- 早期识别不改变审批或 WIPS／S4 先后依赖，也不自动完成外部更新。

### 正式实施前补齐

- 确认 Halewood、Halewood KD、Nitra KD 的实际代码／生效版本及 CBSL–Digitide 团队映射；若要改 Training 的任务触发点，作为单独流程变更确认。

## Identify S4 plants and trigger tasks at the correct stage

Derive Part / Supplier / Plant from live orders for Buyer confirmation; create the S4 task only at the existing implementation control point.

### Before · Existing path

1. **Buyer · Select parts by Company / Plant** — The current prototype has plant filters and Part / Plant rows; existing S4 tasks belong to a later stage.
2. **CBSL / Implementation flow · Handle S4 at the existing trigger** — Training places S4 tasks after the relevant implementation state; price entry must not immediately dispatch a task.

### After · Proposed path

1. **Data service · Retrieve the live plant scope and S4 flags** — Derive plants and source versions from live Part / Supplier / Plant order combinations, retaining multiple plants for the same part.
2. **Buyer · Confirm the scope before changing prices** — The Buyer reviews and confirms, without manually setting an S4 flag. Missing plant or flag data prevents progression of the affected scope.
3. **Buyer → Approval flow · Carry the plant scope through authorisation** — Keep the same scope through price changes, calculation and applicable approval; do not create implementation tasks early.
4. **Implementation flow → CBSL / Digitide · At the control point, route the S4 scope** — Retain the Training trigger: a POA reaches Data Posted Manually / Automatically - Awaiting Approval and includes S4 parts. Dispatch only S4 rows to the mapped team and retain the task and outcome.

### Example

Example: the same part supplies Solihull and Halewood, so retain both combinations. No task is dispatched during Supplier Negotiations; only the confirmed S4 combination goes to CBSL / Digitide at the implementation trigger.

### Controls retained

- Unknown does not mean non-S4; missing source data must not silently suppress a task.
- Early recognition does not change approval or WIPS / S4 dependencies or automatically complete an external update.

### Production dependencies

- Confirm actual codes / effective versions for Halewood, Halewood KD and Nitra KD and the CBSL–Digitide mapping; confirm any change to the Training trigger as a separate workflow change.

## Sources

- **R-1113** NEO Business Requirements (added China requirements) 2(RTM for Requested Changes)_1113 1400 version.xlsx · NEO Business Requirements (adde!E18,N18,P18,Q18; priorities K18:L18
- **S1** NEO Business Requirements (added China requirements) 1.xlsx · RTM for Requested Changes row 18
- **S3-8** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 8 (1-based)
- **S3-38** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 38 (1-based)
- **S4** NEO User Training.docx · Body paragraphs 1642–1709 (1-based)
- **S7** SelectParts.tsx · Numbered source lines
- **S9** s4-hana.ts · Numbered source lines
- **S10** S4HanaTask.tsx · Numbered source lines
- **S15** Integrations - 2026-11-09_0941(Sheet 1).csv · All CSV records; registered parts/price APIs do not prove live-order/plant-flag payload completeness
- **S16** pm-approval.ts · Numbered source lines: s4Ready gate and PM approval dependency
- **S2** NEO Business Requirements (added China requirements) 1.xlsx · P1 CR clean row 39

Before: frozen prototype `3ff8bc0b158ba08f2302e7404bb6185a553088c78614051451e6b5137a26802e`. Historical problems are labelled separately. After is a proposal; numerical examples are illustrative. Production execution: NOT RUN.
