# NEO new requirements — Before / After

Independent bilingual design-review guide, release 20261117-v1.

75 numbered requirements plus one AS-IS baseline. Default Must view: 50 numbered requirements plus the baseline. Before is the frozen NEO prototype; After contains isolated enhancement proposals. Review notes are stored only in the visitor browser and can be exported. No real SAP, workflow, or business record is changed. This publication does not certify business acceptance.
