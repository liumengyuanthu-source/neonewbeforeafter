# CNP-233 — UC mapping checkpoint

Scope: NEO-050, 051, 056, 057, 063, 064 only. ACT identifiers retained; proposed primary Epic is not a Jira change. All product scenarios remain NOT RUN.

The working BRD source is `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx`. Locators below count python-docx document paragraphs from 1, including blank paragraphs. Original BRD locators count tables/rows from 1.

| Requirement | Verified UC coverage | ACT / FR | Gap and local scenarios |
|---|---|---|---|
| NEO-050 | Direct UC-14 ¶291–297; related UC-18 ¶319–325 | ACT-017/019/024; FR10.2/10.6 | Add separate CH Complete, Request Approved and workflow/implementation readback; NEO-050-S01 onward. Original BRD table6 row33 literally contains requested condition. |
| NEO-051 | Related UC-14 ¶291–297, not direct period delegation coverage | ACT-018/032; FR10.6/9.5 | New time-bound DoA delegation scenarios, including same/adjacent/outside level, start/end boundaries and authority loss. UC-16 is additional review, not delegation. NEO-051-S01 onward. |
| NEO-056 | Direct UC-12 ¶277–283 and UC-14 ¶291–297; related UC-13 ¶284–290 and UC-18 | ACT-010/013/032; FR9.3/9.4/9.5, FR10.2 escalation | UC-11 advice explicitly does not imply signing authority; remove it as direct DoA coverage. New approved-matrix boundary/gap/escalation cases. Q57 explicitly requests no extra approvals and M57 identifies good-news/positive-negative inconsistency. R57=Y. Resolve conflict with FR10.2 upward escalation and NEO-063 exceptions; do not remove approved controls by inference. |
| NEO-057 | Direct report slice UC-24 ¶361–367; related UC-17 ¶312–318; task authority TASK-UC17/18/21/22 | ACT-020/036/046/055; FR15/20.3/21/10.3/10.5 | New full open-population report and overdue reminder delivery/dedup/failure scenarios; UC-24 alone does not cover reminder service. |
| NEO-063 | Direct UC-16 ¶305–311; related UC-14 | ACT-018/019/024 retain inherited links, but Add Delegator ACT-018 is not the same action; FR22.3/22.5 plus FR10.6 | FR22.3 resolves ambiguous old UC wording: Add Before blocks original; Add After starts only after original approval and blocks downstream. Review rejection scope remains D22-04. |
| NEO-064 | Direct transfer slice UC-17 ¶312–318; related UC-14; TASK-UC18 group reassignment separate | ACT-018/020; FR22.2/22.5, FR15, FR10.6 | Separate one-task transfer from NEO-051 period DoA delegation. Training ¶1092 limits historical reassignment to GFS/AP/CBSL within respective groups; no unrestricted approver transfer inference. |

## Authority and conflict notes

- Requested Changes E51/E52/E57/E58/E64/E65 read directly from original workbook; K Must/Should/Must/Must/blank/blank; all Finance L and target P blank.
- FR22 addition is a user-requested design direction but explicitly draft, with D22-01–06 unresolved; not signed production policy.
- UC-16 ¶309 generic “Original owner cannot approve ahead of a required reviewer” must not be applied to Add After. FR22.3 items3–4 provide the mode-specific sequence.
- NEO-029 is reuse-only POC session/recovery dependency; no redesign or change to 001–034.


## Full source-cell reconciliation
Q51 requires In Approval until all approvals received. M51 reports premature Awaiting implementation. Q57 requests corporate DoA without additional approvals, R57=Y; this conflicts with unrestricted reading of FR10.2/063 and must be resolved jointly. All nonempty A:R values are preserved in ASSESSMENT.json sourceCells. Source dictionary needs reset_dimensions() due to stale A1 workbook dimensions.


## Full source-cell reconciliation
Q51 requires In Approval until all approvals received. M51 reports premature Awaiting implementation. Q57 requests corporate DoA without additional approvals, R57=Y; this conflicts with unrestricted reading of FR10.2/063 and must be resolved jointly. All nonempty A:R values are preserved in ASSESSMENT.json sourceCells. Source dictionary needs reset_dimensions() due to stale A1 workbook dimensions.


## Full source-cell reconciliation
Q51 requires In Approval until all approvals received. M51 reports premature Awaiting implementation. Q57 requests corporate DoA without additional approvals, R57=Y; this conflicts with unrestricted reading of FR10.2/063 and must be resolved jointly. All nonempty A:R values are preserved in ASSESSMENT.json sourceCells. Source dictionary needs reset_dimensions() due to stale A1 workbook dimensions.
