# CNP-233 授权审批：6项独立评估

本轮只评估050/051/056/057/063/064，不改变产品、原始工作簿或统一QA。页面为独立英文提案、全部合成数据。产品、接口、UAT均NOT RUN。现有实现结论来自代码读取及原QA历史，未冒充本轮实测。

来源优先级：本次用户授权/确认 > Requested Changes原始A:R各列 > 已确认项目政策范围 > 原始BRD及Training > 当前代码观察 > 历史/工作分析。FR22是获准整理的目标设计，D22-01–06仍未签认。工作UC不是已验收用例。

## NEO-050 Clearing House完成、Request批准和实施状态分开

### 用户问题与原文

一方批准而另一方仍待批时，被显示为等待实施，Buyer误以为授权已完成。

> The replacement NEO shall for clearing house items, when all relevant approvals are provided and the FBP has marked the status within the approval request as complete, the approval request shall be marked as "Approved" (separate to the workflow). These details should be stored against the Line items & parent ID for which the request was raised against.

采购期望Q：The replacement NEO shall for clearing house items, when all relevant approvals are provided and the FBP has marked the status within the approval request as complete, the approval request shall be marked as "Approved" (separate to the workflow). These details should be stored against the Line items & parent ID for which the request was raised against.

Until all approvals have been provided it should retain its "In Approval" Status

Finance期望P：空白，未补造。

原优先级：采购Must；Finance None。建议P0：采购Must；提前声称等待实施直接影响授权与下游门槛。

### UC定位与当前基线

UC-14 (direct), UC-18 (related)；ACT-017, ACT-019, ACT-024；FR10.2, FR10.6

源码已有localWorkflowApproved与CH Complete双门，并保存requestVersion、Parent/Line事件；但completeLocalApproval限illustrative-single-line-ch-v1单Line Mandate。requestOverallStatus对完成返回Complete，需与Q51要求Request=Approved重新对齐。不是从零开发，也未证明多Line/Settlement、页面/导出状态一致。

页面登记编号与当前路由：[{"id": "P4.7", "name": "Update Approval Request", "source": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Approvals/FinanceRequestUpdate.tsx", "observation": "当前源码可观察入口；本轮未执行产品功能。", "pageIdBasis": "Canonical QA PAGE registry / user127-page list; historical alias, not React route number", "registrySource": "NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json", "registryLocator": "rows[audit_id=PAGE-P4.7]", "registryObservation": "P4.7 Update Approval Request", "currentRoute": "/approval (RequestDetail action/tab; request query context required)", "routeSource": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/router/index.tsx; views/Approvals/RequestDetail.tsx; views/Management/index.tsx; views/Reporting/index.tsx"}, {"id": "P4.1.12", "name": "Each Line Approval/Decline", "source": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Approvals/AcknowledgeApproval.tsx", "observation": "当前源码可观察入口；本轮未执行产品功能。", "pageIdBasis": "Canonical QA PAGE registry / user127-page list; historical alias, not React route number", "registrySource": "NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json", "registryLocator": "rows[audit_id=PAGE-P4.1.12]", "registryObservation": "P4.1.12 Each Line Approval/Decline", "currentRoute": "/approval (RequestDetail action/tab; request query context required)", "routeSource": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/router/index.tsx; views/Approvals/RequestDetail.tsx; views/Management/index.tsx; views/Reporting/index.tsx"}]

### 方案与准确改动

复用审批完成事件及状态投影，明确DoA、CH、Request Approval、Workflow/Implementation四列。只要有必需批准未完成，Request保持In Approval；全部批准且有当前版本FBP Complete事件后为Approved。实施进度由下游回执独立推进；部分批准沿既有逐Line政策。

主分类：应用内部：状态语义与聚合门槛修正

- ux：列表及详情并列展示Request Approval、Clearing House、Implementation；显示待批角色与当前人。

- frontend：复用RequestDetail、审批节点与状态列；修正列表、Line/Parent摘要、筛选和导出的共享状态函数。

- backend：在同一事务校验当前版本所有required decisions及FBP完成证据，再记录Request Approved；避免并发Complete与批准重复事件。

- data：保存request/version、required-route版本、Line/Parent快照、CH完成actor/time、approval event；历史状态ID需字典Owner映射。

- workflow：Completion gate只开放后续资格，不自动标记Implemented或发送重复实施命令。

数据模型分类：既有请求/CH/实施字段语义与版本关联修正；非新业务主体

性能验收：NOT RUN：先由Owner提供任务/Line规模、并发和部署基线；比较授权结果全量读取、筛选/导出、路由计算、重复请求、DB索引和通知批处理延迟。不得用本页3行合成渲染耗时宣称生产达标。

架构：以请求版本为聚合根，审批与CH完成事件驱动状态投影；多Line分支复用F1021-06，不用单一status字段代表全部。

复用：approval-completion.ts、request-fields.ts、F1021-06/NQA-97；单Line门与事件可复用，现有命名和适用范围仍有缺口。

集成：{"needed": false, "systems": ["NEO"], "provider": "NEO应用及既有身份数据Owner；不新增外部系统", "direction": "应用内部读写；既有身份/组织数据入站只读资格依赖", "reuse": "approval-completion.ts、request-fields.ts、F1021-06/NQA-97；单Line门与事件可复用，现有命名和适用范围仍有缺口。", "evidence": [{"path": "6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx", "locator": "table 6 row 33", "quote": "Once all relevant approvals are provided and the FBP has marked the status within the approval request as complete, the approval request should be marked as “Approved” (separate to the workflow). These details should be stored against the Line items & parent ID for which the request was raised against.\nUsers should have a mechanism within the application to delegate their DOA level for a certain time period, with the ability for that user to add reasoning as to why (e.g. Annual Leave). The application should validate that the delegated individual is within one level of their DOA (if the user i"}, {"path": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p04/approval-completion.ts", "locator": "line 4; singleLineApprovalPolicy", "quote": "export const singleLineApprovalPolicy = 'illustrative-single-line-ch-v1';"}, {"path": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/alignment/request-fields.ts", "locator": "line 26; const overall =", "quote": " const overall = completed ? 'Complete' : request.state === 'submitted' && doa === 'Approved' ? 'Awaiting Clearing House Completion' : doa;"}, {"path": "NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx", "locator": "paragraph 291", "quote": "UC-14 Review and complete the Forum route"}, {"path": "NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx", "locator": "paragraph 319", "quote": "UC-18 Request Settlement and handle rejection"}, {"path": "outputs/neo-jira-stories-20261111/v3/story_data.json", "locator": "entries[act=17]", "quote": "Update Approval Request-FBP | FR10.2"}, {"path": "outputs/neo-jira-stories-20261111/v3/story_data.json", "locator": "entries[act=19]", "quote": "Acknowledge Approval | FR10.6; FR11.1"}, {"path": "outputs/neo-jira-stories-20261111/v3/story_data.json", "locator": "entries[act=24]", "quote": "Start Approval Chain | FR10.6"}], "unknown": "现有内部API DTO、正式角色/政策及数据库迁移契约未签认。"}

依赖：NEO-056正式路由与必需批准集合；既有逐Line/部分审批及Settlement gate；NQA-97；REQ-FR10_6；TRN-AR-DOA-STATUS-01；NEO-029仅复用既有POC会话/草稿恢复，不重做；../solution-review/NEO-029/TASK_TO_POC_CN.md

### 场景与验收边界

每个场景的actual=null，status=NOT RUN。完整字段见ASSESSMENT.json。

- NEO-050-S01｜Buyer/FBP｜输入：DoA Finance=Pending；CH=In progress｜操作：读取列表、详情、Line、Parent和导出｜期望：Request保持In Approval；不得显示Awaiting implementation；三处关联同版。

- NEO-050-S02｜授权FBP｜输入：CH=Complete；reason=All required decisions received｜操作：保存Complete一次 → 刷新再读｜期望：CH=Complete；Request=Approved；Implementation仍Not started；一条完成事件含actor/version/Line/Parent。

- NEO-050-S03｜Buyer和过期FBP会话｜输入：伪造Complete请求；requestVersion=2｜操作：直接调用完成接口 → 回读｜期望：拒绝未授权或过期版本；保存状态不变。

- NEO-050-S04｜两个并发FBP会话｜输入：同一intent重复2次；一个会话修改route version｜操作：并发确认 → 回读事件与状态｜期望：仅一条有效完成；过期路由阻止Complete；不能产生重复实施命令。

- NEO-050-S05｜Finance/实施服务｜输入：SAP receipt=FAILED｜操作：接收下游失败 → 读Request及Line｜期望：保留审批证据；Implementation=Failed/待处理，不伪造Implemented。

- NEO-050-S06｜FBP｜输入：MCI-00057=Approved；58=Approved；59=Rejected｜操作：完成各Line决定 → Complete → 刷新｜期望：按既有部分批准政策，仅批准范围可前行；整体不得冒充全批。

### 页面与来源

[英文页面](pages/NEO-050.html)；[截图1](screenshots/NEO-050-desktop.png)；[截图2](screenshots/NEO-050-narrow.png)；[截图3](screenshots/NEO-050-exception.png)；[截图4](screenshots/NEO-050-approved.png)

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!D51 — Existing functionality - Update UX / Workflow

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E51 — The replacement NEO shall for clearing house items, when all relevant approvals are provided and the FBP has marked the status within the approval request as complete, the approval request shall be marked as "Approved" (separate to the workflow). These details should be stored against the Line items & parent ID for which the request was raised agai

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!G51 — Yes

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!J51 — Yes

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!K51 — Must

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!M51 — Items approved by one party but awaiting approval by the other are shown as "awaiting implementation". This is not the correct status

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!Q51 — The replacement NEO shall for clearing house items, when all relevant approvals are provided and the FBP has marked the status within the approval request as complete, the approval request shall be marked as "Approved" (separate to the workflow). These details should be stored against the Line items & parent ID for which the request was raised agai

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!R51 — N

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / table 6 row 33 — Once all relevant approvals are provided and the FBP has marked the status within the approval request as complete, the approval request should be marked as “Approved” (separate to the workflow). These details should be stored against the Line items & parent ID for which the request was raised against. Users should have a mechanism within the appli

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p04/approval-completion.ts` / line 4; singleLineApprovalPolicy — export const singleLineApprovalPolicy = 'illustrative-single-line-ch-v1';

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/alignment/request-fields.ts` / line 26; const overall = —  const overall = completed ? 'Complete' : request.state === 'submitted' && doa === 'Approved' ? 'Awaiting Clearing House Completion' : doa;

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraph 291 — UC-14 Review and complete the Forum route

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraph 319 — UC-18 Request Settlement and handle rejection

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=17] — Update Approval Request-FBP | FR10.2

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=19] — Acknowledge Approval | FR10.6; FR11.1

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=24] — Start Approval Chain | FR10.6

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / rows[audit_id=PAGE-P4.7] — P4.7 Update Approval Request

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / rows[audit_id=PAGE-P4.1.12] — P4.1.12 Each Line Approval/Decline

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A1206:N1206 — MCI_REQUEST | 申请与审批 | 业务 | APPROVAL_STATUS_ID | int(11) | integer | 是 | FK | MCI_REF_APPROVAL_STATUS | APPROVAL_STATUS_ID | 已建 | 否 | Primary Key of MCI_REF_APPROVAL_STATUS table | 结构+字典

## NEO-051 按有效期委托DoA并保留原审批人

### 用户问题与原文

审批人休假后需要管理员重路由，缺少可审计的合格代理安排。

> The replacement NEO shall allow users to have a mechanism within the application to delegate their DOA level for a certain time period, with the ability for that user to add reasoning as to why (e.g. Annual Leave). the application shall validate that the delegated individual is within one level of their DOA (if the user is not, this action cannot be performed). the application shall store a log of these instances where DOA levels have been delegated (e.g. to cover Annual Leave). Note: Show multiple names if someone is out of office.

采购期望Q：The replacement NEO shall allow users to have a mechanism within the application to delegate their DOA level for a certain time period, with the ability for that user to add reasoning as to why (e.g. Annual Leave). the application shall validate that the delegated individual is within one level of their DOA (if the user is not, this action cannot be performed). the application shall store a log of these instances where DOA levels have been delegated (e.g. to cover Annual Leave). Note: Show multiple names if someone is out of office.

Finance期望P：空白，未补造。

原优先级：采购Should；Finance None。建议P1：源Should；已有本地可复用基础，先确认委派范围和权限再扩展。

### UC定位与当前基线

UC-14 (related)；ACT-018, ACT-032；FR10.6, FR9.5

现有DelegateDoa与doa-delegation.ts已保存原因、带时区起止时间、原/代理assignment；按硬编码orderedLevels判一档，限定普通任务且未批准。delegation-window按读取/命令时切换。实现是具体任务/请求版本委派，不能据此认定“用户整个期间所有未来审批”已支持。

页面登记编号与当前路由：[{"id": "P4.1.11", "name": "Delegate / Acknowledge Approval", "source": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Approvals/DelegateDoa.tsx", "observation": "当前源码可观察入口；本轮未执行产品功能。", "pageIdBasis": "Canonical QA PAGE registry / user127-page list; historical alias, not React route number", "registrySource": "NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json", "registryLocator": "rows[audit_id=PAGE-P4.1.11]", "registryObservation": "P4.1.11 Delegate／Acknowledge Approval", "currentRoute": "/approval (RequestDetail action/tab; request query context required)", "routeSource": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/router/index.tsx; views/Approvals/RequestDetail.tsx; views/Management/index.tsx; views/Reporting/index.tsx"}]

### 方案与准确改动

复用限时委派表单和双姓名历史，先确认范围为单任务还是用户级安排；按批准的等级顺序及适用权限评估候选。保存前预览适用任务、开始/结束和原审批人；到期由服务端时钟和权限重检撤销代理行动权。

主分类：应用内部：现有委派扩展与权限政策对齐

- ux：委派页列原审批人、代理、期间、原因及适用请求；不把该动作命名为Transfer。

- frontend：复用DelegateDoa日期、人员选择与日志；明确按任务/期间范围，保留输入及冲突提示。

- backend：复用逻辑task及assignment；将资格/有效期判断置于服务端，处理失效用户、重叠委派和到期时的正在处理任务。

- data：持久化principal/delegate、authority-policy、scope、start/end instant/timezone、createdBy/reason及撤销事件；字典现有DELEGATOR不足以证明已有期间字段。

- workflow：原任务不视为完成；代理实际决定记录actual actor及on-behalf-of；过期后按确认政策恢复合格原审批人。

数据模型分类：已有task-bound委派记录扩展；若业务确认全期间覆盖未来任务才新增用户级委派范围实体

性能验收：NOT RUN：先由Owner提供任务/Line规模、并发和部署基线；比较授权结果全量读取、筛选/导出、路由计算、重复请求、DB索引和通知批处理延迟。不得用本页3行合成渲染耗时宣称生产达标。

架构：委派授权为有范围和有效期的独立记录，通过既有assignment投影；不修改用户永久DoA、不新增IAM。

复用：DelegateDoa、doa-delegation、delegation-window；NQA-95及F1021-06；正式等级顺序、跨角色/CoC与全期间范围未签认。

集成：{"needed": false, "systems": ["NEO", "既有身份/组织数据"], "provider": "NEO应用及既有身份数据Owner；不新增外部系统", "direction": "应用内部读写；既有身份/组织数据入站只读资格依赖", "reuse": "DelegateDoa、doa-delegation、delegation-window；NQA-95及F1021-06；正式等级顺序、跨角色/CoC与全期间范围未签认。", "evidence": [{"path": "6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx", "locator": "table 6 row 33", "quote": "Users should have a mechanism within the application to delegate their DOA level for a certain time period, with the ability for that user to add reasoning as to why (e.g. Annual Leave). The application should validate that the delegated individual is within one level of their DOA (if the user is not, this action cannot be performed). The application should store a log of these instances where DOA levels have been delegated (e.g. to cover Annual Leave). Note: Show multiple names if someone is out of office. \nUsers should have the ability to approve/ reject individual child items from the appro"}, {"path": "6.技术方案/2 - Tech NEO/NEO User Training.docx", "locator": "paragraph 1005", "quote": "Note: Managed by members of FBP or Finance Approver group"}, {"path": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p04/doa-delegation.ts", "locator": "line 8; const orderedLevels", "quote": "const orderedLevels = ['D', 'LL6', 'LL5', 'LL4', 'LL3', 'LL2.5', 'LL2', 'CEO'];"}, {"path": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p04/delegation-window.ts", "locator": "line 7; export function delegationStatus", "quote": "export function delegationStatus(row: DoaDelegation, now = Date.now()): 'Scheduled' | 'Active' | 'Expired' {"}, {"path": "NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx", "locator": "paragraph 291", "quote": "UC-14 Review and complete the Forum route"}, {"path": "outputs/neo-jira-stories-20261111/v3/story_data.json", "locator": "entries[act=18]", "quote": "Add Delegator | FR10.6"}, {"path": "outputs/neo-jira-stories-20261111/v3/story_data.json", "locator": "entries[act=32]", "quote": "Edit DOA Rules | FR9.5"}], "unknown": "现有内部API DTO、正式角色/政策及数据库迁移契约未签认。"}

依赖：NEO-056正式等级与角色/CoC矩阵；NEO-064与本项边界；NQA-95；FIELD-PF-0480；NEO-029仅复用既有POC会话/草稿恢复，不重做；../solution-review/NEO-029/TASK_TO_POC_CN.md

### 场景与验收边界

每个场景的actual=null，status=NOT RUN。完整字段见ASSESSMENT.json。

- NEO-051-S01｜授权委派维护人｜输入：delegate=Alex Chen；start=2026-11-16T09:00:00+08:00；end=2026-11-20T18:00:00+08:00；reason=Annual leave｜操作：预览适用范围 → 保存 → 刷新｜期望：原人及代理姓名、范围、期间和原因一致；不更改永久DoA。

- NEO-051-S02｜授权委派维护人｜输入：同级/相邻一级/相隔两级三个已签认fixture｜操作：分别尝试委派｜期望：按确认的within-one-level表逐项允许/拒绝；未签认等级不自动猜测。

- NEO-051-S03｜代理人｜输入：now=start-1ms/start/end-1ms/end｜操作：分别尝试批准 → 重开页面｜期望：起止边界按确认政策，只有有效期且当时有资格者可行动；到期不能用旧链接批准。

- NEO-051-S04｜管理员/两个窗口｜输入：相同任务新增重叠代理；移除delegate角色；旧revision提交｜操作：并发保存 → 刷新 → 代理尝试批准｜期望：不得产生双有效assignment；资格撤销后拒绝；输入保留并提示重读。

- NEO-051-S05｜代理人｜输入：endsAt早于startsAt；reason空｜操作：保存｜期望：拒绝；原assignment和历史不变。

- NEO-051-S06｜通知服务/审批人｜输入：通知失败且代理期结束原人已离职｜操作：运行边界任务 → 回读授权与投递｜期望：不延长代理权、不激活失效原人；进入确认的恢复责任队列，送达失败与授权状态分开。

### 页面与来源

[英文页面](pages/NEO-051.html)；[截图1](screenshots/NEO-051-desktop.png)；[截图2](screenshots/NEO-051-narrow.png)；[截图3](screenshots/NEO-051-exception.png)

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!D52 — New functionality

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E52 — The replacement NEO shall allow users to have a mechanism within the application to delegate their DOA level for a certain time period, with the ability for that user to add reasoning as to why (e.g. Annual Leave). the application shall validate that the delegated individual is within one level of their DOA (if the user is not, this action cannot b

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!G52 — No

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!K52 — Should

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!M52 — When users are OoO unable to easily delegate approvals to other empowered users. Instead items have to be manually rerouted or approvals progressed via admin access.

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!Q52 — The replacement NEO shall allow users to have a mechanism within the application to delegate their DOA level for a certain time period, with the ability for that user to add reasoning as to why (e.g. Annual Leave). the application shall validate that the delegated individual is within one level of their DOA (if the user is not, this action cannot b

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!R52 — N

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / table 6 row 33 — Users should have a mechanism within the application to delegate their DOA level for a certain time period, with the ability for that user to add reasoning as to why (e.g. Annual Leave). The application should validate that the delegated individual is within one level of their DOA (if the user is not, this action cannot be performed). The applicati

- `6.技术方案/2 - Tech NEO/NEO User Training.docx` / paragraph 1005 — Note: Managed by members of FBP or Finance Approver group

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p04/doa-delegation.ts` / line 8; const orderedLevels — const orderedLevels = ['D', 'LL6', 'LL5', 'LL4', 'LL3', 'LL2.5', 'LL2', 'CEO'];

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p04/delegation-window.ts` / line 7; export function delegationStatus — export function delegationStatus(row: DoaDelegation, now = Date.now()): 'Scheduled' | 'Active' | 'Expired' {

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraph 291 — UC-14 Review and complete the Forum route

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=18] — Add Delegator | FR10.6

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=32] — Edit DOA Rules | FR9.5

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / rows[audit_id=PAGE-P4.1.11] — P4.1.11 Delegate／Acknowledge Approval

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A1172:N1172 — MCI_APPROVAL | 申请与审批 | 业务 | DELEGATOR | varchar(255) | varchar(255) | 是 | 否 | 结构

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A1173:N1173 — MCI_APPROVAL | 申请与审批 | 业务 | DELEGATOR_ADDED_BY | varchar(255) | varchar(255) | 是 | 否 | 结构

## NEO-056 按企业DoA生成必需审批，明确例外加签

### 用户问题与原文

M57报告good-news和positive/negative Settlement路由不一致，产生企业DoA以外的额外审批。

> NEO Should correctly implement the DOA and ensure that approvals are collected appropriately.

采购期望Q：As a procurement user - the DOA that is implemented should reflect the corporate DOA standards and not implement additional approvals

Finance期望P：空白，未补造。

原优先级：采购Must；Finance None。建议P0：采购Must且R57=Y；影响审批控制与正负交易正确性，先于扩大委派和转办。

### UC定位与当前基线

UC-12 (direct), UC-14 (direct), UC-13 (related), UC-18 (related)；ACT-010, ACT-013, ACT-032；FR9, FR9.4, FR9.5

ManageDoa已有规则编辑、版本冲突与导出。domain/access/doa.ts从Training常量选GBP/forum行，自己注明category applicability和actor mapping未确认；brd-request仍直接selectDoaRow，不能证明管理页保存的所有规则已经驱动所有Mandate/Settlement分支。

页面登记编号与当前路由：[{"id": "P7.2", "name": "Manage DOA", "source": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Management/Doa.tsx", "observation": "当前源码可观察入口；本轮未执行产品功能。", "pageIdBasis": "Canonical QA PAGE registry / user127-page list; historical alias, not React route number", "registrySource": "NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json", "registryLocator": "rows[audit_id=PAGE-P7.2]", "registryObservation": "P7.2 Management - Manage DoA", "currentRoute": "/admin/master-data?section=doa", "routeSource": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/router/index.tsx; views/Approvals/RequestDetail.tsx; views/Management/index.tsx; views/Reporting/index.tsx"}, {"id": "P4.1.7", "name": "Approval Check", "source": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Approvals/RequestApprovalCheck.tsx", "observation": "当前源码可观察入口；本轮未执行产品功能。", "pageIdBasis": "Canonical QA PAGE registry / user127-page list; historical alias, not React route number", "registrySource": "NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json", "registryLocator": "rows[audit_id=PAGE-P4.1.7]", "registryObservation": "P4.1.7 Approval Check", "currentRoute": "/approval (RequestDetail action/tab; request query context required)", "routeSource": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/router/index.tsx; views/Approvals/RequestDetail.tsx; views/Management/index.tsx; views/Reporting/index.tsx"}]

### 方案与准确改动

以签认的企业DoA矩阵作为唯一版本化路由依据；分开计算Risk/Opportunity，不将正负简单净额相抵。用业务金样校核positive/negative、LSP/POA/TD、币种及边界。默认只生成矩阵必需节点；FR10.2 FBP向上升级及063例外加签独立记录原因/权限，是否保留须R57双方对齐。

主分类：应用内部：DoA规则与审批路由一致性修正

- ux：Approval Check显示政策版本、Risk/Opportunity依据、必需节点及例外节点，不显示未经确认的阈值。

- frontend：复用P7.2/Approval Check；显示路由依据与无法匹配的具体条件，禁止静默选默认论坛。

- backend：统一规则解析服务贯通配置、预览和提交；双重版本检查；GBP转换依据与正负方向政策按金样校验。

- data：DoA版本/生效期、类别/交易/TD范围、金额精度及边界、角色映射；冻结request routing basis与exception理由。

- workflow：创建恰当的必需节点，例外升级/加签作为单独审计决定；政策变化对在途任务的适用方式待定。

数据模型分类：既有DoA配置增加生效版本/匹配范围与冻结决策依据；不是新增外部主数据系统

性能验收：NOT RUN：先由Owner提供任务/Line规模、并发和部署基线；比较授权结果全量读取、筛选/导出、路由计算、重复请求、DB索引和通知批处理延迟。不得用本页3行合成渲染耗时宣称生产达标。

架构：复用现有规则管理与路由接口，替换只供展示的Training常量耦合；不引入新规则平台，先做有版本的内部决策服务。

复用：Management/Doa.tsx、access/doa-settings、selectDoaRow、P4.1.7；参考数据列与事件机制可复用，但配置到运行时契约待查证。

集成：{"needed": false, "systems": ["NEO"], "provider": "NEO应用及既有身份数据Owner；不新增外部系统", "direction": "应用内部读写；既有身份/组织数据入站只读资格依赖", "reuse": "Management/Doa.tsx、access/doa-settings、selectDoaRow、P4.1.7；参考数据列与事件机制可复用，但配置到运行时契约待查证。", "evidence": [{"path": "6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx", "locator": "table 6 row 25", "quote": "Note: For requests linked to line items, the DOA should apply to the calculated “Request total – Risks” and “Request total – Opportunities” fields. The DOA should then apply the highest DOA applicable considering the values in these 2 fields.\nWhere request not linked to line items, take the GBP value keyed onto the transaction request (e.g. payment term acceleration payments) Need to add up positive and negative values and separate these. Then Apply DOA to highest value.\nIf the line item/ parent ID has already received a level of sign off previously (e.g. via request for mandate), the system s"}, {"path": "6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx", "locator": "table 6 row 29", "quote": "A purchasing FBP user should also have the ability to escalate (increase) the DOA levels if required (e.g. for certain inflation claims), with ability to add comments as to why. The user should not be able to reduce the DOA levels set by the system. This should also update the level of forum required. "}, {"path": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/access/doa.ts", "locator": "line 6; routing decision", "quote": " * routing decision: category applicability and actor mappings need confirmation. */"}, {"path": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p04/brd-request.ts", "locator": "line 4; selectDoaRow", "quote": "import {selectDoaRow} from '../access/doa';"}, {"path": "NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx", "locator": "paragraph 277", "quote": "UC-12 Submit a formal Mandate"}, {"path": "NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx", "locator": "paragraph 291", "quote": "UC-14 Review and complete the Forum route"}, {"path": "NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx", "locator": "paragraph 284", "quote": "UC-13 Follow the Opportunity branch"}, {"path": "NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx", "locator": "paragraph 319", "quote": "UC-18 Request Settlement and handle rejection"}, {"path": "outputs/neo-jira-stories-20261111/v3/story_data.json", "locator": "entries[act=10]", "quote": "Request For Mandate | FR9; FR9.4"}, {"path": "outputs/neo-jira-stories-20261111/v3/story_data.json", "locator": "entries[act=13]", "quote": "Approval Check | FR9.4; FR10.2"}, {"path": "outputs/neo-jira-stories-20261111/v3/story_data.json", "locator": "entries[act=32]", "quote": "Edit DOA Rules | FR9.5"}], "unknown": "现有内部API DTO、正式角色/政策及数据库迁移契约未签认。"}

依赖：正式企业DoA矩阵及双向Settlement金样；NEO-063例外审批；NEO-051/064人员资格；NQA-88；REQ-FR9_4；F1021-06；NEO-029仅复用既有POC会话/草稿恢复，不重做；../solution-review/NEO-029/TASK_TO_POC_CN.md

### 场景与验收边界

每个场景的actual=null，status=NOT RUN。完整字段见ASSESSMENT.json。

- NEO-056-S01｜Buyer/FBP｜输入：Risk £12000.00；Opportunity £8000.00；LSP；GBP｜操作：预览路由 → 提交 → 刷新｜期望：按两类金额各自匹配并取适用较高DoA；不以净额£4000路由；实际人员匹配签认金样。

- NEO-056-S02｜规则Owner｜输入：9999.99 / 10000.00 / 10000.01；Risk与Opportunity各跑一组｜操作：分别预览/提交｜期望：每个边界结果等于该fixture预先签认路由；不将T视为企业实际阈值。

- NEO-056-S03｜FBP｜输入：无适用类别；未知FX basis；未映射approver｜操作：提交｜期望：明确阻止并指出缺口；不能选默认forum或补造批准人。

- NEO-056-S04｜Buyer/规则Owner｜输入：预览policy=v7；提交前已变v8｜操作：两会话更新 → 提交旧预览｜期望：按确认的在途政策处理；不能静默保存与预览不同route。

- NEO-056-S05｜授权FBP｜输入：reason=Contractual exception review；additional review=Legal｜操作：预览例外 → 保存｜期望：必需DoA仍完整；额外节点独立标为例外，理由/权限可查；禁止降级。

- NEO-056-S06｜Finance｜输入：对应positive/negative Settlement两笔等绝对金额金样｜操作：从已批准Mandate发Settlement → 检查是否可引用旧批准｜期望：适用FR9.4且FBP确认才复用；正负路由完全匹配签认期望，不机械统一。

### 页面与来源

[英文页面](pages/NEO-056.html)；[截图1](screenshots/NEO-056-desktop.png)；[截图2](screenshots/NEO-056-narrow.png)；[截图3](screenshots/NEO-056-exception.png)

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!D57 — Existing functionality - Update/correct logic

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E57 — NEO Should correctly implement the DOA and ensure that approvals are collected appropriately.

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!G57 — Yes

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!J57 — Yes

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!K57 — Must

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!M57 — Procurement - the DOA that is implemented and used within NEO does not mirror the corporate DOA and asks for additional approvals that are not part of the DOA (particularly on good news items) The DOA applied to positive IDs is not the same as negatives at settlement.

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!Q57 — As a procurement user - the DOA that is implemented should reflect the corporate DOA standards and not implement additional approvals

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!R57 — Y

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / table 6 row 25 — Note: For requests linked to line items, the DOA should apply to the calculated “Request total – Risks” and “Request total – Opportunities” fields. The DOA should then apply the highest DOA applicable considering the values in these 2 fields. Where request not linked to line items, take the GBP value keyed onto the transaction request (e.g. payment

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / table 6 row 29 — A purchasing FBP user should also have the ability to escalate (increase) the DOA levels if required (e.g. for certain inflation claims), with ability to add comments as to why. The user should not be able to reduce the DOA levels set by the system. This should also update the level of forum required. 

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/access/doa.ts` / line 6; routing decision —  * routing decision: category applicability and actor mappings need confirmation. */

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p04/brd-request.ts` / line 4; selectDoaRow — import {selectDoaRow} from '../access/doa';

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraph 277 — UC-12 Submit a formal Mandate

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraph 291 — UC-14 Review and complete the Forum route

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraph 284 — UC-13 Follow the Opportunity branch

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraph 319 — UC-18 Request Settlement and handle rejection

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=10] — Request For Mandate | FR9; FR9.4

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=13] — Approval Check | FR9.4; FR10.2

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=32] — Edit DOA Rules | FR9.5

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / rows[audit_id=PAGE-P7.2] — P7.2 Management - Manage DoA

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / rows[audit_id=PAGE-P4.1.7] — P4.1.7 Approval Check

## NEO-057 开放任务状态、当前责任人与逾期提醒

### 用户问题与原文

现有Task Completion报告未清楚告诉业务任务当前停在谁手里。

> NEO should show the current status of any task that is open and who it is with. This should be available within the UI of the application and as a report that can be downloaded to show where tasks/actions/approvals are awaiting with auotmated reminder functionality for overdue tasks/approvals

采购期望Q：NEO should show the current status of any task that is open and who it is with. This should be available within the UI of the application and as a report that can be downloaded to show where tasks/actions/approvals are awaiting with auotmated reminder functionality for overdue tasks/approvals

Finance期望P：空白，未补造。

原优先级：采购Must；Finance None。建议P1：采购Must；可见性先交付，但自动提醒必须连通知契约、日历和可靠投递一起验收。

### UC定位与当前基线

UC-24 (direct-report-slice), UC-17 (related)；ACT-020, ACT-036, ACT-046, ACT-055；FR15, FR21, FR20.3, FR10.5

Tasks队列已有assignedTo、状态和任务来源；TaskCompletion前端从completion data生成查询/导出，p05/task-reporting另有Assigned to字段与snapshot。SLA代码采用固定毫秒天/小时，不是批准的工作日历。调度表确有TD提醒和审批周报，但TD行描述“创建次日”与频率“每周二/四”冲突；不能当全部逾期任务通知契约。

页面登记编号与当前路由：[{"id": "P3", "name": "Task list", "source": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Tasks/index.tsx", "observation": "当前源码可观察入口；本轮未执行产品功能。", "pageIdBasis": "Canonical QA PAGE registry / user127-page list; historical alias, not React route number", "registrySource": "NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json", "registryLocator": "rows[audit_id=PAGE-P3]", "registryObservation": "P3 Task list", "currentRoute": "/tasks", "routeSource": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/router/index.tsx; views/Approvals/RequestDetail.tsx; views/Management/index.tsx; views/Reporting/index.tsx"}, {"id": "P6.3", "name": "Task Completion Report", "source": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Reporting/TaskCompletion.tsx", "observation": "当前源码可观察入口；本轮未执行产品功能。", "pageIdBasis": "Canonical QA PAGE registry / user127-page list; historical alias, not React route number", "registrySource": "NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json", "registryLocator": "rows[audit_id=PAGE-P6.3]", "registryObservation": "P6.3 Task Completion Report", "currentRoute": "/reporting?section=task-completion", "routeSource": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/router/index.tsx; views/Approvals/RequestDetail.tsx; views/Management/index.tsx; views/Reporting/index.tsx"}]

### 方案与准确改动

复用任务read model，汇聚开放Task/Action/Approval，显示个人或组、状态、due和记录版本；导出同一授权筛选的全部记录。提醒由后台按确认的due/calendar/event规则生成，投递失败可追踪重试，不能重复创建任务或更新业务状态。

主分类：集成＋应用：任务报告扩展和通知可靠投递

- ux：统一开放任务列表，先显示当前Owner；状态、Due及提醒结果可筛选，空态和缺失期限明确。

- frontend：复用Tasks/TaskCompletion/导出；个人或组分别表达；一个footer计数，分页不限制导出全量。

- backend：共享权限过滤与任务快照查询；稳定分页；按task/assignment/rule version建立提醒去重与outbox，服务端重查当前受理人。

- data：task logical ID、assignment version、current user/group、due instant/calendar ID、notification event/attempt/receipt；不把“Queued”当Sent。

- workflow：逾期不自动批准/完成；转办后停发旧Owner提醒，处理暂停、等待依赖与已结束任务。

数据模型分类：现有任务read model补当前Owner投影；通知outbox/投递attempt/receipt为拟新增技术记录

性能验收：NOT RUN：先由Owner提供任务/Line规模、并发和部署基线；比较授权结果全量读取、筛选/导出、路由计算、重复请求、DB索引和通知批处理延迟。不得用本页3行合成渲染耗时宣称生产达标。

架构：内部任务read model + 既有企业通知能力适配器；仅确认后复用TD scheduler/邮件基础，不凭目录假设已具备通用提醒服务。

复用：tasks/queue、p05/task-reporting、Reporting/TaskCompletion；Scheduler的TD提醒及审批周报为复用候选，非通用契约。

集成：{"needed": true, "systems": ["NEO", "企业通知平台（供应方待确认）"], "provider": "企业通知/邮件服务Owner待确认", "direction": "NEO任务事件 → 企业通知通道 → 收件人；投递结果 → NEO", "reuse": "tasks/queue、p05/task-reporting、Reporting/TaskCompletion；Scheduler的TD提醒及审批周报为复用候选，非通用契约。", "evidence": [{"path": "6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx", "locator": "table 6 row 40", "quote": "FR15 | Task List | Context: The application will contain a task list for all users. When a user receives a task (e.g. buyer receiving an enquiry or GFS receiving a checking task, the task will appear in this list. \nThe solution should contain a tab for “My Tasks”, which all users should have access to. \nIf a user accesses this tab, they should have a view of a grid containing all the tasks which are relevant for them/ their user group (e.g. GFS, Buyer etc.).\nA user should have the ability to filter and sort the task list. \nA user should be able to select a particular task. When selected, they should have the ability to assign that task to themselves or someone else in their user group. \nVisibility should be managed at group level, with the following exceptions:\nBuyers should have visibility of tasks relating to their buyer code and then linked purchasing managers and senior purchasing managers (based on CoC) should also see/action those tasks. \nFor certain approval tasks (e.g. Trading Division), tasks will be created for specific users instead of groups. GFS should have the ability in the system to assign new users if needed to the task."}, {"path": "6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx", "locator": "table 6 row 73", "quote": "FR21 | Controls – Task SLA’s  | The solution should allow SLA’s to be stated against each task type (in days)\nThe SLA status should then be displayed against each task in the task list. The statuses should be as follows:\nGreen: Within SLA\nAmber: Approaching SLA \nRed: Breached SLA "}, {"path": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/tasks/queue.ts", "locator": "line 56; assignedTo:", "quote": "    source:'Standalone',sourceId:r.id,sourceVersion:r.revision,requestId:r.id,claimIds:[],lineIds:[],status,assignedTo:status==='Completed'?null:manual.ownerId,"}, {"path": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/tasks/sla.ts", "locator": "line 22; const unit=", "quote": " const unit=rule?.isHourly?3600000:86400000;"}, {"path": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p05/task-reporting.ts", "locator": "line 457; 'Assigned to'", "quote": "                'Claim IDs': r.claimIds.join(', '), 'Line IDs': r.lineIds.join(', '), 'Status': r.status, 'Assigned to': r.assignedTo,"}, {"path": "6.技术方案/2 - Tech NEO/Scheduler Processes - 2026-11-09_0944.xlsx", "locator": "Sheet 1!B14:G14", "quote": "Sends emails to open Trading Division (TD) tasks assignee next day of creation | 09:00 | Every Tuesday and Thursday"}, {"path": "6.技术方案/2 - Tech NEO/Scheduler Processes - 2026-11-09_0944.xlsx", "locator": "Sheet 1!B16:G16", "quote": "Approval request report | Sends weekly twice report for approval requests"}, {"path": "NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx", "locator": "paragraph 361", "quote": "UC-24 Use reports and audit evidence"}, {"path": "NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx", "locator": "paragraph 312", "quote": "UC-17 Transfer and suspend work"}, {"path": "outputs/neo-jira-stories-20261111/v3/story_data.json", "locator": "entries[act=20]", "quote": "Reassign Task | FR15"}, {"path": "outputs/neo-jira-stories-20261111/v3/story_data.json", "locator": "entries[act=36]", "quote": "Manage SLA | FR21"}, {"path": "outputs/neo-jira-stories-20261111/v3/story_data.json", "locator": "entries[act=46]", "quote": "Task Completion Report | FR20.3"}, {"path": "outputs/neo-jira-stories-20261111/v3/story_data.json", "locator": "entries[act=55]", "quote": "Action Task for User | FR10.5"}], "unknown": "接口目录不能证明消息payload、送达回执、幂等或重试契约；日历/频率待确认。"}

依赖：NEO-051/064实际owner投影；SLA日历/时区/暂停规则；通知服务Owner确认；ACT-036/046跨Epic；REQ-FR15；REQ-FR21；F1021-12；F1021-30；NEO-029仅复用既有POC会话/草稿恢复，不重做；../solution-review/NEO-029/TASK_TO_POC_CN.md

### 场景与验收边界

每个场景的actual=null，status=NOT RUN。完整字段见ASSESSMENT.json。

- NEO-057-S01｜有权限报告用户｜输入：Status=Open；Task type=Approval｜操作：筛选 → 分页 → 下载｜期望：UI总数与全量授权筛选导出一致；当前个人或组可识别；不能泄漏权限外行。

- NEO-057-S02｜当前任务Owner｜输入：Owner=Alex Chen → Jamie Reed；assignment=a2｜操作：转办后刷新报告 → 导出｜期望：只显示当前Owner，旧assignment仍在审计；不按Created by假定Owner。

- NEO-057-S03｜通知scheduler｜输入：due=2026-11-16T17:00:00+08:00；run=17:00及17:00:01｜操作：按固定时钟执行提醒 → 重复运行｜期望：边界按政策；每task/assignment/rule/window只产生一次有效提醒，Owner来自当前状态。

- NEO-057-S04｜通知服务Owner｜输入：发送timeout，结果未知；随后回执Delivered｜操作：重试并对账｜期望：先查同一event结果；不重复投递/建任务，最终状态与receipt一致；Failed不显示Sent。

- NEO-057-S05｜权限Owner/用户｜输入：导出请求中撤销CoC权限；Task已Closed｜操作：尝试下载和提醒｜期望：导出再验权限；完成/失效assignment不发可行动提醒。

- NEO-057-S06｜报告用户｜输入：Search=NO_MATCH_ABC；due=null｜操作：搜索 → 清除 → 下载｜期望：明确空态且可恢复；缺due显示—，不伪造逾期/默认期限。

### 页面与来源

[英文页面](pages/NEO-057.html)；[截图1](screenshots/NEO-057-desktop.png)；[截图2](screenshots/NEO-057-narrow.png)；[截图3](screenshots/NEO-057-exception.png)

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!D58 — Existing functionality - Update UX / Workflow

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E58 — NEO should show the current status of any task that is open and who it is with. This should be available within the UI of the application and as a report that can be downloaded to show where tasks/actions/approvals are awaiting with auotmated reminder functionality for overdue tasks/approvals

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!G58 — Yes

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!K58 — Must

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!M58 — Current task completion report doesn't detail who the task is with

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!Q58 — NEO should show the current status of any task that is open and who it is with. This should be available within the UI of the application and as a report that can be downloaded to show where tasks/actions/approvals are awaiting with auotmated reminder functionality for overdue tasks/approvals

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!R58 — N

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / table 6 row 40 — FR15 | Task List | Context: The application will contain a task list for all users. When a user receives a task (e.g. buyer receiving an enquiry or GFS receiving a checking task, the task will appear in this list.  The solution should contain a tab for “My Tasks”, which all users should have access to.  If a user accesses this tab, they should have

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / table 6 row 73 — FR21 | Controls – Task SLA’s  | The solution should allow SLA’s to be stated against each task type (in days) The SLA status should then be displayed against each task in the task list. The statuses should be as follows: Green: Within SLA Amber: Approaching SLA  Red: Breached SLA 

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/tasks/queue.ts` / line 56; assignedTo: —     source:'Standalone',sourceId:r.id,sourceVersion:r.revision,requestId:r.id,claimIds:[],lineIds:[],status,assignedTo:status==='Completed'?null:manual.ownerId,

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/tasks/sla.ts` / line 22; const unit= —  const unit=rule?.isHourly?3600000:86400000;

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p05/task-reporting.ts` / line 457; 'Assigned to' —                 'Claim IDs': r.claimIds.join(', '), 'Line IDs': r.lineIds.join(', '), 'Status': r.status, 'Assigned to': r.assignedTo,

- `6.技术方案/2 - Tech NEO/Scheduler Processes - 2026-11-09_0944.xlsx` / Sheet 1!B14:G14 — Sends emails to open Trading Division (TD) tasks assignee next day of creation | 09:00 | Every Tuesday and Thursday

- `6.技术方案/2 - Tech NEO/Scheduler Processes - 2026-11-09_0944.xlsx` / Sheet 1!B16:G16 — Approval request report | Sends weekly twice report for approval requests

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraph 361 — UC-24 Use reports and audit evidence

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraph 312 — UC-17 Transfer and suspend work

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=20] — Reassign Task | FR15

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=36] — Manage SLA | FR21

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=46] — Task Completion Report | FR20.3

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=55] — Action Task for User | FR10.5

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / rows[audit_id=PAGE-P3] — P3 Task list

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / rows[audit_id=PAGE-P6.3] — P6.3 Task Completion Report

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A1667:N1667 — MCI_TASK | 问询、任务与附件 | 业务 | ASSIGNED_USER | varchar(255) | varchar(255) | 是 | 否 | Column to store the assigned user for the given task | 结构+字典

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A1668:N1668 — MCI_TASK | 问询、任务与附件 | 业务 | ASSIGNED_GROUP | varchar(255) | varchar(255) | 是 | 否 | Column to store the assigned group for the given task | 结构+字典

- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` / CSV header and complete 23-row directory reviewed — Record Name:, Integrations, , , , , , , , , , , , , , , , , , , , , 

## NEO-063 按Before/After顺序增加必需审阅

### 用户问题与原文

特殊事项需要额外或高级审阅，当前任务不应靠线下邮件绕过可见依赖。

> Enable additional approvals so approvers can add additional or senior-level approvers when specific or exceptional cases require further review.

采购期望Q：空白，未补造。

Finance期望P：空白，未补造。

原优先级：采购None；Finance None。建议P1：K/L为空，建议P1为分析意见；与DoA例外策略一起确认后复用实现。

### UC定位与当前基线

UC-16 (direct), UC-14 (related)；ACT-018, ACT-019, ACT-024；FR10.6, FR22.3, FR22.5

当前TaskActions已有Add Before/Add After，dependency.ts已有子task与parent关联及不同激活顺序。候选来自workflowScenarios().eligibleActorIds，属于POC配置，不能视为完整正式eligibility/SoD。旧UC-16笼统“原人不得先批准”需以FR22.3的Before/After区别解读。

页面登记编号与当前路由：[{"id": "P4.1.11", "name": "Approval task actions (related host)", "source": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Approvals/Decisions.tsx", "observation": "当前源码可观察入口；本轮未执行产品功能。", "pageIdBasis": "Canonical QA PAGE registry / user127-page list; historical alias, not React route number", "registrySource": "NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json", "registryLocator": "rows[audit_id=PAGE-P4.1.11]", "registryObservation": "P4.1.11 Delegate／Acknowledge Approval", "currentRoute": "/approval (RequestDetail action/tab; request query context required)", "routeSource": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/router/index.tsx; views/Approvals/RequestDetail.tsx; views/Management/index.tsx; views/Reporting/index.tsx"}]

### 方案与准确改动

复用POC按钮、reason、reviewer及依赖机制，补清楚的路由预览和受影响Line范围。Before先审阅后恢复原任务；After原人先批准、再激活追加任务，并阻挡下游。加签不可替代正式DoA，拒绝/退回只按已确认范围处理。

主分类：应用内部：复用加签能力并补权限/范围/依赖闭环

- ux：选择Add Before或Add After，合格reviewer、scope、reason；确认前展示顺序与当前被阻挡的任务。

- frontend：复用TaskActions/ApprovalFlow，明确额外审阅与DoA节点视觉区别；显示退回、拒绝及恢复状态。

- backend：请求版本/当前assignment/权限二次校验；拒绝自审和循环依赖；原子创建子任务和审计事件，幂等处理重试。

- data：parent task、child task、before/after、affected Line snapshot、request version、policy/reason、review outcome。

- workflow：Before等待子任务；After等原批准再启子任务；未满足required review不前行，拒绝/return采用D22-04确认路径。

数据模型分类：复用既有parent/child dependency；补Line scope及政策证据，非新审批引擎

性能验收：NOT RUN：先由Owner提供任务/Line规模、并发和部署基线；比较授权结果全量读取、筛选/导出、路由计算、重复请求、DB索引和通知批处理延迟。不得用本页3行合成渲染耗时宣称生产达标。

架构：复用现有dependency图和任务命令，补正式资格/范围策略，禁止另造一套审批引擎。

复用：Decisions.tsx、dependency.ts、approval.ts及H31–H35；保留POC方法，替换mock候选和未签认政策。

集成：{"needed": false, "systems": ["NEO"], "provider": "NEO应用及既有身份数据Owner；不新增外部系统", "direction": "应用内部读写；既有身份/组织数据入站只读资格依赖", "reuse": "Decisions.tsx、dependency.ts、approval.ts及H31–H35；保留POC方法，替换mock候选和未签认政策。", "evidence": [{"path": "8.需求文档/20261110_NEO_FR22_Approval_Controls_v1/NEO_FR22_Approval_Controls_EN.md", "locator": "FR22.3, line 36", "quote": "## FR22.3 — Add Before / Add After Reviewers\n\n1. Only users explicitly authorised for the current request and task shall be able to add a required reviewer. The user shall select **Add Before** or **Add After**, an eligible reviewer, the review scope and a mandatory reason.\n2. The additional review shall reference the relevant request version and affected Line or Lines. It shall retain its relationship with the originating task and shall not replace any required DoA approval.\n3. **Add Before:** the additional review shall be completed with an outcome that permits continuation before the original task becomes actionable again. The original task shall retain its identity and applicable remaining-SLA information.\n4. **Add After:** the original approver shall complete their approval before the additional review becomes actionable. A dependent downstream step shall not proceed until the additional review has been completed with an outcome that permits continuation. An original rejection or return shall not activate a normal forward approval path.\n5. Required additional review shall not be treated as optional advice that the original approver can silently ignore. If an advisory consultation is needed, it shall be identified separately from a required approval dependency."}, {"path": "NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx", "locator": "paragraph 308", "quote": "Normal path. Add Before and After in separate runs; complete the dependent actions in the required sequence."}, {"path": "NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx", "locator": "paragraph 309", "quote": "Exceptions and recovery. Original owner cannot approve ahead of a required reviewer; reject or return dependencies remain visible."}, {"path": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p04/dependency.ts", "locator": "line 8; const before=", "quote": "  const before=c.action==='add-before',id='TASK-ADDED-'+c.envelope.intentId,child:LogicalApprovalTask={taskId:id,nodeId:'added-'+c.envelope.intentId,requestVersion:r.version,assignmentId:'ASG-ADDED-'+c.envelope.intentId,state:'queued',kind:before?'before':'after',roleLabel:before?'Additional Before reviewer':'Additional After reviewer',clock:null};"}, {"path": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Approvals/Decisions.tsx", "locator": "line 20; const recipients =", "quote": "  const recipients = workflowScenarios().find(row => row.id === request.scenarioId)?.eligibleActorIds.filter(id => id !== neo.actor.actorId) ?? [];"}, {"path": "NEO-POC/UK_DEMO/20261010_ADD_TRANSFER_VERIFICATION_v1/BEFORE_AFTER_HIGHLIGHT_ACCEPTANCE_v2.md", "locator": "H31–H35 table rows", "quote": "H35: The original owner approves first; the added task becomes pending. The recipient shown currently has no available approval action. | NOT RUN — UK gate unmet"}, {"path": "NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx", "locator": "paragraph 305", "quote": "UC-16 Add a reviewer with dependencies"}, {"path": "NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx", "locator": "paragraph 291", "quote": "UC-14 Review and complete the Forum route"}, {"path": "outputs/neo-jira-stories-20261111/v3/story_data.json", "locator": "entries[act=18]", "quote": "Add Delegator | FR10.6"}, {"path": "outputs/neo-jira-stories-20261111/v3/story_data.json", "locator": "entries[act=19]", "quote": "Acknowledge Approval | FR10.6; FR11.1"}, {"path": "outputs/neo-jira-stories-20261111/v3/story_data.json", "locator": "entries[act=24]", "quote": "Start Approval Chain | FR10.6"}], "unknown": "现有内部API DTO、正式角色/政策及数据库迁移契约未签认。"}

依赖：NEO-056区分标准DoA与例外审阅；FR22 D22-04权限及拒绝影响范围；H31–H35；AC-FR22-05/06/09；NEO-029仅复用既有POC会话/草稿恢复，不重做；../solution-review/NEO-029/TASK_TO_POC_CN.md

### 场景与验收边界

每个场景的actual=null，status=NOT RUN。完整字段见ASSESSMENT.json。

- NEO-063-S01｜当前合格审批人｜输入：mode=Add Before；reviewer=Alex Chen；Line=MCI-00057；reason=Validate signed terms｜操作：预览 → 确认 → 原人尝试批准 → 追加人批准｜期望：原人等待；子审阅可行动；完成后恢复同一原task/剩余SLA；下游不提前。

- NEO-063-S02｜当前合格审批人｜输入：mode=Add After；reviewer=Alex Chen；reason=Confirm exception｜操作：确认 → 原人批准 → 子审阅批准｜期望：原人先可批准；子任务先Queued后Active；子任务完成前下游blocked。

- NEO-063-S03｜追加审阅人｜输入：Line=MCI-00057；outcome=Return；reason=Signed term missing｜操作：退回 → 检查其余Line和任务｜期望：按D22-04签认范围退回；不默默继续、不自动终止整份Request。

- NEO-063-S04｜未授权人/当前人｜输入：reviewer=self；循环task引用；reason空｜操作：分别提交｜期望：拒绝且无多余子任务；仅隐藏按钮不足以通过。

- NEO-063-S05｜两个审批窗口｜输入：v3旧assignment与v4；重复intent｜操作：同时确认 → 刷新｜期望：仅有效版本创建一次依赖；取消无变更，冲突保留输入。

- NEO-063-S06｜通知服务｜输入：子审阅assignment已存，通知Failed｜操作：重试通知 → 审批链回读｜期望：依赖仍有效且下游blocked；重试不能再建子task；提供失败恢复。

### 页面与来源

[英文页面](pages/NEO-063.html)；[截图1](screenshots/NEO-063-desktop.png)；[截图2](screenshots/NEO-063-narrow.png)；[截图3](screenshots/NEO-063-exception.png)；[截图4](screenshots/NEO-063-add-after.png)

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!D64 — Existing functionality - Update UX / Workflow

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E64 — Enable additional approvals so approvers can add additional or senior-level approvers when specific or exceptional cases require further review.

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!G64 — Yes

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!J64 — No

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!M64 — Inflexible approval workflow

- `8.需求文档/20261110_NEO_FR22_Approval_Controls_v1/NEO_FR22_Approval_Controls_EN.md` / FR22.3, line 36 — ## FR22.3 — Add Before / Add After Reviewers  1. Only users explicitly authorised for the current request and task shall be able to add a required reviewer. The user shall select **Add Before** or **Add After**, an eligible reviewer, the review scope and a mandatory reason. 2. The additional review shall reference the relevant request version and a

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraph 308 — Normal path. Add Before and After in separate runs; complete the dependent actions in the required sequence.

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraph 309 — Exceptions and recovery. Original owner cannot approve ahead of a required reviewer; reject or return dependencies remain visible.

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p04/dependency.ts` / line 8; const before= —   const before=c.action==='add-before',id='TASK-ADDED-'+c.envelope.intentId,child:LogicalApprovalTask={taskId:id,nodeId:'added-'+c.envelope.intentId,requestVersion:r.version,assignmentId:'ASG-ADDED-'+c.envelope.intentId,state:'queued',kind:before?'before':'after',roleLabel:before?'Additional Before reviewer':'Additional After reviewer',clock:null};

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Approvals/Decisions.tsx` / line 20; const recipients = —   const recipients = workflowScenarios().find(row => row.id === request.scenarioId)?.eligibleActorIds.filter(id => id !== neo.actor.actorId) ?? [];

- `NEO-POC/UK_DEMO/20261010_ADD_TRANSFER_VERIFICATION_v1/BEFORE_AFTER_HIGHLIGHT_ACCEPTANCE_v2.md` / H31–H35 table rows — H35: The original owner approves first; the added task becomes pending. The recipient shown currently has no available approval action. | NOT RUN — UK gate unmet

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraph 305 — UC-16 Add a reviewer with dependencies

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraph 291 — UC-14 Review and complete the Forum route

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=18] — Add Delegator | FR10.6

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=19] — Acknowledge Approval | FR10.6; FR11.1

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=24] — Start Approval Chain | FR10.6

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / rows[audit_id=PAGE-P4.1.11] — P4.1.11 Delegate／Acknowledge Approval

## NEO-064 单项审批转办与限时委派分开

### 用户问题与原文

原审批人不可用导致审批停滞，需要把当前可行动任务转给具备同等责任资格的同事。

> Allow approvers to delegate or transfer approvals to an appropriate colleague when needed, reducing unnecessary delays caused by approver availability.

采购期望Q：空白，未补造。

Finance期望P：空白，未补造。

原优先级：采购None；Finance None。建议P1：K/L为空，建议P1；已有POC基础但正式资格和SoD是上线前置。

### UC定位与当前基线

UC-17 (direct-transfer-slice), UC-14 (related)；ACT-018, ACT-020；FR10.6, FR15, FR22.2, FR22.5

POC审批TaskActions已有Transfer，approval.ts停用旧assignment并创建新assignment；收件人从fixture场景候选。Tasks/ReassignTask只覆盖Implementation、AP practice、Standalone/Settlement GFS检查。Training组内改派不能证明所有审批可跨组转办。

页面登记编号与当前路由：[{"id": "P4.1.11", "name": "Approval task actions", "source": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Approvals/Decisions.tsx", "observation": "当前源码可观察入口；本轮未执行产品功能。", "pageIdBasis": "Canonical QA PAGE registry / user127-page list; historical alias, not React route number", "registrySource": "NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json", "registryLocator": "rows[audit_id=PAGE-P4.1.11]", "registryObservation": "P4.1.11 Delegate／Acknowledge Approval", "currentRoute": "/approval (RequestDetail action/tab; request query context required)", "routeSource": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/router/index.tsx; views/Approvals/RequestDetail.tsx; views/Management/index.tsx; views/Reporting/index.tsx"}, {"id": "P3.6", "name": "Reassign Task", "source": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Tasks/ReassignTask.tsx", "observation": "当前源码可观察入口；本轮未执行产品功能。", "pageIdBasis": "Canonical QA PAGE registry / user127-page list; historical alias, not React route number", "registrySource": "NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json", "registryLocator": "rows[audit_id=PAGE-P3.6]", "registryObservation": "P3.6 Task Detail-领取／改派任务", "currentRoute": "/tasks (Reassign Task dialog)", "routeSource": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/router/index.tsx; views/Approvals/RequestDetail.tsx; views/Management/index.tsx; views/Reporting/index.tsx"}]

### 方案与准确改动

复用审批Transfer，并明确“当前单项转办”与051“期间DoA委派”入口。转办保持task、request version、deadline和Claim owner；选择正式合格且无利益冲突的接收人，确认前预览owner变化，原人立即丧失行动权。转回也重新验证。

主分类：应用内部：复用转办能力并补资格/旧链接失效/通知闭环

- ux：Transfer approval页只显示当前任务、原/新Owner、due和原因；期间委派单独指向051。

- frontend：复用TaskActions Transfer及确认模式，不能把GFS组内Reassign的名单套给DoA审批。

- backend：当前assignment、request version、role/DoA/CoC/SoD/active校验；事务写转办和outbox；旧链接及并发批准被拒。

- data：logicalTaskId、old/new assignment、policy version、actor/reason/time、due unchanged、request/Line关联；保留旧assignment审计。

- workflow：只改变可行动Owner；不批准、不完成、不改Claim归属或重置SLA；转回新建assignment event。

数据模型分类：复用既有assignment/history；补正式资格policy版本与通知事件

性能验收：NOT RUN：先由Owner提供任务/Line规模、并发和部署基线；比较授权结果全量读取、筛选/导出、路由计算、重复请求、DB索引和通知批处理延迟。不得用本页3行合成渲染耗时宣称生产达标。

架构：复用现有任务命令和assignment版本控制，以正式eligibility服务替代fixture候选；通知走057共同适配器。

复用：approval.ts transfer、Decisions.tsx和FR22.2；ReassignTask仅组内实现任务可复用交互，不继承其权限规则。

集成：{"needed": false, "systems": ["NEO", "既有身份/组织数据"], "provider": "NEO应用及既有身份数据Owner；不新增外部系统", "direction": "应用内部读写；既有身份/组织数据入站只读资格依赖", "reuse": "approval.ts transfer、Decisions.tsx和FR22.2；ReassignTask仅组内实现任务可复用交互，不继承其权限规则。", "evidence": [{"path": "8.需求文档/20261110_NEO_FR22_Approval_Controls_v1/NEO_FR22_Approval_Controls_EN.md", "locator": "FR22.2, line 24", "quote": "## FR22.2 — Transfer and Transfer Back\n\n1. The current assigned approver shall be able to transfer an actionable task to an eligible recipient, subject to the applicable transfer policy. A transfer reason shall be mandatory.\n2. Eligibility shall be checked against the approval responsibility being transferred: applicable role, DoA authority, organisational scope, active access and segregation-of-duties rules. Job title, apparent seniority or FBP nomination alone shall not establish eligibility.\n3. The recipient list shall contain only confirmed eligible users. Where a complete role model is unavailable, a controlled, explicitly approved candidate list may be used. If eligibility cannot be established, transfer shall not proceed.\n4. Self-transfer shall not be permitted. A recipient must not gain approval rights over their own request or perform an incompatible approval responsibility through transfer.\n5. Transfer shall preserve the logical task, approval requirement, request version, due time and elapsed SLA. It shall change the actionable assignment without implicitly changing the Claim owner."}, {"path": "8.需求文档/20261110_NEO_FR22_Approval_Controls_v1/NEO_FR22_Approval_Controls_EN.md", "locator": "FR22.5, line 63", "quote": "## FR22.5 — Common Permissions, Audit and Notifications\n\n1. Each action shall be checked against the actual actor, current assignment, request version, state and applicable policy when it is confirmed. Hiding a button shall not be the only permission control.\n2. The user shall see the effect on the owner, route and affected approvals before confirming a change. Cancelling the action shall leave the saved state unchanged.\n3. Every successful action shall record the Request and affected Line IDs, request version, logical task and assignment, actual actor, reason, timestamp, previous and resulting state, owner changes, relevant SLA values and applicable policy version.\n4. The route and activity history shall distinguish suspended, transferred, additional-review, retained-approval and reapproval events. An action shall not overwrite an earlier decision or audit entry.\n5. Notifications shall follow the approved event, recipient and channel configuration. New actionable assignments shall be directed to the current eligible assignee; obsolete or duplicate events shall not create additional actionable tasks or permit a former assignee to act."}, {"path": "6.技术方案/2 - Tech NEO/NEO User Training.docx", "locator": "paragraph 1092", "quote": "Note: One GFS, AP, CBSL user can assign to another GFS, AP, CBSL respectively "}, {"path": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p04/approval.ts", "locator": "line 50; else if(c.action==='transfer')", "quote": " else if(c.action==='transfer'){const scenario=workflowScenarios().find(s=>s.id===r.scenarioId);requireCondition(c.recipientId&&c.recipientId!==a.actor.actorId&&scenario?.eligibleActorIds.includes(c.recipientId),'ineligible-recipient');assignment.active=false;const next={...assignment,assignmentId:store.nextId('ASG'),actorId:c.recipientId,active:true,capabilities:[...assignment.capabilities]};r.assignments.push(next);t!.assignmentId=next.assignmentId;state.notices.push({id:store.nextId('NOTICE'),requestId:r.id,requestVersion:r.version,taskId:t!.taskId,assignmentId:next.assignmentId,recipientId:next.actorId,kind:'assigned',eventId:''})}"}, {"path": "NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Tasks/ReassignTask.tsx", "locator": "line 21; const supported =", "quote": "  const supported = task.source === 'Implementation' || task.source === 'AP practice' || task.source === 'Standalone' && task.type === 'GFS check' || task.source === 'Settlement' && task.type === 'GFS check';"}, {"path": "NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx", "locator": "paragraph 312", "quote": "UC-17 Transfer and suspend work"}, {"path": "NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx", "locator": "paragraph 291", "quote": "UC-14 Review and complete the Forum route"}, {"path": "outputs/neo-jira-stories-20261111/v3/story_data.json", "locator": "entries[act=18]", "quote": "Add Delegator | FR10.6"}, {"path": "outputs/neo-jira-stories-20261111/v3/story_data.json", "locator": "entries[act=20]", "quote": "Reassign Task | FR15"}], "unknown": "现有内部API DTO、正式角色/政策及数据库迁移契约未签认。"}

依赖：NEO-051期间委派边界；NEO-056正式资格；NEO-057通知；FR22 D22-03；NQA-92/F1021-12只证组内改派；H29/H30；AC-FR22-04/09；NEO-029仅复用既有POC会话/草稿恢复，不重做；../solution-review/NEO-029/TASK_TO_POC_CN.md

### 场景与验收边界

每个场景的actual=null，status=NOT RUN。完整字段见ASSESSMENT.json。

- NEO-064-S01｜当前审批人｜输入：recipient=Alex Chen；reason=Annual leave cover｜操作：预览owner/due → 确认 → 刷新｜期望：同task/version/due、Claim owner不变；新assignment可行动，原人旧链接不能行动。

- NEO-064-S02｜当前审批人｜输入：recipient=Self / requester / inactive colleague / other CoC｜操作：分别尝试Transfer｜期望：按已确认权限与SoD逐项拒绝；不因同组或资深就放行。

- NEO-064-S03｜接收人｜输入：Transfer back to Jamie Reed；reason=Returned to work｜操作：转回 → 检查历史｜期望：新增assignment event；不复活旧assignment/通知，deadline不重置。

- NEO-064-S04｜两个审批窗口｜输入：A Transfer与B Approve同taskVersion同时提交｜操作：并发提交 → 重复同一intent → 刷新｜期望：只有一个符合当前assignment的命令生效；另一个明确冲突；无丢失决定。

- NEO-064-S05｜审批人｜输入：reason=Annual leave cover；Cancel；随后v3过期｜操作：取消一次 → 再次确认旧版本｜期望：取消无变更；过期提交拒绝并保留原因供review。

- NEO-064-S06｜通知服务｜输入：新assignment已保存；mail delivery=Failed｜操作：运行重试 → 旧owner打开历史链接｜期望：只有新owner可行动；邮件失败不回滚到双owner；幂等补发并记录回执。

### 页面与来源

[英文页面](pages/NEO-064.html)；[截图1](screenshots/NEO-064-desktop.png)；[截图2](screenshots/NEO-064-narrow.png)；[截图3](screenshots/NEO-064-exception.png)

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!D65 — New functionality

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E65 — Allow approvers to delegate or transfer approvals to an appropriate colleague when needed, reducing unnecessary delays caused by approver availability.

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!G65 — Yes

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!J65 — Yes

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!M65 — Approval dependency / bottleneck

- `8.需求文档/20261110_NEO_FR22_Approval_Controls_v1/NEO_FR22_Approval_Controls_EN.md` / FR22.2, line 24 — ## FR22.2 — Transfer and Transfer Back  1. The current assigned approver shall be able to transfer an actionable task to an eligible recipient, subject to the applicable transfer policy. A transfer reason shall be mandatory. 2. Eligibility shall be checked against the approval responsibility being transferred: applicable role, DoA authority, organi

- `8.需求文档/20261110_NEO_FR22_Approval_Controls_v1/NEO_FR22_Approval_Controls_EN.md` / FR22.5, line 63 — ## FR22.5 — Common Permissions, Audit and Notifications  1. Each action shall be checked against the actual actor, current assignment, request version, state and applicable policy when it is confirmed. Hiding a button shall not be the only permission control. 2. The user shall see the effect on the owner, route and affected approvals before confirm

- `6.技术方案/2 - Tech NEO/NEO User Training.docx` / paragraph 1092 — Note: One GFS, AP, CBSL user can assign to another GFS, AP, CBSL respectively 

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p04/approval.ts` / line 50; else if(c.action==='transfer') —  else if(c.action==='transfer'){const scenario=workflowScenarios().find(s=>s.id===r.scenarioId);requireCondition(c.recipientId&&c.recipientId!==a.actor.actorId&&scenario?.eligibleActorIds.includes(c.recipientId),'ineligible-recipient');assignment.active=false;const next={...assignment,assignmentId:store.nextId('ASG'),actorId:c.recipientId,active:tr

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Tasks/ReassignTask.tsx` / line 21; const supported = —   const supported = task.source === 'Implementation' || task.source === 'AP practice' || task.source === 'Standalone' && task.type === 'GFS check' || task.source === 'Settlement' && task.type === 'GFS check';

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraph 312 — UC-17 Transfer and suspend work

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraph 291 — UC-14 Review and complete the Forum route

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=18] — Add Delegator | FR10.6

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=20] — Reassign Task | FR15

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / rows[audit_id=PAGE-P4.1.11] — P4.1.11 Delegate／Acknowledge Approval

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / rows[audit_id=PAGE-P3.6] — P3.6 Task Detail-领取／改派任务

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A1667:N1667 — MCI_TASK | 问询、任务与附件 | 业务 | ASSIGNED_USER | varchar(255) | varchar(255) | 是 | 否 | Column to store the assigned user for the given task | 结构+字典

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A1668:N1668 — MCI_TASK | 问询、任务与附件 | 业务 | ASSIGNED_GROUP | varchar(255) | varchar(255) | 是 | 否 | Column to store the assigned group for the given task | 结构+字典