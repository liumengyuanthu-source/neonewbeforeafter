# 待业务确认问题

Owner为建议角色，尚无已确认具名责任人。无需用户提供技术接口术语；先回答业务例子。

## NEO-050 Clearing House完成、Request批准和实施状态分开

### 050-Q1 所有人批准了，但FBP还没点Complete时，Request列显示什么？

背景：Q51只明确未集齐批准保持In Approval；全部批准未Complete的名称未单列。

例子：DoA=Approved、CH=Awaiting Completion时，Request显示In Approval还是Awaiting Clearing House Completion？

建议Owner：Finance流程Owner。影响：状态映射、筛选和导出一致。

### 050-Q2 三条Line中两条批准、一条拒绝时，Complete和实施放行分别覆盖哪两条？

背景：FR10.6及NQA-97已有部分批准规则，不能全请求假定Approved。

例子：MCI-00057/58批准，59拒绝；只能按确认政策推进批准子集。

建议Owner：Procurement/Finance流程Owner。影响：多Line门槛及历史迁移。

## NEO-051 按有效期委托DoA并保留原审批人

### 051-Q1 休假期间委派的是当前这一项，还是这个人的所有现有和新审批？

背景：当前POC按taskId/requestVersion保存；原需求说delegate their DOA level for a certain time period。

例子：周一设置到周五，周三新来一项是否自动给代理？

建议Owner：审批政策Owner。影响：数据模型、页面范围和新任务路由。

### 051-Q2 “相差一级”包括同级、上一级和下一级吗？各级正式先后顺序是什么？

背景：POC有固定级别数组，不能作为企业政策。

例子：同级候选、相邻候选、跨两级候选分别应允许哪个？

建议Owner：Procurement/Finance DoA Owner。影响：候选名单和授权校验。

### 051-Q3 谁可以替别人设置委派，到期时未完成审批交回谁？

背景：Training为FBP/FA维护；源需求说users delegate their own level。

例子：原审批人已离职，代理期结束，不能恢复到失效账号。

建议Owner：Access Owner与流程Owner。影响：委派管理权和恢复规则。

## NEO-056 按企业DoA生成必需审批，明确例外加签

### 056-Q1 企业DoA最新批准版在哪里？请给一笔好消息和一笔坏消息Settlement的正确审批名单。

背景：M/Q57要求去掉额外审批，R57明确需要双方对齐。

例子：相同绝对金额的Opportunity和Risk，是相同审批人还是不同路径？

建议Owner：企业DoA Owner、Procurement和Finance。影响：路由正确性及开发验收基准。

### 056-Q2 “不增加额外审批”是否仍允许FBP有理由上调、或特殊事项加签？

背景：Q57与FR10.2和NEO-063存在需要明确的政策边界。

例子：矩阵只要求两步，但一笔法律例外需专家复核，是否允许？

建议Owner：Procurement/Finance审批政策Owner。影响：056与063验收不能互相矛盾。

### 056-Q3 新DoA生效后，已提交的请求保持旧路线还是重新判断？

背景：当前配置和冻结请求版本须一致。

例子：周二提交，周三更换矩阵，周四批准按哪版？

建议Owner：审批政策Owner。影响：在途升级、重新批准与审计。

## NEO-057 开放任务状态、当前责任人与逾期提醒

### 057-Q1 哪些开放任务需要提醒？逾期后多久提醒一次，提醒给谁？

背景：TD既有调度不是所有Task/Action/Approval的策略。

例子：审批逾期一天提醒当前人；组内未领取时提醒谁？

建议Owner：流程Owner及Notification Owner。影响：事件范围、收件人和频率。

### 057-Q2 SLA按自然日还是工作日？用哪个地区假期、工作时间和时区？

背景：源码固定毫秒单位；FR21仅说days。

例子：周五17点到期，周末和中国/英国假日怎么处理？

建议Owner：流程Owner。影响：Due计算和超时边界。

### 057-Q3 TD提醒以创建次日为准，还是每周二和周四为准？

背景：调度源同一行描述与频率不一致。

例子：周四创建的任务应周五发还是下周二发？

建议Owner：TD流程Owner/应用支持。影响：复用旧scheduler前必须解冲突。

## NEO-063 按Before/After顺序增加必需审阅

### 063-Q1 谁能加签，哪些人可作为必需审阅人？

背景：FR22 D22-04未定；资深职称不是自动授权。

例子：普通审批人可找法务复核吗，还是仅FBP可新增？

建议Owner：流程Owner和Access Owner。影响：按钮与候选权限。

### 063-Q2 额外审阅拒绝一条Line时，要退哪几条、退给谁？

背景：不能自行推定整份Request终止。

例子：三条Line中只复核MCI-00057；拒绝后另外两条是否继续？

建议Owner：Procurement/Finance流程Owner。影响：依赖、部分批准及恢复路径。

### 063-Q3 这次是必须完成的审阅，还是仅征求意见？

背景：FR22.3区分required review与advisory consultation。

例子：法务仅提供建议是否应阻挡下游？

建议Owner：请求Owner/审批政策Owner。影响：不要把可忽略建议做成强制审批。

## NEO-064 单项审批转办与限时委派分开

### 064-Q1 “合适的同事”具体需要哪些角色、DoA、CoC和职责分离条件？

背景：同组、同职称或资深不等于具备当前审批责任。

例子：同一CoC同级但也是该Request申请人，不能据此放行。

建议Owner：DoA与Access Owner。影响：收件人校验。

### 064-Q2 原审批人失联时，谁能替他转办？是否允许转回？

背景：FR22目标为当前assignee转办；恢复例外未批准。

例子：原人已离职且无法点Transfer，谁可接手操作？

建议Owner：流程Owner和Access Owner。影响：异常恢复角色。

### 064-Q3 转办是否仅Mandate/Settlement审批？CBSL、GFS、AP沿用各自规则吗？

背景：FR22 scope未自动扩展到其他request/CBSL；Training已有同组改派。

例子：GFS检查转办不可借用DoA审批候选名单。

建议Owner：各任务流程Owner。影响：范围边界与跨Epic验收。