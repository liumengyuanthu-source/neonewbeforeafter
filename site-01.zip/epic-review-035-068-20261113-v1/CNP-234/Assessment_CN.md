# CNP-234 Implementation — 独立需求评估


范围仅036/049/058/065；001–034不重做。页面为英文React/AntD独立方案，全部示例合成；真实产品、接口、数据库、部署和UAT未执行。原型/代码观察不代表生产已实现。沿用当前主题和既有QA authority，无源文件/产品/共享QA修改。


## NEO-036 异常处理责任与闭环规则


**源行**：Requested Changes A37:R37；全部非空单元格已保存到ASSESSMENT.json/sourceCells。采购优先级：未填；财务：未填；建议：P0决策 / P1开发。K/L均空；责任决策是049/058/065闭环前置，建议先定Owner再开发，非来源指定P0。


### 用户问题
数据错误、Digitide处理中断和未付款等不同问题缺少统一责任边界；源E37只要求梳理，未批准一个新的统一RACI。R37=Y要求采购和财务对齐。

### 当前基线与复用
FR14已按类型分配GFS/CBSL/Buyer/AP；FR15有组内任务与受控改派；现有p05实施记录、enquiry、task queue可复用。没有证据证明所有异常已按统一关闭条件、责任升级和时限执行。付款未发生也不必然是实施失败，需独立核对UC-22付款输入。

FR14/15、Tasks/ReassignTask、p05 implementation、enquiry、MCI_TASK；支付调查复用UC-22只读对账入口。

### 建议方案及架构
先把异常分成数据不一致、执行服务故障、合同处理、付款未到四类，确认每类Responsible、单一Accountable、Consulted/Informed、接手条件及关闭证据。页面提出异常工作项和责任卡；规则确认后配置到既有任务/实施事件，避免把自由评论当完成。

复用内部任务和实施事件模型，以可版本化责任配置扩展；不新增外部工作流平台。

### 修改与影响
- ux：显示问题、当前责任、下一步和关闭依据；RACI配置与业务异常详情分开，保留待确认角色。
- frontend：扩展Tasks/Enquiry详情，提供受控Assign、Request clarification、Record resolution及历史，不再靠共享邮箱判断进度。
- backend：服务端按异常类型/交易分支/权限决定路由；更新task、assignment、case状态与审计同事务；重复提交复用intent。
- data：复用MCI_TASK受理人/组/备注/SLA；补exception type、RACI rule version、responsible/accountable、resolution evidence、related transaction和revision；业务时限不得从示例推定。
- workflow：移交须新owner有效后生效；等待外部/等待业务分别计时；未有关闭证据保持开放。付款问题可转Finance调查但不伪造支付。

### 集成边界
- needed：False
- systems：['NEO内部任务']
- provider：NEO应用Owner / 企业身份Owner；CBSL/Digitide是人员团队
- direction：内部case/task assignment；不新增CBSL或SAP容器合同API
- reuse：现有任务/组/权限与审计复用
- evidence：FR15、MCI_TASK、reassignment及enquiry源码
- unknown：角色、组成员来源及服务交接权限未签认

### 依赖
- NEO-049合同责任
- NEO-058回执与关闭口径
- NEO-065 CBSL协作
- NEO-057提醒和SLA（其他Epic）
- 既有NEO-029会话/输入保留结论，只复用

### ACT / FR核对
Inherited ACT labels verified against current story_data; canonical PAGE identifiers verified in the registered QA model.
- ACT-020 Reassign Task / FR15
- ACT-021 Manage Enquiry Task / FR10.4; FR11
- ACT-022 Manage Task / FR11
- ACT-025 Complete Task / FR14; FR15

### UC / 页面定位
- UC-17 related / paragraphs 312–318 / 新增跨类型异常RACI、接手/退回、证据关闭和未付款调查；现有UC不是完整责任矩阵。
- UC-19 related / paragraphs 326–332 / 新增跨类型异常RACI、接手/退回、证据关闭和未付款调查；现有UC不是完整责任矩阵。
- UC-20 related / paragraphs 333–339 / 新增跨类型异常RACI、接手/退回、证据关闭和未付款调查；现有UC不是完整责任矩阵。
- UC-21 related / paragraphs 340–346 / 新增跨类型异常RACI、接手/退回、证据关闭和未付款调查；现有UC不是完整责任矩阵。
- UC-22 related / paragraphs 347–353 / 新增跨类型异常RACI、接手/退回、证据关闭和未付款调查；现有UC不是完整责任矩阵。
PAGE-P3, PAGE-P3.1, PAGE-P3.4, PAGE-P3.5, PAGE-P3.6；127-page canonical QA，不与旧143页别名混用。

### 复核场景（产品全部NOT RUN）


**NEO-036-S01** Buyer。前置：异常EX-036-01已建立；版本3；RACI政策待签认。输入：type=Data mismatch; reason=Source price differs。操作：选择责任组Data Operations，填写原因并确认。预期：记录一个当前责任任务；业务确认的Accountable保留；Claim不变Implemented。Actual=null；NOT RUN。


**NEO-036-S02** Finance investigator。前置：已到付款日但无匹配付款。输入：paymentRef=00004567; period=2026-11。操作：打开付款核对，记录未匹配并转AP调查。预期：显示Not reconciled；不伪造付款或关闭异常。Actual=null；NOT RUN。


**NEO-036-S03** Service lead。前置：CBSL等待Buyer补资料。输入：question=Confirm effective date; due=2026-11-16。操作：Raise clarification；Buyer回复2026-12-01。预期：原问题和回复可回读；责任回到原执行任务，时钟按已确认政策。Actual=null；NOT RUN。


**NEO-036-S04** Unrelated buyer。前置：无案件访问授权。输入：exception=EX-036-01。操作：通过直接URL提交Assign。预期：拒绝读取/修改；无owner和事件变化。Actual=null；NOT RUN。


**NEO-036-S05** Two service leads。前置：同一task revision=3。输入：A=Assign CBSL; B=Assign AP。操作：A保存后B用旧版本提交。预期：仅A生效；B冲突并保留输入，不能覆盖新owner。Actual=null；NOT RUN。


**NEO-036-S06** Resolution owner。前置：外部结果Unknown。输入：evidence=mail says done。操作：尝试Close exception。预期：阻止关闭；仍待核对，有责任人。Actual=null；NOT RUN。


**NEO-036-S07** Service lead。前置：保存响应超时。输入：intent=EX036-001; reason=Need source check。操作：保存；重开并按原intent查询，再重试。预期：只一条移交事件；未确认结果前不产生第二个任务。Actual=null；NOT RUN。


### 精确来源
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!A37: “NEO-036”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!B37: “Both”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!E37: “Review workflows & RACI - specifically to data issues, digitide issues, issue resoloution, payments not made etc.”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!R37: “Y”
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` — paragraphs 312–318: “UC-17 Transfer and suspend work
Actor and precondition. Current reviewer and eligible recipient. The policy permits the action and identifies the current task.
Trigger. An eligible actor chooses transfer or suspension.
Normal path. Transfer and trans”
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` — paragraphs 326–332: “UC-19 Implement a standard price claim
Actor and precondition. Robot, Buyer, CBSL and PM. Settlement is approved and marked complete.
Trigger. Approved Settlement is marked complete for a standard Price Claim.
Normal path. Execute WIPS creation and a”
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` — paragraphs 333–339: “UC-20 Implement alternative POA branches
Actor and precondition. CBSL, GFS and Buyer. An approved transaction subtype identifies the proper route.
Trigger. Approved completion triggers an alternative POA subtype.
Normal path. Exercise AMM via ATP, co”
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` — paragraphs 340–346: “UC-21 Implement LSP payable and receivable
Actor and precondition. Buyer, SAP execution, GFS and billing actors. Approved LSP and the applicable funding direction are known.
Trigger. Approved completion triggers an LSP payable or receivable route.
No”
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` — paragraphs 347–353: “UC-22 Import and reconcile payments
Actor and precondition. Material Cost Analyst and Finance. A SAP payment report and period are available.
Trigger. MCA receives the payment input for upload.
Normal path. Upload the correct ordered columns; track i”
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` — rows[audit_id=PAGE-P3]: “P3 Task list | 用户127项页面清单；原FR定位按原文保留：FR15：按角色／组显示任务，支持筛选、处理、领取及受控改派。
 FR21：按任务类型配置天数并展示 Green／Amber／Red 状态。
 Training：Manage Task（¶1126）。
第二部分来源：Before别名P15；tasks、roles，Dictionary/Schema及既有FIELD_REGISTER精确引用见本行planningRecords与合并计划：/Volumes/KIOXIA/JLR”
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` — rows[audit_id=PAGE-P3.1]: “P3.1 Task Detail-Enquiry／Action | 用户127项页面清单；原FR定位按原文保留：FR10.4：接收、答复并完成 Enquiry，向发起人发送回复通知。
 FR10.5：处理行动、备注与截止时间，完成后更新请求并通知相应 FBP。
 Training：Manage Enquiry Task（¶1105）；Action Task for User（¶1487）。
 Enquiry 与 Action 具有不同完成及通知条件。”
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` — rows[audit_id=PAGE-P3.4]: “P3.4 Task Detail-WIPS／S4 Hana | 用户127项页面清单；原FR定位按原文保留：FR13：在批准后处理 WIPS Claim，跟踪 Buyer／Manager 批准及处理结果。
 FR14：按交易分支向 GFS、CBSL、Buyer 或 AP 分派人工任务。。承载／依赖关联：FR16，不作为独立覆盖。
 Training：Create WIPS Claim（¶1254）；WIPS Approval（¶1363）；CBSL S4 Hana Task（¶1641）。
 F”
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` — rows[audit_id=PAGE-P3.5]: “P3.5 Task Detail-其他人工实施 | 用户127项页面清单；原FR定位按原文保留：FR14：按交易分支向 GFS、CBSL、Buyer 或 AP 分派人工任务。
 Training：Complete Task（¶1186）。
 各分支完成条件和责任组不能合并为同一个通用“完成”。
第二部分来源：Before别名P15.12–P15.18；tasks、implementation、lsp，Dictionary/Schema及既有FIELD_REGISTER精确引用见本行plannin”
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` — rows[audit_id=PAGE-P3.6]: “P3.6 Task Detail-领取／改派任务 | 用户127项页面清单；原FR定位按原文保留：FR15：按角色／组显示任务，支持筛选、处理、领取及受控改派。
 Training：Reassign Task（¶1090）。
 分配权限不等于任意跨组转交。
第二部分来源：Before别名P15.1；tasks、roles，Dictionary/Schema及既有FIELD_REGISTER精确引用见本行planningRecords与合并计划：/Volumes/KIOXIA/JLR Appian”
- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` — table 6 row 39: “FR14 | Manual Tasks to Complete Certain Low Volume Transaction Types | If the solution is unable to update the details of a particular settlement request within the system of record, then the solution should generate a task called “Manual System Upda”
- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` — table 6 row 40: “FR15 | Task List | Context: The application will contain a task list for all users. When a user receives a task (e.g. buyer receiving an enquiry or GFS receiving a checking task, the task will appear in this list. 
The solution should contain a tab f”
- `6.技术方案/2 - Tech NEO/NEO User Training.docx` — paragraphs 1091–1092: “Reassign Task
Note: One GFS, AP, CBSL user can assign to another GFS, AP, CBSL respectively ”
- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` — 字段字典!A1662:R1672: “MCI_TASK | 问询、任务与附件 | 业务 | TASK_ID | int(11) | integer | 否 | PK | 否 | Primary key of the table. This table holds information of Tasks | 结构+字典
MCI_TASK | 问询、任务与附件 | 业务 | ENQUIRY_ID | int(11) | integer | 是 | FK | MCI_ENQUIRY | ENQUIRY_ID | 已建 | 否 | Pri”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/tasks/reassignment.ts` — line 25: “requireCondition(recipientId !== ownerId && taskTeam(subject) === taskTeam(taskRecipientSubject(recipientId)), 'same-team-recipient-required');”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p05/implementation.ts` — line 13: “export function currentOwner(c: ImplementationCase, a: AuthorityContext, g: LocalGuard) { requireCondition(c.task.ownerId === a.actor.actorId && g.assignmentId === c.task.assignmentId, 'not-current-assignee'); }”
- `outputs/neo-jira-stories-20261111/v3/story_data.json` — entries[act=20]: “Reassign Task | FR15 | Implementation”
- `outputs/neo-jira-stories-20261111/v3/story_data.json` — entries[act=21]: “Manage Enquiry Task | FR10.4; FR11 | Authorisation”
- `outputs/neo-jira-stories-20261111/v3/story_data.json` — entries[act=22]: “Manage Task | FR11 | Authorisation”
- `outputs/neo-jira-stories-20261111/v3/story_data.json` — entries[act=25]: “Complete Task | FR14; FR15 | Implementation”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/router/index.tsx` — line 29: “<Route path="/implementation" element={<Implementation/>}/><Route path="/finance/payments" element={<Payments/>}/><Route path="/finance/reserve" element={<Reserve teams={section==='teams'}/>}/><Route path="/finance/journal" element={<Journal/>}/><Rou”
- `outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/solution-review/NEO-029/STATUS.json` — status and userDirection: “DELEGATED_REUSE_EXISTING_POC; 029 我们POC有方案了，用POC的，发一个task就好了. Implementation and acceptance not yet confirmed.”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/theme/index.ts` — line 9: “const checkedControl = { colorPrimary: '#000000', colorPrimaryHover: '#000000' };”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/components/DataTable/index.tsx` — line 8: “export function DataTable<T extends object>({ pagination, rowSelection, scroll, recordLabel = 'record', ariaLabel, ...rest }: DataTableProps<T>) {”

## NEO-049 SAP ECC容器合同任务交接Digitide


**源行**：Requested Changes A50:R50；全部非空单元格已保存到ASSESSMENT.json/sourceCells。采购优先级：Must；财务：未填；建议：P1。K50=Must、L50空；已发生任务卡住，优先补清楚动作和交接，但自动路由待Owner决策。


### 用户问题
M50明确任务停在Buyer但Buyer不知道需指示Digitide。Q50包含EPMC/BAC/TD全部SAP ECC路由，要求任务动作清楚，并允许指派或自动指派Digitide且信息齐备。

### 当前基线与复用
FR14的Trading Division历史规则为Buyer执行；UC-20已有container contract review及拒绝重建。当前ManualSystemTask/AMM/Tasks分支和assignment可复用，但未证明存在覆盖EPMC/BAC/TD三类且可由Buyer跨组交Digitide的完整合同任务包。通用reassignment明确same-team限制。

ManualSystemTask、AMM、MCI_TASK、UC-20和任务审计可复用；现有组内reassign不是Buyer→Digitide授权。

### 建议方案及架构
批准且满足实施前置后生成明确的Create/progress container contract任务，带冻结的Settlement/Line/parts/价格/日期/附件；按已批准责任策略交Digitide组或先由Buyer确认交接。个人领取保留审计。完成必须记录合同编号、逐项完成依据及未完成项，后续审批/生效状态单列。

采用NEO内部任务交接＋Digitide人工SAP操作；若未来自动建合同另立接口范围，不能借LumpSum PO创建API代替容器合同契约。

### 修改与影响
- ux：显示SAP ECC、EPMC/BAC/TD分支、Buyer、执行组、交接状态和必备资料；明确Assign to Digitide、Return to Buyer和Record contract。
- frontend：复用人工任务详情、字段/附件只读快照与任务领取组件；把“指示Digitide”变成可追踪交接动作。
- backend：新增受控跨职责路由命令，不放开所有任务跨组reassign；校验批准版本、资料、候选权限和一次性handoff，拒绝过时或重复建单。
- data：复用MCI_TASK+settlement/line关联；保存branch/system、instruction、approved snapshot version、contract ref、attachment refs、assignment version、completion evidence。合同号是字符串，保留前导零。
- workflow：Buyer到Digitide政策需与FR14 TD Buyer规则对齐；退回资料不丢原指令；拒绝合同按UC-20关闭旧行并重新审批，不原地覆写批准依据。

### 集成边界
- needed：False
- systems：['NEO内部任务；SAP ECC由Digitide人工操作']
- provider：NEO应用Owner / 企业身份Owner；CBSL/Digitide是人员团队
- direction：内部case/task assignment；不新增CBSL或SAP容器合同API
- reuse：现有任务/组/权限与审计复用
- evidence：集成目录证明服务存在，不证明完整契约、权限、可用性或真实回执；人工操作不等于自动接口
- unknown：角色、组成员来源及服务交接权限未签认

### 依赖
- NEO-036责任矩阵
- NEO-065身份/组及案件访问
- SAP ECC合同必填字段/附件模板Owner
- TD审批和GFS前置；UC-20拒绝重建

### ACT / FR核对
Inherited ACT labels verified against current story_data; canonical PAGE identifiers verified in the registered QA model.
- ACT-025 Complete Task / FR14; FR15
- ACT-044 Create Trading Division Request / FR9.2; FR11; FR11.1

### UC / 页面定位
- UC-20 direct / paragraphs 333–339 / 新增EPMC/BAC/TD准确分支、Buyer到Digitide交接与完整资料包，明确不直接实现SAP建合同API。 EPMC与EMC名称对应关系待业务确认。
- UC-18 related / paragraphs 319–325 / 新增EPMC/BAC/TD准确分支、Buyer到Digitide交接与完整资料包，明确不直接实现SAP建合同API。 EPMC与EMC名称对应关系待业务确认。
PAGE-P3, PAGE-P3.5, PAGE-P3.6, PAGE-P4.4；127-page canonical QA，不与旧143页别名混用。

### 复核场景（产品全部NOT RUN）


**NEO-049-S01** Buyer。前置：EPMC/BAC/TD各运行一轮；批准Settlement版本3，必需资料齐。输入：system=SAP ECC; instruction=Create approved container contract。操作：Review instruction → Assign to Digitide → Confirm。预期：按确认策略生成一个Digitide任务；冻结批准版本和全部资料，Buyer可见进度。Actual=null；NOT RUN。


**NEO-049-S02** Buyer。前置：缺签署协议。输入：attachment=null; branch=BAC。操作：尝试Assign to Digitide。预期：字段旁指出Missing agreement；保留指令；不创建任务。Actual=null；NOT RUN。


**NEO-049-S03** Digitide member。前置：有权且已领取。输入：contractNumber=00004567; evidence=Release confirmation。操作：Record contract，确认并重开。预期：前导零保留；Task完成与合同释放/价格生效分别显示，未满足关闭政策不关Claim。Actual=null；NOT RUN。


**NEO-049-S04** Digitide member。前置：合同一行拒绝。输入：line=2; result=Rejected。操作：Return to Buyer并记录原因。预期：按UC-20保留旧行，确认重建/重审批路径，不覆写原批准值。Actual=null；NOT RUN。


**NEO-049-S05** Unauthorised buyer。前置：不在允许服务交接范围。输入：recipient=CBSL member。操作：直接调用跨组handoff。预期：拒绝；现有same-team reassign不被绕过。Actual=null；NOT RUN。


**NEO-049-S06** Two buyers。前置：handoff revision=3。输入：intent=H049-001。操作：双击确认并另一窗口重复提交。预期：只一个任务/assignment；重复返回原结果。Actual=null；NOT RUN。


**NEO-049-S07** Buyer。前置：批准资料版本3已变4。输入：instruction version=3。操作：提交交接。预期：拒绝旧快照，保留输入并提示重审；不发送过期资料。Actual=null；NOT RUN。


### 精确来源
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!A50: “NEO-049”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!B50: “Both”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!C50: “EPMC/BAC Workflow”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!D50: “Existing functionality - Update UX / Workflow”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!E50: “EPMC/BAC SAP Container Contract workflow needs to be reviewed and clarity around R&Rs for raising container contract.
Could be directed directly to digitide to raise the container contract on behalf of the buyer (or greater clarity on the buyer to in”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!K50: “Must”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!M50: “Workflows get stuck with buyers but they don't realise they need to instruct digitide.”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!Q50: “As a buyer - when a Risk/Opp is ready to be implemetned into a SAP ECC system (EPMC/BAC/TD) the task that is triggered needs to make it clear the actions that can now be taken to raise/progress the container contract in SAP. It should be possible to ”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!R50: “N”
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` — paragraphs 333–339: “UC-20 Implement alternative POA branches
Actor and precondition. CBSL, GFS and Buyer. An approved transaction subtype identifies the proper route.
Trigger. Approved completion triggers an alternative POA subtype.
Normal path. Exercise AMM via ATP, co”
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` — paragraphs 319–325: “UC-18 Request Settlement and handle rejection
Actor and precondition. Buyer and FBP. The applicable Mandate result, Deal Signed, Contractual and agreement evidence are available.
Trigger. Buyer has final signed terms and starts Settlement.
Normal pat”
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` — rows[audit_id=PAGE-P3]: “P3 Task list | 用户127项页面清单；原FR定位按原文保留：FR15：按角色／组显示任务，支持筛选、处理、领取及受控改派。
 FR21：按任务类型配置天数并展示 Green／Amber／Red 状态。
 Training：Manage Task（¶1126）。
第二部分来源：Before别名P15；tasks、roles，Dictionary/Schema及既有FIELD_REGISTER精确引用见本行planningRecords与合并计划：/Volumes/KIOXIA/JLR”
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` — rows[audit_id=PAGE-P3.5]: “P3.5 Task Detail-其他人工实施 | 用户127项页面清单；原FR定位按原文保留：FR14：按交易分支向 GFS、CBSL、Buyer 或 AP 分派人工任务。
 Training：Complete Task（¶1186）。
 各分支完成条件和责任组不能合并为同一个通用“完成”。
第二部分来源：Before别名P15.12–P15.18；tasks、implementation、lsp，Dictionary/Schema及既有FIELD_REGISTER精确引用见本行plannin”
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` — rows[audit_id=PAGE-P3.6]: “P3.6 Task Detail-领取／改派任务 | 用户127项页面清单；原FR定位按原文保留：FR15：按角色／组显示任务，支持筛选、处理、领取及受控改派。
 Training：Reassign Task（¶1090）。
 分配权限不等于任意跨组转交。
第二部分来源：Before别名P15.1；tasks、roles，Dictionary/Schema及既有FIELD_REGISTER精确引用见本行planningRecords与合并计划：/Volumes/KIOXIA/JLR Appian”
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` — rows[audit_id=PAGE-P4.4]: “P4.4 Create Trading Division Request | 用户127项页面清单；原FR定位按原文保留：FR9.2：创建非普通 Claim 关联的请求，至少上传一份文件并先交 GFS。。承载／依赖关联：FR11、FR11.1，不作为独立覆盖。
 Training：Create Trading Division Request（¶1424）。
第二部分来源：Before别名P12.2；request、tasks、files，Dictionary/Schema及既有FIELD_RE”
- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` — table 6 row 39: “*Trading Division* - Where settlement request is for trading division and all approvers received
Task should generate for a buyer User linked to buyer code 
*Payment Term Acceleration* - On back of an Ad hoc clearing house item
Task should generate f”
- `6.技术方案/2 - Tech NEO/NEO User Training.docx` — paragraphs 1191–1196: “Complete Task action can be performed on different Manual tasks in Tasks list.
Manual Tasks - RMA 
Manual Tasks - ATP/ AMM/ Resource
	Manual Tasks - POA
	Manual Tasks - Manual Invoice
	Manual Tasks - Ad-Hoc Approval Request”
- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` — 字段字典!A1662:R1672: “MCI_TASK | 问询、任务与附件 | 业务 | TASK_ID | int(11) | integer | 否 | PK | 否 | Primary key of the table. This table holds information of Tasks | 结构+字典
MCI_TASK | 问询、任务与附件 | 业务 | ENQUIRY_ID | int(11) | integer | 是 | FK | MCI_ENQUIRY | ENQUIRY_ID | 已建 | 否 | Pri”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/tasks/reassignment.ts` — line 25: “requireCondition(recipientId !== ownerId && taskTeam(subject) === taskTeam(taskRecipientSubject(recipientId)), 'same-team-recipient-required');”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p05/manual-system-task.ts` — line 7: “export type ManualSystemCause = 'RMA' | 'POA (Out of Scope Part)' | 'ATP' | 'Resource' | 'Manual Invoice';”
- `outputs/neo-jira-stories-20261111/v3/story_data.json` — entries[act=25]: “Complete Task | FR14; FR15 | Implementation”
- `outputs/neo-jira-stories-20261111/v3/story_data.json` — entries[act=44]: “Create Trading Division Request | FR9.2; FR11; FR11.1 | Authorisation”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/router/index.tsx` — line 29: “<Route path="/implementation" element={<Implementation/>}/><Route path="/finance/payments" element={<Payments/>}/><Route path="/finance/reserve" element={<Reserve teams={section==='teams'}/>}/><Route path="/finance/journal" element={<Journal/>}/><Rou”
- `outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/solution-review/NEO-029/STATUS.json` — status and userDirection: “DELEGATED_REUSE_EXISTING_POC; 029 我们POC有方案了，用POC的，发一个task就好了. Implementation and acceptance not yet confirmed.”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/theme/index.ts` — line 9: “const checkedControl = { colorPrimary: '#000000', colorPrimaryHover: '#000000' };”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/components/DataTable/index.tsx` — line 8: “export function DataTable<T extends object>({ pagination, rowSelection, scroll, recordLabel = 'record', ariaLabel, ...rest }: DataTableProps<T>) {”

## NEO-058 已批准POA逐项实施、核对与恢复


**源行**：Requested Changes A59:R59；全部非空单元格已保存到ASSESSMENT.json/sourceCells。采购优先级：未填；财务：未填；建议：P0。K/L为空；建议P0基于错误实施状态和重复价格更新风险，先验契约与状态一致性，再开放自动重试。


### 用户问题
M59报告NEO显示实施但WIPS未实施、同一零件既错误又success、CBSL清任务而ID仍等实施。Q59还要求审批前尽量识别批准依据与WIPS/SAP ECC/S4差异，并对实施中差异恢复闭环。

### 当前基线与复用
当前p05 implementation已有阶段顺序、attempt/correlation、unknown先lookup、重复/冲突receipt和版本范围校验；wips creation有资料检查，S4模块有本地任务完成与ATP reference。代码ready依赖local completion，不能据此证明真实S4写回。集成目录有WIPS create/approve及两个回调、SAP parts/price GET；没有验证逐零件完整回执、未知结果查询及S4 POA自动写回契约。

p05/implementation receipt/lookup/idempotency、WIPS recovery UI、S4 task字段、MCI_RISK_OPPORTUNITY_PART_WIPS_CLAIM；NEO-029输入/会话恢复仅引用。

### 建议方案及架构
复用实施状态机，审批前按适用源获取当前价格/有效期/零件资格，保留snapshot时间和差异；审批后逐system/part/operation跟踪Pending、Processing、Confirmed、Failed、Unknown。Unknown只能查询原attempt或转受控人工核对；部分成功不重做成功行。批准数据变化先判断重新审批。Task Completed与External Implemented分开，只有所有应实施项有可核对的外部证据且当前批准版本一致才能关闭。

扩展已有内部实施状态机和适配器；复用WIPS AA通道及SAP只读查询，经契约核验后上线。不新造自动化平台，不推定S4写回已存在。

### 修改与影响
- ux：一个实施页并列批准值、源值/时间、执行结果、外部参考、当前责任；错误定位零件和操作；Unknown禁Retry并提供Check source result。
- frontend：复用WipsRpaTask/S4HanaTask/BuyerRpaReview及implementation timeline；增加precheck、partial/unknown/readback投影与逐项操作资格。
- backend：持久化command intent、frozen payload、correlation、result per occurrence；回调验签/授权、重复/乱序/范围校验；读取原attempt结果后才允许重试；outbox提交和事件投影原子化。
- data：以source system+part occurrence+plant+effective period+approved version关联价格；保留decimal精度（字典START/END_PRICE numeric(19,5)）及currency；receipt原文/规范状态/时间/版本分别存储，schema仅候选。
- workflow：前置差异→Buyer纠正/重审批；确定未提交才重试；未知结果→核对；人工接管锁定自动执行；成功行不重发；未实施行有责任人，不允许孤儿状态或仅清任务。

### 集成边界
- needed：True
- systems：['WIPS / Automation Anywhere', 'SAP ECC', 'S4 Hana']
- provider：WIPS/AA、SAP ECC、S4接口Owner，待正式确认
- direction：NEO→WIPS创建/批准；WIPS→NEO回调；NEO→SAP查询；SAP/S4写回按分支另核
- reuse：目录中MCI_raiseWIPSClaim、MCI_approveWIPSClaim、MCI AA WIPS Response及Approval Response；SAP parts/price GET是候选复用
- evidence：集成目录证明服务存在，不证明完整契约、权限、可用性或真实回执；人工操作不等于自动接口
- unknown：逐项payload、验签、幂等键、unknown查询、price精度、超时、S4 POA写回及责任方均待确认

### 依赖
- NEO-036异常责任
- NEO-049 SAP ECC人工路线
- NEO-065 CBSL协作
- 源系统各字段/回执/读回契约与Owner
- 既有NEO-029 POC恢复仅复用
- NQA-119/120/121/122及同一测试Word6.53–6.56

### ACT / FR核对
ACT-027 is Create WIPS Claim / FR13 (related precreation; UC-19 starts after approved Settlement). ACT-062 is CBSL S4 Hana Task, not a generic ATP task. UC-20 directly covers alternative/container routes; exact S4 precheck/readback/partial-result coverage needs new local scenarios.
- ACT-023 Raise WIPS Claim Manually / FR13; FR14
- ACT-027 Create WIPS Claim / FR13
- ACT-061 WIPS update fail - CBSL Task / FR13; FR14 (associated)
- ACT-062 CBSL S4 Hana Task / FR13; FR14 (associated)
- ACT-063 WIPS Claim Approval - RPA Fail / FR13; FR14 (associated)
- ACT-064 Buyer Review Required - RPA Error / FR13; FR14 (associated)

### UC / 页面定位
- UC-19 direct / paragraphs 326–332 / 新增审批前差异校验、SAP ECC/S4各路由逐行结果、partial success、conflicting callback、人工接管与任务清除后孤儿恢复。
- UC-20 direct-branch / paragraphs 333–339 / 新增审批前差异校验、SAP ECC/S4各路由逐行结果、partial success、conflicting callback、人工接管与任务清除后孤儿恢复。
PAGE-P3.4, PAGE-P3.5, PAGE-P3.1；127-page canonical QA，不与旧143页别名混用。

### 复核场景（产品全部NOT RUN）


**NEO-058-S01** Buyer。前置：批准前，源可查询。输入：part=JX1-100-A; approvedPrice=12.50000 GBP; sourcePrice=12.30000 GBP。操作：Run precheck；查看差异；纠正并按政策重新提交。预期：保存源时间及值；未解决的阻断差异不批准；不把差异自动当错误。Actual=null；NOT RUN。


**NEO-058-S02** RPA service。前置：批准版本3；三零件待实施。输入：A success; B failed; C unknown。操作：接收三行结果并打开实施页。预期：A只一条Confirmed；B Failed；C Unknown；Overall未Implemented，B/C有责任人。Actual=null；NOT RUN。


**NEO-058-S03** Recovery owner。前置：创建超时结果未知。输入：correlation=CORR-058-001。操作：Retry应禁用；Check source result找到WIPS-0042。预期：绑定原attempt/参考；不再次创建，不重复价格变更。Actual=null；NOT RUN。


**NEO-058-S04** Integration service。前置：已有成功receipt。输入：receipt=REC-058-001; duplicate same payload then conflicting price。操作：重复与冲突回调依次送入。预期：同内容幂等；冲突隔离显示，不能把成功/错误同时算通过。Actual=null；NOT RUN。


**NEO-058-S05** CBSL executor。前置：已人工完成S4任务但无确认外部结果。输入：ATP ref=00003456; taskComplete=true。操作：完成任务后读取Claim。预期：Task completed可显示；External implementation仍Awaiting confirmation；有核对任务。Actual=null；NOT RUN。


**NEO-058-S06** Buyer and RPA。前置：批准版本3执行中，Buyer改version4。输入：newPrice=12.60000 GBP。操作：attempt3回执到达；新版本尝试继续。预期：旧回执保留历史不覆盖新版本；按政策重审批，不静默refresh已批准payload。Actual=null；NOT RUN。


**NEO-058-S07** Recovery owner。前置：人工接管中，迟到机器人成功。输入：takeover=true; receipt=REC-058-LATE。操作：接收原attempt回执；执行人工完成命令。预期：记录迟到结果并核对，双重实施被阻断，成功项不再重做。Actual=null；NOT RUN。


**NEO-058-S08** API operator。前置：S4读回权限失效或服务超时。输入：HTTP 403 then timeout。操作：查询源结果；尝试关闭。预期：状态保持Unknown/Blocked，明确Owner和重试依据，不回退为无提交。Actual=null；NOT RUN。


**NEO-058-S09** Finance control。前置：所有适用项有确认的价格/生效日/版本。输入：A=12.50000 GBP effective2026-12-01; B=4.25000 GBP。操作：读取回执与源对账后Close implementation。预期：只当前完整证据可转Implemented，事件、任务、Claim及报表一致持久回读。Actual=null；NOT RUN。


### 精确来源
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!A59: “NEO-058”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!B59: “Procurement”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!C59: “POA Implementation”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!D59: “Existing functionality - Update UX / Workflow”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!E59: “The implementation of approved POA claims either by RPA robot or by Digitide shared service must be operate smoothly with updates made into source system and tasks/status aligned into NEO”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!G59: “Yes”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!H59: “Partially”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!I59: “Yes”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!M59: “Various issues with implementation of POAs via robot (NEO item implemented but not in WIPS, tasks can be confusing, issues implementing with CBSL, issues with RPA errors highlighting errors for certain parts but also listing them as “success”). Somet”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!Q59: “As a procurement user - approved POA updates must be made into the downstream systems (WIPS / SAP ECC / S4). Where there are errors/disconnects between the approved data in NEO and the data in the source system these should where possible be identifi”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!R59: “N”
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` — paragraphs 326–332: “UC-19 Implement a standard price claim
Actor and precondition. Robot, Buyer, CBSL and PM. Settlement is approved and marked complete.
Trigger. Approved Settlement is marked complete for a standard Price Claim.
Normal path. Execute WIPS creation and a”
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` — paragraphs 333–339: “UC-20 Implement alternative POA branches
Actor and precondition. CBSL, GFS and Buyer. An approved transaction subtype identifies the proper route.
Trigger. Approved completion triggers an alternative POA subtype.
Normal path. Exercise AMM via ATP, co”
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` — rows[audit_id=PAGE-P3.4]: “P3.4 Task Detail-WIPS／S4 Hana | 用户127项页面清单；原FR定位按原文保留：FR13：在批准后处理 WIPS Claim，跟踪 Buyer／Manager 批准及处理结果。
 FR14：按交易分支向 GFS、CBSL、Buyer 或 AP 分派人工任务。。承载／依赖关联：FR16，不作为独立覆盖。
 Training：Create WIPS Claim（¶1254）；WIPS Approval（¶1363）；CBSL S4 Hana Task（¶1641）。
 F”
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` — rows[audit_id=PAGE-P3.5]: “P3.5 Task Detail-其他人工实施 | 用户127项页面清单；原FR定位按原文保留：FR14：按交易分支向 GFS、CBSL、Buyer 或 AP 分派人工任务。
 Training：Complete Task（¶1186）。
 各分支完成条件和责任组不能合并为同一个通用“完成”。
第二部分来源：Before别名P15.12–P15.18；tasks、implementation、lsp，Dictionary/Schema及既有FIELD_REGISTER精确引用见本行plannin”
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` — rows[audit_id=PAGE-P3.1]: “P3.1 Task Detail-Enquiry／Action | 用户127项页面清单；原FR定位按原文保留：FR10.4：接收、答复并完成 Enquiry，向发起人发送回复通知。
 FR10.5：处理行动、备注与截止时间，完成后更新请求并通知相应 FBP。
 Training：Manage Enquiry Task（¶1105）；Action Task for User（¶1487）。
 Enquiry 与 Action 具有不同完成及通知条件。”
- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` — table 6 row 38: “FR13 | Complete Purchase Order Amendments (POA) - WIPS and S4 Hana in Future). | Once a transaction has been submitted for a POA claim and all approvals have been received (i.e. Clearing house approval if applicable, star chamber approval if applicab”
- `6.技术方案/2 - Tech NEO/NEO User Training.docx` — paragraphs 1642–1656: “CBSL S4 Hana Task

Note: Managed by members from CBSL group only.

When a Risk/ Opp has moved to a status of "Data Posted Manually - Awaiting Approval" or "Data Posted Automatically - Awaiting Approval", relates to a POA line and if S4 Hana parts are”
- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` — 字段字典!A901:R909: “MCI_RISK_OPPORTUNITY_PART_WIPS_CLAIM | 索赔 | 业务 | RISK_OPPORTUNITY_PART_WIPS_CLAIM_ID | int(11) | integer | 否 | PK | 否 | Primary key of the table. This table holds information of risk opportunity part wips claim | 结构+字典
MCI_RISK_OPPORTUNITY_PART_WIPS_”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p05/implementation.ts` — line 94: “requireCondition(!last || last.outcome === 'success' || last.outcome === 'no-commit', 'unknown-or-processing-outcome');”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p05/implementation.ts` — line 113: “requireCondition(x.outcome !== 'unknown' || cmd.kind === 'lookup', 'lookup-original-unknown-required');”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p05/implementation.ts` — line 134: “c.exceptions.push('Receipt scope mismatch: ' + cmd.receiptId);”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/wips/s4-hana.ts` — line 77: “ready:(posting:Posting)=>!s4Parts(posting.snapshot.buffer).length||!!read().find(r=>r.postingId===posting.id)?.completion,”
- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` — line 8; service MCI_getPartPriceDetails: “2,MCI_getPartPriceDetails,Integration used to fetch part price details from SAP to Appian and process with POA claims,Material Cost & Inventory,Integration,Appian,SAP,Apigee,MCI SAP,GET,”
- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` — line 46; service MCI_raiseWIPSClaim: “12,MCI_raiseWIPSClaim,Creates a claim in WIPS system,Material Cost & Inventory,Integration,Appian,WIPS,Automation Anywhere,MCI AA,POST,”
- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` — line 65; service MCI_approveWIPSClaim: “13,MCI_approveWIPSClaim,Send a request to approve the claim in WIPS,Material Cost & Inventory,Integration,Appian,WIPS,Automation Anywhere,MCI AA,POST,”
- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` — line 91; service MCI AA WIPS Response: “16,MCI AA WIPS Response,Returns claim creation response from WIPS to Appian,Material Cost & Inventory,API,WIPS,Appian,Automation Anywhere,NA,NA,”
- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` — line 92; service MCI AA WIPS Approval Response: “17,MCI AA WIPS Approval Response,Returns claim approval response from WIPS to Appian,Material Cost & Inventory,API,WIPS,Appian,Automation Anywhere,NA,NA,”
- `outputs/neo-jira-stories-20261111/v3/story_data.json` — entries[act=23]: “Raise WIPS Claim Manually | FR13; FR14 | Implementation”
- `outputs/neo-jira-stories-20261111/v3/story_data.json` — entries[act=27]: “Create WIPS Claim | FR13 | Implementation”
- `outputs/neo-jira-stories-20261111/v3/story_data.json` — entries[act=61]: “WIPS update fail - CBSL Task | FR13; FR14 (associated) | Implementation”
- `outputs/neo-jira-stories-20261111/v3/story_data.json` — entries[act=62]: “CBSL S4 Hana Task | FR13; FR14 (associated) | Implementation”
- `outputs/neo-jira-stories-20261111/v3/story_data.json` — entries[act=63]: “WIPS Claim Approval - RPA Fail | FR13; FR14 (associated) | Implementation”
- `outputs/neo-jira-stories-20261111/v3/story_data.json` — entries[act=64]: “Buyer Review Required - RPA Error | FR13; FR14 (associated) | Implementation”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/router/index.tsx` — line 29: “<Route path="/implementation" element={<Implementation/>}/><Route path="/finance/payments" element={<Payments/>}/><Route path="/finance/reserve" element={<Reserve teams={section==='teams'}/>}/><Route path="/finance/journal" element={<Journal/>}/><Rou”
- `outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/solution-review/NEO-029/STATUS.json` — status and userDirection: “DELEGATED_REUSE_EXISTING_POC; 029 我们POC有方案了，用POC的，发一个task就好了. Implementation and acceptance not yet confirmed.”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/theme/index.ts` — line 9: “const checkedControl = { colorPrimary: '#000000', colorPrimaryHover: '#000000' };”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/components/DataTable/index.tsx` — line 8: “export function DataTable<T extends object>({ pagination, rowSelection, scroll, recordLabel = 'record', ariaLabel, ...rest }: DataTableProps<T>) {”

## NEO-065 CBSL案件协作、受理与进度追踪


**源行**：Requested Changes A66:R66；全部非空单元格已保存到ASSESSMENT.json/sourceCells。采购优先级：未填；财务：未填；建议：P1。K/L空；当前已有基础且是049/058责任闭环依赖，建议P1，先确认账号和保密访问。


### 用户问题
E66要求将CBSL组或个人直接分配到相关case并跟踪进度，减少共享邮箱；D66写New functionality，但G66=Yes且当前已有CBSL任务，不能把整块当新增。

### 当前基线与复用
FR15与字典已有ASSIGNED_USER/GROUP、COMMENTS、SLA；Training允许GFS/AP/CBSL各自组内改派。当前queue、reassignment、WIPS enquiry及S4任务已有授权/版本/备注。源码多处使用offline cbsl样本；未证明企业身份目录、多人案件协作、真正进度持久化及端到端通知。

FR15、MCI_TASK、Tasks queue/Reassign、WIPS/S4 enquiry及task events；现有组内约束保留，跨组handoff作为独立权限。

### 建议方案及架构
扩展既有案件任务为CBSL组队列、个人领取、明确状态/下一步和案件时间线；保留一个当前可执行owner，协作者有清楚的只读/评论/处理权限。Buyer可提出受控服务交接，CBSL在组内指派；问询回复关联版本、附件和零件。

CBSL是组织团队，以NEO内部任务/协作模型实现；无需新增CBSL API。若后续明确实时聊天、Teams或跨系统通知，再单独核对服务契约。

### 修改与影响
- ux：病例式工作区展示任务、执行组/人、进度、待谁回复、下一步；提供Claim task、Assign、Ask Buyer、Add update，完成门槛依交易决定。
- frontend：复用Task list、Enquiry、Reassign；在案件页聚合关联任务与活动，避免复制Case和外部mailbox会话。
- backend：组/个人成员资格和case范围双检查；claim使用compare-and-set确保两人只一人成功；评论/附件权限不自动授予批准或关闭权。
- data：复用MCI_TASK group/user/comment；新增case membership/协作角色、task assignment revision、activity events和attachment refs；身份来源与离组清理契约待确认。
- workflow：未领取归组，领取后归个人；询问中标Waiting for Buyer，回复回原任务；完成不直接等于外部实施，重开和移交按036/058。

### 集成边界
- needed：False
- systems：['NEO内部任务']
- provider：NEO应用Owner / 企业身份Owner；CBSL/Digitide是人员团队
- direction：内部case/task assignment；不新增CBSL或SAP容器合同API
- reuse：现有任务/组/权限与审计复用
- evidence：FR15、MCI_TASK、reassignment及enquiry源码
- unknown：角色、组成员来源及服务交接权限未签认

### 依赖
- NEO-036责任和升级
- NEO-049合同handoff
- NEO-058真实实施状态
- 企业身份/CBSL成员目录与保密授权
- NEO-057进度报告/提醒只复用依赖

### ACT / FR核对
Inherited ACT labels verified against current story_data; canonical PAGE identifiers verified in the registered QA model.
- ACT-020 Reassign Task / FR15
- ACT-021 Manage Enquiry Task / FR10.4; FR11
- ACT-025 Complete Task / FR14; FR15
- ACT-061 WIPS update fail - CBSL Task / FR13; FR14 (associated)

### UC / 页面定位
- UC-17 related / paragraphs 312–318 / 新场景覆盖CBSL组队列领取、个体协作权限、并发claim、case进度及离组回收；UC-17转办不是全部协作。
- UC-19 related / paragraphs 326–332 / 新场景覆盖CBSL组队列领取、个体协作权限、并发claim、case进度及离组回收；UC-17转办不是全部协作。
- UC-20 related / paragraphs 333–339 / 新场景覆盖CBSL组队列领取、个体协作权限、并发claim、case进度及离组回收；UC-17转办不是全部协作。
PAGE-P3, PAGE-P3.1, PAGE-P3.4, PAGE-P3.5, PAGE-P3.6；127-page canonical QA，不与旧143页别名混用。

### 复核场景（产品全部NOT RUN）


**NEO-065-S01** CBSL member Morgan Reed。前置：授权CBSL组；task未领取。输入：case=COL-065-01。操作：Claim task → Confirm。预期：当前owner Morgan Reed；同组可看进度但不同时执行。Actual=null；NOT RUN。


**NEO-065-S02** Two CBSL members。前置：同一未领取task version2。输入：A=Morgan Reed; B=Alex Patel。操作：同时Claim task。预期：只有一个成功；另一个看到现owner，不能覆盖。Actual=null；NOT RUN。


**NEO-065-S03** Buyer。前置：允许给CBSL服务任务，保密授权具备。输入：instruction=Confirm contract effective date。操作：Assign group并确认；CBSL Add update。预期：case进度和活动可见；不依赖共享邮箱。Actual=null；NOT RUN。


**NEO-065-S04** CBSL assignee。前置：当前版本3。输入：question=Please confirm date。操作：Ask Buyer；Buyer回复2026-12-01。预期：Waiting for Buyer到In progress，原task关联问题和回复，不新建孤儿。Actual=null；NOT RUN。


**NEO-065-S05** Unauthorised CBSL member。前置：同组但没有保密权限。输入：confidential case=COL-065-02。操作：打开URL/附件并尝试领取。预期：列表不泄露敏感信息，服务器拒绝数据和附件。Actual=null；NOT RUN。


**NEO-065-S06** Service lead。前置：当前owner已离组。输入：newOwner=Alex Patel; reason=Team membership changed。操作：按批准策略重新指派并由旧人提交。预期：新assignment生效，旧人操作失效，原记录与原因保留。Actual=null；NOT RUN。


**NEO-065-S07** CBSL assignee。前置：任务待外部核对。输入：comment=Work performed; external result=Unknown。操作：Add update并尝试Complete case。预期：评论保存；不把评论或任务完成当外部实施成功。Actual=null；NOT RUN。


**NEO-065-S08** CBSL assignee。前置：保存响应丢失。输入：intent=COL065-001; note=Waiting for release。操作：提交后重开，查询同intent。预期：只一条活动；输入可恢复，不重复任务/评论。Actual=null；NOT RUN。


### 精确来源
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!A66: “NEO-065”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!B66: “Procurement”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!C66: “Workflow”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!D66: “New functionality”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!E66: “Integrate CBSL collaboration into the workflow by assigning CBSL teams or individuals directly to relevant cases and tracking their progress, rather than relying primarily on communication through a shared mailbox.”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!G66: “Yes”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!I66: “Yes”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!J66: “Yes”
- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` — RTM for Requested Changes!M66: “Limited CBSL collaboration visibility”
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` — paragraphs 312–318: “UC-17 Transfer and suspend work
Actor and precondition. Current reviewer and eligible recipient. The policy permits the action and identifies the current task.
Trigger. An eligible actor chooses transfer or suspension.
Normal path. Transfer and trans”
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` — paragraphs 326–332: “UC-19 Implement a standard price claim
Actor and precondition. Robot, Buyer, CBSL and PM. Settlement is approved and marked complete.
Trigger. Approved Settlement is marked complete for a standard Price Claim.
Normal path. Execute WIPS creation and a”
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` — paragraphs 333–339: “UC-20 Implement alternative POA branches
Actor and precondition. CBSL, GFS and Buyer. An approved transaction subtype identifies the proper route.
Trigger. Approved completion triggers an alternative POA subtype.
Normal path. Exercise AMM via ATP, co”
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` — rows[audit_id=PAGE-P3]: “P3 Task list | 用户127项页面清单；原FR定位按原文保留：FR15：按角色／组显示任务，支持筛选、处理、领取及受控改派。
 FR21：按任务类型配置天数并展示 Green／Amber／Red 状态。
 Training：Manage Task（¶1126）。
第二部分来源：Before别名P15；tasks、roles，Dictionary/Schema及既有FIELD_REGISTER精确引用见本行planningRecords与合并计划：/Volumes/KIOXIA/JLR”
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` — rows[audit_id=PAGE-P3.1]: “P3.1 Task Detail-Enquiry／Action | 用户127项页面清单；原FR定位按原文保留：FR10.4：接收、答复并完成 Enquiry，向发起人发送回复通知。
 FR10.5：处理行动、备注与截止时间，完成后更新请求并通知相应 FBP。
 Training：Manage Enquiry Task（¶1105）；Action Task for User（¶1487）。
 Enquiry 与 Action 具有不同完成及通知条件。”
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` — rows[audit_id=PAGE-P3.4]: “P3.4 Task Detail-WIPS／S4 Hana | 用户127项页面清单；原FR定位按原文保留：FR13：在批准后处理 WIPS Claim，跟踪 Buyer／Manager 批准及处理结果。
 FR14：按交易分支向 GFS、CBSL、Buyer 或 AP 分派人工任务。。承载／依赖关联：FR16，不作为独立覆盖。
 Training：Create WIPS Claim（¶1254）；WIPS Approval（¶1363）；CBSL S4 Hana Task（¶1641）。
 F”
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` — rows[audit_id=PAGE-P3.5]: “P3.5 Task Detail-其他人工实施 | 用户127项页面清单；原FR定位按原文保留：FR14：按交易分支向 GFS、CBSL、Buyer 或 AP 分派人工任务。
 Training：Complete Task（¶1186）。
 各分支完成条件和责任组不能合并为同一个通用“完成”。
第二部分来源：Before别名P15.12–P15.18；tasks、implementation、lsp，Dictionary/Schema及既有FIELD_REGISTER精确引用见本行plannin”
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` — rows[audit_id=PAGE-P3.6]: “P3.6 Task Detail-领取／改派任务 | 用户127项页面清单；原FR定位按原文保留：FR15：按角色／组显示任务，支持筛选、处理、领取及受控改派。
 Training：Reassign Task（¶1090）。
 分配权限不等于任意跨组转交。
第二部分来源：Before别名P15.1；tasks、roles，Dictionary/Schema及既有FIELD_REGISTER精确引用见本行planningRecords与合并计划：/Volumes/KIOXIA/JLR Appian”
- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` — table 6 row 40: “FR15 | Task List | Context: The application will contain a task list for all users. When a user receives a task (e.g. buyer receiving an enquiry or GFS receiving a checking task, the task will appear in this list. 
The solution should contain a tab f”
- `6.技术方案/2 - Tech NEO/NEO User Training.docx` — paragraphs 1091–1092: “Reassign Task
Note: One GFS, AP, CBSL user can assign to another GFS, AP, CBSL respectively ”
- `6.技术方案/2 - Tech NEO/NEO User Training.docx` — paragraphs 1642–1646: “CBSL S4 Hana Task

Note: Managed by members from CBSL group only.

When a Risk/ Opp has moved to a status of "Data Posted Manually - Awaiting Approval" or "Data Posted Automatically - Awaiting Approval", relates to a POA line and if S4 Hana parts are”
- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` — 字段字典!A1662:R1672: “MCI_TASK | 问询、任务与附件 | 业务 | TASK_ID | int(11) | integer | 否 | PK | 否 | Primary key of the table. This table holds information of Tasks | 结构+字典
MCI_TASK | 问询、任务与附件 | 业务 | ENQUIRY_ID | int(11) | integer | 是 | FK | MCI_ENQUIRY | ENQUIRY_ID | 已建 | 否 | Pri”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/wips/creation.ts` — line 172: “return { ok: false, message: 'The CBSL assignee needs confidential access to this Claim.' };”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/tasks/reassignment.ts` — line 25: “requireCondition(recipientId !== ownerId && taskTeam(subject) === taskTeam(taskRecipientSubject(recipientId)), 'same-team-recipient-required');”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/wips/s4-hana.ts` — line 78: “notices(actor:IdentityScenario){return list(actor).flatMap(v=>{”
- `outputs/neo-jira-stories-20261111/v3/story_data.json` — entries[act=20]: “Reassign Task | FR15 | Implementation”
- `outputs/neo-jira-stories-20261111/v3/story_data.json` — entries[act=21]: “Manage Enquiry Task | FR10.4; FR11 | Authorisation”
- `outputs/neo-jira-stories-20261111/v3/story_data.json` — entries[act=25]: “Complete Task | FR14; FR15 | Implementation”
- `outputs/neo-jira-stories-20261111/v3/story_data.json` — entries[act=61]: “WIPS update fail - CBSL Task | FR13; FR14 (associated) | Implementation”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/router/index.tsx` — line 29: “<Route path="/implementation" element={<Implementation/>}/><Route path="/finance/payments" element={<Payments/>}/><Route path="/finance/reserve" element={<Reserve teams={section==='teams'}/>}/><Route path="/finance/journal" element={<Journal/>}/><Rou”
- `outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/solution-review/NEO-029/STATUS.json` — status and userDirection: “DELEGATED_REUSE_EXISTING_POC; 029 我们POC有方案了，用POC的，发一个task就好了. Implementation and acceptance not yet confirmed.”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/theme/index.ts` — line 9: “const checkedControl = { colorPrimary: '#000000', colorPrimaryHover: '#000000' };”
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/components/DataTable/index.tsx` — line 8: “export function DataTable<T extends object>({ pagination, rowSelection, scroll, recordLabel = 'record', ariaLabel, ...rest }: DataTableProps<T>) {”