# 待业务确认


以下为方案所需决策；不以示例数据替代规则。


## NEO-036 异常处理责任与闭环规则

- **036-Q1 数据错、Digitide处理不了、已到付款日但没付款，分别由谁负责解决、谁最终确认关闭？**
  背景：E37未提供角色表且R37=Y。 示例：SAP价格不一致由Buyer补正还是数据团队；付款未到由AP调查还是FBP？
  Owner：Procurement与Finance流程Owner；影响：任务路由和关闭权限。

- **036-Q2 移交后对方未接手或超时，何时升级给谁？**
  背景：FR15只支持组内处理，跨组责任变化须明确。 示例：CBSL等Buyer回复两天，SLA暂停还是继续？
  Owner：流程Owner及服务负责人；影响：受理、退回、计时和提醒。

- **036-Q3 哪些材料足以关闭异常？**
  背景：关闭任务不能证明外部更新或支付。 示例：有邮件回复但没有SAP付款记录，是否仍保持待核对？
  Owner：Finance控制Owner；影响：防止假闭环。

## NEO-049 SAP ECC容器合同任务交接Digitide

- **049-Q1 EPMC、BAC、TD分别自动交Digitide，还是Buyer先确认再交？**
  背景：Q50同时提供两种可能，FR14 TD原来给Buyer。 示例：TD已批后直接进入Digitide队列是否保留Buyer确认？
  Owner：Procurement流程Owner及Digitide服务Owner；影响：路由、授权及上线范围。

- **049-Q2 Digitide建容器合同最少需要哪些字段和附件？**
  背景：来源要求all required information但未列完整模板。 示例：是否必须采购组织、供应商、物料、有效期、批准价格及签署协议？
  Owner：SAP ECC业务Owner、Digitide；影响：前后端校验和拒绝/补资料。

- **049-Q3 输入合同号就算完成，还是要等合同释放或价格生效？**
  背景：UC-20要求external evidence，编号存在不代表所有行生效。 示例：合同00004567已创建但两行被拒绝，NEO状态应如何显示？
  Owner：Finance与SAP ECC控制Owner；影响：完成门槛及逐行对账。

- **049-Q4 原需求的EPMC与BRD里的EMC是否指同一分支？**
  背景：Requested Changes写EPMC，工作BRD UC-20写EMC；不能直接把名称归一。 示例：若EPMC是新的SAP ECC组织范围，应明确适用公司和采购组织。
  Owner：SAP ECC业务Owner；影响：分支映射、任务生成及数据选择。

## NEO-058 已批准POA逐项实施、核对与恢复

- **058-Q1 每个系统用什么回执或查询结果证明每个零件、价格及生效日已实施？**
  背景：目录只证明接口候选存在，没有完整逐项合同。 示例：WIPS-0042返回success但一行仍12.30000而批准12.50000，应拒绝关闭。
  Owner：WIPS/AA、SAP ECC、S4接口Owner；影响：完成门槛和自动对账。

- **058-Q2 超时查不到结果时，谁能核对原操作？现有系统支持按什么键查重？**
  背景：未知结果不得直接新建或重试。 示例：WIPS建单超时，需按原correlation/业务键查是否已建，不能再建第二张。
  Owner：Integration Owner及Digitide；影响：幂等、未知恢复及人工锁。

- **058-Q3 审批前哪些差异必须挡住，批准后哪些变化必须重批？**
  背景：Q59说where possible，未定义允许的源价格变化与容差。 示例：批准后源价格12.30000变12.40000，是否重新计算差额并重批？
  Owner：Procurement/Finance政策Owner；影响：预校验、版本和财务正确性。

- **058-Q4 已有“任务完成但ID等待实施”的记录如何修复，谁批准修复？**
  背景：M59是已报告业务缺陷；本轮无真实记录可复现。 示例：CBSL已完成但无外部回执，先建核对任务还是重开原任务？
  Owner：应用支持与Finance控制Owner；影响：历史修复方案及迁移边界。

## NEO-065 CBSL案件协作、受理与进度追踪

- **065-Q1 CBSL和Digitide在这项工作里是同一团队/同一账号组吗？谁维护成员？**
  背景：源文本名称并用，但没有确认组织身份映射。 示例：一个Digitide新人加入是否自动成为CBSL候选、能看哪些CoC？
  Owner：Service Owner与IAM Owner；影响：候选人、授权与账号离职。

- **065-Q2 “直接分配到case”是承担一个任务，还是成为持续协作者？**
  背景：两者生命周期和权限不同。 示例：CBSL已完成建合同，后续Buyer改信息时该成员还可评论或看到新附件吗？
  Owner：Procurement及Access Owner；影响：case membership和访问期限。

- **065-Q3 保密案件可以交给哪些CBSL成员？任务领取是否需要额外授权？**
  背景：现有源码保密access检查必须保留。 示例：非授权同组成员不能因看到队列就打开保密价格附件。
  Owner：信息Owner与Access Owner；影响：数据泄露防护和候选筛选。