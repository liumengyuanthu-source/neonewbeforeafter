# CNP-234 — UC定位与边界

只评估036/049/058/065。Epic为分析分类，未写Jira。工作BRD的UC是来源场景，执行仍NOT RUN。段落从1计，含空段。

## NEO-036 — 异常处理责任与闭环规则
- UC-17: related，NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx paragraphs 312–318
- UC-19: related，NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx paragraphs 326–332
- UC-20: related，NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx paragraphs 333–339
- UC-21: related，NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx paragraphs 340–346
- UC-22: related，NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx paragraphs 347–353
- 缺口：新增跨类型异常RACI、接手/退回、证据关闭和未付款调查；现有UC不是完整责任矩阵。
- ACT: ACT-020, ACT-021, ACT-022, ACT-025; FR: FR15; FR10.4; FR11; FR14; FR16 (payment investigation related)
- Canonical pages: PAGE-P3, PAGE-P3.1, PAGE-P3.4, PAGE-P3.5, PAGE-P3.6

## NEO-049 — SAP ECC容器合同任务交接Digitide
- UC-20: direct，NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx paragraphs 333–339
- UC-18: related，NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx paragraphs 319–325
- 缺口：新增EPMC/BAC/TD准确分支、Buyer到Digitide交接与完整资料包，明确不直接实现SAP建合同API。 EPMC与EMC名称对应关系待业务确认。
- ACT: ACT-025, ACT-044; FR: FR14; FR15; FR9.2; FR11; FR11.1
- Canonical pages: PAGE-P3, PAGE-P3.5, PAGE-P3.6, PAGE-P4.4

## NEO-058 — 已批准POA逐项实施、核对与恢复
- UC-19: direct，NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx paragraphs 326–332
- UC-20: direct-branch，NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx paragraphs 333–339
- 缺口：新增审批前差异校验、SAP ECC/S4各路由逐行结果、partial success、conflicting callback、人工接管与任务清除后孤儿恢复。
- ACT: ACT-023, ACT-027, ACT-061, ACT-062, ACT-063, ACT-064; FR: FR13; FR14; FR1.6 (preapproval source comparison related)
- Canonical pages: PAGE-P3.4, PAGE-P3.5, PAGE-P3.1

## NEO-065 — CBSL案件协作、受理与进度追踪
- UC-17: related，NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx paragraphs 312–318
- UC-19: related，NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx paragraphs 326–332
- UC-20: related，NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx paragraphs 333–339
- 缺口：新场景覆盖CBSL组队列领取、个体协作权限、并发claim、case进度及离组回收；UC-17转办不是全部协作。
- ACT: ACT-020, ACT-021, ACT-025, ACT-061; FR: FR15; FR10.4; FR13; FR14
- Canonical pages: PAGE-P3, PAGE-P3.1, PAGE-P3.4, PAGE-P3.5, PAGE-P3.6
