# NEO-035–068 需求评估与方案汇总

本轮完成34条独立方案评估。001–034沿用既有交付，不重新评估。页面为独立候选设计，产品、接口及业务验收均为 **NOT RUN**。

## 1. 按 Epic 分工

| Epic | 范围 | 数量 | 详细评估 |
|---|---|---:|---|
| CNP-231 | 建档与数据 | 16 | [评估与页面](CNP-231/index.html) |
| CNP-233 | 授权审批 | 6 | [评估与页面](CNP-233/index.html) |
| CNP-234 | 实施 | 4 | [评估与页面](CNP-234/index.html) |
| CNP-235 | 财务与连续性 | 8 | [评估与页面](CNP-235/index.html) |

## 2. 方案如何合并

| 共同能力 | 需求 | 处理方式 |
|---|---|---|
| 审批控制 | 050、051、056、057、063、064 | 共享审批版本、任务归属、实际操作人和时钟。期间委托、任务转办、加签分别定义；完成 CH 不等于已批准或下游实施。 |
| Claim 与商业粒度 | 038–043、045、052–054、059–062、066、068 | 沿用 Claim／Parent／Parts／期间对象，先确定新增维度。多 Lever、多供应商、多年协议不能用一个文本字段掩盖各自金额和版本。 |
| 计算与财务口径 | 035、037、044、046–048、054、055、062、067、068 | 计算、分类、输入源及报告用同一受控版本。缺失的 £pu、Memo、Journal、付款或 FTO 规则需业务确认，不能由页面样例反推公式。 |
| 实施与异常恢复 | 036、049、058、065 | 复用任务和接口框架，确认责任与真实下游回执。超时先查原结果，部分成功按行处理，人工完成不得自动冒充外部成功。 |
| 沿用既有方案 | 001–034 | 仅引用已有交付作为依赖。029继续沿用POC方案，本轮不另设计，不修改旧包。 |

## 3. 逐项简表

| 需求 | 主要改动 | 建议优先级 | 页面 |
|---|---|---|
| NEO-035 ExWorks £m 与平均车 £pu：同口径展示和导出 | 应用内部修改 | P1；先完成口径决策 | [打开](CNP-235/pages/NEO-035.html) |
| NEO-036 异常处理责任与闭环规则 | 应用内部修改 | P0决策 / P1开发 | [打开](CNP-234/pages/NEO-036.html) |
| NEO-037 Memo实际汇率、过账状态与删除规则重核 | 应用内部修改 | P0决策和财务金样；随后开发 | [打开](CNP-235/pages/NEO-037.html) |
| NEO-038 Maturity / Likelihood 与 G Gate 对齐 | 应用内部修改 | P1 | [打开](CNP-231/pages/NEO-038.html) |
| NEO-039 币种变更自动计算起始价 | 应用内部修改 | P1 | [打开](CNP-231/pages/NEO-039.html) |
| NEO-040 按用途精简Runout、ATP及币种字段 | 应用内部修改 | P1 | [打开](CNP-231/pages/NEO-040.html) |
| NEO-041 同一零件单Claim支持多个Lever | 数据模型／架构调整 | P0决策 / P2开发 | [打开](CNP-231/pages/NEO-041.html) |
| NEO-042 AMM每Part支持超过3个Escalator | 应用＋集成 | P1 | [打开](CNP-231/pages/NEO-042.html) |
| NEO-043 精简CO2及创建校验 | 应用内部修改 | P2 | [打开](CNP-231/pages/NEO-043.html) |
| NEO-044 NEO ID粒度Journal、Reserve和POA证据一致 | 应用＋集成 | P0 | [打开](CNP-235/pages/NEO-044.html) |
| NEO-045 LSP财务组合自动派生及失败重试 | 应用＋集成 | P0 | [打开](CNP-231/pages/NEO-045.html) |
| NEO-046 Reporting Category单独决定Team及会计映射 | 数据模型／架构调整 | P0业务决策 / P1开发 | [打开](CNP-235/pages/NEO-046.html) |
| NEO-047 同一Reserve输出完整BS及IS会计分录 | 数据模型／架构调整 | P0 | [打开](CNP-235/pages/NEO-047.html) |
| NEO-048 自动SAP付款输入取代KSB1手工上传 | 应用＋集成 | P1；接口契约先行 | [打开](CNP-235/pages/NEO-048.html) |
| NEO-049 SAP ECC容器合同任务交接Digitide | 应用内部修改 | P1 | [打开](CNP-234/pages/NEO-049.html) |
| NEO-050 Clearing House完成、Request批准和实施状态分开 | 应用内部修改 | P0 | [打开](CNP-233/pages/NEO-050.html) |
| NEO-051 按有效期委托DoA并保留原审批人 | 应用内部修改 | P1 | [打开](CNP-233/pages/NEO-051.html) |
| NEO-052 Global Commodity Lead Area保留或移除决策 | 应用内部修改 | P0决策 / P2开发 | [打开](CNP-231/pages/NEO-052.html) |
| NEO-053 简化Inflation类型及条件字段 | 应用内部修改 | P2 | [打开](CNP-231/pages/NEO-053.html) |
| NEO-054 FTO / FFP数据准确性与缺口恢复 | 应用＋集成 | P0 | [打开](CNP-231/pages/NEO-054.html) |
| NEO-055 Buyer Forecast Download多财年筛选与Excel格式 | 应用内部修改 | P1（分析建议，源K/L未填） | [打开](CNP-235/pages/NEO-055.html) |
| NEO-056 按企业DoA生成必需审批，明确例外加签 | 应用内部修改 | P0 | [打开](CNP-233/pages/NEO-056.html) |
| NEO-057 开放任务状态、当前责任人与逾期提醒 | 应用＋集成 | P1 | [打开](CNP-233/pages/NEO-057.html) |
| NEO-058 已批准POA逐项实施、核对与恢复 | 应用＋集成 | P0 | [打开](CNP-234/pages/NEO-058.html) |
| NEO-059 混合涨跌价及相关GSDB的统一谈判视图 | 数据模型／架构调整 | P0决策 / P2开发 | [打开](CNP-231/pages/NEO-059.html) |
| NEO-060 复用Copy Claim并补齐复制边界 | 应用内部修改 | P1 | [打开](CNP-231/pages/NEO-060.html) |
| NEO-061 完善Parts搜索筛选及数据范围 | 应用内部修改 | P1 | [打开](CNP-231/pages/NEO-061.html) |
| NEO-062 价格差计算明细与缺失解释 | 应用内部修改 | P1 | [打开](CNP-231/pages/NEO-062.html) |
| NEO-063 按Before/After顺序增加必需审阅 | 应用内部修改 | P1 | [打开](CNP-233/pages/NEO-063.html) |
| NEO-064 单项审批转办与限时委派分开 | 应用内部修改 | P1 | [打开](CNP-233/pages/NEO-064.html) |
| NEO-065 CBSL案件协作、受理与进度追踪 | 应用内部修改 | P1 | [打开](CNP-234/pages/NEO-065.html) |
| NEO-066 大量Parts处理性能与可靠恢复 | 性能与可靠性 | P1 | [打开](CNP-231/pages/NEO-066.html) |
| NEO-067 Claim列表导出增加已批准字段 | 应用内部修改 | P1（分析建议，源K/L未填） | [打开](CNP-235/pages/NEO-067.html) |
| NEO-068 多年生产率协议与逐年履行 | 数据模型／架构调整 | P0决策 / P2开发 | [打开](CNP-231/pages/NEO-068.html) |

## 4. 来源和确认边界

主类按本轮方案影响单计；保留Epic原始细分。应用＋集成包括文件契约、既有接口核对/扩展与通知投递，不等于已确认新增API。仅有条件需要外部字段或实时来源时，暂归应用内部并保留待决。数据模型调整不等于需要新平台。

原始需求按 Requested Changes 的 E、P、Q及其他非空列逐项保留，精确原文在 SOURCE_CELLS_035_068.json。UC来源、直接／关联关系、待补场景及页面编号见各Epic的USE_CASE_MAP.md。新场景使用本包NEO编号别名，不创建官方UC、ACT或Jira记录。

业务问题集中在 [OPEN_QUESTIONS_CN.md](OPEN_QUESTIONS_CN.md)。优先级是建议，原Procurement／Finance优先级保存在详细记录中，未把空值补成Must。

查看 [简明Excel](NEO_035_068_Summary_CN.xlsx) 或 [交互总览](index.html)。各Epic原始证据及页面验证结果保留在各自目录。

## 5. 下一步

1. 先确认影响范围和数据模型的分歧，再排开发；已有可复用的页面或服务不重复造。
2. 业务Owner确认公式、角色、审批例外和主数据政策；系统Owner确认接口覆盖、结果回读与测试数据。
3. 以已确认方案拆分开发任务，复用既有ACT/FR/UC和唯一QA台账。通过本轮页面检查不代表已开发、已联调或已验收。