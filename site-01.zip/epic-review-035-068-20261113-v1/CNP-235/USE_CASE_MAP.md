# CNP-235 · UC 定位检查点

范围仅 NEO-035、037、044、046、047、048、055、067；不修改现有产品、QA 或 Jira。下列是分析映射，不是官方 UC/ACT 新编号。项目 neo-ba / neo-qa / neo-jira-story / jlr-frontend-ux 技能已读取。

依据：工作 BRD `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` 段落354–360 UC-23（完整财务期间）、361–367 UC-24（报表/审计）；原始 BRD V3.1 Table 6 各 FR；Training 原动作与现有 ACT 数据核验。

|需求|现有 ACT / FR|UC 关联判断|本地新场景别名及缺口|
|---|---|---|---|
|035|ACT-041/042/050；FR18、20.1、20.4|UC-24 相关，不直接覆盖平均车 £pu 新口径|NEO-035-S01 起：同版本 ExWorks 分子/分母、£m/£pu一致；FR18 明确移除旧 £pu 列，不能直接恢复|
|037|ACT-058/059/060；FR17关联|UC-23 直接覆盖调整流程；新规则需独立场景|NEO-037-S01 起：实际汇率、posting/reversal、删除、prepayment排除、base status规则；Training段落1550–1623|
|044|ACT-029/048/042；FR17.5、17.8、20.4，20.2仅相关|UC-23 直接覆盖Journal/Reserve对账；UC-24相关|NEO-044-S01 起：ID粒度、零差异、PPV/retro明细；不能将FR20.2交易数量报表当Reserve明细|
|046|ACT-035/028/029；FR17.2|UC-23相关；配置管理只是其前置条件|NEO-046-S01 起：Category-only映射与版本迁移；FR17.2原规则明确同时用Category/Lever|
|047|ACT-029/048；FR17/17.5，20.2仅相关|UC-23直接，UC-24相关|NEO-047-S01 起：一个ID多会计分录、动态账户列、IS总额与明细追踪|
|048|ACT-029/047；FR17.5/17.6|UC-22付款输入直接；UC-23期间流程直接|NEO-048-S01 起：自动SAP输入取代文件、幂等与冲销。工作BRD Table24 Row27 IF26是人工上传，不是现成API|
|055|ACT-041仅相关；**FR20.5直接**，FR20.1相关|UC-24直接覆盖过滤导出；需Buyer Forecast独立场景|NEO-055-S01 起：多FY、过滤后全量Excel与字段格式；输入映射漏了FR20.5，已纠正|
|067|ACT-041仅相关；FR20.1相关；Claim列表字段未明确|UC-24直接覆盖导出一致性|NEO-067-S01 起：字段清单/列权限/粒度/版本；不是默认所有字段都能导出|

关键修正：055直接FR是20.5；044补充FR17.8；048补UC-22。035、046均存在明确旧BRD与新需求差异。产品、接口、UAT全部NOT RUN。

## 页面编号边界

本评估P6.1 Finance Claims、P6.5 Buyer Forecast等沿用canonical QA `review-data.json`的用户127项清单（PAGE-P6.1、PAGE-P6.5、PAGE-P7.3、PAGE-P1.1.26）作为历史别名。它与143页表的P6.1 Calculations、Before编号或代码内P6.1.1不是统一编号体系。currentPages的code source单列为当前观察锚点；不从组件文件推断官方编号或route。

## 当前代码能力复用补充

- 055：`views/Reporting/Special.tsx` 的 `buyer-forecast` 已有多FY、Generate、Download；`domain/features/report-exports/reports.ts` 的 forecastRows 为15列，只按FY过滤。重点是扩充确定字段/筛选和独立权限，不重建已有入口。
- 067：`views/WorkQueue/index.tsx` 已有Download Claims / Manage Columns / Show More Details；`queue-fields.ts` 共23列，默认18列；`useWorkQueue.ts` 按授权筛选全量rows与选择列导出。目标列仍未给，先做字段差异，已有列可能无需开发。
- 046与已评[NEO-034](../../solution-review/NEO-034/NEO-034_Consolidated_CN.md)的关系：034判定Category/Lever是否合法；046推导Team。两者职责独立，不能因为Team改为Category-only就取消034。
