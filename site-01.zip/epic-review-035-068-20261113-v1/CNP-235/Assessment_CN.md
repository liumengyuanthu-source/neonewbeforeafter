# CNP-235 财务与连续性 · NEO-035–068独立评估

本目录覆盖8项：035、037、044、046、047、048、055、067。未重评001–034。全部页面为独立设计和合成数据，不改变现有NEO；源条款、代码观察、建议方案与业务待定分开记录。产品、接口和UAT测试全部NOT RUN。源Q列这8项均为空，已逐项保留；R原值不解释为实施授权。

使用项目neo-ba、neo-qa、neo-jira-story、jlr-frontend-ux技能；引用既有QA模型而不创建第二套执行结果表。财务会计公式、FX、SAP模板不得由页面示例推定。

关键定位修正：055直接对应FR20.5/P6.5；044补FR17.8；048补UC-22。页面P编号沿用canonical QA用户127项清单的历史别名；不与143页表或Before编号混用。当前产品观察以独立code source为锚点。源文与当前代码的观察范围不同，旧QA的缺页描述不能覆盖后来已有的本地页面。


## NEO-035 ExWorks £m 与平均车 £pu：同口径展示和导出

**源行 36 · Both**；采购优先级=Could；Finance=Should。建议：P1；先完成口径决策。源优先级采购Could、财务Should；跨报表一致性重要，但未经批准的分母/范围不可先上线。先冻结金样和契约，避免重复开发。

原文：
> Embed ex works and £pu reporting within system
> Allow users to see an ex works average car £pu within the ID screens in NEO; and include this as part of the NEO exports for inclusion in ex works. 
> 
> This will allow new logic and coding with the new system.

目标P：Users of NEO need to be able to see £pu value alongside £m value within NEO when reviewing an ID. The £pu needs to be calculated on the same basis as Ex works so that users can immediately see within NEO the numbers for their IDs that will be reported in Ex works.；Q：未填。M现状：Disconnects between NEO & Tableau reporting。

**用户问题。** 用户在NEO看£m，在ExWorks看£pu，无法直接解释同一个ID的差异；M列明确NEO与Tableau存在断点。

**UC定位。** UC-24 related — 现有报表UC未定义ExWorks平均车£pu公式/同版本比较。ACT：ACT-041, ACT-042, ACT-050；FR：FR18, FR20.1, FR20.4。

**当前基线（源码观察）。** 当前reporting.ts是Request投影，明确不等于Reserve或Claim影响总额；claim-reporting.ts按Line保存的年度Forecast汇总。AutoPam.tsx提供历史文件列表和下载权限，非正式PAM计算。字典有CARLINE_PART_VOLUME、FISCAL_YEAR_CARLINE_VOLUME、FTO百分比和GBP字段，但没有签字批准的平均车£pu公式。NQA-131仅承认本地历史样例；F1021-21仍保留正式公式/输出/GCP缺口。

**建议方案。** 在ID的Finance/Reporting区域并列显示£m和£pu，带同一期间、范围与口径版本；提供Version comparison与缺数状态。后端以版本化报告快照产出两种单位，页面和导出引用同一快照。先由ExWorks/Finance负责人确定算法与分母，再决定本地计算还是消费批准结果。禁止把原FR18明确删除的5个旧字段直接恢复。

**主要类型。** 应用修改 + 计算契约；新增集成有条件。

- ux：ID Finance区域同时展示£m/£pu；期间、scope、版本、缺失原因可追溯；比较旧/新快照并标注差异。
- frontend：共用报告读模型；金额十进制格式化，单位明确；缺/零分母显示—；导出按选择版本而非临时重算。
- backend：版本化ExWorks计算/结果适配服务；校验分子、分母单位、scope和asOf一致；拒绝未批准算法或不完整源。
- data：保存numeratorGBP、denominatorVehicles、period、carline/scope、sourceVersion、ruleVersion、roundingPolicy、comparisonVersion及完整性状态。
- workflow：Finance批准口径后才可激活；修订生成新快照不覆盖历史；生成、交付、下游接受分开记录。

**集成与契约。** needed：待数据可得性决策；不能直接认定已有接口；systems：NEO、ExWorks / Finance dataset、GCP / EDW候选；provider：ExWorks官方结果/车辆分母提供方未确定；Finance负责口径，IT确认源系统。；direction：候选A：NEO本地计算→页面/导出；候选B：批准结果或车辆分母→NEO；原Qlik为NEO→EDW。；reuse：现有FTO/Line版本与导出权限可复用；MFT E2SC零件预测不能自动作为车辆分母，Qlik输出不能冒充ExWorks输入。；evidence：CSV row24 ID18为GCP Data Lake→Appian的part forecast；row29 ID25 Qlik为Appian→EDW；Scheduler row19日17:00生成。；unknown：Appendix L/M实际逻辑与输出文件缺失；车辆范围、加权/加总算法、取消/负数/FX/舍入规则、时区与正式provider待定。。

**架构判断。** 先形成独立版本化报告读模型和decimal计算边界；通过金样判断是否能复用现有数据，本轮不指定新平台。日17:00调度与3天process删除是源事实；FR18/Training 7天文件留存是另一规则，分别设计。

**复用。** Line权限、已有Forecast/GBP值、FTO候选、报表快照与导出组件；不能复用未提供公式或把历史文件列表视为已完成计算。

**性能验证计划。** 在确认真实数据量、授权范围、并发和部署环境后测查询/导出延迟、内存、分页与取消；比较完整授权集合与输出校验和，不为演示修改金额或略过错误。本轮仅测合成页面浏览器几何/交互，没有生产性能结论。

**依赖。** Finance/ExWorks批准的分子分母金样与Appendix L/M/N；NEO-055/067导出schema可共用；独立验收各报表；既有QA：NQA-131、F1021-21、F1021-28。

[业务页面](pages/NEO-035.html) · [桌面截图](screenshots/NEO-035-desktop.png) · [窄屏截图](screenshots/NEO-035-narrow.png) · [异常状态](screenshots/NEO-035-exception.png)

**待确认问题。**

- **NEO-035-Q1 ExWorks平均车£pu究竟按哪一个金额除以哪一批车？** 背景：现有字典同时有零件量与车辆量，公式未定。 例：£m=1.20；用60,000辆为£20，用零件120,000件为£10，两个结果不能任选。 责任：Finance / ExWorks owner。影响：决定公式、数据来源及接口。
- **NEO-035-Q2 新£pu是新增指标，还是要取代曾删除的旧PAM列？** 背景：FR18明确允许删除5列£pu；新需求与旧范围不同。 例：Avg_Car_PU_Impact是否仍不输出，只新增批准的ExWorksAverageCarGBP？ 责任：Finance / Reporting BA。影响：确定字段与兼容策略。
- **NEO-035-Q3 哪个团队提供可对账的数据版本，缺数或更新后如何发布？** 背景：E2SC与Qlik方向不能证明已有ExWorks输入。 例：10月v1与v2金额相同、车辆量变化，用户应能看到两个版本差异。 责任：Finance data owner / Integration lead。影响：决定provider、截止时间和重跑规则。

**可评审验收场景（全部未执行产品测试）。**

- **NEO-035-S01** 角色：Finance analyst；前置：批准的示例口径仅用于测试，GBP1,200,000及60,000辆均属FY26/27同范围；输入：`Numerator=1200000; vehicles=60000; rule=EW-test-v1; source=v1`；操作：打开NEO-L-00035 → 选择FY26/27 v1 → 下载该版本；预期：£m1.20、£pu20.00；页面与导出同一scope/版本；正式期望需Finance签署。；actual=null；NOT RUN。
- **NEO-035-S02** 角色：Finance analyst；前置：同一金样但分母不可用；输入：`vehicles=null，然后vehicles=0`；操作：刷新 → 请求导出；预期：两种情况£pu均为—，明确缺失/零分母；不得输出0或Infinity，缺数标识随导出。；actual=null；NOT RUN。
- **NEO-035-S03** 角色：Finance analyst；前置：保留v1、源v2车辆改为50000；输入：`v1=60000; v2=50000; numerator=1200000`；操作：比较v1/v2 → 再开v1；预期：示例v2 £pu24.00、差额+4.00；旧v1仍20.00，不能暗改历史。；actual=null；NOT RUN。
- **NEO-035-S04** 角色：Unauthorised Buyer；前置：没有该Line数据权限；输入：`NEO-L-00035`；操作：直接请求快照和下载；预期：服务端拒绝，页面/缓存/文件均不泄露数据。；actual=null；NOT RUN。
- **NEO-035-S05** 角色：Report operator；前置：下游发送失败且v1已生成；输入：`delivery=timeout; snapshot=v1`；操作：重试交付两次；预期：保留同一个快照和可审计重试；无重复下游记录，不把生成成功记为GCP接受。；actual=null；NOT RUN。

**来源与简短原句。**（完整摘录/哈希见SOURCE_REGISTER.json）

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` · RTM for Requested Changes A36:R36：{"A": "NEO-035", "B": "Both", "C": "Reporting", "D": "New functionality", "E": "Embed ex works and £pu reporting within system\nAllow users to see an ex works average car £pu within the ID s
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` · Paragraphs 361–367：UC-24 Use reports and audit evidence Actor and precondition. Buyer, Finance, BI and audit. Authorised datasets and report scope are defined. Trigger. An authorised user requests a report exp
- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` · Table 6 Row 51：FR18 | Forecast Reporting Calculations and Output | The application should have a function whereby it is able to provide regular reports (once per day) as an extract to GCP. The solution sho
- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` · Paragraphs 350–367：Appendix H – Report Extract FInd finance extract 13-09.xlsx Appendix I – Approval Hierarchy based on CoC Purchasing Hierachy.xlsx Appendix J – NAF Pin Report Example PIN 22.09.2023 TVM.xlsx 
- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` · 字段字典 rows 2089–2102：2089: MCI_STG_AUTO_PAM_REPORT | 集成暂存 | 暂存 | CARLINE | varchar(50) | varchar(50) | 是 |  |  |  |  |  | 否 |  | 结构 2090: MCI_STG_AUTO_PAM_REPORT | 集成暂存 | 暂存 | CARLINE_PART_VOLUME | decimal(19,10
- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` · CSV physical row 24; ID 18：18 | MFT E2SC | SFTP integration from Appian to BODS system to fetch E2SC csv data files present in zip folder. | Material Cost & Inventory | Other | GCP Data Lake | Appian | BODS | NA | MFT
- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` · CSV physical row 29; ID 25：25 | Qlik Replication | Replicates Autopam Appian MariaDB tables into EDW | Material Cost & Inventory | Other | Appian | EDW | NA | NA | NA | NA | NA | '- | NA | NA | NA | NA | NA | 0 | Targ
- `6.技术方案/2 - Tech NEO/Scheduler Processes - 2026-11-09_0944.xlsx` · Sheet 1 row 19：1.0 | Auto Pam Scheduler | Generates a database financial report useful for checking daily balances | Material Cost & Inventory | MCI Generate Auto PAM Report Scheduler | 17:00 | Daily | 40 
- `6.技术方案/2 - Tech NEO/NEO User Training.docx` · Paragraphs 1925–1929：Auto PAM Report Note: Managed by member of any user group apart from a buyer. Once a PAM file has been and it has been sent to GCP, Appian will contain a grid within the reports section of t
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p05/reporting.ts` · Lines 59–77：    const rows=readable.map((r):ReportRow=>{         const values=r.values,hasRecorded=values!==undefined;         const valid=values&&[values.doaBasisGbp,values.risksGbp,values.opportunitie
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p05/claim-reporting.ts` · Lines 19–22：export const claimReportPhases=['Forecast','In Approval','Returned to Buyer','Awaiting Implementation','Implemented','Status unavailable'] as const; export type ClaimImpactRow={claimId:strin
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Reporting/AutoPam.tsx` · Lines 1–7：import {Button,Card,Tooltip} from 'antd'; import {InfoCircleOutlined} from '@ant-design/icons'; import {DataTable} from '../../components/DataTable';import {PageState} from '../../components
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` · feedback[id=NQA-131]：{"id": "NQA-131", "summary": "Auto PAM Report按Training两列7条历史样例补齐；7天归档与正式计算列为开发待验", "scope": "offline Auto PAM Training report display; formal financial export and GCP lifecycle deferred", "n
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` · issues[id=F1021-21]：{"id": "F1021-21", "status": "BLOCKED_REFERENCE", "problem": "AutoPAM 的独立 P20.5 文件生命周期、定时产出、留存与实际 GCP 回执未实现。保留 Appendix L/M/N、实际文件样本、Phase 2 范围与 GCP 契约缺口。\nNQA-131：专用Auto PAM页面、两列7条历史样例、非Buy
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=41]：User can review Finance Claim Report metrics, filter by CoC and drill into the results.  User story As an FBP or FA user, I want to review the reported risks, opportunities, benefits and cos
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=42]：User can export POA part-level price changes and their financial impact.  User story As a GFS user, I want to export the part-level price changes and their financial impact, so that the part
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=50]：User can access the available Auto PAM report files.  User story As an authorised PAM-report user, I want to view the available Auto PAM files, so that the available Auto PAM output can be a
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` · rows[audit_id=PAGE-P6.1] (127-page registry alias)：P6.1 Finance Claims／Opportunities vs Risks Summary | 用户127项页面清单；原FR定位按原文保留：FR20.1：提供风险／机会及 Finance Claims 汇总报表。  Training：Finance Claim Report（¶1821）。
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` · rows[audit_id=PAGE-P6.7] (127-page registry alias)：P6.7 Auto PAM Report／文件发送历史 | 用户127项页面清单；原FR定位按原文保留：FR18：每日向 GCP 输出汇总／明细，保留一周发送记录与触发的计算规则。  Training：Auto PAM（¶1924）。  输出计算及定时传送属于后台／接口需求，页面映射不代表已联通。 本轮Before/技术字段核对：P20.5；FR18；Training ¶192

## NEO-037 Memo实际汇率、过账状态与删除规则重核

**源行 38 · Finance**；采购优先级=未填；Finance=Must。建议：P0决策和财务金样；随后开发。Finance Must；错误汇率、已过账删除或重复计入直接影响账务与月结，先确认规则再改。

原文：
> Memo reserve functionality needs to be reviewed and revalidated.
> Detailed technical requirements need to be validated with Helen & Linda.

目标P：HJONES20/DMSITH69
- exchange rate corrected to actual rate
-be clear whether memos are posted or not
- treatment of deleted memos
- no prepayment balance sheet entries in the memos report
- do we want to review whether memo should still look at the base reserves status / likelihood?；Q：未填。M现状：未填。

**用户问题。** Memo的金额、过账与删除含义不清，预付款在Memo报告出现造成财务处理与Reserve报告断开。

**UC定位。** UC-23 direct — Memo具体FX、删除、posting与基准reserve依赖需新场景。ACT：ACT-058, ACT-059, ACT-060；FR：FR17, FR17.5, FR17.8。

**当前基线（源码观察）。** Training允许GFS创建、GFS Manager编辑Draft、Finance只读。当前memos.ts有Draft/Confirmed、版本/历史和幂等保存；字段仍叫Budget Exchange Rate，类型包括Prepayment Long/Short Term；Confirmed不是SAP Posted。F1021-17明确后续月份金额和正式财务语义待确认。

**建议方案。** 将Memo生命周期与posting状态分开显示：Draft/Confirmed与Not posted/Posted/Reversed分别建模；使用带日期和来源的Actual FX快照。未过账作废与已过账冲销使用不同授权动作，保留旧记录；预付款会计分录转入统一Reserve输出，Memo报表不重复列入。Base reserve status/likelihood规则先待Helen/Linda确认，不能自行取消。

**主要类型。** 应用内部前后端/数据/流程 + 已有过账证据边界。

- ux：表格列出Memo状态、posting状态、actual FX日期、金额及历史；已过账只允许查看/授权冲销，不提供Delete。
- frontend：Actual FX缺失时阻止金额确认；保留草稿输入；区分Void draft和Request reversal；预付款不出现在Memo会计报告。
- backend：FX来源/精度校验，状态机与独立posting reference；并发版本检查；服务端拒绝更新已过账内容。
- data：新增或明确actualFxRate/source/effectiveDate、postingState/reference、void/reversal linkage、baseReserveSnapshot；不把Confirmed转义成Posted。
- workflow：GFS创建、Manager Draft编辑、Finance只读沿用Training；冲销责任/审批待确认；期间关闭后修订必须另建调整。

**集成与契约。** needed：核心为应用内部；若自动读过账凭据则需确认既有SAP契约；systems：NEO、Actual FX source待确认、SAP posting evidence按需要；provider：Finance确定actual FX权威源及凭据核对责任；direction：批准FX/真实posting receipt→NEO；本轮不增加自动过账；reuse：现有版本、history、Draft门禁可复用；Budget字段和Confirmed状态不能替代actual FX和posting。；evidence：Training ¶1597 Draft edit、¶1617 Finance read only；memos.ts typed budgetExchangeRate / memoStatus。；unknown：actual FX类型/日期、删除冲销及是否继续依赖base likelihood未签署。。

**架构判断。** Memo作为独立调整记录关联冻结Reserve；posting evidence独立模型；使用不可覆盖历史/冲销链接，保留既有离线代码的并发模式，正式DB需另验。

**复用。** Create/View/Edit页面、最新Reserve上下文快照、草稿权限、decimal19_5和历史/intent guard。

**性能验证计划。** 在确认真实数据量、授权范围、并发和部署环境后测查询/导出延迟、内存、分页与取消；比较完整授权集合与输出校验和，不为演示修改金额或略过错误。本轮仅测合成页面浏览器几何/交互，没有生产性能结论。

**依赖。** Helen/Linda明确actual FX与base status/likelihood规则；NEO-047预付款归属；NEO-044Journal对账；既有QA：NQA-116/117、F1021-14/17。

[业务页面](pages/NEO-037.html) · [桌面截图](screenshots/NEO-037-desktop.png) · [窄屏截图](screenshots/NEO-037-narrow.png) · [异常状态](screenshots/NEO-037-exception.png)

**待确认问题。**

- **NEO-037-Q1 Memo使用哪一天、哪一类实际汇率，关闭月份能否重算？** 背景：当前字段仍是预算汇率，Requested Changes要求actual。 例：EUR100,000，预算0.85、实际0.86，使用哪一个日期的0.86？ 责任：Helen / Linda / Finance。影响：决定金额与历史冻结。
- **NEO-037-Q2 已过账Memo应由谁冲销，未过账Memo可否作废？** 背景：删除不能抹去凭据；Confirmed不证明已过账。 例：Memo M-037已在SAP有凭据，再发现重复，应关联反向分录还是次月调整？ 责任：Finance control / SAP owner。影响：决定状态和权限。
- **NEO-037-Q3 Memo是否仍跟随原Reserve的status或likelihood？** 背景：P列明确以问题形式提出，未确认取消。 例：原Reserve改为Closed后，独立Memo要保留、释放还是提示复核？ 责任：Helen / Linda。影响：决定金额触发与历史行为。

**可评审验收场景（全部未执行产品测试）。**

- **NEO-037-S01** 角色：GFS Manager；前置：经批准测试FX是EUR→GBP0.86；10月未关闭；输入：`EUR100000; actualFx=0.86; budgetFx=0.85`；操作：创建Draft → 保存并重新打开；预期：GBP86,000按批准方向计算；actual FX日期/来源保留，不能用85,000。；actual=null；NOT RUN。
- **NEO-037-S02** 角色：GFS Manager；前置：实际汇率缺失；输入：`EUR100000; actualFx=null`；操作：确认Memo；预期：阻止确认，显示缺少actual FX；输入100000保留。；actual=null；NOT RUN。
- **NEO-037-S03** 角色：Finance reader；前置：Memo Draft v1；输入：`amount=100000`；操作：尝试Edit及直接提交API；预期：只读；服务端拒绝，金额和版本不变。；actual=null；NOT RUN。
- **NEO-037-S04** 角色：GFS Manager；前置：Memo有真实posted receipt P-037；输入：`action=delete`；操作：请求删除 → 选择授权冲销路径；预期：拒绝删除，原凭据保留；按签署冲销规则创建关联反向记录，不自动宣称SAP完成。；actual=null；NOT RUN。
- **NEO-037-S05** 角色：GFS Manager；前置：两人从v1编辑同一Draft；输入：`A金额100000; B金额110000`；操作：A保存 → B以v1保存；预期：B收到版本冲突且输入保留；不得覆盖A。；actual=null；NOT RUN。
- **NEO-037-S06** 角色：Finance analyst；前置：同期间存在预付款分录与普通Memo；输入：`ST Prepayment=20000; Accrual memo=5000`；操作：导出Memo和Reserve；预期：Memo排除该预付款；Reserve包括20,000；两份输出不得重计，具体符号依批准金样。；actual=null；NOT RUN。

**来源与简短原句。**（完整摘录/哈希见SOURCE_REGISTER.json）

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` · RTM for Requested Changes A38:R38：{"A": "NEO-037", "B": "Finance", "C": "Finance Reserves", "D": "Existing functionality - Update/correct logic", "E": "Memo reserve functionality needs to be reviewed and revalidated.\nDetail
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` · Paragraphs 354–360：UC-23 Run a complete financial period Actor and precondition. MCA and FBP. Approved formulas, sources, working day calendar and cutoffs exist. Trigger. The confirmed financial calendar opens
- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` · Table 6 Row 47：FR17.5 | Actual Reserves – Generating new reserves | Business Context: Equivalent of the green reserves tab used on the NCR Reserve Excel Once a user has generated a new overall reserve line
- `6.技术方案/2 - Tech NEO/NEO User Training.docx` · Paragraphs 1550–1617：Create Memo Note: Managed by members from GFS group only. Gives Ability to GFS Users to add memo lines into the solution. Create Memo from “Reserve”: Once all mandatory data is added in crea
- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` · 字段字典 rows 1433–1444：1433: MCI_RESERVE_RISK_OPPORTUNITY_MEMO | 准备金与收货 | 业务 | RESERVE_RISK_OPPORTUNITY_MEMO_ID | int(11) | integer | 否 |  | PK |  |  |  | 否 | Primary key of the table. This table holds information
- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` · 字段字典 rows 1462–1471：1462: MCI_RESERVE_RISK_OPPORTUNITY_MEMO | 准备金与收货 | 业务 | VENDOR_EXCHANGE_RATE | decimal(19,5) | numeric(19,5) | 是 |  |  |  |  |  | 否 | vendor_exchange_rate | 结构+字典 1463: MCI_RESERVE_RISK_OPPO
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/features/reserve-views/memos.ts` · Lines 13–42：export type MemoDetails = {supplierClaimType:string;transactionType:string;transactionBreakdown:string;vendorCode:string;vendorName:string;team:string;incomeStatementAccount:string;effective
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` · issues[id=F1021-17]：{"id": "F1021-17", "status": "PARTIAL_IMPLEMENTATION", "problem": "Create Memo已恢复Training字段和双入口，已验GFS、保存刷新、5位金额及全部可编辑字段。业务待澄清：取消“仅当前月”后，各已选月份的金额如何确定？待确认初始 Reserve Value、Increment 与月份间的关系，以及跳
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=58]：GFS can add Memo lines for the applicable Reserve Month-Year.  User story As a GFS user, I want to add a Memo line for the applicable Reserve period, so that manual Memo information can be r
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=59]：GFS/Finance users can view existing Reserve Memo lines.  User story As a GFS or Finance user, I want to view a Reserve Memo and its details, so that differences between generated Reserves an
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=60]：The authorised GFS editor can update a Memo while it is in Draft status.  User story As an authorised GFS editor, I want to edit a Memo while its status is Draft, so that the Draft Memo can 

## NEO-044 NEO ID粒度Journal、Reserve和POA证据一致

**源行 45 · Finance**；采购优先级=未填；Finance=Must。建议：P0。Finance Must；目前人工重排与总额不一致是月结控制风险。需先锁定SAP模板及对账金样。

原文：
> NEO reserves journal template to output at NEO ID level rather than account/cost centre level in a format suitable for upload into SAP using the mass upload transaction.
> The NEO Reserves reports must match the journal output template at a total level, there should be no differencein value between the reserves report and the journal upload template.
> If an adjustment is required, it should be visible in the Reserves report.
> POA Part level detail report for the month should provide the backup to the POA reserves for that month, the current month PPVs and the retros.

目标P：As a finance user, I want to be able to download the reserves reports and SAP upload template which all match and do not require further manipulation of the data.；Q：未填。M现状：We have to manually in excel extract the reserve data and generate the reserves SAP uploads by NEO ID. NEO should output the reserves at the correct level. There are mismatches between the reserves and the reserves report which are not called out on the reserves report creating confusion for business users.。

**用户问题。** 用户手工在Excel按NEO ID重做SAP上传文件，并无法在Reserve报表找到所有调整和差异。

**UC定位。** UC-23 direct — ID粒度、统一版本与三份输出零差异需专测；UC-24 related — 下载/审计关联。ACT：ACT-029, ACT-048, ACT-042；FR：FR17.5, FR17.8, FR20.4, FR20.2。

**当前基线（源码观察）。** FR17.8已有Final Reserve→Journal模板要求；FR17.5要求GR/价格数据快照。当前JournalLine含neo/lineId/account/company/debit/credit，Journal包记录Final版本、mapping/template、predecessor与模拟回执；当前正式模板缺失。FR20.2是月末交易数量/状态报表，不等于Reserve报告。

**建议方案。** 从同一个冻结Final和会计分录集合派生Reserve、Journal与POA证据包。Journal保留NEO ID而非仅汇总account/cost centre；同一ID可以多条借贷分录，Reserve宽表一个ID一行。显示对账差额与调整引用，差额未解释/不为零禁止正式下载。SAP仍按批准mass upload文件交接，上传/park/post分开。

**主要类型。** 应用修改 + SAP文件契约；不默认自动API。

- ux：版本选择、报告/Journal对账矩阵、未解释差异和调整入口；下载包前看到同一Final版本。
- frontend：按ID展示Reserve和journal totals；POA Part/Plant/月/PPV/retro展开；失配时禁用正式模板下载。
- backend：统一decimal会计读模型生成三个文件；验证每币种借贷、NEO ID覆盖、调整关联和template checksum；锁定Final源版本。
- data：NEO ID→多会计line、Part×Plant×period支持明细、adjustmentId、mapping/template/source versions；保留account/cost centre为字符串。
- workflow：生成Draft→review→Final→对账→下载→SAP park/post实际回执；模板替换或源变化重评，已Final不覆盖。

**集成与契约。** needed：SAP mass upload文件必需；自动posting接口未要求；systems：NEO、SAP FI；provider：SAP Finance提供实际mass upload模板、事务约束与错误文件样例；direction：NEO→经授权用户上传SAP；SAP真实上传/park/post结果→对账记录；reuse：现有JournalLine及snapshot guard可复用，但当前illustrative mapping/templates不能用作正式格式。；evidence：FR17.8 Appendix K；源row45要求mass upload及total match；journal.ts包含lineId与finalVersion。；unknown：SAP列序、凭证粒度、字符限制、借贷符号、零值/舍入、跨公司与cost centre规则、部分失败反馈。。

**架构判断。** 统一会计事实表+版本化报告投影；Journal长表、Reserve宽表共享sourceEntryId，不从格式化Excel再反推会计。保留文件边界，自动过账另立范围。

**复用。** 现有Final来源与版本、JournalLine、currency controls、receipt区分、导出权限校验；POA报表当前18列只是临时模板。

**性能验证计划。** 在确认真实数据量、授权范围、并发和部署环境后测查询/导出延迟、内存、分页与取消；比较完整授权集合与输出校验和，不为演示修改金额或略过错误。本轮仅测合成页面浏览器几何/交互，没有生产性能结论。

**依赖。** NEO-047统一BS分录、NEO-037Memo调整、NEO-048付款完整性；SAP批准Appendix K模板及Appendix J金样；既有QA：F1021-14/17/28。

[业务页面](pages/NEO-044.html) · [桌面截图](screenshots/NEO-044-desktop.png) · [窄屏截图](screenshots/NEO-044-narrow.png) · [异常状态](screenshots/NEO-044-exception.png)

**待确认问题。**

- **NEO-044-Q1 SAP mass upload每一行需要哪些列、哪个NEO ID字段和格式？** 背景：源要求ID粒度但未提供SAP模板。 例：同一NEO ID有Accrual与ST Prepayment，是否生成两组借贷、ID放Assignment还是Reference？ 责任：SAP FI owner / Finance。影响：决定输出schema和粒度。
- **NEO-044-Q2 哪些调整必须进入Final，哪些只能出现在后续调整版？** 背景：要实现Report与Journal总额一致必须定义cutoff。 例：Final v3后补£250，更新为v4还是独立postclose journal？ 责任：Finance close owner。影响：决定冻结/继承规则。
- **NEO-044-Q3 POA本月PPV与retro按哪个日期和版本归属？** 背景：不能用Current Month总额替代PPV/retro证据。 例：11月收货但追溯到9月生效的价格，归入哪一期？ 责任：POA Finance / SAP data owner。影响：决定明细计算与对账。

**可评审验收场景（全部未执行产品测试）。**

- **NEO-044-S01** 角色：MCA；前置：已批准测试分录与SAP模板，冻结October Final v3；输入：`NEO-L-00044: Reserve=120000; adjustment=250; final=120250 GBP`；操作：生成三份输出 → 核对ID/币种/版本；预期：Reserve=Journal金额120250；调整250可见；借贷各120250；POA细项按批准金样一致。；actual=null；NOT RUN。
- **NEO-044-S02** 角色：MCA；前置：同一Final但Journal漏掉£250；输入：`report=120250; journal=120000`；操作：执行Reconcile；预期：差额250明确；正式模板下载被阻止，不自动塞入平衡差额。；actual=null；NOT RUN。
- **NEO-044-S03** 角色：Finance reader；前置：只有查看权限；输入：`October Final v3`；操作：尝试生成或修改Journal API；预期：拒绝写；允许授权查看/下载范围需由角色矩阵确认。；actual=null；NOT RUN。
- **NEO-044-S04** 角色：MCA；前置：下载准备过程中Final v4产生；输入：`selectedFinal=v3; current=v4`；操作：保持v3下载 → 改选v4；预期：v3下载仍含v3或明确要求重新选择，不能混入v4；重新选择后全包统一。；actual=null；NOT RUN。
- **NEO-044-S05** 角色：Finance operator；前置：SAP回报其中一条拒绝；输入：`batch=J-044; rejected line=2`；操作：登记实际错误回执 → 修复后重试；预期：未接受行保持待处理；不宣称全部posted；同已成功行不重复上传。；actual=null；NOT RUN。

**来源与简短原句。**（完整摘录/哈希见SOURCE_REGISTER.json）

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` · RTM for Requested Changes A45:R45：{"A": "NEO-044", "B": "Finance", "C": "Finance Reserves", "D": "Existing functionality - Update UX / Workflow", "E": "NEO reserves journal template to output at NEO ID level rather than acco
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` · Paragraphs 354–360：UC-23 Run a complete financial period Actor and precondition. MCA and FBP. Approved formulas, sources, working day calendar and cutoffs exist. Trigger. The confirmed financial calendar opens
- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` · Table 6 Row 47：FR17.5 | Actual Reserves – Generating new reserves | Business Context: Equivalent of the green reserves tab used on the NCR Reserve Excel Once a user has generated a new overall reserve line
- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` · Table 6 Row 50：FR17.8 | Journal Template | The application, based on the final reserves being generated, should have an option for a GFS user to create a Journal template based on the reserve information l
- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` · Table 6 Row 69：FR20.2 | Report – End of Month Report | The solution should allow FBP, Purchasing and GFS users to view the “End of Month Transaction Report”, which has the following format:  Month – Year N
- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` · Table 6 Row 71：FR20.4 | Report – NAF Pin Report POA Part Level Detail Report | Within the report section, GFS and FBP users should have the ability to export a report called “PIN Report” to excel.  When se
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p05/journal.ts` · Lines 11–21：export type JournalLine = {     neo: string;     lineId: string;     account: string;     company: string;     currency: string;     debit: string;     credit: string;     postingDate: strin
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p05/journal.ts` · Lines 47–79：export type JournalPackage = {     id: string;     revision: number;     periodId: string;     finalVersion: number;     mappingVersion: string;     templateVersion: string;     sourceManife
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Journal/index.tsx` · Lines 20–36：  if (!financeAccess(authority)) return <PageState status="403" title="No Journal access for your role." />;   const periods = store.readPeriods(authority).filter((p) => p.state === 'final')
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` · issues[id=F1021-28]：{"id": "F1021-28", "status": "BLOCKED_REFERENCE", "problem": "Part Level与92列Buyer Forecast Appendix H/J未定位，不能由截图恢复全部字段公式。\nNQA-128：NAF Pin生成页、5个筛选/勾选字段和18列临时Excel本地通过；正式Appendix J未取得，当前Reser
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=29]：User can generate a Reserve by selecting a date and Reserve type.  User story As an authorised Reserve user, I want to generate a monthly Reserve for a selected date and type, so that the mo
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=42]：User can export POA part-level price changes and their financial impact.  User story As a GFS user, I want to export the part-level price changes and their financial impact, so that the part
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=48]：User can review month-end snapshots and month-to-date results.  User story As an authorised Finance or Purchasing user, I want to review the month-end reporting snapshots, so that the select
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` · rows[audit_id=PAGE-P6.4] (127-page registry alias)：P6.4 POA Part Level Detail Report，保留历史别名 NAF Pin Report | 用户127项页面清单；原FR定位按原文保留：FR20.4：按财年导出零件及月度收货／价格变动，历史标题 NAF Pin 已修订。  Training：NAF Pin Report（¶1845）。  FR20.4 旧标题有删除线；不重复计作两份报表。 本轮Befor

## NEO-046 Reporting Category单独决定Team及会计映射

**源行 47 · Finance**；采购优先级=未填；Finance=Must。建议：P0业务决策 / P1开发。Finance Must但原文是Can we及Detail to be added；必须先批准Category拆分与迁移，避免影响Reserve和PO。

原文：
> Can we simplify so that only reporting category determines Team (which determines accounting) rather than combination of reporting category and lever? - would require splitting Contracted Raw Materials reporting Category into RMA, AMM and PGM.

目标P：Detail to be added HJONES20；Q：未填。M现状：Causes confusion and complexity with business users and errors in both the reserves and the POs raised。

**用户问题。** Reporting Category加Lever组合复杂，源M列指出Reserve与PO发生错误。

**UC定位。** UC-23 related — 分类配置是月结前置，不是UC-23完整覆盖；需Category-only迁移场景。ACT：ACT-035, ACT-028, ACT-029；FR：FR17.2, FR17.5, FR19.07。

**当前基线（源码观察）。** FR17.2明确按Category+Lever映射Team和IS account/cost centre；当前TeamMappingRow仍含lever，seed里Contracted Raw Materials用于AMM/RMA/PGM三组。现有提交有revision/duplicate/noop/history。Requested Change希望拆分这一个类别，不能只隐藏Lever。

**建议方案。** 经批准后定义Category唯一映射Team、IS account/cost centre及include规则；把Contracted Raw Materials迁移到RMA/AMM/PGM明确类别。保留Lever为业务属性但不参与新规则。配置先预览受影响活动Claims与会计输出，再按生效日期发布；历史Final、PO和旧mappingVersion保持。单Line override与共享映射分开。

**主要类型。** 数据模型/规则版本变更 + 应用流程。

- ux：Mapping表按Reporting Category唯一行；预览旧/新Team和受影响记录；旧类别未分配时展示待处理而非自动猜Team。
- frontend：移除分类规则编辑中的Lever选择但保留Claim业务Lever；effective date/impact preview；按权限显示发布。
- backend：Category唯一性和映射版本；解析顺序明确system mapping与record override；发布前检验所有活动记录及会计组合。
- data：Category主数据拆分、旧→新迁移映射、有效期、ruleVersion；保留旧版本与record-level override来源。
- workflow：Finance批准映射→Super User/GFS Manager维护→影响预览→生效；未映射记录进入异常队列，冻结历史不回写。

**集成与契约。** needed：无需新增外部接口；已有PO/Reserve消费映射需回归；systems：NEO、SAP PO accounting downstream；provider：Finance维护Category/Team/会计主规则；direction：NEO分类结果→Reserve/Journal/已有PO payload；reuse：现有Teams CRUD、revision/history可复用；旧唯一性是全行组合，必须改为有效Category映射唯一性。；evidence：FR17.2 Table6 Row44；team-mappings.ts lines9–28；Training ¶171–185。；unknown：RMA/AMM/PGM新名称、旧数据拆分、override优先级、其他Team/include策略与PO兼容。。

**架构判断。** 规则配置版本化+有效期，避免写死if-else；迁移和源分类分开审计。先完成旧记录分类映射试算，不直接全量修改历史。

**复用。** Teams管理权限/确认/intent与revision guard、现有科目文本字段；NEO-034合法配对矩阵与Team推导是两件事；改为Category-only Team不自动取消Category/Lever合法性校验。

**性能验证计划。** 在确认真实数据量、授权范围、并发和部署环境后测查询/导出延迟、内存、分页与取消；比较完整授权集合与输出校验和，不为演示修改金额或略过错误。本轮仅测合成页面浏览器几何/交互，没有生产性能结论。

**依赖。** [既有NEO-034结论](../../solution-review/NEO-034/NEO-034_Consolidated_CN.md)（复用：合法配对与Team映射职责独立；不重评）；NEO-041类别/财务字段责任；由CNP-231协调；NEO-044/047输出及现有PO会计payload回归。

[业务页面](pages/NEO-046.html) · [桌面截图](screenshots/NEO-046-desktop.png) · [窄屏截图](screenshots/NEO-046-narrow.png) · [异常状态](screenshots/NEO-046-exception.png)

**待确认问题。**

- **NEO-046-Q1 拆分后正式类别叫什么，每个类别映射哪一Team和科目？** 背景：源只提RMA/AMM/PGM，P列详细规则待HJONES20。 例：Contracted Raw Materials – AMM → AMM；旧记录是按Lever迁移还是逐条确认？ 责任：Helen / Finance master-data owner。影响：决定映射与迁移。
- **NEO-046-Q2 手工Override Team还保留吗，什么时候优先？** 背景：ACT-028与共享映射ACT-035是不同动作。 例：Category映射RMA但某条Line曾override TVM，规则更新后保留哪个？ 责任：Finance control。影响：决定例外与审计。
- **NEO-046-Q3 新规则从哪个月开始，已Final和已发PO是否保持？** 背景：历史重写会破坏审计和SAP对账。 例：12月生效，新规则是否影响11月Final v2？ 责任：Finance close / SAP owner。影响：决定切换范围。
- **NEO-046-Q4 Team只看Category后，原034的Category与Lever合法配对还要继续检查吗？** 背景：既有034方案明确配对合法性不等于Team/科目映射。 例：同一个Category已确定RMA，但用户选了不允许的Lever，是否仍阻止保存？ 责任：Finance / Procurement owners。影响：协调两条规则，不能因为简化Team而静默取消034。

**可评审验收场景（全部未执行产品测试）。**

- **NEO-046-S01** 角色：GFS Manager；前置：批准新Category映射v2从2026-12-01有效；输入：`Contracted Raw Materials – RMA → RMA; account=001100050100; cc=0007`；操作：保存Draft mapping → 预览 → 发布并重新读取；预期：新期间相同Category不论Lever均得RMA；科目/成本中心前导零保留。；actual=null；NOT RUN。
- **NEO-046-S02** 角色：GFS Manager；前置：同一有效期已有Category RMA映射；输入：`同Category再映射AMM`；操作：保存；预期：拒绝冲突；保留原映射；不能因为Team不同当作不同合法规则。；actual=null；NOT RUN。
- **NEO-046-S03** 角色：Finance analyst；前置：旧Category尚未人工拆分；输入：`Category=Contracted Raw Materials; Lever=null`；操作：预览影响；预期：显示未映射并阻止依赖其会计输出；不能默认TVM。；actual=null；NOT RUN。
- **NEO-046-S04** 角色：GFS Manager；前置：A/B都编辑v1；输入：`A=RMA; B=AMM`；操作：A提交v2 → B提交v1；预期：B版本冲突，不能覆盖A；历史可追溯。；actual=null；NOT RUN。
- **NEO-046-S05** 角色：Finance reader；前置：11月Final v1已冻结；12月新规则v2；输入：`Historical snapshot=2026-11/v1`；操作：发布v2 → 重新打开11月Final；预期：历史Team/account保持v1；12月新活动记录使用v2；非管理员不能发布。；actual=null；NOT RUN。
- **NEO-046-S06** 角色：Finance editor；前置：已签署034合法配对矩阵仍生效，046映射v2已生效；输入：`Category=RMA; Lever=not-permitted`；操作：修改Lever并尝试保存；预期：即使Team可推导为RMA，仍按批准的034配对政策拒绝或明确警告；不混同两种校验。；actual=null；NOT RUN。

**来源与简短原句。**（完整摘录/哈希见SOURCE_REGISTER.json）

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` · RTM for Requested Changes A47:R47：{"A": "NEO-046", "B": "Finance", "C": "Risk/Opp Creation", "D": "Existing functionality - Update UX / Workflow", "E": "Can we simplify so that only reporting category determines Team (which 
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` · Paragraphs 354–360：UC-23 Run a complete financial period Actor and precondition. MCA and FBP. Approved formulas, sources, working day calendar and cutoffs exist. Trigger. The confirmed financial calendar opens
- `outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/solution-review/NEO-034/NEO-034_Consolidated_CN.md` · Section 2 / 3; approved prior assessment reused, not reassessed：Team Category Mapping 根据 Category＋Lever 决定 Team／科目／Cost Centre。它不是“合法配对清单”，其中空 Lever 也不能自动变成允许任意 Lever 的通配规则
- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` · Table 6 Row 44：FR17.2 | Actual Reserves – Logic for where a line item equals Team  | The following logic dictates how the application should categorise a line item (reserve) for a particular month into the
- `6.技术方案/2 - Tech NEO/NEO User Training.docx` · Paragraphs 171–185：Edit Teams Note: Managed by members in the GFS Manager & Super User group only       After mapping all the fields for new team click on ‘Submit’ button for new team to be added and then clic
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/access/team-mappings.ts` · Lines 5–28：import {reportingCategories} from './source-choices'; export const teamChoices=['AMM','RMA','PGM','SMART','AMM (Unlinked)','Ford','LTSA','ReImagine','Temporary Pricing','FSR','TVM']; export 
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=28]：User can override the Team on an individual claim.  User story As an authorised Finance user, I want to override the Team on an individual claim, so that the individual claim uses the intend
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=29]：User can generate a Reserve by selecting a date and Reserve type.  User story As an authorised Reserve user, I want to generate a monthly Reserve for a selected date and type, so that the mo
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=35]：User can edit an existing Team mapping or add a new mapping.  User story As a Super User or GFS Manager, I want to maintain Team classification mappings, so that shared Team classification i
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` · rows[audit_id=PAGE-P7.3] (127-page registry alias)：P7.3 Management - Teams | 用户127项页面清单；原FR定位按原文保留：FR17.2：按 Reporting Category／Lever 映射 Team、会计科目及 Cost Centre。  Training：Edit Teams（¶170）。
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` · rows[audit_id=PAGE-P1.1.26] (127-page registry alias)：P1.1.26 Edit Reserve Data | 用户127项页面清单；原FR定位按原文保留：FR6.3：维护准备金判断、会计处理及检查信息；与月度准备金生成区分。  Training：Edit Reserve Data（¶663）。  不将此表单自动等同于 Training 单列的 Override Team 操作。 第二部分来源：Before别名P9；reserveI

## NEO-047 同一Reserve输出完整BS及IS会计分录

**源行 48 · Finance**；采购优先级=未填；Finance=Must。建议：P0。Finance Must；缺列/跨报告拼接会漏计或重计，需与044同一会计模型交付。

原文：
> Can we have all balance sheet entries showing on the reserves report, rather than having some which require more than one balance sheet entry appearing on the memos report

目标P：As a finance user I want the reserves report to display all the balance sheet and income statement accounting on the same output.  One line per NEO ID, separate columns for each balance sheet account type - Provision, Accrual, ST Prepayment, LT Prepayment, Loan, Deposit - the number of columns should increase as we add more balacne sheet accounting rules.；Q：未填。M现状：Have to manually stitch together the reserve report and the memos report to see the balance sheet reserves。

**用户问题。** 多种BS分录分散在Reserve和Memo，Finance手工拼接才能看到完整余额。

**UC定位。** UC-23 direct — 一ID多BS及IS完整对账需新场景；UC-24 related — 导出和明细追溯。ACT：ACT-029, ACT-048；FR：FR17, FR17.5, FR17.8。

**当前基线（源码观察）。** FR17已含Provision/Accrual/Receivable/ST/LT Prepayment，FR17.5列单个Balance Sheet Account。当前breakdown.ts按ReserveType做展示；Memo包含Prepayment类型。新要求明确一NEO ID一行，Provision、Accrual、ST/LT Prepayment、Loan、Deposit可扩列，不能只修改表格外观。

**建议方案。** 以ID×期间×会计entry为底层长表，按批准账户类型生成可扩展宽表，同时保留明细钻取。IS与全部BS列同源；一ID可有多种BS entry但不复制整行金额。预付款从Memo报表移到Reserve呈现，调整和冲销保留来源。Receivable在旧FR存在，未被新文明确取消，应提交确认。

**主要类型。** 应用内部前后端 + 会计数据模型变更。

- ux：一ID一行，动态账户类型列与IS总额；可打开entry明细；横向滚动限定表格。
- frontend：同一列schema驱动屏幕和Excel；无适用账户与缺失数据区别显示；Account code原样保留。
- backend：从统一会计entries投影BS/IS；校验分类、符号、未映射账户及合计，不把不同账本/币种直接相加。
- data：entryId、LineID、period、accountType/code、debit/credit、currency、source/adjustment/reversal与ruleVersion；可扩展type而非写死6列。
- workflow：账户类型变更批准后生效，冻结Final不重算；未分类项进入review，正式输出前解决。

**集成与契约。** needed：内部模型；与SAP Journal文件共享契约；systems：NEO、SAP FI via NEO-044 file；provider：Finance定义BS/IS账户字典与符号；direction：NEO会计entries→Reserve宽表/Journal长表；reuse：Reserve snapshot、历史与Excel组件可复用；现有单Type字段不能证明多entry已实现。；evidence：row48 P一ID一行、6类扩展；FR17/17.5存在Receivable；当前Memo financeTypes含预付款。；unknown：Receivable是否另列、Loan/Deposit规则、正负号/净额/重分类、同ID多币种和IS合并规则。。

**架构判断。** 会计事实长表为唯一金额源；宽表只是按批准accountType pivot，schema版本随snapshot固定。避免为新增类型每次加实体列。

**复用。** Reserve period/source snapshots、现有分页/数字格式/导出、Journal对账；科目分类规则须Finance另行批准。

**性能验证计划。** 在确认真实数据量、授权范围、并发和部署环境后测查询/导出延迟、内存、分页与取消；比较完整授权集合与输出校验和，不为演示修改金额或略过错误。本轮仅测合成页面浏览器几何/交互，没有生产性能结论。

**依赖。** NEO-037 Memo去重归属；NEO-044统一会计输出；Finance批准多账户会计规则及账户主数据版本；Finance批准多账户/正负号金样；现有QA F1021-14/17。

[业务页面](pages/NEO-047.html) · [桌面截图](screenshots/NEO-047-desktop.png) · [窄屏截图](screenshots/NEO-047-narrow.png) · [异常状态](screenshots/NEO-047-exception.png)

**待确认问题。**

- **NEO-047-Q1 旧FR里的Receivable是否仍要独立一列？** 背景：新P列列举6种，但没有明确删除旧Receivable。 例：供应商余额不足产生Receivable时，应放Receivable还是Loan？ 责任：Finance accounting owner。影响：决定完整性，不能猜分类。
- **NEO-047-Q2 同一ID不同账户的正负号及IS总额怎么定义？** 背景：页面加总不能代替会计规则。 例：Accrual 120,000及ST Prepayment 20,000，IS是140,000还是按借贷方向计算？ 责任：Finance accounting owner。影响：决定投影、对账和金样。
- **NEO-047-Q3 新增BS类型由谁配置、何时进入报表？** 背景：源要求扩展列，但未定生效规则。 例：12月新增Deposit，11月Final输出是否仍用旧列schema？ 责任：Finance data owner。影响：决定版本与兼容。

**可评审验收场景（全部未执行产品测试）。**

- **NEO-047-S01** 角色：Finance analyst；前置：经Finance批准的合成entry集，统一GBP；输入：`ID47: Accrual=120000, ST Prepayment=20000; ID48: Deposit=5000`；操作：生成Reserve宽表 → 打开ID47明细 → 导出；预期：两个ID两行；ID47两种BS分别120000/20000，ID48 Deposit5000；entry不重复；IS按独立批准金样。；actual=null；NOT RUN。
- **NEO-047-S02** 角色：Finance analyst；前置：没有Loan规则的entry；输入：`accountType=Loan; amount=1000; rule=null`；操作：生成正式报表；预期：未映射异常可见，阻止正式输出；不得塞入Other/0掩盖。；actual=null；NOT RUN。
- **NEO-047-S03** 角色：Finance analyst；前置：一个Memo预付款在同快照已入Reserve；输入：`sourceEntryId=E47; amount=20000`；操作：合并生成 → 导出Memo；预期：Reserve仅计一次20,000；Memo会计报告不重复包含。；actual=null；NOT RUN。
- **NEO-047-S04** 角色：Finance admin；前置：11月v1已冻结，新12月Deposit规则v2；输入：`newType=Deposit; effective=2026-12`；操作：发布规则 → 打开11月/12月输出；预期：11月仍原schema/version；12月使用v2；非admin写入被拒绝。；actual=null；NOT RUN。
- **NEO-047-S05** 角色：Finance analyst；前置：生成过程中同ID有并发调整；输入：`snapshot=v1; adjustment=v2`；操作：下载v1 → 刷新为v2；预期：每份输出内部版本一致，不能部分列v1部分v2；取消/失败保留上一完整输出。；actual=null；NOT RUN。

**来源与简短原句。**（完整摘录/哈希见SOURCE_REGISTER.json）

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` · RTM for Requested Changes A48:R48：{"A": "NEO-047", "B": "Finance", "C": "Finance Reserves", "D": "Existing functionality - Update UX / Workflow", "E": "Can we have all balance sheet entries showing on the reserves report, ra
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` · Paragraphs 354–360：UC-23 Run a complete financial period Actor and precondition. MCA and FBP. Approved formulas, sources, working day calendar and cutoffs exist. Trigger. The confirmed financial calendar opens
- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` · Table 6 Row 42：FR17 | Actual Reserves | Business Context: Users to generate reserves at a point in time. Appian to generate a summary line item which details the Month- Year for the reserves created. This 
- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` · Table 6 Row 47：FR17.5 | Actual Reserves – Generating new reserves | Business Context: Equivalent of the green reserves tab used on the NCR Reserve Excel Once a user has generated a new overall reserve line
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/features/reserve-views/memos.ts` · Lines 25–30：const allowed=(a:AuthorityContext,action:string)=>trainingActionAllowed(subjectForActor(a.actor),action); export const memoFinanceTypes=['Provision','Accrual','Receivable','Prepayment Long T
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/features/reserve-views/breakdown.ts` · Lines 1–45：import { addDecimal, parseDecimal } from '../../p03/decimal'; import type { ReservePeriod } from '../../p05/periods';  export const reserveTypes = ['Provision', 'Accrual', 'Receivable', 'Pre
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` · issues[id=F1021-17]：{"id": "F1021-17", "status": "PARTIAL_IMPLEMENTATION", "problem": "Create Memo已恢复Training字段和双入口，已验GFS、保存刷新、5位金额及全部可编辑字段。业务待澄清：取消“仅当前月”后，各已选月份的金额如何确定？待确认初始 Reserve Value、Increment 与月份间的关系，以及跳
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=29]：User can generate a Reserve by selecting a date and Reserve type.  User story As an authorised Reserve user, I want to generate a monthly Reserve for a selected date and type, so that the mo
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=48]：User can review month-end snapshots and month-to-date results.  User story As an authorised Finance or Purchasing user, I want to review the month-end reporting snapshots, so that the select
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` · rows[audit_id=PAGE-P5.8] (127-page registry alias)：P5.8 Generate Reserve（Draft／Final） | 用户127项页面清单；原FR定位按原文保留：FR17：按月生成 Draft／Final、显示汇总并可归档 Draft。  FR17.5：生成 Line 级金额、分类、变动和账户信息，保留收货／价格计算快照。  Training：Generate Reserve（¶1738）。  BRD FR17 写 GF

## NEO-048 自动SAP付款输入取代KSB1手工上传

**源行 49 · Finance**；采购优先级=未填；Finance=Should。建议：P1；接口契约先行。Finance Should；重复和错误影响Reserve，收益明确，但source API与权限未确认，是交付关键依赖。

原文：
> Feed the payments data automatically from SAP rather than requiring the manual KSB1 upload process

目标P：As a finance user, the information required to calculate the reserves should all be automatically uploaded into NEO (integrated directly with SAP) and should not require manual uploads；Q：未填。M现状：Manual upload causes duplicates and errors affecting reserves accuracy。

**用户问题。** 手工KSB1上传导致重复与错误，Reserve输入不稳定。

**UC定位。** UC-22 direct — 原UC是手工上传；增加自动输入/水位/重放；UC-23 direct — Reserve消费完整付款批次。ACT：ACT-029, ACT-047；FR：FR17.5, FR17.6。

**当前基线（源码观察）。** 工作BRD UC-22/IF26描述SAP report file→user upload→NEO。当前Payments/index.tsx及payments.ts有示例CSV、批次解析、重复/冲销/币种控制；只接受本地演示8列不是KSB1正式契约。接口目录MCI_getPurchaseOrderDetails仅查询PO状态并帮助Implemented，未证明付款/发票/会计项目齐全。

**建议方案。** 通过确认的SAP付款/会计数据provider自动同步至暂存区，校验后归一化成付款事件，按稳定源键幂等应用。显示最后成功完整水位、批次覆盖期间、金额/币种control totals、拒绝/冲销与未匹配ID；失败不得把上次数据标记为今天完整。切换期间手工与自动输入共享去重键，经对账批准后停手工通道。

**主要类型。** 新增/扩展系统集成 + 数据接入与流程。

- ux：自动同步状态、覆盖期间、来源条数与金额、错误/未匹配队列；查看重试前后差异。
- frontend：批次筛选/明细、retry权限与加载状态；上次成功与本次失败并列；保留未处理异常。
- backend：适配器、增量watermark、稳定posting/item键、重放幂等、冲销关联、原始payload归档与服务账户控制；完成后才推进水位。
- data：sourceSystem/company/fiscalYear/document/item、posting/payment dates、currency/amount/direction、reversalReference、PO/NEO映射及batch/version。
- workflow：定时获取→staging→校验/对账→commit→Reserve读快照；异常由Finance处理；手工备用需要授权且不与自动重复计数。

**集成与契约。** needed：是；需新增或扩展付款/会计数据契约；systems：SAP、Integration platform / Apigee候选、NEO；provider：SAP FI/CO数据owner负责付款/会计行；Integration lead确定API/事件/批量接口；direction：SAP→NEO入站；NEO→SAP仅查询/请求，不产生付款；reuse：可复用现有通用认证/Apigee能力、NEO解析校验与批次模型，不能复用PO status响应当付款接口。；evidence：Integrations row11 ID5只写Check status of purchase order；工作BRD Table24 Row27 IF26为手工上传；payments.ts header为本地illustrative。；unknown：KSB1报告variant及完整列、SAP授权端点、增量键、冲销/删除、时间范围、历史补载、时区、量级/频率/SLA。。

**架构判断。** 自动与人工渠道进入同一规范化payment ingestion pipeline；raw/staged/committed分层，at-least-once接收配幂等。接口选型由SAP支持能力决定，不预定实时或消息平台。

**复用。** 现有PaymentPreview校验、金额分组、冲销关联和Reserve source manifests；需扩展正式keys/schema。

**性能验证计划。** 在确认真实数据量、授权范围、并发和部署环境后测查询/导出延迟、内存、分页与取消；比较完整授权集合与输出校验和，不为演示修改金额或略过错误。本轮仅测合成页面浏览器几何/交互，没有生产性能结论。

**依赖。** SAP FI/CO provider与security授权；KSB1样例/全量对账基线；NEO-044/047月结快照；NEO-037实际汇率规则；切换/历史补载与手工备用政策；既有UC-22与FR17问题保持开放。

[业务页面](pages/NEO-048.html) · [桌面截图](screenshots/NEO-048-desktop.png) · [窄屏截图](screenshots/NEO-048-narrow.png) · [异常状态](screenshots/NEO-048-exception.png)

**待确认问题。**

- **NEO-048-Q1 KSB1目前实际用哪个报表variant和列，数据owner提供哪一种自动方式？** 背景：PO查询接口没有付款所需字段证明。 例：Company+Fiscal Year+Document+Item能否唯一识别一条付款？ 责任：SAP FI/CO / Integration lead。影响：决定接口和主键。
- **NEO-048-Q2 同步到什么时间点才算本月完整，失败谁处理？** 背景：最后运行成功时间不能代替数据覆盖水位。 例：13日17:00运行成功但源只到12日，月结可以用吗？ 责任：Finance close / Operations。影响：决定SLA和Final门槛。
- **NEO-048-Q3 切换时旧手工行、冲销和迟到数据怎样去重？** 背景：旧文件和新接口可能包含同一交易。 例：同一SAP行已手工导入，自动重放时应跳过；次日冲销应另记关联事件。 责任：Finance data owner。影响：决定数据迁移和回归。

**可评审验收场景（全部未执行产品测试）。**

- **NEO-048-S01** 角色：Integration service；前置：批准SAP样例含稳定key，NEO-L-00048与PO 4500001048映射；输入：`key=GB01/2026/190000048/001; GBP1000; payment`；操作：同步 → 对账 → commit → 同批重试；预期：仅一条付款及GBP1000；两次接收不重复；水位仅在完整commit后推进。；actual=null；NOT RUN。
- **NEO-048-S02** 角色：Finance operator；前置：原付款已commit；输入：`reversalKey=.../002; reversalOf=.../001; amount=1000`；操作：同步冲销 → 查看明细；预期：原付款保留，冲销关联可追溯；按批准方向统计，不把原行抹掉。；actual=null；NOT RUN。
- **NEO-048-S03** 角色：Integration service；前置：源3行中1条不合法；输入：`amount=ABC on item003`；操作：接收 → 校验；预期：批次显示拒绝/不完整，失败策略按批准atomic/partial契约执行；不能标记完整或推进遗漏行水位。；actual=null；NOT RUN。
- **NEO-048-S04** 角色：Finance operator；前置：上次完整水位12 Nov17:00，本次源超时；输入：`timeout=true`；操作：重试同步；预期：上次完整数据可看但标识陈旧；重试不会重复或伪造新水位。；actual=null；NOT RUN。
- **NEO-048-S05** 角色：Buyer；前置：没有payment管理权限；输入：`batch=PAY-048`；操作：直接请求retry/原始财务payload；预期：服务端拒绝；不暴露跨供应商付款。；actual=null；NOT RUN。
- **NEO-048-S06** 角色：Integration service；前置：手工已导入同源key；两次worker并发；输入：`key=GB01/2026/190000048/001`；操作：自动同步并发commit；预期：唯一键/事务保证一条有效事件；手工与自动均有来源履历。；actual=null；NOT RUN。

**来源与简短原句。**（完整摘录/哈希见SOURCE_REGISTER.json）

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` · RTM for Requested Changes A49:R49：{"A": "NEO-048", "B": "Finance", "C": "Lump Sum Process", "D": "New Integration & Workflow", "E": "Feed the payments data automatically from SAP rather than requiring the manual KSB1 upload 
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` · Paragraphs 354–360：UC-23 Run a complete financial period Actor and precondition. MCA and FBP. Approved formulas, sources, working day calendar and cutoffs exist. Trigger. The confirmed financial calendar opens
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` · Paragraphs 347–353：UC-22 Import and reconcile payments Actor and precondition. Material Cost Analyst and Finance. A SAP payment report and period are available. Trigger. MCA receives the payment input for uplo
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` · Table 24 Row 27：IF26 PO payments import and NEO-ID reconciliation SAP report file -> user upload -> NEO | PO payments, purchasing document reference, NEO ID linkage Reports > PO Payments > Upload; status In
- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` · CSV physical row 11; ID 5：5 | MCI_getPurchaseOrderDetails | Check the status of purchase order in SAP, helps to update the claim to implemented if approved in SAP | Material Cost & Inventory | Integration | Appian | 
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p05/payments.ts` · Lines 16–45：export type PaymentRow = {     rowNumber: number;     rowKey: string;     po: string;     neo: string;     amount: string;     currency: string;     date: string;     direction: string;     
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p05/payments.ts` · Lines 132–163：export function publishPayments(store: P05Store, a: AuthorityContext, g: LocalGuard, p: PaymentPreview): LocalResult {     return store.transact(a, g, { kind: 'publish-payments', preview: p 
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Payments/index.tsx` · Lines 25–43：  const rows = batches.flatMap((batch) => batch.rows.map((row) => ({ ...row, batchId: batch.id }))).filter((row) => !ui.values.paymentSearch || row.po.includes(ui.values.paymentSearch) || ro
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=29]：User can generate a Reserve by selecting a date and Reserve type.  User story As an authorised Reserve user, I want to generate a monthly Reserve for a selected date and type, so that the mo
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=47]：GFS can record a check and justification for a Reserve line.  User story As a GFS user, I want to record that a Reserve line has been checked, so that Finance has a recorded check and justif
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` · rows[audit_id=PAGE-P5.10] (127-page registry alias)：P5.10 Data Checks＋Justification | 用户127项页面清单；原FR定位按原文保留：FR17.6：保存检查筛选、检查标志与认可金额的理由。  Training：Data Checks（¶1532）。 第二部分来源：Before别名P16.1.1；reserveMonth、roles，Dictionary/Schema及既有FIELD_REGISTER

## NEO-055 Buyer Forecast Download多财年筛选与Excel格式

**源行 56 · Procurement**；采购优先级=未填；Finance=未填。建议：P1（分析建议，源K/L未填）。已有明确FR20.5能力基础，采购提到filter/format改进但缺具体清单；可以先定字段与过滤口径，复用授权导出框架。

原文：
> The replacement NEO shall provide users with a report called "Buyer Forecast Download" and be able to download as excel. The format of this report and the ability to filter the data downloaded needs to be improved.

目标P：未填；Q：未填。M现状：Procurement - there is room for improvement in the download and the filters that can be applied (specifics needed)。

**用户问题。** 采购希望Buyer Forecast Excel可按所需范围筛选，格式更适合直接分析。

**UC定位。** UC-24 direct — 独立Buyer Forecast字段/过滤/多FY验收。ACT：ACT-041；FR：FR20.5, FR20.1（相关）。

**当前基线（源码观察）。** 源F56明确BRD FR20.05；FR20.5要求多FY和Appendix H 92列。实际代码Special.tsx已提供buyer-forecast多FY选择、Generate和Download，下载前重新生成并比对snapshot；reports.ts的forecastRows已有15列，且目前仅按FY过滤。它复用finance-claim-report action，不能据此证明Buyer获得权限。完整92列、独立Buyer权限及新增过滤/格式未确认；F1021-28仍开放。旧Appian 50列说明不能继承成新平台限制。

**建议方案。** 在现有Buyer Forecast专用生成/下载能力上扩展Buyer、CoC、Supplier和状态过滤以及批准的Excel布局；保留多FY和sourceRevision。页面Preview与Excel使用同一授权全量快照。年度Forecast Local、Calendarised Forecast Local与GBP必须分清口径；15列候选输出不能冒充Appendix H完整92列。独立report action/Buyer访问由业务确认。

**主要类型。** 应用内部报表/前后端导出。

- ux：多FY必选；常用Buyer/CoC/Supplier/状态过滤；Preview与Download Excel并列，空结果可清除恢复。
- frontend：在现有Special buyer-forecast页面扩展经批准过滤与布局；复用FY多选、Generate和下载校验；分页不缩小导出范围。
- backend：授权过滤先于分页，异步大导出job、过期链接与取消；download重新校验权限和快照，不接受客户端任意field。
- data：经确认Buyer Forecast schema version、field definitions、filter snapshot、actor/asOf/sourceRevision；92列需逐列映射。
- workflow：生成→完成/失败→下载；源/权限变化时要求刷新；不改变Claim审批流程。

**集成与契约。** needed：基础NEO字段不需新增；缺失外部字段时再评估；systems：NEO；provider：NEO保存的Claim/Forecast读模型；Procurement批准字段与filter清单；direction：NEO→授权用户Excel；reuse：现有Special报表生成及15列forecastRows可复用；Finance Claim GBP报表是另一口径，不把年度和calendarised值混用。；evidence：row56 F=BRD FR20.05；BRD Table6 Row72；claim-reporting.ts lines20–22/68。；unknown：Appendix H完整92列、改进字段/顺序、过滤名称与默认、空值/币种/多FY跨表口径。。

**架构判断。** Buyer Forecast独立报表schema与Finance Claim Report共用查询/权限基础；不要把两个报告合并成无定义的万能导出。

**复用。** Special.tsx已有多FY、Generate、Download和snapshot一致性检查；forecastRows已有15列及registered Line授权过滤。扩展现有机制，不重复建设入口。

**性能验证计划。** 在确认真实数据量、授权范围、并发和部署环境后测查询/导出延迟、内存、分页与取消；比较完整授权集合与输出校验和，不为演示修改金额或略过错误。本轮仅测合成页面浏览器几何/交互，没有生产性能结论。

**依赖。** Appendix H或当前业务Excel模板及字段owner；NEO-067共享导出基础但独立schema；既有QA PAGE-P6.5、F1021-28。

[业务页面](pages/NEO-055.html) · [桌面截图](screenshots/NEO-055-desktop.png) · [窄屏截图](screenshots/NEO-055-narrow.png) · [异常状态](screenshots/NEO-055-exception.png)

**待确认问题。**

- **NEO-055-Q1 请列出最常用筛选和导出后现在要手工改的列？** 背景：源M56明确specifics needed。 例：需要按Buyer+Supplier导出两个FY，还是只看自己CoC的未实施机会？ 责任：Procurement report owner。影响：决定筛选范围和默认。
- **NEO-055-Q2 92列哪些保留、改名或新增，完整Excel样例由谁给？** 背景：Appendix H没有找到完整合同，不能凭页面复制。 例：Supplier Code必须文本以保留00123；Forecast Local与GBP要各有币种/口径。 责任：Procurement / BA / Finance。影响：决定schema验收。
- **NEO-055-Q3 多财年输出是同一表按FY列区分，还是每FY一张表？** 背景：FR只要求选一个或多个FY。 例：FY25/26及26/27的同一个ID是否各一行？ 责任：Procurement report owner。影响：决定粒度与可分析性。
- **NEO-055-Q4 Buyer Forecast允许哪些采购和财务角色使用？** 背景：当前代码复用finance-claim-report动作，不能确认Buyer权限。 例：Buyer只看自己的CoC，FBP看负责区域，还是其他范围？ 责任：Procurement / Access owner。影响：决定独立报表权限与行过滤。

**可评审验收场景（全部未执行产品测试）。**

- **NEO-055-S01** 角色：Buyer；前置：授权CoC Cabin有3条跨FY记录；另CoC一条不可见；输入：`FY=[2025/26,2026/27]; Buyer=Alice; Supplier=00123`；操作：Apply filters → Preview → Download Excel；预期：只含符合权限与筛选的完整3条，非当前页数；FY和Supplier00123保留，Filters sheet匹配。；actual=null；NOT RUN。
- **NEO-055-S02** 角色：Buyer；前置：未选FY；输入：`FY=[]`；操作：Preview；预期：提示Select at least one financial year；不生成含所有FY的文件。；actual=null；NOT RUN。
- **NEO-055-S03** 角色：Buyer；前置：合法筛选无匹配；输入：`Supplier=NO-MATCH`；操作：Apply → Clear filters；预期：显示无结果、下载禁用；Clear后恢复默认授权结果。；actual=null；NOT RUN。
- **NEO-055-S04** 角色：Buyer；前置：导出前权限或数据版本改变；输入：`preview=v1; entitlement revoked`；操作：Download；预期：服务端拒绝/要求刷新，不泄露旧快照；已填写筛选仍保留。；actual=null；NOT RUN。
- **NEO-055-S05** 角色：Buyer；前置：后台导出失败；输入：`job=BF55; status=failed`；操作：Retry；预期：保留筛选、显示失败且可重试；不下载空文件当成功；重复点击不创建重复job。；actual=null；NOT RUN。

**来源与简短原句。**（完整摘录/哈希见SOURCE_REGISTER.json）

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` · RTM for Requested Changes A56:R56：{"A": "NEO-055", "B": "Procurement", "C": "Reporting", "D": "Existing functionality - Update UX / Workflow", "E": "The replacement NEO shall provide users with a report called \"Buyer Foreca
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` · Paragraphs 361–367：UC-24 Use reports and audit evidence Actor and precondition. Buyer, Finance, BI and audit. Authorised datasets and report scope are defined. Trigger. An authorised user requests a report exp
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Reporting/Special.tsx` · Lines 13–27：export default function Special({ kind }: { kind: ReportKind }) {   const d = useDownstream(), [filter, setFilter] = useState(initial), [snapshot, setSnapshot] = useState<WorkbookSnapshot | 
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/features/report-exports/reports.ts` · Lines 12–26：export const reportDefinitions = [   { id:'poa-parts', label:'POA Part Level Detail', action:'naf-pin-report' },   { id:'buyer-forecast', label:'Buyer Forecast', action:'finance-claim-report
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/features/report-exports/reports.ts` · Lines 49–57：function forecastRows(runtime: OfflineRuntime, a: AuthorityContext, filter: ReportFilter):ReportRow[] {   return reportLines(runtime,a).filter(({saved})=>filter.years.includes(saved.snapshot
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/features/report-exports/reports.ts` · Lines 80–101：  }); } export function buildSpecialReport(runtime:OfflineRuntime,a:AuthorityContext,kind:ReportKind,filter:ReportFilter):WorkbookSnapshot {   if(!canRunReport(a,kind))throw Error('You do no
- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` · Table 6 Row 72：FR20.5 | Report Extract | Users should have the ability to select a tab called “Reports” within the application.  Once selected, a user should see a report called “Buyer Forecast Download”. 
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p05/claim-reporting.ts` · Lines 19–22：export const claimReportPhases=['Forecast','In Approval','Returned to Buyer','Awaiting Implementation','Implemented','Status unavailable'] as const; export type ClaimImpactRow={claimId:strin
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p05/claim-reporting.ts` · Lines 65–70： return projectClaimImpact(sources,a,filter,{requests:runtime.requests.listRequests(a),settlements:runtime.requests.listSettlements(a),cases:runtime.downstream.readCases(a),financeFields}); 
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` · issues[id=F1021-28]：{"id": "F1021-28", "status": "BLOCKED_REFERENCE", "problem": "Part Level与92列Buyer Forecast Appendix H/J未定位，不能由截图恢复全部字段公式。\nNQA-128：NAF Pin生成页、5个筛选/勾选字段和18列临时Excel本地通过；正式Appendix J未取得，当前Reser
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=41]：User can review Finance Claim Report metrics, filter by CoC and drill into the results.  User story As an FBP or FA user, I want to review the reported risks, opportunities, benefits and cos
- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` · rows[audit_id=PAGE-P6.5] (127-page registry alias)：P6.5 Buyer Forecast Download | 用户127项页面清单；原FR定位按原文保留：FR20.5：按一个或多个财年导出 Buyer Forecast，字段参照附录 H。  原文提到平台列数限制，不直接继承为新平台限制。 本轮Before/技术字段核对：P20.6（未找到独立Before图）；FR20.5；F2021-091…095；Data Diction

## NEO-067 Claim列表导出增加已批准字段

**源行 68 · Procurement**；采购优先级=未填；Finance=未填。建议：P1（分析建议，源K/L未填）。源未给字段清单和优先级，先确认后可低耦合扩充；敏感字段与粒度必须先明确。

原文：
> Add more fields when download the claim list, to let user to be able to see more details on the report

目标P：未填；Q：未填。M现状：Exported claim list with less information。

**用户问题。** Claim列表导出信息不足，用户需另查详情才能分析。

**UC定位。** UC-24 direct — Claim列表具体入口、字段和列权限未定义。ACT：ACT-041；FR：FR20.1（相关）, FR20（相关）。

**当前基线（源码观察）。** 源E68仅要求more fields，未给字段清单。实际WorkQueue.tsx已提供Download Claims、Manage Columns及Show More Details；queue-fields.ts有23列、默认18列；useWorkQueue.ts导出授权并筛选后的全量rows及当前选择列，下载校验authority generation。Reporting Value GBP来自calendarisedForecastGbp。Finance Claim报表是独立年度Forecast投影。当前基线已有选择列和导出，是否还需开发取决于目标字段是否在23列内。以上为源码观察，未执行当前产品。

**建议方案。** 先确认用户目标列表和缺少列，再对现有23列注册表做差异。已有列可通过Manage Columns/Show More Details配置满足；缺失的Reporting Category、Team、Currency或Last Updated等仅作为候选新增投影，逐列确认来源/权限/空值。保留现有授权全量过滤导出、默认列与Line粒度；不重建已有导出功能。

**主要类型。** 应用内部导出；外部字段才触发集成评估。

- ux：Download列选择/预览，使用业务字段名；保留当前过滤范围和Line粒度提示；字段不可用给具体理由。
- frontend：复用现有列选择/更多详情/下载工具条；扩展已批准字段注册和格式，保留默认18列及Line ID不可取消规则；不重复创建新导出页。
- backend：现有本地exportRows可作为投影参考；正式服务扩展typed field allow-list与行/列权限、源版本校验、缓存隔离；客户端管理列不构成服务端授权。
- data：export schemaVersion/selectedFields/filter/sourceVersions；新增字段逐项标注类型、来源、空值及aggregation；不复制Parent金额到每Line。
- workflow：只改变导出任务；不改变Claim审批状态。字段新增经owner批准后启用，旧schema可回溯。

**集成与契约。** needed：已存NEO字段不需新增；外部独有字段待清单后决定；systems：NEO、未确定的外部字段provider（如提出）；provider：Claim字段owner；如字段只存在SAP/ExWorks需单独确认；direction：NEO→用户Excel；不得默认新增对外发送；reuse：当前useWorkQueue.exportRows已经按授权筛选后的全量rows和所选列导出；缺的只是待确认字段及正式服务契约，不是整个导出能力。；evidence：WorkQueue index.tsx line72 Download Claims、149–153 Manage Columns；useWorkQueue.ts lines40–55全量/authority；queue-fields.ts lines3–6共23列默认18，Reporting Value GBP使用calendarisedForecastGbp。；unknown：目标Claim列表页面、确切列名、字段来源、敏感范围、Parent/Line粒度和多值字段展开。。

**架构判断。** 基于现有queueColumns注册表扩展类型化projection；先做23列与目标清单差异，目标已存在时可以配置/使用指引解决。Finance Claim年度Forecast与All Claims calendarised Reporting Value保持不同定义。

**复用。** WorkQueue现有Manage Columns、Show More Details、23列注册表/默认18列、授权过滤后的完整rows、导出authority generation检查；只开发经确认的字段差异。

**性能验证计划。** 在确认真实数据量、授权范围、并发和部署环境后测查询/导出延迟、内存、分页与取消；比较完整授权集合与输出校验和，不为演示修改金额或略过错误。本轮仅测合成页面浏览器几何/交互，没有生产性能结论。

**依赖。** Procurement明确列清单与目标入口；NEO-055同用导出基础但保留报告独立定义；现有NQA-60 ID语义、UC-24授权数据边界。

[业务页面](pages/NEO-067.html) · [桌面截图](screenshots/NEO-067-desktop.png) · [窄屏截图](screenshots/NEO-067-narrow.png) · [异常状态](screenshots/NEO-067-exception.png)

**待确认问题。**

- **NEO-067-Q1 具体是哪一个Claim列表，最需要新增哪几列？** 背景：实际All Claims已有23列/默认18列与Manage Columns；源未说明想要的字段是否已存在。 例：All Claims下载要Buyer、Team、Reporting Category，还是审批页面的Request字段？ 责任：Procurement owner。影响：决定入口和字段范围。
- **NEO-067-Q2 遇到一个Parent多个Line或一个Line多个Request时，要怎样显示？** 背景：直接join会重复金额。 例：Parent有3条Line、Line有2次Request，仍要每Line一行还是另表列Request？ 责任：Procurement / Reporting BA。影响：决定粒度和防重计。
- **NEO-067-Q3 哪些字段仅Finance能导出，空值应该怎样表示？** 背景：页面能看到部分字段不证明可批量下载全部。 例：Finance comments不可给Buyer时是完全不提供该列还是拒绝所选模板？ 责任：Data owner / Security。影响：决定列权限与文件兼容。

**可评审验收场景（全部未执行产品测试）。**

- **NEO-067-S01** 角色：Buyer；前置：批准新schema v2，授权两条Line；输入：`fields=[Line ID,Buyer,Reporting Category,Team,Currency]; Supplier=00123`；操作：选择字段 → Preview → Download Excel；预期：列按选择顺序、两条Line一行各一条、Supplier00123文本；无未授权行/列。；actual=null；NOT RUN。
- **NEO-067-S02** 角色：Buyer；前置：Financial comments未授权；输入：`fields include Finance comments`；操作：直接构造download请求；预期：服务端拒绝该字段或按明确契约剔除并告知，不泄露缓存文件。；actual=null；NOT RUN。
- **NEO-067-S03** 角色：Buyer；前置：一Line有两个Request；输入：`Line=NEO-L-00067; Requests=2`；操作：导出Line粒度；预期：仍一Line一行金额不翻倍；多Request按批准关联sheet处理。；actual=null；NOT RUN。
- **NEO-067-S04** 角色：Buyer；前置：Team无有效映射；输入：`Team=null`；操作：Preview → Download；预期：显示—并保留空值语义，不默认TVM；不伪造Team来源。；actual=null；NOT RUN。
- **NEO-067-S05** 角色：Buyer；前置：预览后sourceRevision改变或任务失败；输入：`preview=v2; current=v3`；操作：Download → Retry；预期：输出来自完整一致快照或要求刷新；重复点击去重；筛选/列选择保留。；actual=null；NOT RUN。

**来源与简短原句。**（完整摘录/哈希见SOURCE_REGISTER.json）

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` · RTM for Requested Changes A68:R68：{"A": "NEO-067", "B": "Procurement", "C": "Reporting", "D": "Existing functionality - Update UX / Workflow", "E": "Add more fields when download the claim list, to let user to be able to see
- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` · Paragraphs 361–367：UC-24 Use reports and audit evidence Actor and precondition. Buyer, Finance, BI and audit. Authorised datasets and report scope are defined. Trigger. An authorised user requests a report exp
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/WorkQueue/index.tsx` · Lines 70–80： const toolbar=<Space wrap size={8} className={styles.toolbar}>{canStart(neo.actor)&&<Button type="primary" icon={<PlusOutlined/>} onClick={()=>neo.startClaim('create')}>Create Claim</Button
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/WorkQueue/index.tsx` · Lines 116–154：            </label>             <label className={styles.switchLabel} htmlFor={switchId+'-details'}>Show More Details               <Switch id={switchId+'-details'} checked={q.moreDetails} 
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/hooks/useWorkQueue.ts` · Lines 40–55： const selection={tab:'all' as const,search:'',status:'',ownerId:'',page:1,pageSize:1000000,sortKey:sort.key,sortDirection:sort.direction};  const authorised=selectQueue(all,actor,selection)
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/alignment/queue-fields.ts` · Lines 1–7：import type {ClaimValues,QueueRow,SavedLocalDraft} from '../p02/contracts'; export type QueueOriginal={claim:Partial<ClaimValues>;naf:string|null;lineId:string|null;findId:string|null;parent
- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` · Table 6 Row 68：FR20.1 | Report – Opportunities Vs Risks Summary.  | The application should contain a report which is visible to FBP users, split by the application status of whether they have been realised
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p05/claim-reporting.ts` · Lines 19–22：export const claimReportPhases=['Forecast','In Approval','Returned to Buyer','Awaiting Implementation','Implemented','Status unavailable'] as const; export type ClaimImpactRow={claimId:strin
- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p05/claim-reporting.ts` · Lines 65–70： return projectClaimImpact(sources,a,filter,{requests:runtime.requests.listRequests(a),settlements:runtime.requests.listSettlements(a),cases:runtime.downstream.readCases(a),financeFields}); 
- `outputs/neo-jira-stories-20261111/v3/story_data.json` · entries[act=41]：User can review Finance Claim Report metrics, filter by CoC and drill into the results.  User story As an FBP or FA user, I want to review the reported risks, opportunities, benefits and cos