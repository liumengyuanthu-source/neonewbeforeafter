# 业务确认问题

以下是需业务/数据owner确认的具体问题，不是开发默认规则。每项问题的影响与例子保持可直接讨论。


## NEO-035 ExWorks £m 与平均车 £pu：同口径展示和导出

- **NEO-035-Q1 ExWorks平均车£pu究竟按哪一个金额除以哪一批车？** 背景：现有字典同时有零件量与车辆量，公式未定。 例：£m=1.20；用60,000辆为£20，用零件120,000件为£10，两个结果不能任选。 责任：Finance / ExWorks owner。影响：决定公式、数据来源及接口。
- **NEO-035-Q2 新£pu是新增指标，还是要取代曾删除的旧PAM列？** 背景：FR18明确允许删除5列£pu；新需求与旧范围不同。 例：Avg_Car_PU_Impact是否仍不输出，只新增批准的ExWorksAverageCarGBP？ 责任：Finance / Reporting BA。影响：确定字段与兼容策略。
- **NEO-035-Q3 哪个团队提供可对账的数据版本，缺数或更新后如何发布？** 背景：E2SC与Qlik方向不能证明已有ExWorks输入。 例：10月v1与v2金额相同、车辆量变化，用户应能看到两个版本差异。 责任：Finance data owner / Integration lead。影响：决定provider、截止时间和重跑规则。

## NEO-037 Memo实际汇率、过账状态与删除规则重核

- **NEO-037-Q1 Memo使用哪一天、哪一类实际汇率，关闭月份能否重算？** 背景：当前字段仍是预算汇率，Requested Changes要求actual。 例：EUR100,000，预算0.85、实际0.86，使用哪一个日期的0.86？ 责任：Helen / Linda / Finance。影响：决定金额与历史冻结。
- **NEO-037-Q2 已过账Memo应由谁冲销，未过账Memo可否作废？** 背景：删除不能抹去凭据；Confirmed不证明已过账。 例：Memo M-037已在SAP有凭据，再发现重复，应关联反向分录还是次月调整？ 责任：Finance control / SAP owner。影响：决定状态和权限。
- **NEO-037-Q3 Memo是否仍跟随原Reserve的status或likelihood？** 背景：P列明确以问题形式提出，未确认取消。 例：原Reserve改为Closed后，独立Memo要保留、释放还是提示复核？ 责任：Helen / Linda。影响：决定金额触发与历史行为。

## NEO-044 NEO ID粒度Journal、Reserve和POA证据一致

- **NEO-044-Q1 SAP mass upload每一行需要哪些列、哪个NEO ID字段和格式？** 背景：源要求ID粒度但未提供SAP模板。 例：同一NEO ID有Accrual与ST Prepayment，是否生成两组借贷、ID放Assignment还是Reference？ 责任：SAP FI owner / Finance。影响：决定输出schema和粒度。
- **NEO-044-Q2 哪些调整必须进入Final，哪些只能出现在后续调整版？** 背景：要实现Report与Journal总额一致必须定义cutoff。 例：Final v3后补£250，更新为v4还是独立postclose journal？ 责任：Finance close owner。影响：决定冻结/继承规则。
- **NEO-044-Q3 POA本月PPV与retro按哪个日期和版本归属？** 背景：不能用Current Month总额替代PPV/retro证据。 例：11月收货但追溯到9月生效的价格，归入哪一期？ 责任：POA Finance / SAP data owner。影响：决定明细计算与对账。

## NEO-046 Reporting Category单独决定Team及会计映射

- **NEO-046-Q1 拆分后正式类别叫什么，每个类别映射哪一Team和科目？** 背景：源只提RMA/AMM/PGM，P列详细规则待HJONES20。 例：Contracted Raw Materials – AMM → AMM；旧记录是按Lever迁移还是逐条确认？ 责任：Helen / Finance master-data owner。影响：决定映射与迁移。
- **NEO-046-Q2 手工Override Team还保留吗，什么时候优先？** 背景：ACT-028与共享映射ACT-035是不同动作。 例：Category映射RMA但某条Line曾override TVM，规则更新后保留哪个？ 责任：Finance control。影响：决定例外与审计。
- **NEO-046-Q3 新规则从哪个月开始，已Final和已发PO是否保持？** 背景：历史重写会破坏审计和SAP对账。 例：12月生效，新规则是否影响11月Final v2？ 责任：Finance close / SAP owner。影响：决定切换范围。
- **NEO-046-Q4 Team只看Category后，原034的Category与Lever合法配对还要继续检查吗？** 背景：既有034方案明确配对合法性不等于Team/科目映射。 例：同一个Category已确定RMA，但用户选了不允许的Lever，是否仍阻止保存？ 责任：Finance / Procurement owners。影响：协调两条规则，不能因为简化Team而静默取消034。

## NEO-047 同一Reserve输出完整BS及IS会计分录

- **NEO-047-Q1 旧FR里的Receivable是否仍要独立一列？** 背景：新P列列举6种，但没有明确删除旧Receivable。 例：供应商余额不足产生Receivable时，应放Receivable还是Loan？ 责任：Finance accounting owner。影响：决定完整性，不能猜分类。
- **NEO-047-Q2 同一ID不同账户的正负号及IS总额怎么定义？** 背景：页面加总不能代替会计规则。 例：Accrual 120,000及ST Prepayment 20,000，IS是140,000还是按借贷方向计算？ 责任：Finance accounting owner。影响：决定投影、对账和金样。
- **NEO-047-Q3 新增BS类型由谁配置、何时进入报表？** 背景：源要求扩展列，但未定生效规则。 例：12月新增Deposit，11月Final输出是否仍用旧列schema？ 责任：Finance data owner。影响：决定版本与兼容。

## NEO-048 自动SAP付款输入取代KSB1手工上传

- **NEO-048-Q1 KSB1目前实际用哪个报表variant和列，数据owner提供哪一种自动方式？** 背景：PO查询接口没有付款所需字段证明。 例：Company+Fiscal Year+Document+Item能否唯一识别一条付款？ 责任：SAP FI/CO / Integration lead。影响：决定接口和主键。
- **NEO-048-Q2 同步到什么时间点才算本月完整，失败谁处理？** 背景：最后运行成功时间不能代替数据覆盖水位。 例：13日17:00运行成功但源只到12日，月结可以用吗？ 责任：Finance close / Operations。影响：决定SLA和Final门槛。
- **NEO-048-Q3 切换时旧手工行、冲销和迟到数据怎样去重？** 背景：旧文件和新接口可能包含同一交易。 例：同一SAP行已手工导入，自动重放时应跳过；次日冲销应另记关联事件。 责任：Finance data owner。影响：决定数据迁移和回归。

## NEO-055 Buyer Forecast Download多财年筛选与Excel格式

- **NEO-055-Q1 请列出最常用筛选和导出后现在要手工改的列？** 背景：源M56明确specifics needed。 例：需要按Buyer+Supplier导出两个FY，还是只看自己CoC的未实施机会？ 责任：Procurement report owner。影响：决定筛选范围和默认。
- **NEO-055-Q2 92列哪些保留、改名或新增，完整Excel样例由谁给？** 背景：Appendix H没有找到完整合同，不能凭页面复制。 例：Supplier Code必须文本以保留00123；Forecast Local与GBP要各有币种/口径。 责任：Procurement / BA / Finance。影响：决定schema验收。
- **NEO-055-Q3 多财年输出是同一表按FY列区分，还是每FY一张表？** 背景：FR只要求选一个或多个FY。 例：FY25/26及26/27的同一个ID是否各一行？ 责任：Procurement report owner。影响：决定粒度与可分析性。
- **NEO-055-Q4 Buyer Forecast允许哪些采购和财务角色使用？** 背景：当前代码复用finance-claim-report动作，不能确认Buyer权限。 例：Buyer只看自己的CoC，FBP看负责区域，还是其他范围？ 责任：Procurement / Access owner。影响：决定独立报表权限与行过滤。

## NEO-067 Claim列表导出增加已批准字段

- **NEO-067-Q1 具体是哪一个Claim列表，最需要新增哪几列？** 背景：实际All Claims已有23列/默认18列与Manage Columns；源未说明想要的字段是否已存在。 例：All Claims下载要Buyer、Team、Reporting Category，还是审批页面的Request字段？ 责任：Procurement owner。影响：决定入口和字段范围。
- **NEO-067-Q2 遇到一个Parent多个Line或一个Line多个Request时，要怎样显示？** 背景：直接join会重复金额。 例：Parent有3条Line、Line有2次Request，仍要每Line一行还是另表列Request？ 责任：Procurement / Reporting BA。影响：决定粒度和防重计。
- **NEO-067-Q3 哪些字段仅Finance能导出，空值应该怎样表示？** 背景：页面能看到部分字段不证明可批量下载全部。 例：Finance comments不可给Buyer时是完全不提供该列还是拒绝所选模板？ 责任：Data owner / Security。影响：决定列权限与文件兼容。