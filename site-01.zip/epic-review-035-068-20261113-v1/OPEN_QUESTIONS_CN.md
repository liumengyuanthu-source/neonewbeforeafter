# NEO-035–068 业务确认问题



问题只描述未定政策或缺少材料，不把原型候选行为作为业务已确认规则。



## NEO-035 ExWorks £m 与平均车 £pu：同口径展示和导出



### Q1 ExWorks平均车£pu究竟按哪一个金额除以哪一批车？

背景：现有字典同时有零件量与车辆量，公式未定。

例子：£m=1.20；用60,000辆为£20，用零件120,000件为£10，两个结果不能任选。

建议确认方：Finance / ExWorks owner

不确认的影响：决定公式、数据来源及接口



### Q2 新£pu是新增指标，还是要取代曾删除的旧PAM列？

背景：FR18明确允许删除5列£pu；新需求与旧范围不同。

例子：Avg_Car_PU_Impact是否仍不输出，只新增批准的ExWorksAverageCarGBP？

建议确认方：Finance / Reporting BA

不确认的影响：确定字段与兼容策略



### Q3 哪个团队提供可对账的数据版本，缺数或更新后如何发布？

背景：E2SC与Qlik方向不能证明已有ExWorks输入。

例子：10月v1与v2金额相同、车辆量变化，用户应能看到两个版本差异。

建议确认方：Finance data owner / Integration lead

不确认的影响：决定provider、截止时间和重跑规则



## NEO-036 异常处理责任与闭环规则



### 036-Q1 数据错、Digitide处理不了、已到付款日但没付款，分别由谁负责解决、谁最终确认关闭？

背景：E37未提供角色表且R37=Y。

例子：SAP价格不一致由Buyer补正还是数据团队；付款未到由AP调查还是FBP？

建议确认方：Procurement与Finance流程Owner

不确认的影响：任务路由和关闭权限



### 036-Q2 移交后对方未接手或超时，何时升级给谁？

背景：FR15只支持组内处理，跨组责任变化须明确。

例子：CBSL等Buyer回复两天，SLA暂停还是继续？

建议确认方：流程Owner及服务负责人

不确认的影响：受理、退回、计时和提醒



### 036-Q3 哪些材料足以关闭异常？

背景：关闭任务不能证明外部更新或支付。

例子：有邮件回复但没有SAP付款记录，是否仍保持待核对？

建议确认方：Finance控制Owner

不确认的影响：防止假闭环



## NEO-037 Memo实际汇率、过账状态与删除规则重核



### Q1 Memo使用哪一天、哪一类实际汇率，关闭月份能否重算？

背景：当前字段仍是预算汇率，Requested Changes要求actual。

例子：EUR100,000，预算0.85、实际0.86，使用哪一个日期的0.86？

建议确认方：Helen / Linda / Finance

不确认的影响：决定金额与历史冻结



### Q2 已过账Memo应由谁冲销，未过账Memo可否作废？

背景：删除不能抹去凭据；Confirmed不证明已过账。

例子：Memo M-037已在SAP有凭据，再发现重复，应关联反向分录还是次月调整？

建议确认方：Finance control / SAP owner

不确认的影响：决定状态和权限



### Q3 Memo是否仍跟随原Reserve的status或likelihood？

背景：P列明确以问题形式提出，未确认取消。

例子：原Reserve改为Closed后，独立Memo要保留、释放还是提示复核？

建议确认方：Helen / Linda

不确认的影响：决定金额触发与历史行为



## NEO-038 Maturity / Likelihood 与 G Gate 对齐



### NEO-038-Q01 谈判中且Probable应显示G几？Closed如何显示？

背景：ClaimValues存储maturity、likelihood两个字符串；创建页显示原字段。代码观察未建立G Gate版本化映射证据。BRD FR16把谈判成熟度与Workflow分开。

例子：例如Negotiation + Probable，不用示例猜成G3。

建议确认方：Jacob / Finance

不确认的影响：决定完整映射和未命中行为



### NEO-038-Q02 配置更新后，已批准Claim是否保留原G Gate？

背景：ClaimValues存储maturity、likelihood两个字符串；创建页显示原字段。代码观察未建立G Gate版本化映射证据。BRD FR16把谈判成熟度与Workflow分开。

例子：11月版本G2，12月新表G3。

建议确认方：Finance / Product Owner

不确认的影响：决定历史快照和重算范围



## NEO-039 币种变更自动计算起始价



### NEO-039-Q01 Currency-only应使用哪种率，取哪一天？

背景：PartPrices已有Resource/Currency条件下的直接价格修改。BRD明确预算率按年、月率按月；接口目录只证实Monex月率MFT，不能替代未确认的预算率。

例子：GBP 100转EUR，用年度预算率还是生效月月率？

建议确认方：Finance FX owner

不确认的影响：决定金额且阻止混率



### NEO-039-Q02 同一供应商的新GSDB如何证明相关？

背景：PartPrices已有Resource/Currency条件下的直接价格修改。BRD明确预算率按年、月率按月；接口目录只证实Monex月率MFT，不能替代未确认的预算率。

例子：同名Supplier A但两个代码，是否足够？

建议确认方：Vendor Master owner

不确认的影响：决定自动换码资格



## NEO-040 按用途精简Runout、ATP及币种字段



### NEO-040-Q01 FFP数量是否已经扣除Runout之后的产量？

背景：Runout及日期仍为可编辑字段，CalculationResults仍展示Runout影响；ATP在More options/特定WIPS上下文存在，Currency来自供应商上下文。直接删除可能改变金额。

例子：12月停产，全年量12,000是否已扣成9,000？

建议确认方：Finance / FFP owner

不确认的影响：防止重复扣量



### NEO-040-Q02 哪些交易仍需要ATP Reference？

背景：Runout及日期仍为可编辑字段，CalculationResults仍展示Runout影响；ATP在More options/特定WIPS上下文存在，Currency来自供应商上下文。直接删除可能改变金额。

例子：AMM与普通Price Claim是否不同？

建议确认方：CBSL / Procurement

不确认的影响：决定条件字段与模板



## NEO-041 同一零件单Claim支持多个Lever



### NEO-041-Q01 多个Lever金额是相加，还是依次按比例调整？

背景：ClaimValues与数据字典Claim均为单leverId/LEVER_ID；Reserve Team映射FR17.2以Lever和Reporting Category判定。因此不只是多选框。

例子：100元先+5%再-2%，结果102.90还是103？

建议确认方：Procurement / Finance

不确认的影响：决定公式和UI



### NEO-041-Q02 一个Claim含Inflation与Productivity时，Reserve归哪个Team？

背景：ClaimValues与数据字典Claim均为单leverId/LEVER_ID；Reserve Team映射FR17.2以Lever和Reporting Category判定。因此不只是多选框。

例子：风险+5与节约-2属于两个类别。

建议确认方：Finance

不确认的影响：决定归类和报表拆分



## NEO-042 AMM每Part支持超过3个Escalator



### NEO-042-Q01 WIPS每Part最终支持10条还是15条？

背景：现产品WipsPanel有ATP Reference与本地WIPS模拟入口；目录AA部署仅给string=null，未证实AMM指数结构或WIPS最大数。源Q43说10–15，受WIPS限制。

例子：第11条是允许、拒绝还是需人工？

建议确认方：WIPS / CBSL

不确认的影响：决定边界与异常流程



### NEO-042-Q02 每个指数必须提供哪些值，权重是否必须合计100%？

背景：现产品WipsPanel有ATP Reference与本地WIPS模拟入口；目录AA部署仅给string=null，未证实AMM指数结构或WIPS最大数。源Q43说10–15，受WIPS限制。

例子：5条各20%，一个缺基期。

建议确认方：AMM业务owner

不确认的影响：决定校验和公式



## NEO-043 精简CO2及创建校验



### NEO-043-Q01 CO2在报表或合规上还有实际消费者吗？

背景：当前Claim向导仍有CO₂ Data步骤；BRD将其定义为informational。Working BRD明确optional CO2和100字符描述的历史要求。

例子：只取消新录入，但2025年的CO2仍可查。

建议确认方：Procurement / Finance

不确认的影响：决定是否可移出向导



### NEO-043-Q02 描述必须回答哪些业务内容，能否替代100字符下限？

背景：当前Claim向导仍有CO₂ Data步骤；BRD将其定义为informational。Working BRD明确optional CO2和100字符描述的历史要求。

例子：原因+依据+影响三项已清楚但仅80字符。

建议确认方：Procurement / Clearing House

不确认的影响：决定提交校验



## NEO-044 NEO ID粒度Journal、Reserve和POA证据一致



### Q1 SAP mass upload每一行需要哪些列、哪个NEO ID字段和格式？

背景：源要求ID粒度但未提供SAP模板。

例子：同一NEO ID有Accrual与ST Prepayment，是否生成两组借贷、ID放Assignment还是Reference？

建议确认方：SAP FI owner / Finance

不确认的影响：决定输出schema和粒度



### Q2 哪些调整必须进入Final，哪些只能出现在后续调整版？

背景：要实现Report与Journal总额一致必须定义cutoff。

例子：Final v3后补£250，更新为v4还是独立postclose journal？

建议确认方：Finance close owner

不确认的影响：决定冻结/继承规则



### Q3 POA本月PPV与retro按哪个日期和版本归属？

背景：不能用Current Month总额替代PPV/retro证据。

例子：11月收货但追溯到9月生效的价格，归入哪一期？

建议确认方：POA Finance / SAP data owner

不确认的影响：决定明细计算与对账



## NEO-045 LSP财务组合自动派生及失败重试



### NEO-045-Q01 用哪些买家输入唯一确定财务组合？

背景：LSP字段已在创建页，由Material Group、Vehicle Line等参考选项提供输入；接口Id10已有companyCode、purchaseOrganization、glAccount、costCenter字段，不等于组合规则已实现。

例子：GB03 + Material Group MG01，是否还需Vehicle Line？

建议确认方：GFS / SAP Master Data

不确认的影响：决定表主键和无/多匹配处理



### NEO-045-Q02 PO超时但SAP实际已建单时，谁用什么字段查重？

背景：LSP字段已在创建页，由Material Group、Vehicle Line等参考选项提供输入；接口Id10已有companyCode、purchaseOrganization、glAccount、costCenter字段，不等于组合规则已实现。

例子：NEO无PO号，但SAP已有CLM-01。

建议确认方：SAP integration owner / Digitide

不确认的影响：防止重复PO



## NEO-046 Reporting Category单独决定Team及会计映射



### Q1 拆分后正式类别叫什么，每个类别映射哪一Team和科目？

背景：源只提RMA/AMM/PGM，P列详细规则待HJONES20。

例子：Contracted Raw Materials – AMM → AMM；旧记录是按Lever迁移还是逐条确认？

建议确认方：Helen / Finance master-data owner

不确认的影响：决定映射与迁移



### Q2 手工Override Team还保留吗，什么时候优先？

背景：ACT-028与共享映射ACT-035是不同动作。

例子：Category映射RMA但某条Line曾override TVM，规则更新后保留哪个？

建议确认方：Finance control

不确认的影响：决定例外与审计



### Q3 新规则从哪个月开始，已Final和已发PO是否保持？

背景：历史重写会破坏审计和SAP对账。

例子：12月生效，新规则是否影响11月Final v2？

建议确认方：Finance close / SAP owner

不确认的影响：决定切换范围



### Q4 Team只看Category后，原034的Category与Lever合法配对还要继续检查吗？

背景：既有034方案明确配对合法性不等于Team/科目映射。

例子：同一个Category已确定RMA，但用户选了不允许的Lever，是否仍阻止保存？

建议确认方：Finance / Procurement owners

不确认的影响：协调两条规则，不能因为简化Team而静默取消034



## NEO-047 同一Reserve输出完整BS及IS会计分录



### Q1 旧FR里的Receivable是否仍要独立一列？

背景：新P列列举6种，但没有明确删除旧Receivable。

例子：供应商余额不足产生Receivable时，应放Receivable还是Loan？

建议确认方：Finance accounting owner

不确认的影响：决定完整性，不能猜分类



### Q2 同一ID不同账户的正负号及IS总额怎么定义？

背景：页面加总不能代替会计规则。

例子：Accrual 120,000及ST Prepayment 20,000，IS是140,000还是按借贷方向计算？

建议确认方：Finance accounting owner

不确认的影响：决定投影、对账和金样



### Q3 新增BS类型由谁配置、何时进入报表？

背景：源要求扩展列，但未定生效规则。

例子：12月新增Deposit，11月Final输出是否仍用旧列schema？

建议确认方：Finance data owner

不确认的影响：决定版本与兼容



## NEO-048 自动SAP付款输入取代KSB1手工上传



### Q1 KSB1目前实际用哪个报表variant和列，数据owner提供哪一种自动方式？

背景：PO查询接口没有付款所需字段证明。

例子：Company+Fiscal Year+Document+Item能否唯一识别一条付款？

建议确认方：SAP FI/CO / Integration lead

不确认的影响：决定接口和主键



### Q2 同步到什么时间点才算本月完整，失败谁处理？

背景：最后运行成功时间不能代替数据覆盖水位。

例子：13日17:00运行成功但源只到12日，月结可以用吗？

建议确认方：Finance close / Operations

不确认的影响：决定SLA和Final门槛



### Q3 切换时旧手工行、冲销和迟到数据怎样去重？

背景：旧文件和新接口可能包含同一交易。

例子：同一SAP行已手工导入，自动重放时应跳过；次日冲销应另记关联事件。

建议确认方：Finance data owner

不确认的影响：决定数据迁移和回归



## NEO-049 SAP ECC容器合同任务交接Digitide



### 049-Q1 EPMC、BAC、TD分别自动交Digitide，还是Buyer先确认再交？

背景：Q50同时提供两种可能，FR14 TD原来给Buyer。

例子：TD已批后直接进入Digitide队列是否保留Buyer确认？

建议确认方：Procurement流程Owner及Digitide服务Owner

不确认的影响：路由、授权及上线范围



### 049-Q2 Digitide建容器合同最少需要哪些字段和附件？

背景：来源要求all required information但未列完整模板。

例子：是否必须采购组织、供应商、物料、有效期、批准价格及签署协议？

建议确认方：SAP ECC业务Owner、Digitide

不确认的影响：前后端校验和拒绝/补资料



### 049-Q3 输入合同号就算完成，还是要等合同释放或价格生效？

背景：UC-20要求external evidence，编号存在不代表所有行生效。

例子：合同00004567已创建但两行被拒绝，NEO状态应如何显示？

建议确认方：Finance与SAP ECC控制Owner

不确认的影响：完成门槛及逐行对账



### 049-Q4 原需求的EPMC与BRD里的EMC是否指同一分支？

背景：Requested Changes写EPMC，工作BRD UC-20写EMC；不能直接把名称归一。

例子：若EPMC是新的SAP ECC组织范围，应明确适用公司和采购组织。

建议确认方：SAP ECC业务Owner

不确认的影响：分支映射、任务生成及数据选择



## NEO-050 Clearing House完成、Request批准和实施状态分开



### 050-Q1 所有人批准了，但FBP还没点Complete时，Request列显示什么？

背景：Q51只明确未集齐批准保持In Approval；全部批准未Complete的名称未单列。

例子：DoA=Approved、CH=Awaiting Completion时，Request显示In Approval还是Awaiting Clearing House Completion？

建议确认方：Finance流程Owner

不确认的影响：状态映射、筛选和导出一致



### 050-Q2 三条Line中两条批准、一条拒绝时，Complete和实施放行分别覆盖哪两条？

背景：FR10.6及NQA-97已有部分批准规则，不能全请求假定Approved。

例子：MCI-00057/58批准，59拒绝；只能按确认政策推进批准子集。

建议确认方：Procurement/Finance流程Owner

不确认的影响：多Line门槛及历史迁移



## NEO-051 按有效期委托DoA并保留原审批人



### 051-Q1 休假期间委派的是当前这一项，还是这个人的所有现有和新审批？

背景：当前POC按taskId/requestVersion保存；原需求说delegate their DOA level for a certain time period。

例子：周一设置到周五，周三新来一项是否自动给代理？

建议确认方：审批政策Owner

不确认的影响：数据模型、页面范围和新任务路由



### 051-Q2 “相差一级”包括同级、上一级和下一级吗？各级正式先后顺序是什么？

背景：POC有固定级别数组，不能作为企业政策。

例子：同级候选、相邻候选、跨两级候选分别应允许哪个？

建议确认方：Procurement/Finance DoA Owner

不确认的影响：候选名单和授权校验



### 051-Q3 谁可以替别人设置委派，到期时未完成审批交回谁？

背景：Training为FBP/FA维护；源需求说users delegate their own level。

例子：原审批人已离职，代理期结束，不能恢复到失效账号。

建议确认方：Access Owner与流程Owner

不确认的影响：委派管理权和恢复规则



## NEO-052 Global Commodity Lead Area保留或移除决策



### NEO-052-Q01 最终保留可维护列表，还是从新Claim移除该字段？

背景：原E53要求maintainable列表；Q53要求remove field；R53=Y。Training335支持编辑/停用列表。ClaimValues和数据库有commodityLeadAreaId，不可当已批准删除。

例子：E53新增Software等；Q53完全删除字段。请选择一个目标。

建议确认方：Procurement / Finance

不确认的影响：否则开发验收方向相反



### NEO-052-Q02 历史报表还需要按这个分类筛选吗？

背景：原E53要求maintainable列表；Q53要求remove field；R53=Y。Training335支持编辑/停用列表。ClaimValues和数据库有commodityLeadAreaId，不可当已批准删除。

例子：旧Claim的Plastic Moulds能否仍筛选导出？

建议确认方：Reporting owner

不确认的影响：决定兼容策略



## NEO-053 简化Inflation类型及条件字段



### NEO-053-Q01 具体停用哪些Inflation类型，从何时生效？

背景：当前Inflation支持多个类型/材料、单位、Base/New Rate；activeReferenceChoices已支持活动选项。源未指出究竟移除Energy、Raw Materials等哪项。

例子：Freight、Labour是完全停用还是仅某组织不用？

建议确认方：Procurement / Finance

不确认的影响：决定列表和生效策略



### NEO-053-Q02 有在途Claim使用已停用类型时可否继续Settlement？

背景：当前Inflation支持多个类型/材料、单位、Base/New Rate；activeReferenceChoices已支持活动选项。源未指出究竟移除Energy、Raw Materials等哪项。

例子：旧Labour行有已签协议及费率。

建议确认方：Finance / Clearing House

不确认的影响：避免迁移后流程卡死



## NEO-054 FTO / FFP数据准确性与缺口恢复



### NEO-054-Q01 FTO和FFP各由谁提供，文件是全FY替换还是增量？

背景：Fto.tsx已有上传校验、按FY替换、文件历史及有原因改量。UC-07要求FTO四维匹配且缺失不是零；当前OFFLINE合成源不证明生产FTO/FFP准确。

例子：本日少了一个Part，表示删除、零量还是漏数？

建议确认方：FTO / FFP data owner

不确认的影响：决定摄取与缺失判断



### NEO-054-Q02 四维匹配失败时允许哪些人在何处改量？

背景：Fto.tsx已有上传校验、按FY替换、文件历史及有原因改量。UC-07要求FTO四维匹配且缺失不是零；当前OFFLINE合成源不证明生产FTO/FFP准确。

例子：同零件SOL有量、HAL缺量，不能借用SOL的量。

建议确认方：Finance / Data owner

不确认的影响：决定权限和修复流程



## NEO-055 Buyer Forecast Download多财年筛选与Excel格式



### Q1 请列出最常用筛选和导出后现在要手工改的列？

背景：源M56明确specifics needed。

例子：需要按Buyer+Supplier导出两个FY，还是只看自己CoC的未实施机会？

建议确认方：Procurement report owner

不确认的影响：决定筛选范围和默认



### Q2 92列哪些保留、改名或新增，完整Excel样例由谁给？

背景：Appendix H没有找到完整合同，不能凭页面复制。

例子：Supplier Code必须文本以保留00123；Forecast Local与GBP要各有币种/口径。

建议确认方：Procurement / BA / Finance

不确认的影响：决定schema验收



### Q3 多财年输出是同一表按FY列区分，还是每FY一张表？

背景：FR只要求选一个或多个FY。

例子：FY25/26及26/27的同一个ID是否各一行？

建议确认方：Procurement report owner

不确认的影响：决定粒度与可分析性



### Q4 Buyer Forecast允许哪些采购和财务角色使用？

背景：当前代码复用finance-claim-report动作，不能确认Buyer权限。

例子：Buyer只看自己的CoC，FBP看负责区域，还是其他范围？

建议确认方：Procurement / Access owner

不确认的影响：决定独立报表权限与行过滤



## NEO-056 按企业DoA生成必需审批，明确例外加签



### 056-Q1 企业DoA最新批准版在哪里？请给一笔好消息和一笔坏消息Settlement的正确审批名单。

背景：M/Q57要求去掉额外审批，R57明确需要双方对齐。

例子：相同绝对金额的Opportunity和Risk，是相同审批人还是不同路径？

建议确认方：企业DoA Owner、Procurement和Finance

不确认的影响：路由正确性及开发验收基准



### 056-Q2 “不增加额外审批”是否仍允许FBP有理由上调、或特殊事项加签？

背景：Q57与FR10.2和NEO-063存在需要明确的政策边界。

例子：矩阵只要求两步，但一笔法律例外需专家复核，是否允许？

建议确认方：Procurement/Finance审批政策Owner

不确认的影响：056与063验收不能互相矛盾



### 056-Q3 新DoA生效后，已提交的请求保持旧路线还是重新判断？

背景：当前配置和冻结请求版本须一致。

例子：周二提交，周三更换矩阵，周四批准按哪版？

建议确认方：审批政策Owner

不确认的影响：在途升级、重新批准与审计



## NEO-057 开放任务状态、当前责任人与逾期提醒



### 057-Q1 哪些开放任务需要提醒？逾期后多久提醒一次，提醒给谁？

背景：TD既有调度不是所有Task/Action/Approval的策略。

例子：审批逾期一天提醒当前人；组内未领取时提醒谁？

建议确认方：流程Owner及Notification Owner

不确认的影响：事件范围、收件人和频率



### 057-Q2 SLA按自然日还是工作日？用哪个地区假期、工作时间和时区？

背景：源码固定毫秒单位；FR21仅说days。

例子：周五17点到期，周末和中国/英国假日怎么处理？

建议确认方：流程Owner

不确认的影响：Due计算和超时边界



### 057-Q3 TD提醒以创建次日为准，还是每周二和周四为准？

背景：调度源同一行描述与频率不一致。

例子：周四创建的任务应周五发还是下周二发？

建议确认方：TD流程Owner/应用支持

不确认的影响：复用旧scheduler前必须解冲突



## NEO-058 已批准POA逐项实施、核对与恢复



### 058-Q1 每个系统用什么回执或查询结果证明每个零件、价格及生效日已实施？

背景：目录只证明接口候选存在，没有完整逐项合同。

例子：WIPS-0042返回success但一行仍12.30000而批准12.50000，应拒绝关闭。

建议确认方：WIPS/AA、SAP ECC、S4接口Owner

不确认的影响：完成门槛和自动对账



### 058-Q2 超时查不到结果时，谁能核对原操作？现有系统支持按什么键查重？

背景：未知结果不得直接新建或重试。

例子：WIPS建单超时，需按原correlation/业务键查是否已建，不能再建第二张。

建议确认方：Integration Owner及Digitide

不确认的影响：幂等、未知恢复及人工锁



### 058-Q3 审批前哪些差异必须挡住，批准后哪些变化必须重批？

背景：Q59说where possible，未定义允许的源价格变化与容差。

例子：批准后源价格12.30000变12.40000，是否重新计算差额并重批？

建议确认方：Procurement/Finance政策Owner

不确认的影响：预校验、版本和财务正确性



### 058-Q4 已有“任务完成但ID等待实施”的记录如何修复，谁批准修复？

背景：M59是已报告业务缺陷；本轮无真实记录可复现。

例子：CBSL已完成但无外部回执，先建核对任务还是重开原任务？

建议确认方：应用支持与Finance控制Owner

不确认的影响：历史修复方案及迁移边界



## NEO-059 混合涨跌价及相关GSDB的统一谈判视图



### NEO-059-Q01 可接受一个Parent下面保留多个Line吗？

背景：当前Claim单kind、单vendorCode；Working BRD CLM-02历史要求不同方向分开linked claims。Q60多代码同供应商明确提出Parent改善，不能直接把Parent删除。

例子：UK100 GBP风险+1000；EU100 EUR机会折合-1200，Parent净机会-200。

建议确认方：Procurement / Finance

不确认的影响：决定是否需重构Line



### NEO-059-Q02 DoA按净200，还是正负两侧较大金额1200判断？

背景：当前Claim单kind、单vendorCode；Working BRD CLM-02历史要求不同方向分开linked claims。Q60多代码同供应商明确提出Parent改善，不能直接把Parent删除。

例子：抵消后净额很小但实际价格变动较大。

建议确认方：Finance / DoA owner

不确认的影响：决定审批风险和金额



## NEO-060 复用Copy Claim并补齐复制边界



### NEO-060-Q01 复制时哪些字段和附件必须保留，哪些必须清空？

背景：当前React存在Copy existing Claim，调用canViewSource/startCopy；source来自fixtures数组。UC-03和ENH-001已明确不复制审批执行历史。仅代码观察，当前产品动态持久化未在本轮执行。

例子：同供应商新年度协议，旧价格和签字附件能否带入？

建议确认方：Procurement / Security

不确认的影响：决定白名单和误用风险



### NEO-060-Q02 源Claim被撤销或访问权收回后，保存新草稿怎么办？

背景：当前React存在Copy existing Claim，调用canViewSource/startCopy；source来自fixtures数组。UC-03和ENH-001已明确不复制审批执行历史。仅代码观察，当前产品动态持久化未在本轮执行。

例子：复制后尚未保存，权限已撤销。

建议确认方：Product / Security

不确认的影响：决定保存时再校验



## NEO-061 完善Parts搜索筛选及数据范围



### NEO-061-Q01 车系按零件适配还是按当年生产计划筛选？

背景：当前SelectParts已有supplier scoped catalogue、company/plant、part number search、vehicle/model year、跨页选择及来源变更处理。增量不是从零加筛选；实际API目录只证明vendor/plant/offset/limit。

例子：同Part适配Defender，但本年HAL不生产。

建议确认方：Procurement / Part Master owner

不确认的影响：决定过滤含义



### NEO-061-Q02 真实最大结果和常用筛选组合是什么？

背景：当前SelectParts已有supplier scoped catalogue、company/plant、part number search、vehicle/model year、跨页选择及来源变更处理。增量不是从零加筛选；实际API目录只证明vendor/plant/offset/limit。

例子：一个GSDB下2万part–plant，用户常查哪些字段？

建议确认方：Procurement / SAP API owner

不确认的影响：决定服务端过滤与分页



## NEO-062 价格差计算明细与缺失解释



### NEO-062-Q01 这里price gap指单价差，还是含量后的年度差额？

背景：CalculationResults已有Start/New price、GBP delta、年度/Calendarised和Runout；Calculation.tsx有来源和stale提示。新增重点是可解释链条与错误定位，不是重复新增一张汇总表。

例子：100→105 GBP是5 GBP/part，12,000量后60,000 GBP。

建议确认方：Finance / Procurement

不确认的影响：决定标题/单位/公式



### NEO-062-Q02 缺量时允许显示单价差并把总额标Incomplete吗？

背景：CalculationResults已有Start/New price、GBP delta、年度/Calendarised和Runout；Calculation.tsx有来源和stale提示。新增重点是可解释链条与错误定位，不是重复新增一张汇总表。

例子：单价齐全但FTO为空，不能总额=0。

建议确认方：Finance

不确认的影响：决定部分可用结果



## NEO-063 按Before/After顺序增加必需审阅



### 063-Q1 谁能加签，哪些人可作为必需审阅人？

背景：FR22 D22-04未定；资深职称不是自动授权。

例子：普通审批人可找法务复核吗，还是仅FBP可新增？

建议确认方：流程Owner和Access Owner

不确认的影响：按钮与候选权限



### 063-Q2 额外审阅拒绝一条Line时，要退哪几条、退给谁？

背景：不能自行推定整份Request终止。

例子：三条Line中只复核MCI-00057；拒绝后另外两条是否继续？

建议确认方：Procurement/Finance流程Owner

不确认的影响：依赖、部分批准及恢复路径



### 063-Q3 这次是必须完成的审阅，还是仅征求意见？

背景：FR22.3区分required review与advisory consultation。

例子：法务仅提供建议是否应阻挡下游？

建议确认方：请求Owner/审批政策Owner

不确认的影响：不要把可忽略建议做成强制审批



## NEO-064 单项审批转办与限时委派分开



### 064-Q1 “合适的同事”具体需要哪些角色、DoA、CoC和职责分离条件？

背景：同组、同职称或资深不等于具备当前审批责任。

例子：同一CoC同级但也是该Request申请人，不能据此放行。

建议确认方：DoA与Access Owner

不确认的影响：收件人校验



### 064-Q2 原审批人失联时，谁能替他转办？是否允许转回？

背景：FR22目标为当前assignee转办；恢复例外未批准。

例子：原人已离职且无法点Transfer，谁可接手操作？

建议确认方：流程Owner和Access Owner

不确认的影响：异常恢复角色



### 064-Q3 转办是否仅Mandate/Settlement审批？CBSL、GFS、AP沿用各自规则吗？

背景：FR22 scope未自动扩展到其他request/CBSL；Training已有同组改派。

例子：GFS检查转办不可借用DoA审批候选名单。

建议确认方：各任务流程Owner

不确认的影响：范围边界与跨Epic验收



## NEO-065 CBSL案件协作、受理与进度追踪



### 065-Q1 CBSL和Digitide在这项工作里是同一团队/同一账号组吗？谁维护成员？

背景：源文本名称并用，但没有确认组织身份映射。

例子：一个Digitide新人加入是否自动成为CBSL候选、能看哪些CoC？

建议确认方：Service Owner与IAM Owner

不确认的影响：候选人、授权与账号离职



### 065-Q2 “直接分配到case”是承担一个任务，还是成为持续协作者？

背景：两者生命周期和权限不同。

例子：CBSL已完成建合同，后续Buyer改信息时该成员还可评论或看到新附件吗？

建议确认方：Procurement及Access Owner

不确认的影响：case membership和访问期限



### 065-Q3 保密案件可以交给哪些CBSL成员？任务领取是否需要额外授权？

背景：现有源码保密access检查必须保留。

例子：非授权同组成员不能因看到队列就打开保密价格附件。

建议确认方：信息Owner与Access Owner

不确认的影响：数据泄露防护和候选筛选



## NEO-066 大量Parts处理性能与可靠恢复



### NEO-066-Q01 最慢案例有多少Part–Plant行，在哪一步超时？

背景：当前Calculation有本地input check job registry、retry same frozen input，清楚提示其不代表财务有效。没有生产并发/延迟证据；不能据此称大批量问题已解决。

例子：2万行加载慢，还是提交后5分钟没有结果？

建议确认方：Procurement / Operations

不确认的影响：定位性能阶段



### NEO-066-Q02 业务可接受多久看到已保存/最终结果？

背景：当前Calculation有本地input check job registry、retry same frozen input，清楚提示其不代表财务有效。没有生产并发/延迟证据；不能据此称大批量问题已解决。

例子：先返回受理号、几分钟后完成是否可接受？

建议确认方：Product / Operations

不确认的影响：决定SLO和同步/异步



## NEO-067 Claim列表导出增加已批准字段



### Q1 具体是哪一个Claim列表，最需要新增哪几列？

背景：实际All Claims已有23列/默认18列与Manage Columns；源未说明想要的字段是否已存在。

例子：All Claims下载要Buyer、Team、Reporting Category，还是审批页面的Request字段？

建议确认方：Procurement owner

不确认的影响：决定入口和字段范围



### Q2 遇到一个Parent多个Line或一个Line多个Request时，要怎样显示？

背景：直接join会重复金额。

例子：Parent有3条Line、Line有2次Request，仍要每Line一行还是另表列Request？

建议确认方：Procurement / Reporting BA

不确认的影响：决定粒度和防重计



### Q3 哪些字段仅Finance能导出，空值应该怎样表示？

背景：页面能看到部分字段不证明可批量下载全部。

例子：Finance comments不可给Buyer时是完全不提供该列还是拒绝所选模板？

建议确认方：Data owner / Security

不确认的影响：决定列权限与文件兼容



## NEO-068 多年生产率协议与逐年履行



### NEO-068-Q01 每年生产率降幅基于原价，还是上一年已降后的价？

背景：ClaimValues只有fiscalYearId，MYA Reference是文本引用，不是多年履约模型；Reserve/Auto PAM按财年和期间消费，不能简单把FY改多选。

例子：100元每年-2%，三年是98/96/94还是98/96.04/94.1192？

建议确认方：Procurement / Finance

不确认的影响：决定金额和精度



### NEO-068-Q02 一次批准整个协议，还是每年金额单独批准？

背景：ClaimValues只有fiscalYearId，MYA Reference是文本引用，不是多年履约模型；Reserve/Auto PAM按财年和期间消费，不能简单把FY改多选。

例子：2027–2029承诺中2028量尚未确定。

建议确认方：Finance / DoA owner

不确认的影响：决定审批与未到期执行

