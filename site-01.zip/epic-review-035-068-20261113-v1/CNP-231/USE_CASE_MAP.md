# CNP-231 UC定位与差量

仅038/039/040/041/042/043/045/052/053/054/059/060/061/062/066/068。原001–034未重评、未修改。

UC来自工作BRD A.8，属于工作用例而非签署验收。ACT来自现有Story输入；没有生成官方UC/ACT编号。direct=当前UC动作直接覆盖；related=仅相关上下游；所有新增细节使用NEO-###-S##本地别名。

|需求|已核对UC|新增/修正|
|---|---|---|
|NEO-038|UC-02 related, UC-09 related|新增输入组合→G0–G5、未映射、版本生效及历史回读场景。原UC仅覆盖输入，不包含G Gate映射。|
|NEO-039|UC-02 related, UC-05 related, UC-07 related|新增同一供应商不同GSDB币种、汇率类型/日期、舍入与缺率场景。|
|NEO-040|UC-05 direct, UC-06 related, UC-07 related|需新增字段移除/条件显示与历史值及计算影响的差量场景；UC-06不代表授权恢复已停用的Parts Excel导入。|
|NEO-041|UC-02 related, UC-10 related, UC-18 related, UC-23 related|新增同一part/plant多Lever价格分量、叠加/复合方式、归类与审批快照场景。|
|NEO-042|UC-02 related, UC-05 related, UC-20 related|UC-20明确AMM/ATP及复杂工作表；新增可变10–15边界的结构化指数、校验与下游回执场景。|
|NEO-043|UC-02 direct, UC-10 direct|覆盖CO2从新录入移除但历史保留，以及description最低长度的业务确认差量。|
|NEO-045|UC-09 direct, UC-21 related|新增有效期组合匹配、无/多命中、master-data纠正及PO未知结果对账重试。|
|NEO-052|UC-02 related, UC-24 related|E53要求可维护列表、Q53要求移除，必须决策。现UC不覆盖停用输入后的历史/报告影响。|
|NEO-053|UC-10 direct|需要逐类型退役、生效日期、旧行重开及在途Settlement影响场景。|
|NEO-054|UC-07 direct, UC-23 related|新增真实来源版本、四维键、FFP独立缺失、全量/增量、迟到/重复和修复回读。|
|NEO-059|UC-02 related, UC-18 related, UC-23 related|E60净额自动定Risk/Opp，Q60相关多GSDB并建议Parent；原CLM-02要求分开关联，需新商业模型/审批口径场景。|
|NEO-060|UC-03 direct, UC-02 related|不是全新UC；需覆盖真实可访问源、复制字段清单、重新取主数据、重复点击/保存/重开。|
|NEO-061|UC-04 direct, UC-06 related|补UC-04直接映射；新增服务端过滤/分页、跨页选择保持、车系语义及来源失败。|
|NEO-062|UC-07 direct, UC-24 related|新增行级公式/金额/版本解释、missing与zero以及更正后重算和导出一致。|
|NEO-066|UC-04 related, UC-07 related, UC-08 direct|补UC-08直接场景；需真实规模基线、重复开始、刷新续查、超时已提交、部分失败及取消。|
|NEO-068|UC-02 related, UC-18 related, UC-23 related, UC-24 related|现UC单FY/期间场景不能证明多年；新增年度计划、重叠生效期、复利基价、逐年审批/实施及协议修订。|

关键源冲突：052 E53维护列表 / Q53移除字段；059 E60混合涨跌价 / Q60多相关GSDB及Parent改善；042 Q43上限10–15需WIPS确认。040的历史UC-06不授权恢复当前已停用的Parts Excel导入。

当前代码仅做只读检视；没有运行产品或写Jira。