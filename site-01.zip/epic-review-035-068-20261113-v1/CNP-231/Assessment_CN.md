# CNP-231 建档与数据：16项完整评估


状态：独立方案，可评审；所有产品、接口、UAT场景NOT RUN。英文页面数据均为合成样例，映射/金额示例不构成业务规则。没有修改当前原型、源Excel、Jira或唯一QA总表。


原始来源优先级与建议排期分列。sourceTarget保留P，sourceTargetQ保留Q。源冲突须业务owner决定；示例参数仅用于方案交互。


## NEO-038 Maturity / Likelihood 与 G Gate 对齐

来源：8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx / RTM for Requested Changes / row 39。采购=空；Finance=Could。建议 **P1**：源Finance Could，但同时影响采购/Finance口径，应先锁定映射再排实现。

**原E**：Simplify and commonise likeihood / maturity language & classification used across NEO with other Finance process/applications. Detailed requirements would be required. Jacob.

**原P**：As a finance user - based on the maturity & likeihood input by the user I want to show the G Gate status as an output to the users. (Calculated automatically based on tables in background)

**原Q**：As a procurement user I want to see / use the same maturity staus as aligned in supplier negotiation to the G0 to G5 status in Ex Works.

**UC定位**：UC-02 (related), UC-09 (related)。新增输入组合→G0–G5、未映射、版本生效及历史回读场景。原UC仅覆盖输入，不包含G Gate映射。

**当前基线（代码观察）**：ClaimValues存储maturity、likelihood两个字符串；创建页显示原字段。代码观察未建立G Gate版本化映射证据。BRD FR16把谈判成熟度与Workflow分开。

**建议方案**：建议保留原成熟度和可能性，在Finance维护的生效期映射表上只读派生G Gate。未命中显示Not mapped并允许保存草稿；是否阻止Mandate由Finance确认。不得直接将G Gate当工作流状态。

**主要性质**：应用内部前后端、配置与审计。**架构判断**：版本化内部规则表即可，不需新平台。

**ACT核验**：ACT-001 Create Claim [FR1; FR1.1–FR1.6] existing action retained; requirement-specific gaps in UC map；ACT-004 Update Claim [FR6; FR6.1] existing action retained; requirement-specific gaps in UC map；补充候选：ACT-051 Reference data

- ux：原两项选择后显示G Gate及生效日期；缺映射给Finance处理入口。

- frontend：调用同一派生结果，摘要、编辑、导出一致；不在多个页面各写一套映射。

- backend：按公司/期间/成熟度/可能性解析唯一有效映射，检测重叠和无命中。

- data：新增版本化映射及结果快照；旧Claim保留原代码与当时版本。

- workflow：已审批版本不因配置更新静默变更；提交时重新核验当前适用版本。

**集成**：无需为语言对齐新增接口；只有确认Ex Works为权威实时状态源后才另审。

提供方：Finance/Jacob提供映射业务表；NEO维护；方向：内部配置→Claim→Finance报告

复用证据：复用Claim字段、Reference Data维护/审计能力；无现成G Gate契约证明。

未知契约：G0–G5完整矩阵、Closed映射、是否按组织或财年不同。

**前置材料/依赖**：Jacob/Finance完整G0–G5矩阵，包含无效/Closed组合；确认公司/财年生效范围与版本切换、已审批历史处理

**相关需求（不重评）**：

**既有结论链接**：

**页面编号边界**：id沿用INPUT_SCOPE中的历史Training页面映射；斜杠分别表示创建/更新或相关页面，不是一个路由ID。React实际组件由source列定位。此轮未重新核验历史截图页号。

**问题**：

- NEO-038-Q01 谈判中且Probable应显示G几？Closed如何显示？ 例如：例如Negotiation + Probable，不用示例猜成G3。 Owner：Jacob / Finance；影响：决定完整映射和未命中行为

- NEO-038-Q02 配置更新后，已批准Claim是否保留原G Gate？ 例如：11月版本G2，12月新表G3。 Owner：Finance / Product Owner；影响：决定历史快照和重算范围

**验收设计，未执行**：

- NEO-038-S01；角色Buyer Alice；前提权限已核验；测试业务规则/金样已批准；使用隔离数据；输入Maturity=Negotiation；Likelihood=Probable；经批准测试表v1映射G2；操作选择组合 → 保存并重新打开；预期显示G2及v1；原两个输入保持；原审批快照不变；实际=null；NOT RUN。

- NEO-038-S02；角色Buyer Alice；前提同一隔离记录；具备故障/缺失条件；输入选择未映射组合 Placeholder + Closed；操作执行受影响动作 → 再重新打开已保存记录；预期显示Not mapped，保留输入，不假造G Gate；实际=null；NOT RUN。

- NEO-038-S03；角色Buyer Alice / unauthorised Bob；前提非授权用户Bob；Alice已把记录由revision7保存到8；输入Bob尝试修改；Alice旧页面仍携带revision7；操作分别提交旧版本/无权限请求；预期服务端拒绝；不泄露受限内容；保留授权编辑缓冲；重新载入后只见revision8，不能覆盖已批准快照；实际=null；NOT RUN。

**来源证据**：

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E39：「Simplify and commonise likeihood / maturity language & classification used across NEO with other Finance process/applications. Detailed requirements would be required. Jacob.」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!L39：「Could」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!P39：「As a finance user - based on the maturity & likeihood input by the user I want to show the G Gate status as an output to the users. (Calculated automatically based on tables in background)」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!Q39：「As a procurement user I want to see / use the same maturity staus as aligned in supplier negotiation to the G0 to G5 status in Ex Works.」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!R39：「Y」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 206–212 (zero-based), A.8 UC-02：「Normal path. Enter core details, notification, POA dates and estimates; add evidence; save or submit to Created.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 255–261 (zero-based), A.8 UC-09：「Normal path. Capture transaction dates and estimates, then complete the applicable Lump Sum Data and supplier facing PO Description.」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 4 (zero-based table 5 / row 3)：「FR1.2 | Create Risk/ Opportunity – Line Item Level Data Capture | Context: Following on from FR1.1. The below data will be captured at a line-item level (similar to the current AS IS FIND solution).
An interface should b」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 41 (zero-based table 5 / row 40)：「FR16 | Workflow | Context: All line items within the solution will go through the following workflow steps.
The workflow should go through the following steps:
Line Item Created
Supplier Negotiations – Track Milestone (M」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A714:O714：「MCI_RISK_OPPORTUNITY | 索赔 | 业务 | MILESTONE_ID | int(11) | integer | 是 |  | FK | MCI_REF_MILESTONE | MILESTONE_ID | 已建 | 否 | Primary key of MCI_MILESTONE | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A716:O716：「MCI_RISK_OPPORTUNITY | 索赔 | 业务 | LIKELIHOOD_ID | int(11) | integer | 是 |  | FK | MCI_REF_LIKELIHOOD | LIKELIHOOD_ID | 已建 | 否 | Primary key of MCI_LIKELIHOOD | 结构+字典」

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p02/contracts.ts` / line 12：「export type ClaimValues=ClaimAlignmentValues&{transactionDrivers?:string;nonStandardTransactionKind?:string;priceCurrency?:string;buyerCode:string;nonStandardTransaction:boolean;dummy:boolean;paymentReleaseDate:string;bu」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=1] / name, fr, area：「Create Claim | FR1; FR1.1–FR1.6 | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=4] / name, fr, area：「Update Claim | FR6; FR6.1 | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=51] / name, fr, area：「Reference data | FR19 and sub-FRs | Claims and data」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR18-039：「Milestone / Maturity Status」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR18-044：「Calendarised Forecast Local*」

现有QA引用：FR18-039, FR18-044；只链接，不重记PASS。

页面：[English proposal](pages/NEO-038.html)；[Desktop](screenshots/NEO-038-desktop.png)；[Narrow](screenshots/NEO-038-narrow.png)。


## NEO-039 币种变更自动计算起始价

来源：8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx / RTM for Requested Changes / row 40。采购=Could；Finance=空。建议 **P1**：源Could；错误起始价影响后续金额，先做受控预览和缺率阻断。

**原E**：When completing a currency only resource with the same supplier, can NEO utilise the correct JLR FX rate (budget?) to calculate the new start price automatically based on the FX rate for the new supplier code.


**原P**：空

**原Q**：As a Procurement User, I need NEO to automatically calculate the updated start price using the applicable JLR FX rate for the selected supplier code when processing a currency-only resource change, so that pricing remains accurate and consistent without manual calculation

**UC定位**：UC-02 (related), UC-05 (related), UC-07 (related)。新增同一供应商不同GSDB币种、汇率类型/日期、舍入与缺率场景。

**当前基线（代码观察）**：PartPrices已有Resource/Currency条件下的直接价格修改。BRD明确预算率按年、月率按月；接口目录只证实Monex月率MFT，不能替代未确认的预算率。

**建议方案**：为Currency-only Resource提供可审阅的转换预览：旧GSDB币种/原价→所选新GSDB币种/换算起始价。固定率类型、有效期、方向、精度，用户确认后应用；缺率保留原价且禁止应用。

**主要性质**：应用计算＋现有汇率/供应商数据复用。**架构判断**：在现有价格计算服务增加可追踪换算，不需要独立汇率平台。

**ACT核验**：ACT-001 Create Claim [FR1; FR1.1–FR1.6] existing action retained; requirement-specific gaps in UC map；ACT-004 Update Claim [FR6; FR6.1] existing action retained; requirement-specific gaps in UC map；补充候选：

- ux：在Part Prices选择新GSDB，显示转换公式、率基准和Preview / Apply。

- frontend：金额小数输入及多行预览，取消不改价，修改GSDB使旧预览失效。

- backend：统一高精度转换与货币方向；服务端重查供应商关系、汇率版本和乐观锁。

- data：保存旧/新GSDB、币种、原价、新起始价、rateId/rateType/asOf及rounding。

- workflow：当前价基础变化使计算和未提交审批草稿失效，已批准记录走更正路径。

**集成**：复用MCI_getVendorDetails及已确认适用的汇率输入；不自动新增Monex API。

提供方：SAP Vendor Master；Finance FX owner；Monex/BODS（月率通道）；方向：SAP/FX source→NEO；后续价格→既有WIPS/SAP

复用证据：Id3 vendor查询；Id19 MFT Monthly仅证实月率；BRD FR19.02年度预算表。

未知契约：budget问号未决；年度率文件契约、新GSDB关系、外币交叉转换及舍入未签。

**前置材料/依赖**：Finance批准的FX类型/方向/日期/舍入金样；Vendor Master提供相关GSDB关系及新旧币种契约

**相关需求（不重评）**：NEO-018 接口边界；仅链接既有评估；NEO-059 相关GSDB的Parent方案

**既有结论链接**：[NEO-018](../../solution-review/NEO-018/NEO-018_Consolidated_CN.md)

**页面编号边界**：id沿用INPUT_SCOPE中的历史Training页面映射；斜杠分别表示创建/更新或相关页面，不是一个路由ID。React实际组件由source列定位。此轮未重新核验历史截图页号。

**问题**：

- NEO-039-Q01 Currency-only应使用哪种率，取哪一天？ 例如：GBP 100转EUR，用年度预算率还是生效月月率？ Owner：Finance FX owner；影响：决定金额且阻止混率

- NEO-039-Q02 同一供应商的新GSDB如何证明相关？ 例如：同名Supplier A但两个代码，是否足够？ Owner：Vendor Master owner；影响：决定自动换码资格

**验收设计，未执行**：

- NEO-039-S01；角色Buyer Alice；前提权限已核验；测试业务规则/金样已批准；使用隔离数据；输入旧GSDB=UK100/GBP；新GSDB=EU100/EUR；原价100.00；测试批准率1 GBP=1.15 EUR；操作Preview → 核对115.00 EUR → Apply → 保存重开；预期起始价115.00 EUR；保留率版本与原100.00 GBP，其他行不变；实际=null；NOT RUN。

- NEO-039-S02；角色Buyer Alice；前提同一隔离记录；具备故障/缺失条件；输入删去EUR适用率后Preview；操作执行受影响动作 → 再重新打开已保存记录；预期不显示0或估算价；提示Missing rate；Apply禁用；实际=null；NOT RUN。

- NEO-039-S03；角色Buyer Alice / unauthorised Bob；前提非授权用户Bob；Alice已把记录由revision7保存到8；输入Bob尝试修改；Alice旧页面仍携带revision7；操作分别提交旧版本/无权限请求；预期服务端拒绝；不泄露受限内容；保留授权编辑缓冲；重新载入后只见revision8，不能覆盖已批准快照；实际=null；NOT RUN。

**来源证据**：

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E40：「When completing a currency only resource with the same supplier, can NEO utilise the correct JLR FX rate (budget?) to calculate the new start price automatically based on the FX rate for the new supplier code.
」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!K40：「Could」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!Q40：「As a Procurement User, I need NEO to automatically calculate the updated start price using the applicable JLR FX rate for the selected supplier code when processing a currency-only resource change, so that pricing remain」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!R40：「N」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 206–212 (zero-based), A.8 UC-02：「Normal path. Enter core details, notification, POA dates and estimates; add evidence; save or submit to Created.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 227–233 (zero-based), A.8 UC-05：「Normal path. Apply a common change, then separate selected batches; preview and edit an individual row; save.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 241–247 (zero-based), A.8 UC-07：「Normal path. Run a Finance golden case; inspect each output; resolve FTO match failure through its authorised update and refresh.」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 54 (zero-based table 5 / row 53)：「FR19.02 | Ref Data – Exchange Rates (Budget) | Do not need ability to edit
Table containing rows for all countries, with a conversion number by which each currency converts to £GBP. Manually uploaded once per year.」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 55 (zero-based table 5 / row 54)：「FR19.03 | Ref Data – Exchange Rates (Monthly) | Do not need ability to edit
Data detailed in the above, but split by each month/ year. 
Store data for current and last financial year. 
Technical note: This is currently s」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A906:O906：「MCI_RISK_OPPORTUNITY_PART_WIPS_CLAIM | 索赔 | 业务 | START_PRICE | decimal(19,5) | numeric(19,5) | 是 |  |  |  |  |  | 否 | Column to hold value of start_price | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A907:O907：「MCI_RISK_OPPORTUNITY_PART_WIPS_CLAIM | 索赔 | 业务 | START_PRICE_CURRENCY | varchar(255) | varchar(255) | 是 |  |  |  |  |  | 否 | Column to hold value of start_price_currency | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A1877:O1877：「MCI_CURRENCY_EXCHANGE_RATE | 汇率与月结 | 业务 | FISCAL_YEAR_ID | int(11) | integer | 是 |  | FK | MCI_REF_FISCAL_YEAR | FISCAL_YEAR_ID | 已建 | 否 | Primary key of MCI_REF_FISCAL_YEAR | 结构+字典」

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Parts/PartPrices.tsx` / line 33：「const blocked=p.disabled||s.reconciliationRequired,allowDirect=b.claim.transactionBreakdown==='Resource'||b.claim.transactionDrivers==='Currency'||b.claim.leverId==='Currency',preview=p.filter.preview;」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=1] / name, fr, area：「Create Claim | FR1; FR1.1–FR1.6 | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=4] / name, fr, area：「Update Claim | FR6; FR6.1 | Claims and data」

- `6.技术方案/2 - Tech NEO/Scheduler Processes - 2026-11-09_0944.xlsx` / Sheet 1!A9:O9：「8.0 | Load monthly exchange rates | Receives monthly exchange rates from BODS via SFTP. Data source system is Monex. Receives rates in USD and convert in GBP.
Loads current exchange rates into current month, previous mon」

- `6.技术方案/2 - Tech NEO/Scheduler Processes - 2026-11-09_0944.xlsx` / Sheet 1!A13:O13：「10.0 | Email reminder to update budget exchange rates | Sends an email reminder to super users group for updating budget exchange rates from start of March. | Material Cost & Inventory | MCI Email Reminder to Update Exch」

- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` / CSV physical line 9; integration 3：「3,MCI_getVendorDetails,Integration used to fetch vendor details from SAP to Appian,Material Cost & Inventory,Integration,Appian,SAP,Apigee,MCI SAP,GET,https://api.jlr-ddc.com/material-cost-inventory-service/vendor-data-d」

- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` / CSV physical line 111; integration 19：「19,MFT M Exchange Rate,SFTP integration from Appian to BODS system to fetch monthly exchange rates from csv data files present in zip folder.,Material Cost & Inventory,Other,Monex,Appian,BODS,NA,MFT,NA,NA,NA,NA,NA,mft.jl」

- `outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/solution-review/NEO-018/NEO-018_Consolidated_CN.md` / opening summary; reused only, no reassessment：「# NEO-018 · S/4HANA供应商、零件价格、车型和收货数据接入

本轮是独立页面及集成方案，未修改现有NEO prototype、共享QA、接口、数据库或线上系统。页面英文，评估中文。代码、价格、BP、订单／收货数量及版本均为合成审阅数据，不是从SAP读取的结果；未执行财务计算、Reserve生成或下游任务派发。

## 1. 原需求与证据

Halewood转到S4后，继续依赖ECC的旧价格／收货数据会使起始价格和Actu」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR18-040：「Currency*」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR18-041：「Exchange Rate*」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR79-Q03：「FTO / GR / E2SC契约」

现有QA引用：FR18-040, FR18-041, FR79-Q03；只链接，不重记PASS。

页面：[English proposal](pages/NEO-039.html)；[Desktop](screenshots/NEO-039-desktop.png)；[Narrow](screenshots/NEO-039-narrow.png)。


## NEO-040 按用途精简Runout、ATP及币种字段

来源：8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx / RTM for Requested Changes / row 41。采购=Should；Finance=空。建议 **P1**：源Should；减负有价值但金额回归必须先通过。

**原E**：UI/System & Bulk upload template should contain only columns that are actually required.
3x Columns below need to be validated and confirmed if actually required.
Run Out - Run Out Date - ATP Reference
Currency - implied by the GSDB code, not entered by the buyer.

**原P**：空

**原Q**：空

**UC定位**：UC-05 (direct), UC-06 (related), UC-07 (related)。需新增字段移除/条件显示与历史值及计算影响的差量场景；UC-06不代表授权恢复已停用的Parts Excel导入。

**当前基线（代码观察）**：Runout及日期仍为可编辑字段，CalculationResults仍展示Runout影响；ATP在More options/特定WIPS上下文存在，Currency来自供应商上下文。直接删除可能改变金额。

**建议方案**：先按交易类型制定字段矩阵：币种只读派生；ATP仅适用分支显示；Runout保留在展开的生命周期字段中，直至Finance确认FFP已含停产裁剪才可删除输入。旧值永不清空。

**主要性质**：条件化表单＋校验/计算影响核验。**架构判断**：应用规则治理，非纯CSS删列；无新增平台。

**ACT核验**：ACT-001 Create Claim [FR1; FR1.1–FR1.6] existing action retained; requirement-specific gaps in UC map；ACT-026 Bulk Upload Parts [FR1.6; FR13 (associated)] existing action retained; requirement-specific gaps in UC map；补充候选：

- ux：常用Part Prices只保留核心价格；Lifecycle可展开；需要Runout date时就近提示。

- frontend：统一适用矩阵控制表格与模板版本，保留隐藏值但不自动用于不适用新交易。

- backend：服务端校验适用/必填，模板模式仅在获准时维护；检测历史字段对重算影响。

- data：保留IS_RUNOUT/RUNOUT_DATE及ATP历史，增加模板/规则版本。

- workflow：字段撤销之前比较Finance金样，流程缺关键数据时仍阻断。

**集成**：无需新增外部接口；FFP来源是否含pro-rate需数据owner证明。

提供方：NEO / Finance；FFP owner；方向：内部字段→计算；FFP→NEO

复用证据：复用PartPrices的Runout条件逻辑和只读币种，不重建导入能力。

未知契约：Runout是否已含在FFP、ATP哪些分支仍必需、模板是否仍在本项目启用。

**前置材料/依赖**：Finance提供含Runout和不含Runout的FFP金样；CBSL确认ATP分支与现行模板是否适用

**相关需求（不重评）**：NEO-054 FTO/FFP口径；NEO-043 必填矩阵

**既有结论链接**：

**页面编号边界**：id沿用INPUT_SCOPE中的历史Training页面映射；斜杠分别表示创建/更新或相关页面，不是一个路由ID。React实际组件由source列定位。此轮未重新核验历史截图页号。

**问题**：

- NEO-040-Q01 FFP数量是否已经扣除Runout之后的产量？ 例如：12月停产，全年量12,000是否已扣成9,000？ Owner：Finance / FFP owner；影响：防止重复扣量

- NEO-040-Q02 哪些交易仍需要ATP Reference？ 例如：AMM与普通Price Claim是否不同？ Owner：CBSL / Procurement；影响：决定条件字段与模板

**验收设计，未执行**：

- NEO-040-S01；角色Buyer Alice；前提权限已核验；测试业务规则/金样已批准；使用隔离数据；输入POA Price Claim；GBP派生；Runout=Yes；日期=31 Dec 2026；操作打开Lifecycle → 设日期 → 保存重开并与已批准金样对比；预期日期保留；币种不可自由改；Runout按批准口径只计一次；实际=null；NOT RUN。

- NEO-040-S02；角色Buyer Alice；前提同一隔离记录；具备故障/缺失条件；输入Runout=Yes但日期留空；操作执行受影响动作 → 再重新打开已保存记录；预期保留价格输入并提示Enter runout date，不能形成完整计算；实际=null；NOT RUN。

- NEO-040-S03；角色Buyer Alice / unauthorised Bob；前提非授权用户Bob；Alice已把记录由revision7保存到8；输入Bob尝试修改；Alice旧页面仍携带revision7；操作分别提交旧版本/无权限请求；预期服务端拒绝；不泄露受限内容；保留授权编辑缓冲；重新载入后只见revision8，不能覆盖已批准快照；实际=null；NOT RUN。

**来源证据**：

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E41：「UI/System & Bulk upload template should contain only columns that are actually required.
3x Columns below need to be validated and confirmed if actually required.
Run Out - Run Out Date - ATP Reference
Currency - implied」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!K41：「Should」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!R41：「N」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 227–233 (zero-based), A.8 UC-05：「Normal path. Apply a common change, then separate selected batches; preview and edit an individual row; save.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 234–240 (zero-based), A.8 UC-06：「Normal path. Download template and valid values; validate a file; apply the accepted batch.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 241–247 (zero-based), A.8 UC-07：「Normal path. Run a Finance golden case; inspect each output; resolve FTO match failure through its authorised update and refresh.」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 8 (zero-based table 5 / row 7)：「FR1.6 | Create Risk/ Opportunity – Add Part Level Data (for POA) | Context: Following on from FR1.2. This will allow a user to capture part level data relating to a POA. Where the parts relate to WIPS, it will aim to sim」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 20 (zero-based table 5 / row 19)：「FR8.1 | Display Calculations (FTO) | The application should have a summary of part level calculations carried out within the solution. 
Display vehicle line breakdowns and view of calculations. Include Runout. 
The syste」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A829:O829：「MCI_RISK_OPPORTUNITY_PART | 索赔 | 业务 | IS_RUNOUT | tinyint(1) | smallint | 是 | 0 |  |  |  |  | 否 | is_runout | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A830:O830：「MCI_RISK_OPPORTUNITY_PART | 索赔 | 业务 | RUNOUT_DATE | date | date | 是 |  |  |  |  |  | 否 | runout_date | 结构+字典」

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Parts/PartPrices.tsx` / line 51：「case 'P03-F017':return <Radio.Group aria-label={`Runout ${id}`} value={metadata(id)?.runout} disabled={blocked} options={[{label:'Yes',value:true},{label:'No',value:false}]} onChange={e=>applyResult(editRunout(s,id,e.tar」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=1] / name, fr, area：「Create Claim | FR1; FR1.1–FR1.6 | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=26] / name, fr, area：「Bulk Upload Parts | FR1.6; FR13 (associated) | Claims and data」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR79-Q01：「日期 / Runout / 周切分」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR18-040：「Currency*」

现有QA引用：FR79-Q01, FR18-040；只链接，不重记PASS。

页面：[English proposal](pages/NEO-040.html)；[Desktop](screenshots/NEO-040-desktop.png)；[Narrow](screenshots/NEO-040-narrow.png)。


## NEO-041 同一零件单Claim支持多个Lever

来源：8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx / RTM for Requested Changes / row 42。采购=Should；Finance=空。建议 **P0决策 / P2开发**：源Should；改变核心维度，先定模型以免与059、068重复返工。

**原E**：Reduce the number of levers within NEO and allow a single claim to be submitted with multiple levers.

**原P**：空

**原Q**：As a Procurement User, I need NEO to support multiple levers within a single claim for the same part, so that related changes can be managed together without requiring multiple claims, reducing duplicate effort, approval activity, and pricing inconsistencies

**UC定位**：UC-02 (related), UC-10 (related), UC-18 (related), UC-23 (related)。新增同一part/plant多Lever价格分量、叠加/复合方式、归类与审批快照场景。

**当前基线（代码观察）**：ClaimValues与数据字典Claim均为单leverId/LEVER_ID；Reserve Team映射FR17.2以Lever和Reporting Category判定。因此不只是多选框。

**建议方案**：建议一份Claim下保留按part/plant的Lever分量；明确基价、各分量和最终价。主分类与Finance分摊规则独立确认，保存分量版本并冻结提交。不要把逗号分隔字符串塞回单Lever字段。

**主要性质**：业务数据模型与计算/审批变更。**架构判断**：先做领域数据模型决策，不等于另建技术平台。

**ACT核验**：ACT-001 Create Claim [FR1; FR1.1–FR1.6] existing action retained; requirement-specific gaps in UC map；ACT-035 Edit Teams [FR17.2 (associated)] existing action retained; requirement-specific gaps in UC map；ACT-012 Submit Settlement Request [FR9.1; FR9.4] existing action retained; requirement-specific gaps in UC map；补充候选：ACT-051 Reference data

- ux：Part price components中逐行添加Lever及金额，显示各分量与最终价。

- frontend：分量表增删、重复Lever提示，预览sum/compound所选规则后应用。

- backend：按确认顺序/叠加政策计算且校验总价；审批服务冻结分量，消费者使用同一版本。

- data：Claim/Part/Lever子表或price component实体；老单Lever映射单分量，保留历史。

- workflow：组合变化触发重算/重新审批规则；Settlement与Reserve保留分量归属。

**集成**：现有下游可能只收最终价，是否也接收多Lever必须逐接口确认。

提供方：NEO；WIPS/SAP；Finance reporting owner；方向：NEO分量→审批/Finance；最终价或分量→WIPS/SAP

复用证据：复用Lever参考、Part价格行和审批快照机制；没有多Lever下游payload证据。

未知契约：同一part不同Lever能否相抵，Reserve Team拆分、DoA口径以及复合次序。

**前置材料/依赖**：采购提供同Part多Lever真实报价与分量样例；Finance批准相加/复合次序、Reserve Team分摊和DoA金额；下游owner给最终价/多分量payload及迁移规则

**相关需求（不重评）**：NEO-034 Reporting Category与Lever合法组合，只复用既有结论；NEO-046审批影响由相邻Epic核对；NEO-059 Parent及净额方向

**既有结论链接**：[NEO-034](../../solution-review/NEO-034/NEO-034_Consolidated_CN.md)

**页面编号边界**：id沿用INPUT_SCOPE中的历史Training页面映射；斜杠分别表示创建/更新或相关页面，不是一个路由ID。React实际组件由source列定位。此轮未重新核验历史截图页号。

**问题**：

- NEO-041-Q01 多个Lever金额是相加，还是依次按比例调整？ 例如：100元先+5%再-2%，结果102.90还是103？ Owner：Procurement / Finance；影响：决定公式和UI

- NEO-041-Q02 一个Claim含Inflation与Productivity时，Reserve归哪个Team？ 例如：风险+5与节约-2属于两个类别。 Owner：Finance；影响：决定归类和报表拆分

**验收设计，未执行**：

- NEO-041-S01；角色Buyer Alice；前提权限已核验；测试业务规则/金样已批准；使用隔离数据；输入Part JLR-100/Plant SOL；基价100 GBP；Inflation +5；Productivity -2；测试政策为加总；操作增加两个分量 → Preview → 保存并打开摘要；预期两分量各有ID，最终价103 GBP；报价/分类依据可追溯；实际=null；NOT RUN。

- NEO-041-S02；角色Buyer Alice；前提同一隔离记录；具备故障/缺失条件；输入把已提交分量在旧revision中改成+8；操作执行受影响动作 → 再重新打开已保存记录；预期拒绝覆盖；保留编辑缓冲，要求重新载入并评审审批影响；实际=null；NOT RUN。

- NEO-041-S03；角色Buyer Alice / unauthorised Bob；前提非授权用户Bob；Alice已把记录由revision7保存到8；输入Bob尝试修改；Alice旧页面仍携带revision7；操作分别提交旧版本/无权限请求；预期服务端拒绝；不泄露受限内容；保留授权编辑缓冲；重新载入后只见revision8，不能覆盖已批准快照；实际=null；NOT RUN。

- NEO-041-S04；角色Buyer Alice；前提对应政策、金样与接口/权限测试环境已批准；隔离数据；输入基价100 GBP；Inflation +5%；Productivity -2%；政策compound-v1；操作按先+5%再-2%预览，互换顺序并比较；预期保留显式顺序和规则版本；第一组结果102.90；如换顺序政策禁止则明确拒绝，不静默以相加103替代；实际=null；NOT RUN。

- NEO-041-S05；角色Buyer Alice；前提对应政策、金样与接口/权限测试环境已批准；隔离数据；输入已批准Claim分量Inflation+5/Productivity-2；Reserve两个分类规则待批准；操作调整其中分量并查看已批准版本/新草稿；预期原103 GBP及两分量快照保持；新版本是否重批由批准政策决定；不得将一笔净额重复计入两个Reserve Team；实际=null；NOT RUN。

**来源证据**：

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E42：「Reduce the number of levers within NEO and allow a single claim to be submitted with multiple levers.」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!K42：「Should」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!Q42：「As a Procurement User, I need NEO to support multiple levers within a single claim for the same part, so that related changes can be managed together without requiring multiple claims, reducing duplicate effort, approval」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!R42：「Y」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 206–212 (zero-based), A.8 UC-02：「Normal path. Enter core details, notification, POA dates and estimates; add evidence; save or submit to Created.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 262–268 (zero-based), A.8 UC-10：「Normal path. Add different Inflation types, units, rates, Base Position and Pain Share; retain optional CO2 evidence.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 318–324 (zero-based), A.8 UC-18：「Normal path. Create Settlement from the approved basis, review final values and submit; reject, correct and rerequest in a separate run.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 353–359 (zero-based), A.8 UC-23：「Normal path. Prepare daily inputs and Draft Reserve; review and adjust; freeze Final; prepare and reconcile Journal; confirm actual posting.」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 4 (zero-based table 5 / row 3)：「FR1.2 | Create Risk/ Opportunity – Line Item Level Data Capture | Context: Following on from FR1.1. The below data will be captured at a line-item level (similar to the current AS IS FIND solution).
An interface should b」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 44 (zero-based table 5 / row 43)：「FR17.2 | Actual Reserves – Logic for where a line item equals Team  | The following logic dictates how the application should categorise a line item (reserve) for a particular month into the relevant team category (e.g. 」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A706:O706：「MCI_RISK_OPPORTUNITY | 索赔 | 业务 | LEVER_ID | int(11) | integer | 是 |  | FK | MCI_REF_LEVER | LEVER_ID | 已建 | 否 | Primary key of MCI_LEVER | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A248:O248：「MCI_REF_LEVER | 参考数据 | 参考 | LEVER_ID | int(11) | integer | 否 |  | PK |  |  |  | 否 | Primary key of the table. This table holds information of levers | 结构+字典」

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p02/contracts.ts` / line 12：「export type ClaimValues=ClaimAlignmentValues&{transactionDrivers?:string;nonStandardTransactionKind?:string;priceCurrency?:string;buyerCode:string;nonStandardTransaction:boolean;dummy:boolean;paymentReleaseDate:string;bu」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=1] / name, fr, area：「Create Claim | FR1; FR1.1–FR1.6 | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=35] / name, fr, area：「Edit Teams | FR17.2 (associated) | Finance and continuity」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=12] / name, fr, area：「Submit Settlement Request | FR9.1; FR9.4 | Authorisation」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=51] / name, fr, area：「Reference data | FR19 and sub-FRs | Claims and data」

- `outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/solution-review/NEO-034/NEO-034_Consolidated_CN.md` / opening summary; reused only, no reassessment：「# NEO-034 · Reporting Category 与 Lever 组合校验

## 1. 本次结论

这条要解决的是：**两个下拉值各自合法，放在一起却不符合 Finance 的分类要求。** 例如选了某个 Lever，却配上业务不允许的 Reporting Category；目前没有组合限制，后面的准备金／报告就可能分错类。[S1]

建议建立一份由业务签认、带版本的允许组合清单，在两边修改时使用同一校验：**Financ」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR18-032：「Lever*」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR16-Q07：「参考数据与正式人员映射」

现有QA引用：FR18-032, FR16-Q07；只链接，不重记PASS。

页面：[English proposal](pages/NEO-041.html)；[Desktop](screenshots/NEO-041-desktop.png)；[Narrow](screenshots/NEO-041-narrow.png)。


## NEO-042 AMM每Part支持超过3个Escalator

来源：8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx / RTM for Requested Changes / row 43。采购=Must；Finance=空。建议 **P1**：源Must，有明确3条瓶颈；契约与业务边界须先确认。

**原E**：The ability to add more than 3x AMM escalators per part when submitting an AMM ATP in NEO.
Avoid the use of "complex worksheet attachments"

**原P**：空

**原Q**：As a buyer I need the existing AMM functionality to allow more than 3x escalator codes to be submitted per part. (Variable amount based on requirement and need maximum of 10-15 escalator codes per part based on limitation within WIPS)

**UC定位**：UC-02 (related), UC-05 (related), UC-20 (related)。UC-20明确AMM/ATP及复杂工作表；新增可变10–15边界的结构化指数、校验与下游回执场景。

**当前基线（代码观察）**：现产品WipsPanel有ATP Reference与本地WIPS模拟入口；目录AA部署仅给string=null，未证实AMM指数结构或WIPS最大数。源Q43说10–15，受WIPS限制。

**建议方案**：按Part提供可增减的Escalator子表，取代必须依赖complex worksheet；提交前校验code、基期、权重/公式及有效期。上限由WIPS批准能力配置，页面先展示5条可审阅示例。

**主要性质**：结构化明细＋AMM下游契约扩展。**架构判断**：可变长子表＋现有适配器扩展；不默认新平台。

**ACT核验**：ACT-001 Create Claim [FR1; FR1.1–FR1.6] existing action retained; requirement-specific gaps in UC map；ACT-026 Bulk Upload Parts [FR1.6; FR13 (associated)] existing action retained; requirement-specific gaps in UC map；ACT-027 Create WIPS Claim [FR13] related standard WIPS action, not proof of AMM payload；补充候选：

- ux：一Part一组Escalator，Add、Remove、Validate及总权重；错误定位具体代码。

- frontend：动态子表与重复/缺值错误，批量输入时保留失败行。

- backend：校验已确认的上限和公式；发送与回执按part/component关联、可重放不重复。

- data：新增PartEscalator子记录，不能新增第4到第15个硬编码列。

- workflow：AMM ATP提交冻结指数版本；下游拒绝回到可修正任务，不假完成。

**集成**：WIPS/ATP AMM路径需要确认或扩展payload；AA网关存在不等于指数契约可复用。

提供方：WIPS/ATP owner；Automation Anywhere；CBSL；方向：NEO→WIPS/ATP；执行回执→NEO

复用证据：现有AA deploy/callback通道候选；需WIPS正式schema、上限和失败样例。

未知契约：最大10还是15、权重总和政策、指数日期/精度与非同币种规则。

**前置材料/依赖**：WIPS确认10或15上限、指数schema和错误回执样例；AMM owner批准指数公式/权重/日期规则

**相关需求（不重评）**：NEO-041 分量模型；NEO-046 审批快照

**既有结论链接**：

**页面编号边界**：id沿用INPUT_SCOPE中的历史Training页面映射；斜杠分别表示创建/更新或相关页面，不是一个路由ID。React实际组件由source列定位。此轮未重新核验历史截图页号。

**问题**：

- NEO-042-Q01 WIPS每Part最终支持10条还是15条？ 例如：第11条是允许、拒绝还是需人工？ Owner：WIPS / CBSL；影响：决定边界与异常流程

- NEO-042-Q02 每个指数必须提供哪些值，权重是否必须合计100%？ 例如：5条各20%，一个缺基期。 Owner：AMM业务owner；影响：决定校验和公式

**验收设计，未执行**：

- NEO-042-S01；角色AMM Buyer Alice；前提权限已核验；测试业务规则/金样已批准；使用隔离数据；输入Part JLR-200；五个不同Escalator E01–E05；每条权重20%；测试上限10；操作添加第5条 → Validate → 提交AMM ATP并读取回执；预期5条结构化保存；权重100%；只在实际成功回执后完成；实际=null；NOT RUN。

- NEO-042-S02；角色AMM Buyer Alice；前提同一隔离记录；具备故障/缺失条件；输入配置上限10后尝试第11条或重复E01；操作执行受影响动作 → 再重新打开已保存记录；预期阻止超限/重复并保留原10条；不得静默截断；实际=null；NOT RUN。

- NEO-042-S03；角色Buyer Alice / unauthorised Bob；前提非授权用户Bob；Alice已把记录由revision7保存到8；输入Bob尝试修改；Alice旧页面仍携带revision7；操作分别提交旧版本/无权限请求；预期服务端拒绝；不泄露受限内容；保留授权编辑缓冲；重新载入后只见revision8，不能覆盖已批准快照；实际=null；NOT RUN。

**来源证据**：

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E43：「The ability to add more than 3x AMM escalators per part when submitting an AMM ATP in NEO.
Avoid the use of "complex worksheet attachments"」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!K43：「Must」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!Q43：「As a buyer I need the existing AMM functionality to allow more than 3x escalator codes to be submitted per part. (Variable amount based on requirement and need maximum of 10-15 escalator codes per part based on limitatio」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!R43：「N」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 206–212 (zero-based), A.8 UC-02：「Normal path. Enter core details, notification, POA dates and estimates; add evidence; save or submit to Created.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 227–233 (zero-based), A.8 UC-05：「Normal path. Apply a common change, then separate selected batches; preview and edit an individual row; save.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 332–338 (zero-based), A.8 UC-20：「Normal path. Exercise AMM via ATP, container contract review, Price Correction and Resource in separate appropriate records. Confirm BAC or EMC routing for EMC delivered parts and the AMM complex worksheet when linking m」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 8 (zero-based table 5 / row 7)：「FR1.6 | Create Risk/ Opportunity – Add Part Level Data (for POA) | Context: Following on from FR1.2. This will allow a user to capture part level data relating to a POA. Where the parts relate to WIPS, it will aim to sim」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 39 (zero-based table 5 / row 38)：「FR14 | Manual Tasks to Complete Certain Low Volume Transaction Types | If the solution is unable to update the details of a particular settlement request within the system of record, then the solution should generate a t」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A906:O906：「MCI_RISK_OPPORTUNITY_PART_WIPS_CLAIM | 索赔 | 业务 | START_PRICE | decimal(19,5) | numeric(19,5) | 是 |  |  |  |  |  | 否 | Column to hold value of start_price | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A907:O907：「MCI_RISK_OPPORTUNITY_PART_WIPS_CLAIM | 索赔 | 业务 | START_PRICE_CURRENCY | varchar(255) | varchar(255) | 是 |  |  |  |  |  | 否 | Column to hold value of start_price_currency | 结构+字典」

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Parts/WipsPanel.tsx` / line 13：「return <Card title="WIPS" style={{marginTop:24}}><Flex vertical gap={16}><Form layout="vertical">{showReference&&<Form.Item label="ATP Reference"><Input value={s.atpReference??''} aria-label="ATP Reference" maxLength={25」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=1] / name, fr, area：「Create Claim | FR1; FR1.1–FR1.6 | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=26] / name, fr, area：「Bulk Upload Parts | FR1.6; FR13 (associated) | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=27] / name, fr, area：「Create WIPS Claim | FR13 | Implementation」

- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` / CSV physical line 46; integration 12：「12,MCI_raiseWIPSClaim,Creates a claim in WIPS system,Material Cost & Inventory,Integration,Appian,WIPS,Automation Anywhere,MCI AA,POST,https://jlra360-3.my.automationanywhere.digital/v3/automations/deploy,JSON,JSON,NA,X-」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR79-Q03：「FTO / GR / E2SC契约」

现有QA引用：FR79-Q03；只链接，不重记PASS。

页面：[English proposal](pages/NEO-042.html)；[Desktop](screenshots/NEO-042-desktop.png)；[Narrow](screenshots/NEO-042-narrow.png)。


## NEO-043 精简CO2及创建校验

来源：8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx / RTM for Requested Changes / row 44。采购=Should；Finance=空。建议 **P2**：源Should；减少无效输入，需先获Finance/数据消费者共同确认。

**原E**：Fields and data collected as part of the Risk/Opp should be reviewed to only collect data that is actually required.

For example could Co2 section be removed.
The validation rules on items should be reviewed to ensure appropriate.

**原P**：空

**原Q**：As a procurement user I would remove the CO2 section from the completion of risk/opp and review other fields to ensure that only necessary data is being collected.

Where fields have validation (i.e. minimum text length these should be reviewed to ensure that they are driving useful input and not leading to bad behaviours - such as copying/pasting text to meet a minimum length)

**UC定位**：UC-02 (direct), UC-10 (direct)。覆盖CO2从新录入移除但历史保留，以及description最低长度的业务确认差量。

**当前基线（代码观察）**：当前Claim向导仍有CO₂ Data步骤；BRD将其定义为informational。Working BRD明确optional CO2和100字符描述的历史要求。

**建议方案**：独立方案在新建向导移除CO2输入步骤，在历史摘要保留原CO2。将描述改为能说明商业原因、供应商依据和影响的内容校验；最低长度数值待确认，不擅自取消必需证据。

**主要性质**：表单、必填矩阵与兼容性修改。**架构判断**：配置化阶段校验；无新平台。

**ACT核验**：ACT-001 Create Claim [FR1; FR1.1–FR1.6] existing action retained; requirement-specific gaps in UC map；ACT-005 Submit Claim [FR1; FR16] existing action retained; requirement-specific gaps in UC map；补充候选：

- ux：新建流减少CO2一步；描述使用明确字段，不用冗长指导或复制字数。

- frontend：新建与历史摘要不同呈现；未完成资料随保存保留。

- backend：按交易/阶段执行统一必填政策；旧CO2不因未提交新值被清空。

- data：保留历史CO2、原描述及政策版本；不做物理删列。

- workflow：Mandate/Settlement的证据门槛仍独立；政策切换后在途草稿处理需确认。

**集成**：无需新增接口；已有报表若消费CO2需先列清消费者。

提供方：NEO / Procurement / Finance；方向：内部录入→摘要/历史/报表

复用证据：复用向导、Draft和服务端校验框架；本轮页面不是对当前代码的修改。

未知契约：CO2监管/报表消费者、描述替代规则、在途草稿是否沿用旧规则。

**前置材料/依赖**：确认CO2实际报表/合规消费者及停录入生效日期；采购与Clearing House批准替代描述/证据完整度规则

**相关需求（不重评）**：NEO-040 字段适用矩阵；NEO-053 Inflation精简

**既有结论链接**：

**页面编号边界**：id沿用INPUT_SCOPE中的历史Training页面映射；斜杠分别表示创建/更新或相关页面，不是一个路由ID。React实际组件由source列定位。此轮未重新核验历史截图页号。

**问题**：

- NEO-043-Q01 CO2在报表或合规上还有实际消费者吗？ 例如：只取消新录入，但2025年的CO2仍可查。 Owner：Procurement / Finance；影响：决定是否可移出向导

- NEO-043-Q02 描述必须回答哪些业务内容，能否替代100字符下限？ 例如：原因+依据+影响三项已清楚但仅80字符。 Owner：Procurement / Clearing House；影响：决定提交校验

**验收设计，未执行**：

- NEO-043-S01；角色Buyer Alice；前提权限已核验；测试业务规则/金样已批准；使用隔离数据；输入新POA；商业原因=Supplier energy cost increase；依据=attached agreement；影响=+2 GBP/part；操作填写必要信息 → 下一步并保存；预期无CO2必填阻断；历史Claim原CO2仍可只读查看；证据仍按规则校验；实际=null；NOT RUN。

- NEO-043-S02；角色Buyer Alice；前提同一隔离记录；具备故障/缺失条件；输入删除所有商业原因再Submit；操作执行受影响动作 → 再重新打开已保存记录；预期提示Provide commercial reason；保留其余输入；不得只以字符数判断完整；实际=null；NOT RUN。

- NEO-043-S03；角色Buyer Alice / unauthorised Bob；前提非授权用户Bob；Alice已把记录由revision7保存到8；输入Bob尝试修改；Alice旧页面仍携带revision7；操作分别提交旧版本/无权限请求；预期服务端拒绝；不泄露受限内容；保留授权编辑缓冲；重新载入后只见revision8，不能覆盖已批准快照；实际=null；NOT RUN。

**来源证据**：

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E44：「Fields and data collected as part of the Risk/Opp should be reviewed to only collect data that is actually required.

For example could Co2 section be removed.
The validation rules on items should be reviewed to ensure a」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!K44：「Should」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!Q44：「As a procurement user I would remove the CO2 section from the completion of risk/opp and review other fields to ensure that only necessary data is being collected.

Where fields have validation (i.e. minimum text length 」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!R44：「Y」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 206–212 (zero-based), A.8 UC-02：「Normal path. Enter core details, notification, POA dates and estimates; add evidence; save or submit to Created.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 262–268 (zero-based), A.8 UC-10：「Normal path. Add different Inflation types, units, rates, Base Position and Pain Share; retain optional CO2 evidence.」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 4 (zero-based table 5 / row 3)：「FR1.2 | Create Risk/ Opportunity – Line Item Level Data Capture | Context: Following on from FR1.1. The below data will be captured at a line-item level (similar to the current AS IS FIND solution).
An interface should b」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 7 (zero-based table 5 / row 6)：「FR1.5 | Create Risk/ Opportunity – Co2 Data | Context: Following on from FR1.3. This will allow a user to capture Co2 data for informational purposes as the current FIND system does today.
An interface should be displaye」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A773:O773：「MCI_RISK_OPPORTUNITY_CO2 | 索赔 | 业务 | CO2E_START_POSITION | decimal(19,5) | numeric(19,5) | 是 |  |  |  |  |  | 否 | co2e_start_position | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A774:O774：「MCI_RISK_OPPORTUNITY_CO2 | 索赔 | 业务 | CO2E_END_POSITION | decimal(19,5) | numeric(19,5) | 是 |  |  |  |  |  | 否 | co2e_end_position | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A2483:O2483：「MCI_STG_REPORT_EXTRACT | 集成暂存 | 暂存 | CO2E_START_POSITION_KG | decimal(19,5) | numeric(19,5) | 是 |  |  |  |  |  | 否 |  | 结构」

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Claim/index.tsx` / line 40：「const steps=[{title:'Core Data',key:'core',go:()=>{neo.updateUi({claimStep:'core'});neo.go('V-02')}},{title:'Supplier Claim Details',key:'supplier',go:()=>{neo.updateUi({claimStep:'supplier'});neo.go('V-02')}},{title:'Do」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=1] / name, fr, area：「Create Claim | FR1; FR1.1–FR1.6 | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=5] / name, fr, area：「Submit Claim | FR1; FR16 | Claims and data」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR18-034：「Description*」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID NQA-28：「Inflation多类型/材料/Other/单位费率与CO2精确差值」

现有QA引用：FR18-034, NQA-28；只链接，不重记PASS。

页面：[English proposal](pages/NEO-043.html)；[Desktop](screenshots/NEO-043-desktop.png)；[Narrow](screenshots/NEO-043-narrow.png)。


## NEO-045 LSP财务组合自动派生及失败重试

来源：8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx / RTM for Requested Changes / row 46。采购=空；Finance=Must。建议 **P0**：Finance Must；错误财务组合直接导致SAP PO失败，需优先明确定义。

**原E**：When Lump Sum Payments are raised by Buyers the master data of Company Code / Purchase Org must be selected correctly

**原P**：As a finance user I need the data entered on a Lump Sum PO by the buyer to be correct and applicable and to not cause failures downstream.
This should be achieved based on the selections entered by the buyer automatically selecting the correct Cost Centre and other fields required for the PO raising.

This should be defined/held in a table in the admin section of NEO as these may change overtime.

**原Q**：As a buyer when raising a lump sum order I should input the minimum amount of information possible, which is relevant to the risk/opp and the system should automatically identify the correct background information to ensure that the SAP NDPC lump Sum PO is raised correctly with the appropriate finance information. 

POs that fail to be generated due to errorneous finance information/setup should be routed appropriately for the master data to be corrected and the PO retriggered (or sent to digitide to be raised manually).

**UC定位**：UC-09 (direct), UC-21 (related)。新增有效期组合匹配、无/多命中、master-data纠正及PO未知结果对账重试。

**当前基线（代码观察）**：LSP字段已在创建页，由Material Group、Vehicle Line等参考选项提供输入；接口Id10已有companyCode、purchaseOrganization、glAccount、costCenter字段，不等于组合规则已实现。

**建议方案**：按买家最少输入匹配一个有效Finance组合，派生Cost Centre、GL、Purchase Org等只读字段并保存规则版本。无匹配阻断PO发起并交给主数据owner；失败回执路由纠正后对账再重触发或Digitide人工。

**主要性质**：财务参考组合＋接口校验/错误恢复。**架构判断**：NEO版本化规则表＋既有SAP适配器；不新增主数据平台。

**ACT核验**：ACT-001 Create Claim [FR1; FR1.1–FR1.6] existing action retained; requirement-specific gaps in UC map；ACT-022 Manage Task [FR11] related GFS review only; not PO creation or mapping maintenance；补充候选：ACT-051 Reference data

- ux：业务输入与派生财务信息分组；无有效组合显示具体缺口及负责角色。

- frontend：组合Preview与更改提示；买家不能随意覆盖派生值。

- backend：验证唯一匹配/生效期/权限；生成PO前重校验，idempotency key关联Settlement版本。

- data：版本化组合键值表；code以字符串保存前导零，保留规则及PO尝试/回执。

- workflow：主数据纠正任务→重新核验→对账/重试或人工移交；未知PO结果禁止新建重试。

**集成**：复用SAP company/purchase org/purchase group GET及raiseLumpSumPO POST，补足错误码、回执、查重契约。

提供方：SAP Master Data/GFS；Apigee；Digitide人工处理；方向：SAP参考→NEO；NEO→SAP PO；PO状态→NEO

复用证据：Id7/8/9参考查询；Id10含companyCode/purchaseOrganization/glAccount/costCenter；Id5查询PO状态。

未知契约：映射键是否包括公司/采购组织/Material Group/Vehicle Line/Payable方向、owner与审批、未知PO查重能力。

**前置材料/依赖**：GFS批准组合键及GL/CC/Purchase Org映射样表和有效期；SAP提供无/多匹配、PO失败/未知结果查重与回执契约；确认主数据修复owner、重试权限和Digitide移交条件

**相关需求（不重评）**：CNP-234实施失败恢复契约

**既有结论链接**：

**页面编号边界**：id沿用INPUT_SCOPE中的历史Training页面映射；斜杠分别表示创建/更新或相关页面，不是一个路由ID。React实际组件由source列定位。此轮未重新核验历史截图页号。

**问题**：

- NEO-045-Q01 用哪些买家输入唯一确定财务组合？ 例如：GB03 + Material Group MG01，是否还需Vehicle Line？ Owner：GFS / SAP Master Data；影响：决定表主键和无/多匹配处理

- NEO-045-Q02 PO超时但SAP实际已建单时，谁用什么字段查重？ 例如：NEO无PO号，但SAP已有CLM-01。 Owner：SAP integration owner / Digitide；影响：防止重复PO

**验收设计，未执行**：

- NEO-045-S01；角色Buyer Alice + Finance admin；前提权限已核验；测试业务规则/金样已批准；使用隔离数据；输入Company=GB03；Material Group=MG01；有效规则v3→Org=1000, GL=001100040501, CC=0007；操作Preview → 确认只读组合 → 保存重开 → 发送经批准PO；预期前导零逐字保留；规则v3可查；SAP回执与单次业务意图关联；实际=null；NOT RUN。

- NEO-045-S02；角色Buyer Alice + Finance admin；前提同一隔离记录；具备故障/缺失条件；输入输入组合命中0条或2条；随后PO响应超时；操作执行受影响动作 → 再重新打开已保存记录；预期不随机选规则；未知结果先查重，不允许直接创建第二个PO；实际=null；NOT RUN。

- NEO-045-S03；角色Buyer Alice / unauthorised Bob；前提非授权用户Bob；Alice已把记录由revision7保存到8；输入Bob尝试修改；Alice旧页面仍携带revision7；操作分别提交旧版本/无权限请求；预期服务端拒绝；不泄露受限内容；保留授权编辑缓冲；重新载入后只见revision8，不能覆盖已批准快照；实际=null；NOT RUN。

**来源证据**：

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E46：「When Lump Sum Payments are raised by Buyers the master data of Company Code / Purchase Org must be selected correctly」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!L46：「Must」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!P46：「As a finance user I need the data entered on a Lump Sum PO by the buyer to be correct and applicable and to not cause failures downstream.
This should be achieved based on the selections entered by the buyer automaticall」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!Q46：「As a buyer when raising a lump sum order I should input the minimum amount of information possible, which is relevant to the risk/opp and the system should automatically identify the correct background information to ens」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!R46：「N」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 255–261 (zero-based), A.8 UC-09：「Normal path. Capture transaction dates and estimates, then complete the applicable Lump Sum Data and supplier facing PO Description.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 339–345 (zero-based), A.8 UC-21：「Normal path. Test payable PO creation and failure fallback; test receivable balance sufficiency, PO path and the manual invoice branch.」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 15 (zero-based table 5 / row 14)：「FR6.1 | Edit Risk/ Opportunity – Add Lump Sum Data | Context: A negotiations with Suppliers progress, the line-item information will require updates. The below functionality details how a user will carry out specific upd」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 37 (zero-based table 5 / row 36)：「FR12 | Generate PO (Lump Sum Items Only) in SAP | Once a user had triggered a transaction against a Lump Sum, RMA – Lump Sum or PGM – Lump Sum claim (see FR9), clearing house approval/ Star Chamber approval has been obta」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A727:O727：「MCI_RISK_OPPORTUNITY | 索赔 | 业务 | COMPANY_CODE | varchar(255) | varchar(255) | 是 |  |  |  |  |  | 否 | company_code | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A729:O729：「MCI_RISK_OPPORTUNITY | 索赔 | 业务 | COST_CENTER_ID | int(11) | integer | 是 |  | FK | MCI_REF_COST_CENTER | COST_CENTER_ID | 已建 | 否 | Primary key of MCI_COST_CENTER | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A575:O575：「MCI_REF_VEHICLE_LINE | 参考数据 | 参考 | COST_CENTER_ID | int(11) | integer | 是 |  | FK | MCI_REF_COST_CENTER | COST_CENTER_ID | 已建 | 否 | Primary Key of MCI_REF_COST_CENTER table | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A599:O599：「MCI_REF_VENDOR_REMIT_PARTNER | 参考数据 | 参考 | PURCHASE_ORGANISATION | varchar(50) | varchar(50) | 是 |  |  |  |  |  | 否 | Column to hold Purchase Organisation value | 结构+字典」

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Claim/index.tsx` / line 42：「const lspIds:FieldId[]=['P02-F076','P02-F077','P02-F078','P02-F079','P02-F080','P02-F081','P02-F082','P02-F083','P02-F084','P02-F085','P02-F089','P02-F090','P02-F091'];」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=1] / name, fr, area：「Create Claim | FR1; FR1.1–FR1.6 | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=22] / name, fr, area：「Manage Task | FR11 | Authorisation」

- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` / CSV physical line 19; integration 10：「10,MCI_raiseLumpSumPO,Integration used to create a purchase order in SAP,Material Cost & Inventory,Integration,Appian,SAP,Apigee,MCI SAP,POST,https://api.jlr-ddc.com/material-cost-inventory-service/create-purchase-order,」

- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` / CSV physical line 11; integration 5：「5,MCI_getPurchaseOrderDetails,"Check the status of purchase order in SAP, helps to update the claim to implemented if approved in SAP",Material Cost & Inventory,Integration,Appian,SAP,Apigee,MCI SAP,GET,https://api.jlr-d」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=51] / name, fr, area：「Reference data | FR19 and sub-FRs | Claims and data」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR16-Q07：「参考数据与正式人员映射」

现有QA引用：FR16-Q07；只链接，不重记PASS。

页面：[English proposal](pages/NEO-045.html)；[Desktop](screenshots/NEO-045-desktop.png)；[Narrow](screenshots/NEO-045-narrow.png)。


## NEO-052 Global Commodity Lead Area保留或移除决策

来源：8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx / RTM for Requested Changes / row 53。采购=Must；Finance=空。建议 **P0决策 / P2开发**：Procurement Must但目标自相矛盾；先决策，不把Must误当删除授权。

**原E**：The replacement NEO shall provide a maintainable Global Commodity Lead Area list including Casting/Forging/Extrusions, IT Supply Chain Design, Plastic Moulds and Software. Etc

**原P**：空

**原Q**：As a procurement user - the "Global Commodity Lead Area" field should be removed to support simplification

**UC定位**：UC-02 (related), UC-24 (related)。E53要求可维护列表、Q53要求移除，必须决策。现UC不覆盖停用输入后的历史/报告影响。

**当前基线（代码观察）**：原E53要求maintainable列表；Q53要求remove field；R53=Y。Training335支持编辑/停用列表。ClaimValues和数据库有commodityLeadAreaId，不可当已批准删除。

**建议方案**：主方案按Q53展示取消新建字段后的Supplier Claim Details，并保留历史分类；备选页面展示E53的可维护列表。先由采购/Finance选定方向，再只实施被确认方案。

**主要性质**：需求冲突决策；后续配置/表单修改。**架构判断**：避免删除schema；功能政策切换可回滚。

**ACT核验**：ACT-001 Create Claim [FR1; FR1.1–FR1.6] existing action retained; requirement-specific gaps in UC map；补充候选：ACT-051 Reference data

- ux：方案A新建不再录入；历史详情显示已存值。方案B参考列表可新增/停用而非删除历史。

- frontend：根据生效政策展示字段；列表维护使用现有Reference Data交互。

- backend：新建不必填与历史读取分开；停用值不能新增但可读旧记录。

- data：保留外键和历史值；若确认新列表则采用IS_ACTIVE与版本审计。

- workflow：不默认改变审批路由；先确认分类是否用于审批/报表。

**集成**：无需新增外部接口；报告导出字段弃用需consumer确认。

提供方：Procurement / Finance / NEO reference admin；方向：内部分类→Claim/Reports

复用证据：复用MCI_REF_COMMODITY_LEAD_AREA及维护页；源冲突未解除。

未知契约：最终选E还是Q、下游使用情况、在途草稿/历史导出字段策略。

**前置材料/依赖**：Procurement/Finance在E53保留列表与Q53移除字段中签定目标；列明历史筛选/导出消费者及在途草稿政策

**相关需求（不重评）**：NEO-043 表单精简

**既有结论链接**：

**页面编号边界**：id沿用INPUT_SCOPE中的历史Training页面映射；斜杠分别表示创建/更新或相关页面，不是一个路由ID。React实际组件由source列定位。此轮未重新核验历史截图页号。

**问题**：

- NEO-052-Q01 最终保留可维护列表，还是从新Claim移除该字段？ 例如：E53新增Software等；Q53完全删除字段。请选择一个目标。 Owner：Procurement / Finance；影响：否则开发验收方向相反

- NEO-052-Q02 历史报表还需要按这个分类筛选吗？ 例如：旧Claim的Plastic Moulds能否仍筛选导出？ Owner：Reporting owner；影响：决定兼容策略

**验收设计，未执行**：

- NEO-052-S01；角色Buyer Alice / Reference Admin；前提权限已核验；测试业务规则/金样已批准；使用隔离数据；输入政策A=2027-01-01起新建隐藏；旧Claim=Plastic Moulds；操作新建 → 再打开旧Claim和历史导出；预期新建无输入；历史原值和筛选不丢失；政策决定有记录；实际=null；NOT RUN。

- NEO-052-S02；角色Buyer Alice / Reference Admin；前提同一隔离记录；具备故障/缺失条件；输入按方案B停用已有引用的Software；操作执行受影响动作 → 再重新打开已保存记录；预期新Claim不可选；旧Claim仍显示Software，不能级联删除；实际=null；NOT RUN。

- NEO-052-S03；角色Buyer Alice / unauthorised Bob；前提非授权用户Bob；Alice已把记录由revision7保存到8；输入Bob尝试修改；Alice旧页面仍携带revision7；操作分别提交旧版本/无权限请求；预期服务端拒绝；不泄露受限内容；保留授权编辑缓冲；重新载入后只见revision8，不能覆盖已批准快照；实际=null；NOT RUN。

**来源证据**：

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E53：「The replacement NEO shall provide a maintainable Global Commodity Lead Area list including Casting/Forging/Extrusions, IT Supply Chain Design, Plastic Moulds and Software. Etc」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!K53：「Must」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!Q53：「As a procurement user - the "Global Commodity Lead Area" field should be removed to support simplification」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!R53：「Y」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 206–212 (zero-based), A.8 UC-02：「Normal path. Enter core details, notification, POA dates and estimates; add evidence; save or submit to Created.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 360–366 (zero-based), A.8 UC-24：「Normal path. Run reports and actual Tableau access, inspect refresh and period, open filtered exports and follow history to source versions.」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 4 (zero-based table 5 / row 3)：「FR1.2 | Create Risk/ Opportunity – Line Item Level Data Capture | Context: Following on from FR1.1. The below data will be captured at a line-item level (similar to the current AS IS FIND solution).
An interface should b」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 57 (zero-based table 5 / row 56)：「FR19.05 | Ref Data - Global Commodity Lead area | 」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A713:O713：「MCI_RISK_OPPORTUNITY | 索赔 | 业务 | GLOBAL_COMMODITY_LEAD_AREA_ID | int(11) | integer | 是 |  | FK | MCI_REF_COMMODITY_LEAD_AREA | COMMODITY_LEAD_AREA_ID | 已建 | 否 | Primary key of MCI_GLOBAL_COMMODITY_LEAD_AREA | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A117:O117：「MCI_REF_COMMODITY_LEAD_AREA | 参考数据 | 参考 | COMMODITY_LEAD_AREA_ID | int(11) | integer | 否 |  | PK |  |  |  | 否 | Primary key of the table. This table holds information of Commodity Lead Area | 结构+字典」

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p02/contracts.ts` / line 12：「export type ClaimValues=ClaimAlignmentValues&{transactionDrivers?:string;nonStandardTransactionKind?:string;priceCurrency?:string;buyerCode:string;nonStandardTransaction:boolean;dummy:boolean;paymentReleaseDate:string;bu」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=1] / name, fr, area：「Create Claim | FR1; FR1.1–FR1.6 | Claims and data」

- `6.技术方案/2 - Tech NEO/NEO User Training.docx` / paragraph 335 (zero-based)：「When User select to “Edit Commodity Lead Area” (Add or make certain items inactive so as to not display in dropdown selections anymore), user have the ability to select to edit the Global Commodity Lead Area reference da」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=51] / name, fr, area：「Reference data | FR19 and sub-FRs | Claims and data」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR18-038：「Global Commodity Lead Area」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID RANTD-REFERENCE-01：「Reference Data页签/字段/工具栏及离线维护差量」

现有QA引用：FR18-038, RANTD-REFERENCE-01；只链接，不重记PASS。

页面：[English proposal](pages/NEO-052.html)；[Desktop](screenshots/NEO-052-desktop.png)；[Narrow](screenshots/NEO-052-narrow.png)。


## NEO-053 简化Inflation类型及条件字段

来源：8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx / RTM for Requested Changes / row 54。采购=Should；Finance=空。建议 **P2**：源Should；先获清单即可低风险减负，但不删除历史。

**原E**：NEO currently provide options for breaking out inflation type values - energy, raw materials, freight, labour & Semi-cons

Request to simplify/remove some of these levers which are no longer required.

**原P**：空

**原Q**：As a procurement user I want to reduce the number of input fields I am required to capture - potentially inflation type lever could be one of these.

**UC定位**：UC-10 (direct)。需要逐类型退役、生效日期、旧行重开及在途Settlement影响场景。

**当前基线（代码观察）**：当前Inflation支持多个类型/材料、单位、Base/New Rate；activeReferenceChoices已支持活动选项。源未指出究竟移除Energy、Raw Materials等哪项。

**建议方案**：由业务按真实使用情况确认保留清单；新Claim只展示活动类型和其必需字段。已停用类型留在旧Claim只读，并保留费率与证据；与多Lever的分类分量区分。

**主要性质**：参考数据和适用校验简化。**架构判断**：配置治理为主，复用现有表；不等于多Lever结构重构。

**ACT核验**：ACT-001 Create Claim [FR1; FR1.1–FR1.6] existing action retained; requirement-specific gaps in UC map；补充候选：ACT-051 Reference data

- ux：选择Inflation类型后仅呈现对应材料/单位/费率；历史停用行显示Retired但仍可读。

- frontend：复用多类型表，只缩减经批准选项；切换前提示已有值如何处理。

- backend：校验活动类型、生效期和阶段完整度；不凭空填默认费率。

- data：类型IS_ACTIVE/有效期，旧Rate/Unit/Pain Share原值保留。

- workflow：最终协议前补齐仍适用的Inflation数据；退役类型在途处理需确认。

**集成**：内部参考数据；如报表消费分类需同步版本和弃用说明。

提供方：Procurement / Finance reference owner；方向：内部选项→Claim→Finance/Report

复用证据：当前activeReferenceChoices、removedRows和多类型组件可复用；公式不是本次批准内容。

未知契约：实际删哪几类、Pain Share是否仍需、历史可否改价以及报表分类映射。

**前置材料/依赖**：确认逐项停用类型/字段清单及生效日期；Finance明确历史和在途协议处理及报表映射

**相关需求（不重评）**：NEO-041 多Lever；NEO-043 精简输入

**既有结论链接**：

**页面编号边界**：id沿用INPUT_SCOPE中的历史Training页面映射；斜杠分别表示创建/更新或相关页面，不是一个路由ID。React实际组件由source列定位。此轮未重新核验历史截图页号。

**问题**：

- NEO-053-Q01 具体停用哪些Inflation类型，从何时生效？ 例如：Freight、Labour是完全停用还是仅某组织不用？ Owner：Procurement / Finance；影响：决定列表和生效策略

- NEO-053-Q02 有在途Claim使用已停用类型时可否继续Settlement？ 例如：旧Labour行有已签协议及费率。 Owner：Finance / Clearing House；影响：避免迁移后流程卡死

**验收设计，未执行**：

- NEO-053-S01；角色Buyer Alice；前提权限已核验；测试业务规则/金样已批准；使用隔离数据；输入测试配置Energy/Raw Materials活动；Freight停用；旧Claim含Freight=12 GBP；操作创建选项检查 → 再重开旧Claim；预期新建不可选Freight；旧12 GBP与单位完整，未静默改成Energy；实际=null；NOT RUN。

- NEO-053-S02；角色Buyer Alice；前提同一隔离记录；具备故障/缺失条件；输入把选中的Energy移除后取消操作；操作执行受影响动作 → 再重新打开已保存记录；预期原类型及已输入费率保持；确认移除才在当前草稿生效；实际=null；NOT RUN。

- NEO-053-S03；角色Buyer Alice / unauthorised Bob；前提非授权用户Bob；Alice已把记录由revision7保存到8；输入Bob尝试修改；Alice旧页面仍携带revision7；操作分别提交旧版本/无权限请求；预期服务端拒绝；不泄露受限内容；保留授权编辑缓冲；重新载入后只见revision8，不能覆盖已批准快照；实际=null；NOT RUN。

**来源证据**：

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E54：「NEO currently provide options for breaking out inflation type values - energy, raw materials, freight, labour & Semi-cons

Request to simplify/remove some of these levers which are no longer required.」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!K54：「Should」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!Q54：「As a procurement user I want to reduce the number of input fields I am required to capture - potentially inflation type lever could be one of these.」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!R54：「Y」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 262–268 (zero-based), A.8 UC-10：「Normal path. Add different Inflation types, units, rates, Base Position and Pain Share; retain optional CO2 evidence.」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 6 (zero-based table 5 / row 5)：「FR1.4 | Create Risk/ Opportunity – Inflation Data | Context: Following on from FR1.2. This will allow a user to capture inflation data for informational purposes as the current FIND system does today. 
An interface shoul」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 58 (zero-based table 5 / row 57)：「FR19.06 | Ref Data – Inflation Type | 」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A240:O240：「MCI_REF_INFLATION_TYPE | 参考数据 | 参考 | INFLATION_TYPE_ID | int(11) | integer | 否 |  | PK |  |  |  | 否 | Primary key of the table. This table holds information of inflation types | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A786:O786：「MCI_RISK_OPPORTUNITY_INFLATION | 索赔 | 业务 | INFLATION_TYPE_ID | int(11) | integer | 是 |  | FK | MCI_REF_INFLATION_TYPE | INFLATION_TYPE_ID | 已建 | 否 | Primary key of MCI_INFLATION_TYPE | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A792:O792：「MCI_RISK_OPPORTUNITY_INFLATION | 索赔 | 业务 | NEW_RATE | decimal(19,5) | numeric(19,5) | 是 |  |  |  |  |  | 否 | new_rate | 结构+字典」

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Claim/sections/Inflation.tsx` / line 13：「const disabled=b.lifecycle==='saving'||!!session.writeRestriction(actor),types=[...new Set(b.inflation.rows.map(r=>r.type))],active=runtime.management.activeReferenceChoices('inflation-type',inflationTypeOptions);」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=1] / name, fr, area：「Create Claim | FR1; FR1.1–FR1.6 | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=51] / name, fr, area：「Reference data | FR19 and sub-FRs | Claims and data」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR16-Q09：「历史 Inflation 扩展口径」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID NQA-28：「Inflation多类型/材料/Other/单位费率与CO2精确差值」

现有QA引用：FR16-Q09, NQA-28；只链接，不重记PASS。

页面：[English proposal](pages/NEO-053.html)；[Desktop](screenshots/NEO-053-desktop.png)；[Narrow](screenshots/NEO-053-narrow.png)。


## NEO-054 FTO / FFP数据准确性与缺口恢复

来源：8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx / RTM for Requested Changes / row 55。采购=空；Finance=空。建议 **P0**：源优先级空；金额准确和流程阻断影响核心结果，建议先处理。

**原E**：The replacement NEO should support an improved FFP/FTO accuracy to prevent issues with the creation of claims and the forecast of impact. This may be a result of input data but needs to be supported via system and potentially process change to allow this to flow more smoothly

**原P**：空

**原Q**：As a procurement user I want improved FTO/FFP data so that risk/opp creation and approval doesn't fail/stall due to issues with missing FTO/FFP data and to increase usability of forecast data.

**UC定位**：UC-07 (direct), UC-23 (related)。新增真实来源版本、四维键、FFP独立缺失、全量/增量、迟到/重复和修复回读。

**当前基线（代码观察）**：Fto.tsx已有上传校验、按FY替换、文件历史及有原因改量。UC-07要求FTO四维匹配且缺失不是零；当前OFFLINE合成源不证明生产FTO/FFP准确。

**建议方案**：将来源、有效期、匹配状态和异常队列可视化：FTO与FFP各自校验/版本；缺量阻止形成完整金额。由数据owner修复、批准替换，再由Buyer/FBP刷新受影响Claim，冻结报告不被静默重写。

**主要性质**：数据质量与来源契约＋应用恢复流程。**架构判断**：先修数据契约和摄取校验；仅在诊断证明必要时增调度/队列。

**ACT核验**：ACT-031 Manage FTO Volumes [FR8.1; FR19.12 (associated)] existing action retained; requirement-specific gaps in UC map；ACT-033 Upload FTO [FR19.12] existing action retained; requirement-specific gaps in UC map；ACT-054 FTO Refresh [BRD Appendix 7.2 CR10; FR8.1 (associated)] existing action retained; requirement-specific gaps in UC map；补充候选：

- ux：异常队列按FY/GSDB/Part/Plant或Carline显示缺口；关联受影响Claim与Request correction。

- frontend：清晰区分Missing/Stale/Valid zero，修复后显式Refresh和版本差异。

- backend：摄取暂存、唯一键/单位/有效期校验及异常隔离；原子发布有效版本。

- data：保存原始文件hash、行级键、来源批次/时间及使用版本，FTO/FFP分开。

- workflow：数据owner纠正→FBP批准/发布→受影响Claim重算；锁定报告采用后续更正而非覆盖。

**集成**：FTO上传/刷新复用候选；FFP/E2SC来自GCP/BODS MFT，目录有Id18。

提供方：Finance FTO owner；GCP Data Lake/BODS FFP owner；方向：FTO文件/GCP→NEO；异常→数据owner；重算→Finance

复用证据：现有FTO上传解析/全FY替换与Id18 MFT；不得把FFP与FTO视为同一字段。

未知契约：生产数据粒度、全量/增量、时区/日历、有效期、零与missing含义及准时SLA。；接口目录标GCP，Scheduler标EDW，经BODS的实际上游血缘需确认；09:30 Daily是导出登记值而非现网验证。

**前置材料/依赖**：FTO/FFP各自数据owner、源文件和完整schema/四维键/UoM；确认全FY替换/增量、时区/截止时间、迟到/重复/缺量规则；Finance提供正常、missing、valid zero和Runout金样

**相关需求（不重评）**：NEO-040 Runout语义；NEO-018 既有接口评估仅复用

**既有结论链接**：[NEO-018](../../solution-review/NEO-018/NEO-018_Consolidated_CN.md)

**页面编号边界**：id沿用INPUT_SCOPE中的历史Training页面映射；斜杠分别表示创建/更新或相关页面，不是一个路由ID。React实际组件由source列定位。此轮未重新核验历史截图页号。

**问题**：

- NEO-054-Q01 FTO和FFP各由谁提供，文件是全FY替换还是增量？ 例如：本日少了一个Part，表示删除、零量还是漏数？ Owner：FTO / FFP data owner；影响：决定摄取与缺失判断

- NEO-054-Q02 四维匹配失败时允许哪些人在何处改量？ 例如：同零件SOL有量、HAL缺量，不能借用SOL的量。 Owner：Finance / Data owner；影响：决定权限和修复流程

**验收设计，未执行**：

- NEO-054-S01；角色FBP Priya / Buyer Alice；前提权限已核验；测试业务规则/金样已批准；使用隔离数据；输入FY2026；GSDB UK100；JLR-100；SOL=12000；HAL缺失；source FTO-v7；操作查看异常 → 授权修复HAL=8000 → 发布v8 → 刷新Claim；预期SOL保持12000；HAL由Missing变8000；版本v8和更正理由回读；实际=null；NOT RUN。

- NEO-054-S02；角色FBP Priya / Buyer Alice；前提同一隔离记录；具备故障/缺失条件；输入上传同四维键两条矛盾量或迟到旧版本；操作执行受影响动作 → 再重新打开已保存记录；预期隔离冲突，不覆盖有效v8；报告异常负责人，原计算保留且标过期；实际=null；NOT RUN。

- NEO-054-S03；角色Buyer Alice / unauthorised Bob；前提非授权用户Bob；Alice已把记录由revision7保存到8；输入Bob尝试修改；Alice旧页面仍携带revision7；操作分别提交旧版本/无权限请求；预期服务端拒绝；不泄露受限内容；保留授权编辑缓冲；重新载入后只见revision8，不能覆盖已批准快照；实际=null；NOT RUN。

**来源证据**：

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E55：「The replacement NEO should support an improved FFP/FTO accuracy to prevent issues with the creation of claims and the forecast of impact. This may be a result of input data but needs to be supported via system and potent」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!Q55：「As a procurement user I want improved FTO/FFP data so that risk/opp creation and approval doesn't fail/stall due to issues with missing FTO/FFP data and to increase usability of forecast data.」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!R55：「Y」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 241–247 (zero-based), A.8 UC-07：「Normal path. Run a Finance golden case; inspect each output; resolve FTO match failure through its authorised update and refresh.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 353–359 (zero-based), A.8 UC-23：「Normal path. Prepare daily inputs and Draft Reserve; review and adjust; freeze Final; prepare and reconcile Journal; confirm actual posting.」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 20 (zero-based table 5 / row 19)：「FR8.1 | Display Calculations (FTO) | The application should have a summary of part level calculations carried out within the solution. 
Display vehicle line breakdowns and view of calculations. Include Runout. 
The syste」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 64 (zero-based table 5 / row 63)：「FR19.12 | Ref Data – FTO Report | The application should be able to store FTO data for each fiscal year. This should enable Ref Data Admin users to upload the excel file to ingest the data. Users should have the ability 」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A862:O862：「MCI_RISK_OPPORTUNITY_PART_FTO | 索赔 | 业务 | FROZEN_TURNOVER_ID | int(11) | integer | 是 |  |  |  |  |  | 否 | Primary key of MCI_FROZEN_TURNOVER | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A1829:O1829：「MCI_FROZEN_TURNOVER | 零件、预测与周转 | 业务 | FISCAL_YEAR_ID | int(11) | integer | 是 |  | FK | MCI_REF_FISCAL_YEAR | FISCAL_YEAR_ID | 已建 | 否 | Primary key of MCI_REF_FISCAL_YEAR | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A1868:O1868：「MCI_FTO_PROCESSOR | 零件、预测与周转 | 业务 | FISCAL_YEAR_ID | int(11) | integer | 是 |  |  |  |  |  | 否 |  | 结构」

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Management/Fto.tsx` / line 49：「{stage==='form'?<><Collapse items={[{key:'headers',label:'Valid Values for Upload',children:<><strong>Valid Excel Header(s)</strong><ol>{FTO_HEADERS.map(h=><li key={h}>{h}</li>)}</ol></>}]}/><Form layout="vertical"><Grid」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=31] / name, fr, area：「Manage FTO Volumes | FR8.1; FR19.12 (associated) | Finance and continuity」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=33] / name, fr, area：「Upload FTO | FR19.12 | Finance and continuity」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=54] / name, fr, area：「FTO Refresh | BRD Appendix 7.2 CR10; FR8.1 (associated) | Claims and data」

- `6.技术方案/2 - Tech NEO/Scheduler Processes - 2026-11-09_0944.xlsx` / Sheet 1!A15:O15：「6.0 | Fetch Future Forecast data | Fetch future forecast data from BODS server via SFTP. Data comes into BODS server from EDW. | Material Cost & Inventory | MCI Update MFT E2SC Data Scheduler | 09:30 | Daily | 4 minutes 」

- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` / CSV physical line 93; integration 18：「18,MFT E2SC,SFTP integration from Appian to BODS system to fetch E2SC csv data files present in zip folder.,Material Cost & Inventory,Other,GCP Data Lake,Appian,BODS,NA,MFT,NA,NA,NA,NA,NA,mft.jlrext.com,22,/outbound/NEO_」

- `outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/solution-review/NEO-018/NEO-018_Consolidated_CN.md` / opening summary; reused only, no reassessment：「# NEO-018 · S/4HANA供应商、零件价格、车型和收货数据接入

本轮是独立页面及集成方案，未修改现有NEO prototype、共享QA、接口、数据库或线上系统。页面英文，评估中文。代码、价格、BP、订单／收货数量及版本均为合成审阅数据，不是从SAP读取的结果；未执行财务计算、Reserve生成或下游任务派发。

## 1. 原需求与证据

Halewood转到S4后，继续依赖ECC的旧价格／收货数据会使起始价格和Actu」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR79-Q03：「FTO / GR / E2SC契约」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID F1021-25：「FTO全年替换 / 批准证据」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID NQA-76：「FTO 周口径和旧结果提示」

现有QA引用：FR79-Q03, F1021-25, NQA-76；只链接，不重记PASS。

页面：[English proposal](pages/NEO-054.html)；[Desktop](screenshots/NEO-054-desktop.png)；[Narrow](screenshots/NEO-054-narrow.png)。


## NEO-059 混合涨跌价及相关GSDB的统一谈判视图

来源：8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx / RTM for Requested Changes / row 60。采购=空；Finance=空。建议 **P0决策 / P2开发**：源无优先级；身份、DoA及实施拆分风险高，先决策再开发。

**原E**：A buyer should be able to include price up / price down changes into a single line item which NEO then identifies as either a risk or opportunity based on the overall outcome.

**原P**：空

**原Q**：Should be able to submit positive/negative on a single Risk/Opp and the System define overall if this is a risk or opp.

Should be able to manage multiple related supplier codes on a single ID (i.e. diff GSDB codes for the same supplier because they have different currencies but the claim).

This could be accomplished through improvement of Parent Claim functionality

**UC定位**：UC-02 (related), UC-18 (related), UC-23 (related)。E60净额自动定Risk/Opp，Q60相关多GSDB并建议Parent；原CLM-02要求分开关联，需新商业模型/审批口径场景。

**当前基线（代码观察）**：当前Claim单kind、单vendorCode；Working BRD CLM-02历史要求不同方向分开linked claims。Q60多代码同供应商明确提出Parent改善，不能直接把Parent删除。

**建议方案**：优先改善Parent谈判工作区：同一谈判下保留各GSDB/币种/价格方向的Line身份，汇总经批准汇率后的净额与毛额。若坚持单Line承载多个代码，先通过模型决策；页面以Parent方案供审阅。

**主要性质**：核心商业模型与汇总/审批变更候选。**架构判断**：优先Parent增强；单Line多供应商作为待批准替代模型，非默认实现。

**ACT核验**：ACT-001 Create Claim [FR1; FR1.1–FR1.6] existing action retained; requirement-specific gaps in UC map；ACT-002 Link Claim [FR2] existing action retained; requirement-specific gaps in UC map；ACT-003 Update Parent [FR3] existing action retained; requirement-specific gaps in UC map；ACT-012 Submit Settlement Request [FR9.1; FR9.4] existing action retained; requirement-specific gaps in UC map；补充候选：

- ux：一个Parent页管理相关Supplier codes，显示各Line方向、币种、GBP毛额和净额，并保留展开明细。

- frontend：父层统一编辑/预览，子Line来源清楚；无法换算时不显示误导净额。

- backend：验证供应商关系与授权，按规则计算净额/零净额；DoA采用净额还是gross需明确。

- data：沿用Parent/Line关系可减少迁移；若单Line需新增供应商/方向明细，不复用一个vendorCode塞多值。

- workflow：审批冻结Parent成员与金额版本；实施按供应商/币种拆单并独立追踪失败。

**集成**：WIPS/SAP下游仍需可识别单供应商价格命令；净额分类不能替代实施明细。

提供方：NEO / Vendor Master / Finance；WIPS/SAP；方向：供应商关系→NEO；Parent明细→各实施系统；回执→各Line

复用证据：复用现有Parent与Line版本锁；接口是否接受混合/多供应商payload未证明。

未知契约：DoA金额取净/毛、零净额分类、跨币汇率、部分实施失败对Parent状态。

**前置材料/依赖**：采购明确Parent方案可接受性及相关多GSDB关系样例；Finance批准净额/gross DoA、零净额、跨币率与舍入；实施owner定义子Line拆分和部分失败/部分完成规则

**相关需求（不重评）**：NEO-034子Line的Reporting Category/Lever组合校验，仅复用；NEO-041 多Lever；NEO-039 币种转换

**既有结论链接**：[NEO-034](../../solution-review/NEO-034/NEO-034_Consolidated_CN.md)

**页面编号边界**：id沿用INPUT_SCOPE中的历史Training页面映射；斜杠分别表示创建/更新或相关页面，不是一个路由ID。React实际组件由source列定位。此轮未重新核验历史截图页号。

**问题**：

- NEO-059-Q01 可接受一个Parent下面保留多个Line吗？ 例如：UK100 GBP风险+1000；EU100 EUR机会折合-1200，Parent净机会-200。 Owner：Procurement / Finance；影响：决定是否需重构Line

- NEO-059-Q02 DoA按净200，还是正负两侧较大金额1200判断？ 例如：抵消后净额很小但实际价格变动较大。 Owner：Finance / DoA owner；影响：决定审批风险和金额

**验收设计，未执行**：

- NEO-059-S01；角色Buyer Alice；前提权限已核验；测试业务规则/金样已批准；使用隔离数据；输入同一Supplier两GSDB；L1风险+1000 GBP；L2机会-1200 GBP等值；经批准净额政策；操作加入同Parent → Preview aggregate → 保存并发起审批；预期Parent净-200 GBP机会；gross risk1000/opportunity1200及两Line身份保留；实际=null；NOT RUN。

- NEO-059-S02；角色Buyer Alice；前提同一隔离记录；具备故障/缺失条件；输入EU100缺GBP汇率或一个Line被另一Request锁定；操作执行受影响动作 → 再重新打开已保存记录；预期不产出完整净额，不绕过锁；允许保留草稿并指出受影响Line；实际=null；NOT RUN。

- NEO-059-S03；角色Buyer Alice / unauthorised Bob；前提非授权用户Bob；Alice已把记录由revision7保存到8；输入Bob尝试修改；Alice旧页面仍携带revision7；操作分别提交旧版本/无权限请求；预期服务端拒绝；不泄露受限内容；保留授权编辑缓冲；重新载入后只见revision8，不能覆盖已批准快照；实际=null；NOT RUN。

- NEO-059-S04；角色Buyer Alice；前提对应政策、金样与接口/权限测试环境已批准；隔离数据；输入L1 +1000 GBP；L2 -1150 EUR；批准率1GBP=1.15EUR；合计0GBP；操作汇总并查看分类、毛额及DoA依据；预期显示gross risk1000/gross opportunity1000及net0；零净额分类按批准规则，不任意标Risk或Opportunity；实际=null；NOT RUN。

- NEO-059-S05；角色Buyer Alice；前提对应政策、金样与接口/权限测试环境已批准；隔离数据；输入同Parent两Line均已审批；UK100成功回执WIPS-0042；EU100失败；操作读取两回执，对失败Line重试；预期成功Line不重复发送；Parent保持部分完成；原成员/审批金额快照不变；失败Line有责任人；实际=null；NOT RUN。

**来源证据**：

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E60：「A buyer should be able to include price up / price down changes into a single line item which NEO then identifies as either a risk or opportunity based on the overall outcome.」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!Q60：「Should be able to submit positive/negative on a single Risk/Opp and the System define overall if this is a risk or opp.

Should be able to manage multiple related supplier codes on a single ID (i.e. diff GSDB codes for t」

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!R60：「Y」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 206–212 (zero-based), A.8 UC-02：「Normal path. Enter core details, notification, POA dates and estimates; add evidence; save or submit to Created.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 318–324 (zero-based), A.8 UC-18：「Normal path. Create Settlement from the approved basis, review final values and submit; reject, correct and rerequest in a separate run.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 353–359 (zero-based), A.8 UC-23：「Normal path. Prepare daily inputs and Draft Reserve; review and adjust; freeze Final; prepare and reconcile Journal; confirm actual posting.」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 4 (zero-based table 5 / row 3)：「FR1.2 | Create Risk/ Opportunity – Line Item Level Data Capture | Context: Following on from FR1.1. The below data will be captured at a line-item level (similar to the current AS IS FIND solution).
An interface should b」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 9 (zero-based table 5 / row 8)：「FR2 | Group Risks/ Opportunities under one Parent ID (single negotiation) | Ability for buyer user to select to group multiple risks/ opportunities. 
Buyer can add overall parent level description.」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 10 (zero-based table 5 / row 9)：「FR3 | Create new Risks/ Opportunity under an existing parent ID (single negotiation)

Edit parent level item | Context: Buyers will have the ability to create a new line item under a parent ID.
A “buyer” user should have」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A693:O693：「MCI_RISK_OPPORTUNITY | 索赔 | 业务 | FISCAL_YEAR_ID | int(11) | integer | 是 |  | FK | MCI_REF_FISCAL_YEAR | FISCAL_YEAR_ID | 已建 | 否 | Primary key of MCI_FISCAL_YEAR | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A727:O727：「MCI_RISK_OPPORTUNITY | 索赔 | 业务 | COMPANY_CODE | varchar(255) | varchar(255) | 是 |  |  |  |  |  | 否 | company_code | 结构+字典」

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p02/contracts.ts` / line 10：「export type VendorResult={kind:'matched';vendorCode:string;vendorName:string;currency:string;sourceVersion:string}|{kind:'missing'|'ambiguous'|'currency-missing'|'stale';vendorCode:string};」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=1] / name, fr, area：「Create Claim | FR1; FR1.1–FR1.6 | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=2] / name, fr, area：「Link Claim | FR2 | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=3] / name, fr, area：「Update Parent | FR3 | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=12] / name, fr, area：「Submit Settlement Request | FR9.1; FR9.4 | Authorisation」

- `outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/solution-review/NEO-034/NEO-034_Consolidated_CN.md` / opening summary; reused only, no reassessment：「# NEO-034 · Reporting Category 与 Lever 组合校验

## 1. 本次结论

这条要解决的是：**两个下拉值各自合法，放在一起却不符合 Finance 的分类要求。** 例如选了某个 Lever，却配上业务不允许的 Reporting Category；目前没有组合限制，后面的准备金／报告就可能分错类。[S1]

建议建立一份由业务签认、带版本的允许组合清单，在两边修改时使用同一校验：**Financ」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR18-015：「Risk / Opportunity*」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID UI-ACT001-PART-SIGN-READBACK-01：「ACT001 POA editor and saved Parts sign/alert differ」

现有QA引用：FR18-015, UI-ACT001-PART-SIGN-READBACK-01；只链接，不重记PASS。

页面：[English proposal](pages/NEO-059.html)；[Desktop](screenshots/NEO-059-desktop.png)；[Narrow](screenshots/NEO-059-narrow.png)。


## NEO-060 复用Copy Claim并补齐复制边界

来源：8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx / RTM for Requested Changes / row 61。采购=空；Finance=空。建议 **P1**：源空；已有基础，差量较明确，减少重复输入。

**原E**：Simplify repeat claim creation by allowing buyers to copy an existing claim when raising a similar case, reducing repetitive data entry and improving processing efficiency.

**原P**：空

**原Q**：空

**UC定位**：UC-03 (direct), UC-02 (related)。不是全新UC；需覆盖真实可访问源、复制字段清单、重新取主数据、重复点击/保存/重开。

**当前基线（代码观察）**：当前React存在Copy existing Claim，调用canViewSource/startCopy；source来自fixtures数组。UC-03和ENH-001已明确不复制审批执行历史。仅代码观察，当前产品动态持久化未在本轮执行。

**建议方案**：复用现有Copy入口，改为有权限的已保存Claim来源。显示将复制的业务内容，默认重取供应商/价格/日期并清空审批/Settlement/PO/WIPS结果；新Draft只有显式Save后持久化。

**主要性质**：既有能力完善与真实数据接入。**架构判断**：增强现有Claim服务，不新建复制平台或第二向导。

**ACT核验**：ACT-001 Create Claim [FR1; FR1.1–FR1.6] existing action retained; requirement-specific gaps in UC map；ACT-004 Update Claim [FR6; FR6.1] existing action retained; requirement-specific gaps in UC map；补充候选：

- ux：来源搜索、复制范围与日期检查，Create draft后进入熟悉的向导。

- frontend：保留原Copy flow，展示需重新确认字段，取消无新记录。

- backend：服务端逐项白名单复制、源权限再核验、幂等保存，不复制已冻结审批。

- data：新ID/owner/revision，sourceClaimId审计；附件仅复制获准引用并重新验权。

- workflow：新Draft重新走完整批准流程，原Claim无变化。

**集成**：无需新增外部系统；供应商/价格用既有查询刷新。

提供方：NEO Claim repository；既有SAP参考服务；方向：授权源Claim→新Draft；主数据→新Draft

复用证据：views/Claim/index.tsx已有入口；UC-03、ENH-001直接覆盖。fixture可用不代表生产库接口已接通。

未知契约：可复制字段/附件清单、跨FY默认日期、Confidential权限和源删除后的行为。

**前置材料/依赖**：业务批准复制字段/附件白名单和跨FY重置清单；验证真实Claim仓库检索、保存时源权限和幂等契约

**相关需求（不重评）**：NEO-029 复用既有POC任务结论，不重评

**既有结论链接**：[NEO-029](../../solution-review/NEO-029/TASK_TO_POC_CN.md)

**页面编号边界**：id沿用INPUT_SCOPE中的历史Training页面映射；斜杠分别表示创建/更新或相关页面，不是一个路由ID。React实际组件由source列定位。此轮未重新核验历史截图页号。

**问题**：

- NEO-060-Q01 复制时哪些字段和附件必须保留，哪些必须清空？ 例如：同供应商新年度协议，旧价格和签字附件能否带入？ Owner：Procurement / Security；影响：决定白名单和误用风险

- NEO-060-Q02 源Claim被撤销或访问权收回后，保存新草稿怎么办？ 例如：复制后尚未保存，权限已撤销。 Owner：Product / Security；影响：决定保存时再校验

**验收设计，未执行**：

- NEO-060-S01；角色Buyer Alice；前提权限已核验；测试业务规则/金样已批准；使用隔离数据；输入可访问source NEO-L-00001，FY2026，含Settlement与WIPS结果；操作选择Copy → 确认业务内容 → Save draft → 重开源和新记录；预期只新增一个Draft；source不改；新记录无审批/PO/WIPS结果且source link可审计；实际=null；NOT RUN。

- NEO-060-S02；角色Buyer Alice；前提同一隔离记录；具备故障/缺失条件；输入连续双击Save或源变为无权限；操作执行受影响动作 → 再重新打开已保存记录；预期同一意图仅一个Draft；失权时拒绝并不泄露源详情；实际=null；NOT RUN。

- NEO-060-S03；角色Buyer Alice / unauthorised Bob；前提非授权用户Bob；Alice已把记录由revision7保存到8；输入Bob尝试修改；Alice旧页面仍携带revision7；操作分别提交旧版本/无权限请求；预期服务端拒绝；不泄露受限内容；保留授权编辑缓冲；重新载入后只见revision8，不能覆盖已批准快照；实际=null；NOT RUN。

**来源证据**：

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E61：「Simplify repeat claim creation by allowing buyers to copy an existing claim when raising a similar case, reducing repetitive data entry and improving processing efficiency.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 213–219 (zero-based), A.8 UC-03：「Normal path. Create on behalf or initialise a copy; confirm ownership and explicitly save the new draft.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 206–212 (zero-based), A.8 UC-02：「Normal path. Enter core details, notification, POA dates and estimates; add evidence; save or submit to Created.」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 2 (zero-based table 5 / row 1)：「FR1 | Create Risk/ Opportunity | Context: When a user (Buyer) accesses the new application, they will see an option to create a new Risk or Opportunity. 
Ability for a “Buyer” user to “Create New Risk/ Opportunity”.
Once」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 14 (zero-based table 5 / row 13)：「FR6 | Edit Risk/ Opportunity | Context: As negotiations with Suppliers progress, the line-item information will require updates. The below functionality details how a user will carry out updates on a line item. 
A Buyer,」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A693:O693：「MCI_RISK_OPPORTUNITY | 索赔 | 业务 | FISCAL_YEAR_ID | int(11) | integer | 是 |  | FK | MCI_REF_FISCAL_YEAR | FISCAL_YEAR_ID | 已建 | 否 | Primary key of MCI_FISCAL_YEAR | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A704:O704：「MCI_RISK_OPPORTUNITY | 索赔 | 业务 | MYA_REFERENCE | varchar(255) | varchar(255) | 是 |  |  |  |  |  | 否 | mya_reference | 结构+字典」

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Claim/index.tsx` / line 30：「if(copying)return <><PageHeader title="Copy existing Claim"/><Card><Form layout="vertical"><Form.Item label="Source Claim"><Select showSearch={{optionFilterProp:"label"}} value={copyId} onChange={setCopyId} options={sour」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=1] / name, fr, area：「Create Claim | FR1; FR1.1–FR1.6 | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=4] / name, fr, area：「Update Claim | FR6; FR6.1 | Claims and data」

- `outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/solution-review/NEO-029/TASK_TO_POC_CN.md` / opening summary; reused only, no reassessment：「# NEO-029｜沿用现有 POC 的会话超时／编辑进度恢复方案

用户在 NEO Specialist 对话中明确：“029 我们 POC 有方案了，用 POC 的，发一个 task 就好了。”请按你这里已有的 POC 方案处理，不另起一套设计。

需求来源：
/Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China r」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR1-LOCKED-DRAFT-ENTRY：「Settlement锁定的未登记历史样本误入创建向导且Next无反馈」

现有QA引用：FR1-LOCKED-DRAFT-ENTRY；只链接，不重记PASS。

页面：[English proposal](pages/NEO-060.html)；[Desktop](screenshots/NEO-060-desktop.png)；[Narrow](screenshots/NEO-060-narrow.png)。


## NEO-061 完善Parts搜索筛选及数据范围

来源：8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx / RTM for Requested Changes / row 62。采购=空；Finance=空。建议 **P1**：源空；已有能力需确认生产覆盖，聚焦可用性与大数据正确性。

**原E**：Improve part selection efficiency by providing practical search and filtering options(supplier, plant, vehicle line etc.), enabling buyers to quickly identify the correct parts from large datasets.

**原P**：空

**原Q**：空

**UC定位**：UC-04 (direct), UC-06 (related)。补UC-04直接映射；新增服务端过滤/分页、跨页选择保持、车系语义及来源失败。

**当前基线（代码观察）**：当前SelectParts已有supplier scoped catalogue、company/plant、part number search、vehicle/model year、跨页选择及来源变更处理。增量不是从零加筛选；实际API目录只证明vendor/plant/offset/limit。

**建议方案**：把常用车系等筛选与搜索放在同一工作区，保留part/plant身份和跨页选择。先核验API返回完整性和规模，再决定服务端扩展；错误、空结果、已筛选无结果分别呈现。

**主要性质**：已有UX/查询性能完善；接口过滤扩展待确认。**架构判断**：优先现有查询层扩展，索引或缓存须实测后决定。

**ACT核验**：ACT-001 Create Claim [FR1; FR1.1–FR1.6] existing action retained; requirement-specific gaps in UC map；ACT-026 Bulk Upload Parts [FR1.6; FR13 (associated)] existing action retained; requirement-specific gaps in UC map；补充候选：

- ux：同一栏Supplier、Plant、Vehicle line和搜索；显示已选范围和明确空态。

- frontend：受控筛选、取消过期响应、跨页选择/重置提示，表格只内部横滚。

- backend：授权数据先过滤再稳定分页；索引与返回字段按真实数据规模验证。

- data：保持supplier/company/part/plant/sourceVersion完整业务键，避免同零件不同工厂合并。

- workflow：选择源变化时显式核验；保留已选输入而不静默替换。

**集成**：复用MCI_getPartDetails / getPartPriceDetails；vehicle line过滤参数未在目录证明。

提供方：SAP via Apigee；NEO查询服务；方向：NEO检索请求→SAP；分页结果→NEO

复用证据：Id1有vendor、plant、offset、limit；Id2还含materialNumber；现有过滤UI和selection模型可复用。

未知契约：服务端车系/模糊搜索、总数、排序稳定性、数据最大规模和timeout。

**前置材料/依赖**：SAP/Apigee证实车系/part搜索、稳定排序/总数和分页契约；采购提供最大真实数据规模和常用筛选样例

**相关需求（不重评）**：NEO-018 SAP接口已评结论仅复用；NEO-066 性能

**既有结论链接**：[NEO-018](../../solution-review/NEO-018/NEO-018_Consolidated_CN.md)

**页面编号边界**：id沿用INPUT_SCOPE中的历史Training页面映射；斜杠分别表示创建/更新或相关页面，不是一个路由ID。React实际组件由source列定位。此轮未重新核验历史截图页号。

**问题**：

- NEO-061-Q01 车系按零件适配还是按当年生产计划筛选？ 例如：同Part适配Defender，但本年HAL不生产。 Owner：Procurement / Part Master owner；影响：决定过滤含义

- NEO-061-Q02 真实最大结果和常用筛选组合是什么？ 例如：一个GSDB下2万part–plant，用户常查哪些字段？ Owner：Procurement / SAP API owner；影响：决定服务端过滤与分页

**验收设计，未执行**：

- NEO-061-S01；角色Buyer Alice；前提权限已核验；测试业务规则/金样已批准；使用隔离数据；输入Supplier UK100；Plant SOL；Vehicle Defender；search JLR-100；操作Search → 选择结果 → 切到第二页再返回；预期仅授权匹配行；已选part–plant仍在；计数来自全部过滤结果；实际=null；NOT RUN。

- NEO-061-S02；角色Buyer Alice；前提同一隔离记录；具备故障/缺失条件；输入SAP超时，之后较早请求迟到；操作执行受影响动作 → 再重新打开已保存记录；预期显示Retry并保留筛选/选择；旧响应不覆盖新查询结果；实际=null；NOT RUN。

- NEO-061-S03；角色Buyer Alice / unauthorised Bob；前提非授权用户Bob；Alice已把记录由revision7保存到8；输入Bob尝试修改；Alice旧页面仍携带revision7；操作分别提交旧版本/无权限请求；预期服务端拒绝；不泄露受限内容；保留授权编辑缓冲；重新载入后只见revision8，不能覆盖已批准快照；实际=null；NOT RUN。

**来源证据**：

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E62：「Improve part selection efficiency by providing practical search and filtering options(supplier, plant, vehicle line etc.), enabling buyers to quickly identify the correct parts from large datasets.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 220–226 (zero-based), A.8 UC-04：「Normal path. Select several plants and parts; assign plant coverage; generate current prices.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 234–240 (zero-based), A.8 UC-06：「Normal path. Download template and valid values; validate a file; apply the accepted batch.」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 8 (zero-based table 5 / row 7)：「FR1.6 | Create Risk/ Opportunity – Add Part Level Data (for POA) | Context: Following on from FR1.2. This will allow a user to capture part level data relating to a POA. Where the parts relate to WIPS, it will aim to sim」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 65 (zero-based table 5 / row 64)：「FR19.13 | Production Part Numbers | Application should have a link to reference data for Production Part Numbers (from SAP). The application will need to pull the following:
White Part Numbers
Coloured Part Numbers 」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A906:O906：「MCI_RISK_OPPORTUNITY_PART_WIPS_CLAIM | 索赔 | 业务 | START_PRICE | decimal(19,5) | numeric(19,5) | 是 |  |  |  |  |  | 否 | Column to hold value of start_price | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A907:O907：「MCI_RISK_OPPORTUNITY_PART_WIPS_CLAIM | 索赔 | 业务 | START_PRICE_CURRENCY | varchar(255) | varchar(255) | 是 |  |  |  |  |  | 否 | Column to hold value of start_price_currency | 结构+字典」

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Parts/SelectParts.tsx` / line 17：「const filtered=filterParts(catalogue,f),scopeKey=JSON.stringify([b.claim.vendorCode,s.sourceVersion,f.companyCodes,f.plants,f.vehicleLines,f.modelYears]),loaded=f.partsScopeFingerprint===scopeKey||(f.partsScopeFingerprin」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=1] / name, fr, area：「Create Claim | FR1; FR1.1–FR1.6 | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=26] / name, fr, area：「Bulk Upload Parts | FR1.6; FR13 (associated) | Claims and data」

- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` / CSV physical line 7; integration 1：「1,MCI_getPartDetails,Integration used to fetch parts details from SAP to Appian and process with POA claims,Material Cost & Inventory,Integration,Appian,SAP,Apigee,MCI SAP,GET,https://api.jlr-ddc.com/material-cost-invent」

- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` / CSV physical line 8; integration 2：「2,MCI_getPartPriceDetails,Integration used to fetch part price details from SAP to Appian and process with POA claims,Material Cost & Inventory,Integration,Appian,SAP,Apigee,MCI SAP,GET,https://api.jlr-ddc.com/material-c」

- `outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/solution-review/NEO-018/NEO-018_Consolidated_CN.md` / opening summary; reused only, no reassessment：「# NEO-018 · S/4HANA供应商、零件价格、车型和收货数据接入

本轮是独立页面及集成方案，未修改现有NEO prototype、共享QA、接口、数据库或线上系统。页面英文，评估中文。代码、价格、BP、订单／收货数量及版本均为合成审阅数据，不是从SAP读取的结果；未执行财务计算、Reserve生成或下游任务派发。

## 1. 原需求与证据

Halewood转到S4后，继续依赖ECC的旧价格／收货数据会使起始价格和Actu」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID RANTD-PARTS-DEMO-01：「Parts与Calculation缺可直接演示的完整双工厂样例」

现有QA引用：RANTD-PARTS-DEMO-01；只链接，不重记PASS。

页面：[English proposal](pages/NEO-061.html)；[Desktop](screenshots/NEO-061-desktop.png)；[Narrow](screenshots/NEO-061-narrow.png)。


## NEO-062 价格差计算明细与缺失解释

来源：8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx / RTM for Requested Changes / row 63。采购=空；Finance=空。建议 **P1**：源空；透明度可拆为展示已核算值，但未确认金额不能伪装解释完备。

**原E**：Improve price-gap transparency by clearly showing how the price gap is calculated, including the underlying data and any missing or incorrect information, enabling buyers to understand and resolve issues more efficiently.

**原P**：空

**原Q**：空

**UC定位**：UC-07 (direct), UC-24 (related)。新增行级公式/金额/版本解释、missing与zero以及更正后重算和导出一致。

**当前基线（代码观察）**：CalculationResults已有Start/New price、GBP delta、年度/Calendarised和Runout；Calculation.tsx有来源和stale提示。新增重点是可解释链条与错误定位，不是重复新增一张汇总表。

**建议方案**：从每个价格差打开明细，展示原价、新价、币种/汇率、数量来源、日期口径和精度，再给出公式与版本。缺数据标Incomplete并给Correct source；真实0显示0。

**主要性质**：可解释展示＋计算追溯数据。**架构判断**：同一计算服务输出可解释trace；禁止页面和服务公式分叉。

**ACT核验**：ACT-008 Update Buyer Performance [FR7] existing action retained; requirement-specific gaps in UC map；ACT-042 NAF Pin Report [FR20.4] existing action retained; requirement-specific gaps in UC map；补充候选：

- ux：一行一条清晰公式及inputs，缺失处直接提供更正路径。

- frontend：明细展开/抽屉及空值语义；当前值与历史计算版本分开。

- backend：计算结果输出稳定trace DTO，避免前端自行再计算一套Finance值。

- data：保存input/output/source/rule/rounding版本，引用原来源而不是仅存格式化字符串。

- workflow：更正输入后显式Recalculate，审批使用最新被确认版本；历史冻结金额不改写。

**集成**：主要复用既有计算输入；只有来源缺字段才扩展，不因新增解释UI建新接口。

提供方：NEO calculation service / Finance data owner；方向：内部计算trace→页面/导出；缺口→对应owner

复用证据：CalculationResults现有行和current/stale检查可复用；正式Finance金样仍待确认。

未知契约：price gap确切定义、FX方向/rounding、FTO与FFP使用边界及缺失策略。

**前置材料/依赖**：Finance定义price gap单位及独立计算金样；计算服务提供input/source/rule/rounding追溯字段及missing语义

**相关需求（不重评）**：NEO-054 FTO/FFP；NEO-039 FX

**既有结论链接**：

**页面编号边界**：id沿用INPUT_SCOPE中的历史Training页面映射；斜杠分别表示创建/更新或相关页面，不是一个路由ID。React实际组件由source列定位。此轮未重新核验历史截图页号。

**问题**：

- NEO-062-Q01 这里price gap指单价差，还是含量后的年度差额？ 例如：100→105 GBP是5 GBP/part，12,000量后60,000 GBP。 Owner：Finance / Procurement；影响：决定标题/单位/公式

- NEO-062-Q02 缺量时允许显示单价差并把总额标Incomplete吗？ 例如：单价齐全但FTO为空，不能总额=0。 Owner：Finance；影响：决定部分可用结果

**验收设计，未执行**：

- NEO-062-S01；角色Buyer Alice；前提权限已核验；测试业务规则/金样已批准；使用隔离数据；输入start100 GBP；new105 GBP；FTO12000；完整FY；规则v1；操作打开Price gap → 核对输入 → 重算并保存/导出；预期单价差5 GBP；Annual60000 GBP；每项源版本可追溯且与导出一致；实际=null；NOT RUN。

- NEO-062-S02；角色Buyer Alice；前提同一隔离记录；具备故障/缺失条件；输入FTO由12000改为missing；操作执行受影响动作 → 再重新打开已保存记录；预期单价差仍5；Annual显示—/Incomplete而不是0；需更正并重算；实际=null；NOT RUN。

- NEO-062-S03；角色Buyer Alice / unauthorised Bob；前提非授权用户Bob；Alice已把记录由revision7保存到8；输入Bob尝试修改；Alice旧页面仍携带revision7；操作分别提交旧版本/无权限请求；预期服务端拒绝；不泄露受限内容；保留授权编辑缓冲；重新载入后只见revision8，不能覆盖已批准快照；实际=null；NOT RUN。

**来源证据**：

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E63：「Improve price-gap transparency by clearly showing how the price gap is calculated, including the underlying data and any missing or incorrect information, enabling buyers to understand and resolve issues more efficiently」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 241–247 (zero-based), A.8 UC-07：「Normal path. Run a Finance golden case; inspect each output; resolve FTO match failure through its authorised update and refresh.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 360–366 (zero-based), A.8 UC-24：「Normal path. Run reports and actual Tableau access, inspect refresh and period, open filtered exports and follow history to source versions.」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 18 (zero-based table 5 / row 17)：「. FR7 | Calculate POA Claim Value – Buyer Performance | Context: Once a user has provided details of the part changes (POA), the application will need to calculate the claim value based on the changes defined by the user」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 20 (zero-based table 5 / row 19)：「FR8.1 | Display Calculations (FTO) | The application should have a summary of part level calculations carried out within the solution. 
Display vehicle line breakdowns and view of calculations. Include Runout. 
The syste」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A906:O906：「MCI_RISK_OPPORTUNITY_PART_WIPS_CLAIM | 索赔 | 业务 | START_PRICE | decimal(19,5) | numeric(19,5) | 是 |  |  |  |  |  | 否 | Column to hold value of start_price | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A907:O907：「MCI_RISK_OPPORTUNITY_PART_WIPS_CLAIM | 索赔 | 业务 | START_PRICE_CURRENCY | varchar(255) | varchar(255) | 是 |  |  |  |  |  | 否 | Column to hold value of start_price_currency | 结构+字典」

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Parts/CalculationResults.tsx` / line 15：「const columns:TableColumnsType<CalculationRow>=[{title:'Part number',dataIndex:'part',width:180},{title:'Plant',dataIndex:'plant'},{title:'Is Excluded?',render:()=> 'No'},{title:'Vehicle line',dataIndex:'vehicleLine'},{t」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=8] / name, fr, area：「Update Buyer Performance | FR7 | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=42] / name, fr, area：「NAF Pin Report | FR20.4 | Finance and continuity」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR79-Q01：「日期 / Runout / 周切分」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR79-Q03：「FTO / GR / E2SC契约」

现有QA引用：FR79-Q01, FR79-Q03；只链接，不重记PASS。

页面：[English proposal](pages/NEO-062.html)；[Desktop](screenshots/NEO-062-desktop.png)；[Narrow](screenshots/NEO-062-narrow.png)。


## NEO-066 大量Parts处理性能与可靠恢复

来源：8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx / RTM for Requested Changes / row 67。采购=空；Finance=空。建议 **P1**：源空；报告超时/失败影响核心流程，但不能用虚构性能数字承诺。

**原E**：Improve system performance when processing large volumes of parts to avoid page loading timeouts and failed submissions, reducing the need for buyers to retry and preventing disruption to the claim process.

**原P**：空

**原Q**：空

**UC定位**：UC-04 (related), UC-07 (related), UC-08 (direct)。补UC-08直接场景；需真实规模基线、重复开始、刷新续查、超时已提交、部分失败及取消。

**当前基线（代码观察）**：当前Calculation有本地input check job registry、retry same frozen input，清楚提示其不代表财务有效。没有生产并发/延迟证据；不能据此称大批量问题已解决。

**建议方案**：先采集实际parts规模、API/SQL/浏览器阶段耗时与失败率；针对瓶颈分页/批量查询/索引。超同步预算才采用持久任务；页面保存输入、显示真实进度、可离开返回及安全重试。

**主要性质**：性能诊断和可靠性工程；架构方案条件决定。**架构判断**：先测后定；不直接认定需要消息队列/新计算平台。

**ACT核验**：ACT-001 Create Claim [FR1; FR1.1–FR1.6] existing action retained; requirement-specific gaps in UC map；ACT-026 Bulk Upload Parts [FR1.6; FR13 (associated)] existing action retained; requirement-specific gaps in UC map；补充候选：

- ux：处理状态与已保存版本清楚，失败只重试同一操作，显示可纠正行。

- frontend：避免全量DOM和重复请求；分页/虚拟表需无障碍验证；页面返回恢复同一操作。

- backend：批量请求、稳定分页、超时预算、幂等提交和状态读回；任务worker仅在实测需要时新增。

- data：操作id/inputRevision/sourceVersion、结果版本和失败明细持久化；原数据不清空。

- workflow：未知结果先核验，不能因超时重复发起审批/下游；取消只在允许阶段生效。

**集成**：SAP/Apigee分页契约已有；真实rate limit/timeout/批次最大值待测。

提供方：NEO frontend/backend；SAP/Apigee；DB/operations owner；方向：NEO批量请求→SAP；进度/回执→NEO

复用证据：Id1/2 offset+limit与本地job状态模式候选；本地输入检查并非生产计算任务。

未知契约：P50/P95数据规模、并发、SLO、SQL计划、API限流、重试安全和部署容量。

**前置材料/依赖**：记录真实N行/C并发及各阶段P50/P95/失败率基线；产品/运维批准响应和完成SLO、部署容量；SAP提供批次/限流/timeout与重试契约，DB提供执行计划

**相关需求（不重评）**：NEO-061 查询；NEO-054 数据完整性

**既有结论链接**：

**页面编号边界**：id沿用INPUT_SCOPE中的历史Training页面映射；斜杠分别表示创建/更新或相关页面，不是一个路由ID。React实际组件由source列定位。此轮未重新核验历史截图页号。

**问题**：

- NEO-066-Q01 最慢案例有多少Part–Plant行，在哪一步超时？ 例如：2万行加载慢，还是提交后5分钟没有结果？ Owner：Procurement / Operations；影响：定位性能阶段

- NEO-066-Q02 业务可接受多久看到已保存/最终结果？ 例如：先返回受理号、几分钟后完成是否可接受？ Owner：Product / Operations；影响：决定SLO和同步/异步

**验收设计，未执行**：

- NEO-066-S01；角色Buyer Alice；前提权限已核验；测试业务规则/金样已批准；使用隔离数据；输入经业务确认的N行代表数据；并发C；基线/SLO先审批；操作OP-01；revision7；操作提交 → 离开页面 → 重新打开 → 重复点击同一操作并读取结果；预期一个操作及结果版本；所有N行完整；实测P95满足已批准目标；输入不丢；实际=null；NOT RUN。

- NEO-066-S02；角色Buyer Alice；前提同一隔离记录；具备故障/缺失条件；输入请求超时但服务端已接受OP-01；操作执行受影响动作 → 再重新打开已保存记录；预期页面先查OP-01状态；不创建OP-02；失败重试保留同一冻结输入；实际=null；NOT RUN。

- NEO-066-S03；角色Buyer Alice / unauthorised Bob；前提非授权用户Bob；Alice已把记录由revision7保存到8；输入Bob尝试修改；Alice旧页面仍携带revision7；操作分别提交旧版本/无权限请求；预期服务端拒绝；不泄露受限内容；保留授权编辑缓冲；重新载入后只见revision8，不能覆盖已批准快照；实际=null；NOT RUN。

**来源证据**：

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E67：「Improve system performance when processing large volumes of parts to avoid page loading timeouts and failed submissions, reducing the need for buyers to retry and preventing disruption to the claim process.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 220–226 (zero-based), A.8 UC-04：「Normal path. Select several plants and parts; assign plant coverage; generate current prices.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 241–247 (zero-based), A.8 UC-07：「Normal path. Run a Finance golden case; inspect each output; resolve FTO match failure through its authorised update and refresh.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 248–254 (zero-based), A.8 UC-08：「Normal path. Read actual status; leave the page; return to the same claim; receive the ready notification; review Insight.」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 8 (zero-based table 5 / row 7)：「FR1.6 | Create Risk/ Opportunity – Add Part Level Data (for POA) | Context: Following on from FR1.2. This will allow a user to capture part level data relating to a POA. Where the parts relate to WIPS, it will aim to sim」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 18 (zero-based table 5 / row 17)：「. FR7 | Calculate POA Claim Value – Buyer Performance | Context: Once a user has provided details of the part changes (POA), the application will need to calculate the claim value based on the changes defined by the user」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A906:O906：「MCI_RISK_OPPORTUNITY_PART_WIPS_CLAIM | 索赔 | 业务 | START_PRICE | decimal(19,5) | numeric(19,5) | 是 |  |  |  |  |  | 否 | Column to hold value of start_price | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A907:O907：「MCI_RISK_OPPORTUNITY_PART_WIPS_CLAIM | 索赔 | 业务 | START_PRICE_CURRENCY | varchar(255) | varchar(255) | 是 |  |  |  |  |  | 否 | Column to hold value of start_price_currency | 结构+字典」

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Parts/Calculation.tsx` / line 29：「<Collapse items={[{key:'checks',label:'Input checks',children:<Flex vertical gap={16}><Button disabled={p.disabled||!b.p03?.input.selectedIds.length||b.p03?.input.reconciliationRequired} onClick={start}>Start input check」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=1] / name, fr, area：「Create Claim | FR1; FR1.1–FR1.6 | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=26] / name, fr, area：「Bulk Upload Parts | FR1.6; FR13 (associated) | Claims and data」

- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` / CSV physical line 7; integration 1：「1,MCI_getPartDetails,Integration used to fetch parts details from SAP to Appian and process with POA claims,Material Cost & Inventory,Integration,Appian,SAP,Apigee,MCI SAP,GET,https://api.jlr-ddc.com/material-cost-invent」

- `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv` / CSV physical line 8; integration 2：「2,MCI_getPartPriceDetails,Integration used to fetch part price details from SAP to Appian and process with POA claims,Material Cost & Inventory,Integration,Appian,SAP,Apigee,MCI SAP,GET,https://api.jlr-ddc.com/material-c」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR79-Q03：「FTO / GR / E2SC契约」

现有QA引用：FR79-Q03；只链接，不重记PASS。

页面：[English proposal](pages/NEO-066.html)；[Desktop](screenshots/NEO-066-desktop.png)；[Narrow](screenshots/NEO-066-narrow.png)。


## NEO-068 多年生产率协议与逐年履行

来源：8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx / RTM for Requested Changes / row 69。采购=空；Finance=空。建议 **P0决策 / P2开发**：源空；影响多年金额、审批和实施，需要先提供真实样例及金样。

**原E**：Support multi-year productivity agreements, as many supplier commitments extend beyond a single year.

**原P**：空

**原Q**：空

**UC定位**：UC-02 (related), UC-18 (related), UC-23 (related), UC-24 (related)。现UC单FY/期间场景不能证明多年；新增年度计划、重叠生效期、复利基价、逐年审批/实施及协议修订。

**当前基线（代码观察）**：ClaimValues只有fiscalYearId，MYA Reference是文本引用，不是多年履约模型；Reserve/Auto PAM按财年和期间消费，不能简单把FY改多选。

**建议方案**：新增协议主档和逐年价格计划，保留每年适用Part/Plant/币种、基价及承诺变化，逐年生成/关联Claim快照。先确认一次总批准还是逐年批准，再决定未来年度状态；未到期不提前标实施。

**主要性质**：协议/年度计划数据模型与审批/Finance扩展。**架构判断**：协议聚合+年度子记录，保持单FY Claim兼容；不建议在既有FY字段存数组。

**ACT核验**：ACT-001 Create Claim [FR1; FR1.1–FR1.6] existing action retained; requirement-specific gaps in UC map；ACT-012 Submit Settlement Request [FR9.1; FR9.4] existing action retained; requirement-specific gaps in UC map；ACT-029 Generate Reserve [FR17.5] existing action retained; requirement-specific gaps in UC map；ACT-050 Auto PAM Report [FR18] existing action retained; requirement-specific gaps in UC map；补充候选：

- ux：Agreement header下年度Schedule；明确各年基价、新价、有效日、状态与关联Claim。

- frontend：可增加年度、检测重叠与间断，展示累计及逐年变化，不把未实现年视为实现。

- backend：版本化协议/年计划；按确认的加总或复利计算；生成年度Claim幂等。

- data：Agreement、Schedule、AnnualClaim link及version；已批准年冻结，修订不覆盖历史。

- workflow：协议批准与年度执行分层；变更未来年度触发对应重批；Reserve/PAM逐期取已批准计划。

**集成**：沿用每年WIPS/SAP实施命令及Finance报表；未来年payload和排程能力需确认。

提供方：NEO / Procurement / Finance；WIPS/SAP / GCP reporting；方向：协议计划→年度Claim→WIPS/SAP；年度/期间结果→Finance/GCP

复用证据：已有FY Claim、MYA reference及period reports可复用；没有多年协议实体或跨年契约证据。

未知契约：逐年基价复利、未来量/汇率、审批总额、跨年取消/修订及发布时机。

**前置材料/依赖**：真实多年协议样例与逐年起始基价/复利/舍入金样；Finance明确一次总批准或逐年批准、未来量/FX/Reserve/PAM口径；实施owner确认未来年度调度/生效/修订/取消契约

**相关需求（不重评）**：NEO-034 年度Claim的Reporting Category/Lever组合校验，仅复用；NEO-041 多Lever；NEO-059 Parent与身份

**既有结论链接**：[NEO-034](../../solution-review/NEO-034/NEO-034_Consolidated_CN.md)

**页面编号边界**：id沿用INPUT_SCOPE中的历史Training页面映射；斜杠分别表示创建/更新或相关页面，不是一个路由ID。React实际组件由source列定位。此轮未重新核验历史截图页号。

**问题**：

- NEO-068-Q01 每年生产率降幅基于原价，还是上一年已降后的价？ 例如：100元每年-2%，三年是98/96/94还是98/96.04/94.1192？ Owner：Procurement / Finance；影响：决定金额和精度

- NEO-068-Q02 一次批准整个协议，还是每年金额单独批准？ 例如：2027–2029承诺中2028量尚未确定。 Owner：Finance / DoA owner；影响：决定审批与未到期执行

**验收设计，未执行**：

- NEO-068-S01；角色Buyer Alice；前提权限已核验；测试业务规则/金样已批准；使用隔离数据；输入协议2027–2029；起价100 GBP；每年-2%；测试政策为上一年基价、四位小数；操作输入三年 → Preview schedule → 保存/重开 → 修订未来年；预期98.0000、96.0400、94.1192；年度明细及版本保留；已批年度不被覆盖；实际=null；NOT RUN。

- NEO-068-S02；角色Buyer Alice；前提同一隔离记录；具备故障/缺失条件；输入两个年度计划日期重叠或未来年缺FX/Volume；操作执行受影响动作 → 再重新打开已保存记录；预期阻止完整年度金额/发布；指出年度与缺口，保留协议草稿；实际=null；NOT RUN。

- NEO-068-S03；角色Buyer Alice / unauthorised Bob；前提非授权用户Bob；Alice已把记录由revision7保存到8；输入Bob尝试修改；Alice旧页面仍携带revision7；操作分别提交旧版本/无权限请求；预期服务端拒绝；不泄露受限内容；保留授权编辑缓冲；重新载入后只见revision8，不能覆盖已批准快照；实际=null；NOT RUN。

- NEO-068-S04；角色Buyer Alice；前提对应政策、金样与接口/权限测试环境已批准；隔离数据；输入2027–2029每年-2%；原100GBP；四位小数；年度边界Apr1–Mar31；操作逐年预览，跨31Mar/01Apr读取年度Claim和期间报表；预期98.0000、96.0400、94.1192逐年独立；边界无重复计量；跨币/缺FY汇率时只缺对应年度，不用本年率替代；实际=null；NOT RUN。

- NEO-068-S05；角色Buyer Alice；前提对应政策、金样与接口/权限测试环境已批准；隔离数据；输入FY2027已批准98.0000；FY2028原96.0400；2028改为降3%；操作修订未来年、保存新协议版本并打开2027审批；预期FY2027原批准不变；FY2028新值95.0600经所需审批；重算后续年度并标旧预览失效；未来计划不能自动当已实施；实际=null；NOT RUN。

**来源证据**：

- `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx` / RTM for Requested Changes!E69：「Support multi-year productivity agreements, as many supplier commitments extend beyond a single year.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 206–212 (zero-based), A.8 UC-02：「Normal path. Enter core details, notification, POA dates and estimates; add evidence; save or submit to Created.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 318–324 (zero-based), A.8 UC-18：「Normal path. Create Settlement from the approved basis, review final values and submit; reject, correct and rerequest in a separate run.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 353–359 (zero-based), A.8 UC-23：「Normal path. Prepare daily inputs and Draft Reserve; review and adjust; freeze Final; prepare and reconcile Journal; confirm actual posting.」

- `NEO_FULL_OFFLINE/20261028_v1/documents/NEO_Business_Requirements_Document_EN_20261028_v1_WORKING.docx` / paragraphs 360–366 (zero-based), A.8 UC-24：「Normal path. Run reports and actual Tableau access, inspect refresh and period, open filtered exports and follow history to source versions.」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 4 (zero-based table 5 / row 3)：「FR1.2 | Create Risk/ Opportunity – Line Item Level Data Capture | Context: Following on from FR1.1. The below data will be captured at a line-item level (similar to the current AS IS FIND solution).
An interface should b」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 47 (zero-based table 5 / row 46)：「FR17.5 | Actual Reserves – Generating new reserves | Business Context: Equivalent of the green reserves tab used on the NCR Reserve Excel
Once a user has generated a new overall reserve line as per (FR17), this should al」

- `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx` / Table 6, row 51 (zero-based table 5 / row 50)：「FR18 | Forecast Reporting Calculations and Output | The application should have a function whereby it is able to provide regular reports (once per day) as an extract to GCP. The solution should store a log of the latest 」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A693:O693：「MCI_RISK_OPPORTUNITY | 索赔 | 业务 | FISCAL_YEAR_ID | int(11) | integer | 是 |  | FK | MCI_REF_FISCAL_YEAR | FISCAL_YEAR_ID | 已建 | 否 | Primary key of MCI_FISCAL_YEAR | 结构+字典」

- `8.需求文档/页面修复第三轮 Jira user story/NEO_数据字典.xlsx` / 字段字典!A704:O704：「MCI_RISK_OPPORTUNITY | 索赔 | 业务 | MYA_REFERENCE | varchar(255) | varchar(255) | 是 |  |  |  |  |  | 否 | mya_reference | 结构+字典」

- `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/domain/p02/contracts.ts` / line 12：「export type ClaimValues=ClaimAlignmentValues&{transactionDrivers?:string;nonStandardTransactionKind?:string;priceCurrency?:string;buyerCode:string;nonStandardTransaction:boolean;dummy:boolean;paymentReleaseDate:string;bu」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=1] / name, fr, area：「Create Claim | FR1; FR1.1–FR1.6 | Claims and data」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=12] / name, fr, area：「Submit Settlement Request | FR9.1; FR9.4 | Authorisation」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=29] / name, fr, area：「Generate Reserve | FR17.5 | Finance and continuity」

- `outputs/neo-jira-stories-20261111/v3/story_data.json` / entries[act=50] / name, fr, area：「Auto PAM Report | FR18 | Finance and continuity」

- `6.技术方案/2 - Tech NEO/Scheduler Processes - 2026-11-09_0944.xlsx` / Sheet 1!A19:O19：「1.0 | Auto Pam Scheduler | Generates a database financial report useful for checking daily balances | Material Cost & Inventory | MCI Generate Auto PAM Report Scheduler | 17:00 | Daily | 40 Minutes | 3 Days Delete | MCI_」

- `outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/solution-review/NEO-034/NEO-034_Consolidated_CN.md` / opening summary; reused only, no reassessment：「# NEO-034 · Reporting Category 与 Lever 组合校验

## 1. 本次结论

这条要解决的是：**两个下拉值各自合法，放在一起却不符合 Finance 的分类要求。** 例如选了某个 Lever，却配上业务不允许的 Reporting Category；目前没有组合限制，后面的准备金／报告就可能分错类。[S1]

建议建立一份由业务签认、带版本的允许组合清单，在两边修改时使用同一校验：**Financ」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR79-Q01：「日期 / Runout / 周切分」

- `NEO_FULL_OFFLINE/20261028_v1/qa/brd-fr-audit-20261102/build/review-data.json` / ID FR79-Q03：「FTO / GR / E2SC契约」

现有QA引用：FR79-Q01, FR79-Q03；只链接，不重记PASS。

页面：[English proposal](pages/NEO-068.html)；[Desktop](screenshots/NEO-068-desktop.png)；[Narrow](screenshots/NEO-068-narrow.png)。
