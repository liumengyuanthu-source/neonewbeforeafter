# CNP-231 待确认问题


每问均为源缺口/方案决策；未确认前示例不成为规则。


## NEO-038 Maturity / Likelihood 与 G Gate 对齐

**NEO-038-Q01 谈判中且Probable应显示G几？Closed如何显示？**

背景：ClaimValues存储maturity、likelihood两个字符串；创建页显示原字段。代码观察未建立G Gate版本化映射证据。BRD FR16把谈判成熟度与Workflow分开。

例子：例如Negotiation + Probable，不用示例猜成G3。

负责人角色：Jacob / Finance。影响：决定完整映射和未命中行为。

**NEO-038-Q02 配置更新后，已批准Claim是否保留原G Gate？**

背景：ClaimValues存储maturity、likelihood两个字符串；创建页显示原字段。代码观察未建立G Gate版本化映射证据。BRD FR16把谈判成熟度与Workflow分开。

例子：11月版本G2，12月新表G3。

负责人角色：Finance / Product Owner。影响：决定历史快照和重算范围。

## NEO-039 币种变更自动计算起始价

**NEO-039-Q01 Currency-only应使用哪种率，取哪一天？**

背景：PartPrices已有Resource/Currency条件下的直接价格修改。BRD明确预算率按年、月率按月；接口目录只证实Monex月率MFT，不能替代未确认的预算率。

例子：GBP 100转EUR，用年度预算率还是生效月月率？

负责人角色：Finance FX owner。影响：决定金额且阻止混率。

**NEO-039-Q02 同一供应商的新GSDB如何证明相关？**

背景：PartPrices已有Resource/Currency条件下的直接价格修改。BRD明确预算率按年、月率按月；接口目录只证实Monex月率MFT，不能替代未确认的预算率。

例子：同名Supplier A但两个代码，是否足够？

负责人角色：Vendor Master owner。影响：决定自动换码资格。

## NEO-040 按用途精简Runout、ATP及币种字段

**NEO-040-Q01 FFP数量是否已经扣除Runout之后的产量？**

背景：Runout及日期仍为可编辑字段，CalculationResults仍展示Runout影响；ATP在More options/特定WIPS上下文存在，Currency来自供应商上下文。直接删除可能改变金额。

例子：12月停产，全年量12,000是否已扣成9,000？

负责人角色：Finance / FFP owner。影响：防止重复扣量。

**NEO-040-Q02 哪些交易仍需要ATP Reference？**

背景：Runout及日期仍为可编辑字段，CalculationResults仍展示Runout影响；ATP在More options/特定WIPS上下文存在，Currency来自供应商上下文。直接删除可能改变金额。

例子：AMM与普通Price Claim是否不同？

负责人角色：CBSL / Procurement。影响：决定条件字段与模板。

## NEO-041 同一零件单Claim支持多个Lever

**NEO-041-Q01 多个Lever金额是相加，还是依次按比例调整？**

背景：ClaimValues与数据字典Claim均为单leverId/LEVER_ID；Reserve Team映射FR17.2以Lever和Reporting Category判定。因此不只是多选框。

例子：100元先+5%再-2%，结果102.90还是103？

负责人角色：Procurement / Finance。影响：决定公式和UI。

**NEO-041-Q02 一个Claim含Inflation与Productivity时，Reserve归哪个Team？**

背景：ClaimValues与数据字典Claim均为单leverId/LEVER_ID；Reserve Team映射FR17.2以Lever和Reporting Category判定。因此不只是多选框。

例子：风险+5与节约-2属于两个类别。

负责人角色：Finance。影响：决定归类和报表拆分。

## NEO-042 AMM每Part支持超过3个Escalator

**NEO-042-Q01 WIPS每Part最终支持10条还是15条？**

背景：现产品WipsPanel有ATP Reference与本地WIPS模拟入口；目录AA部署仅给string=null，未证实AMM指数结构或WIPS最大数。源Q43说10–15，受WIPS限制。

例子：第11条是允许、拒绝还是需人工？

负责人角色：WIPS / CBSL。影响：决定边界与异常流程。

**NEO-042-Q02 每个指数必须提供哪些值，权重是否必须合计100%？**

背景：现产品WipsPanel有ATP Reference与本地WIPS模拟入口；目录AA部署仅给string=null，未证实AMM指数结构或WIPS最大数。源Q43说10–15，受WIPS限制。

例子：5条各20%，一个缺基期。

负责人角色：AMM业务owner。影响：决定校验和公式。

## NEO-043 精简CO2及创建校验

**NEO-043-Q01 CO2在报表或合规上还有实际消费者吗？**

背景：当前Claim向导仍有CO₂ Data步骤；BRD将其定义为informational。Working BRD明确optional CO2和100字符描述的历史要求。

例子：只取消新录入，但2025年的CO2仍可查。

负责人角色：Procurement / Finance。影响：决定是否可移出向导。

**NEO-043-Q02 描述必须回答哪些业务内容，能否替代100字符下限？**

背景：当前Claim向导仍有CO₂ Data步骤；BRD将其定义为informational。Working BRD明确optional CO2和100字符描述的历史要求。

例子：原因+依据+影响三项已清楚但仅80字符。

负责人角色：Procurement / Clearing House。影响：决定提交校验。

## NEO-045 LSP财务组合自动派生及失败重试

**NEO-045-Q01 用哪些买家输入唯一确定财务组合？**

背景：LSP字段已在创建页，由Material Group、Vehicle Line等参考选项提供输入；接口Id10已有companyCode、purchaseOrganization、glAccount、costCenter字段，不等于组合规则已实现。

例子：GB03 + Material Group MG01，是否还需Vehicle Line？

负责人角色：GFS / SAP Master Data。影响：决定表主键和无/多匹配处理。

**NEO-045-Q02 PO超时但SAP实际已建单时，谁用什么字段查重？**

背景：LSP字段已在创建页，由Material Group、Vehicle Line等参考选项提供输入；接口Id10已有companyCode、purchaseOrganization、glAccount、costCenter字段，不等于组合规则已实现。

例子：NEO无PO号，但SAP已有CLM-01。

负责人角色：SAP integration owner / Digitide。影响：防止重复PO。

## NEO-052 Global Commodity Lead Area保留或移除决策

**NEO-052-Q01 最终保留可维护列表，还是从新Claim移除该字段？**

背景：原E53要求maintainable列表；Q53要求remove field；R53=Y。Training335支持编辑/停用列表。ClaimValues和数据库有commodityLeadAreaId，不可当已批准删除。

例子：E53新增Software等；Q53完全删除字段。请选择一个目标。

负责人角色：Procurement / Finance。影响：否则开发验收方向相反。

**NEO-052-Q02 历史报表还需要按这个分类筛选吗？**

背景：原E53要求maintainable列表；Q53要求remove field；R53=Y。Training335支持编辑/停用列表。ClaimValues和数据库有commodityLeadAreaId，不可当已批准删除。

例子：旧Claim的Plastic Moulds能否仍筛选导出？

负责人角色：Reporting owner。影响：决定兼容策略。

## NEO-053 简化Inflation类型及条件字段

**NEO-053-Q01 具体停用哪些Inflation类型，从何时生效？**

背景：当前Inflation支持多个类型/材料、单位、Base/New Rate；activeReferenceChoices已支持活动选项。源未指出究竟移除Energy、Raw Materials等哪项。

例子：Freight、Labour是完全停用还是仅某组织不用？

负责人角色：Procurement / Finance。影响：决定列表和生效策略。

**NEO-053-Q02 有在途Claim使用已停用类型时可否继续Settlement？**

背景：当前Inflation支持多个类型/材料、单位、Base/New Rate；activeReferenceChoices已支持活动选项。源未指出究竟移除Energy、Raw Materials等哪项。

例子：旧Labour行有已签协议及费率。

负责人角色：Finance / Clearing House。影响：避免迁移后流程卡死。

## NEO-054 FTO / FFP数据准确性与缺口恢复

**NEO-054-Q01 FTO和FFP各由谁提供，文件是全FY替换还是增量？**

背景：Fto.tsx已有上传校验、按FY替换、文件历史及有原因改量。UC-07要求FTO四维匹配且缺失不是零；当前OFFLINE合成源不证明生产FTO/FFP准确。

例子：本日少了一个Part，表示删除、零量还是漏数？

负责人角色：FTO / FFP data owner。影响：决定摄取与缺失判断。

**NEO-054-Q02 四维匹配失败时允许哪些人在何处改量？**

背景：Fto.tsx已有上传校验、按FY替换、文件历史及有原因改量。UC-07要求FTO四维匹配且缺失不是零；当前OFFLINE合成源不证明生产FTO/FFP准确。

例子：同零件SOL有量、HAL缺量，不能借用SOL的量。

负责人角色：Finance / Data owner。影响：决定权限和修复流程。

## NEO-059 混合涨跌价及相关GSDB的统一谈判视图

**NEO-059-Q01 可接受一个Parent下面保留多个Line吗？**

背景：当前Claim单kind、单vendorCode；Working BRD CLM-02历史要求不同方向分开linked claims。Q60多代码同供应商明确提出Parent改善，不能直接把Parent删除。

例子：UK100 GBP风险+1000；EU100 EUR机会折合-1200，Parent净机会-200。

负责人角色：Procurement / Finance。影响：决定是否需重构Line。

**NEO-059-Q02 DoA按净200，还是正负两侧较大金额1200判断？**

背景：当前Claim单kind、单vendorCode；Working BRD CLM-02历史要求不同方向分开linked claims。Q60多代码同供应商明确提出Parent改善，不能直接把Parent删除。

例子：抵消后净额很小但实际价格变动较大。

负责人角色：Finance / DoA owner。影响：决定审批风险和金额。

## NEO-060 复用Copy Claim并补齐复制边界

**NEO-060-Q01 复制时哪些字段和附件必须保留，哪些必须清空？**

背景：当前React存在Copy existing Claim，调用canViewSource/startCopy；source来自fixtures数组。UC-03和ENH-001已明确不复制审批执行历史。仅代码观察，当前产品动态持久化未在本轮执行。

例子：同供应商新年度协议，旧价格和签字附件能否带入？

负责人角色：Procurement / Security。影响：决定白名单和误用风险。

**NEO-060-Q02 源Claim被撤销或访问权收回后，保存新草稿怎么办？**

背景：当前React存在Copy existing Claim，调用canViewSource/startCopy；source来自fixtures数组。UC-03和ENH-001已明确不复制审批执行历史。仅代码观察，当前产品动态持久化未在本轮执行。

例子：复制后尚未保存，权限已撤销。

负责人角色：Product / Security。影响：决定保存时再校验。

## NEO-061 完善Parts搜索筛选及数据范围

**NEO-061-Q01 车系按零件适配还是按当年生产计划筛选？**

背景：当前SelectParts已有supplier scoped catalogue、company/plant、part number search、vehicle/model year、跨页选择及来源变更处理。增量不是从零加筛选；实际API目录只证明vendor/plant/offset/limit。

例子：同Part适配Defender，但本年HAL不生产。

负责人角色：Procurement / Part Master owner。影响：决定过滤含义。

**NEO-061-Q02 真实最大结果和常用筛选组合是什么？**

背景：当前SelectParts已有supplier scoped catalogue、company/plant、part number search、vehicle/model year、跨页选择及来源变更处理。增量不是从零加筛选；实际API目录只证明vendor/plant/offset/limit。

例子：一个GSDB下2万part–plant，用户常查哪些字段？

负责人角色：Procurement / SAP API owner。影响：决定服务端过滤与分页。

## NEO-062 价格差计算明细与缺失解释

**NEO-062-Q01 这里price gap指单价差，还是含量后的年度差额？**

背景：CalculationResults已有Start/New price、GBP delta、年度/Calendarised和Runout；Calculation.tsx有来源和stale提示。新增重点是可解释链条与错误定位，不是重复新增一张汇总表。

例子：100→105 GBP是5 GBP/part，12,000量后60,000 GBP。

负责人角色：Finance / Procurement。影响：决定标题/单位/公式。

**NEO-062-Q02 缺量时允许显示单价差并把总额标Incomplete吗？**

背景：CalculationResults已有Start/New price、GBP delta、年度/Calendarised和Runout；Calculation.tsx有来源和stale提示。新增重点是可解释链条与错误定位，不是重复新增一张汇总表。

例子：单价齐全但FTO为空，不能总额=0。

负责人角色：Finance。影响：决定部分可用结果。

## NEO-066 大量Parts处理性能与可靠恢复

**NEO-066-Q01 最慢案例有多少Part–Plant行，在哪一步超时？**

背景：当前Calculation有本地input check job registry、retry same frozen input，清楚提示其不代表财务有效。没有生产并发/延迟证据；不能据此称大批量问题已解决。

例子：2万行加载慢，还是提交后5分钟没有结果？

负责人角色：Procurement / Operations。影响：定位性能阶段。

**NEO-066-Q02 业务可接受多久看到已保存/最终结果？**

背景：当前Calculation有本地input check job registry、retry same frozen input，清楚提示其不代表财务有效。没有生产并发/延迟证据；不能据此称大批量问题已解决。

例子：先返回受理号、几分钟后完成是否可接受？

负责人角色：Product / Operations。影响：决定SLO和同步/异步。

## NEO-068 多年生产率协议与逐年履行

**NEO-068-Q01 每年生产率降幅基于原价，还是上一年已降后的价？**

背景：ClaimValues只有fiscalYearId，MYA Reference是文本引用，不是多年履约模型；Reserve/Auto PAM按财年和期间消费，不能简单把FY改多选。

例子：100元每年-2%，三年是98/96/94还是98/96.04/94.1192？

负责人角色：Procurement / Finance。影响：决定金额和精度。

**NEO-068-Q02 一次批准整个协议，还是每年金额单独批准？**

背景：ClaimValues只有fiscalYearId，MYA Reference是文本引用，不是多年履约模型；Reserve/Auto PAM按财年和期间消费，不能简单把FY改多选。

例子：2027–2029承诺中2028量尚未确定。

负责人角色：Finance / DoA owner。影响：决定审批与未到期执行。