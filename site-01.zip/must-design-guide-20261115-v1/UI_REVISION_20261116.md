# Must design guide — 16 November 2026 revision

## Current decision

| Requirement | Page decision | Business / integration change retained |
| --- | --- | --- |
| NEO-001 | Both sides use the same Auto PAM Report file list, `NEO / Reports / Auto PAM Report` breadcrumb, report rows and native information icons. | AutoPAM rollover calculation correction. No new report UI or simulated calculation engine. |
| NEO-003 | Both sides use the same existing Part prices page, eight mock part rows, fields and bulk/individual price controls. Only After adds **Refresh prices from SAP** in the existing toolbar. | Retrieve current SAP start prices and retain entered new prices. The price API contract, recalculation policy and approved-version controls remain subject to the existing assessment and confirmations. |
| NEO-007 | Both sides use the same existing Approval Request detail, fields, layout, buttons and interactions. No added FTO / GR panel, evaluation drawer or page. | FTO / GR calculation and DoA / further-approval logic only. Finance sign, period, FX, threshold and missing-GR decisions remain unconfirmed. |
| NEO-004 | Both sides use the same current NAF Pin Report form and generation entry. No additional filters, result tables or detail pages. | Correct POA report calculations and output data. The exact errors and golden expected outputs still require source evidence. |

The current page comparison supersedes the earlier UI proposals for 001, 003, 004 and 007. Original assessments and screenshots remain unchanged as historical material. Their business questions and interface dependencies are not silently removed.

## Sources

1. User's 16 November feedback in this chat: same UI for 001 and 004; report information icons retained; 003 only adds SAP refresh. Reference attachments: `codex-clipboard-68f5dab2-30ea-4985-9d7f-2216b9fa7a07.png` and `codex-clipboard-52ee8cc5-62db-4cbe-a529-9c060dd718be.png`.
2. Frozen 15 November NEO prototype copy: `before-source/`, with original provenance in `BEFORE_VERSION.json`; app SHA-256 `3ff8bc0b158ba08f2302e7404bb6185a553088c78614051451e6b5137a26802e`.
3. Existing captured mock states: `auto-pam`, `prices-edit` and `naf-pin-gfs` in `before-map.json`. Original image captures remain in `before-captures/`.
4. Original requirement wording, Must selection, workbook cell references and existing assessment links remain in `catalog.json` and the guide's Sources tab. The source workbook and source assessments are unchanged.

## Scope and interaction

`comparison.html` loads the unchanged frozen bundle with its captured state into a separate, memory-only review session. The breadcrumb correction applies equally to both sides of 001. The SAP control is the only added page element for 003. The 004 page has no presentation adapter.

The new SAP button opens a confirmation. Cancel or Escape preserves values. Confirm reports that SAP is not connected in this design preview and makes no price changes. It is an interaction proposal, not an implemented SAP retrieval. Existing report downloads and bulk-price operations retain the frozen prototype's mock behavior; they are not evidence of corrected calculation results.

No product source, production data, SAP endpoint or deployed environment was changed. Other 33 guide catalog rows remain unchanged. Review-note and language preference storage keys are retained.

## Local verification

The reproducible browser check is `qa/ui-corrections-20261116/verify.cjs`; its actual result is `qa/ui-corrections-20261116/verification.json`.

Checks cover:

- Same page fields and table positions on both sides of all three entries.
- Pixel-identical Before/After screenshots for 001 and 004 at the checked desktop viewport.
- Both report lists retain six named-file information icons and working tooltips; the seventh blank-file row stays unchanged.
- 003 adds exactly one SAP button to After; cancellation, unavailable-connection feedback, Escape and focus return preserve current prices.
- Existing bulk-price preview remains operable on both sides of 003.
- Both language selections, both comparison sides, current screenshot links, responsive guide layout and review-note persistence.
- Hash checks protect the product bundle, original prototype files and earlier assessments.

New actual browser screenshots are in `captures-20261116/`. These checks establish local design-guide behavior only. Calculation correctness, SAP integration, permissions in production and business acceptance are not tested by this revision.

## NEO-007 follow-up correction

User confirmation, 16 November: “007 没有UI上的变化，before vs after应该保持一致”. Both sides now load the same frozen `approval-detail` state in `comparison.html`; no presentation adapter runs for 007. The same sample values are used to isolate the page comparison. This does not claim the new calculation is implemented. The former independent UI and screenshots remain historical sources, excluded from the current page comparison and current Screenshots tab.

The existing dependency statement and original workbook/source references are retained. Local UI parity evidence is in `qa/neo007-ui-parity-20261116/verification.json`; the previous three-entry verification remains dated evidence for its own scope. No source prototype, original assessment, 005 design, other 35 catalog entries or existing review-note storage key is changed.
