# NEO-004 · POA 零件明细报表纠错

独立评审方案。原型、现有应用代码及 QA 权威表未修改。页面使用合成示例；不是已修复产品，不是 Finance 签收的报表或公式。业务规则未确认处保留问题，不以示例代替答案。

## 本轮界面修订：NEO design system

按用户 12 Nov 2026 确认的项目默认规则，页面已统一使用当前 NEO React theme、JLR Emeric 字体及真实 Ant Design 6.7.0 组件。桌面边距32px、中屏24px、手机16px；表格横向滚动、黑色主按钮、蓝色链接、状态色、下拉、弹窗和校验沿用 NEO。仅展示本条涉及的交互，未连接的导航与最终业务提交禁用。

Reference：`NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/theme/index.ts`、`src/layouts/BasicLayout/`、`src/styles/` 和 `NEO_FULL_OFFLINE/skills/jlr-frontend-ux/references/NEO_UXUI_PRINCIPLES.md`。theme 原文件与只读快照 SHA 一致，详见交付包 `design-source/SOURCE_MANIFEST.json`。配套布局是独立评审页的适配，不是新增产品 design system。

当前本地页面检查见 `PAGE_VISUAL_CHECK.json`；接口、后台、流程、权限和业务验收仍为 NOT RUN。旧截图及旧检查数不作为本版验收依据。此修订没有改写业务范围或原 prototype。

## 1. 分类、关联及优先级

| 项目 | 本条结论 | Source / Reference |
|---|---|---|
| 原需求 | POA Part Detail Report：部分字段计算不正确；Helen Jones 可补充并简化需求。 | S1，E5 / P5 |
| 原分类 | Existing functionality - Update/correct logic，保持原文。 | S1，D5 |
| 主要改动类型 | APP：应用内部报表取数、计算、字段语义及 Excel 输出修复；UI 是辅助，不是仅 UX/UI。 | S1 / S2 / S3 |
| Integration | INT-REUSE 候选：使用已入库的价格、GR、汇率数据。当前没有证据要求新增外部接口或架构；若缺原始数据再评估契约变更。 | S6 |
| Epic | CNP-235；本地 story_data 中 ACT-042 所属 Epic。正式 Epic 标题本轮未确认。 | S5 |
| User story / ACT | ACT-042 NAF Pin Report；新展示标题沿用 BRD 的 POA Part Level Detail Report，历史名保留为别名。 | S3 / S4 / S5 |
| 主 FR | FR20.4；FR17 Reserve 为下游对账影响，不能据此直接改 Reserve 公式。 | S3 / S2 |
| UC | 关联既有 UC-24 明细导出；增加币种和数据版本核对场景是本轮建议，未生成新的正式 UC 编号。 | S7 |
| 页面 | P6.4 POA Part Level Detail Report（NAF Pin Report）；价格差异弹窗与导出范围弹窗为同页拟新增交互，不另造正式页面编号。 | S7 |
| 原优先级 | Finance = Must；Purchasing 未填。来源指向 P1 CR Clean CR29.1。 | S1，F5 / K5 / L5 |
| 实施建议 | P0 候选：财务必需且关联 Reserve 核查；排期需 Finance 确认错误范围与业务影响，不能把本建议当已签收优先级。 | S1 / S2 |
| 真实验收 | NOT RUN。当前只交付独立页面设计与本地设计检查。 | VALIDATION.json |

## 2. 用人话解释这次改什么

问题不是把报表换个样式，而是让列名、币种和实际算出来的值一致。历史 CR29.1 写到：Price Change Local 不正确，回复又说 difference 列基于 GBP。Finance 需要该报表核查 Retros、调查 PPV，并作为 POA Reserve 计算的支持文件。[S2]

例如：某零件原价 EUR100、新价 EUR95。若本次约定用“新价减原价”，本币差额是 EUR−5；仅为演示，若 1 EUR = GBP0.85，则 GBP 差额是 −4.25。这两个值不能都叫 Price Change Local。**符号方向、汇率类型/日期、价格单位仍需确认；上述是展示例子，不是签收公式。**

当前 React 源码 NafPin 提供 FY、Vendor、日期筛选和生成/下载；其配套数据明确标注为静态 fixture，价格币种全部为 GBP，Price Change GBP 使用 next-current。它不能证明非 GBP 的本币差额已正确，不能作为现网缺陷复现或修复证据。[S8]

## 3. 页面方案

### 3.1 报表入口与结果

沿用 P6.4。用户选择 Financial year(s)、Vendor、From/To Date，再 Generate Report。BRD 支持一个或多个财年；现有组件为单选，设计采用复选方案，需对齐现网习惯及最终范围。Vendor/日期沿用已检查本地组件，不声称是 FR20.4 完整字段清单。[S3 / S8]

保留 Line、Part、Plant；本币原价、新价、Price Change Local 与币种并列，Price Change GBP 单独显示。页面预览是建议增加的核对便利，不是原需求明示必须新增一页。

![P6.4 生成入口](NEO-004_Page_Entry.png)

![P6.4 本币与 GBP 分列结果](NEO-004_Page_Results.png)

### 3.2 查看价格差异

每条记录通过最前面的查看图标打开同页弹窗，核对原价、新价、本币差额、GBP 汇率和差额。不可在报表中改交易价格，不可用显示汇率反写历史 Claim。

![价格差异明细](NEO-004_Page_Breakdown.png)

### 3.3 导出范围

Review export 先显示所选财年、日期、行数和字段组。正式实现应生成真正 XLSX，金额为数字，币种明确；当前独立设计的 Download Excel 禁用，未实现正式导出，也没有伪造下载成功。

![导出范围核对](NEO-004_Page_Export.png)

### 3.4 数据缺失

缺汇率时保留本币金额，受影响 GBP 字段为“—”，注明具体 Line / Part；本方案建议暂阻该筛选范围导出，等待 Finance 确认是否允许带异常标识导出。其他筛选组合未受影响的记录不应被一并锁死。零值与缺失值必须区分。

![缺汇率时的处理](NEO-004_Page_Missing.png)

页面还提供无匹配数据、生成失败、财年未选和日期倒置的本地演示。筛选及金额只针对两条合成 fixture；不连接数据库，不证明生产多财年、期间分配和报表生成正确。

## 4. Solution、Change 和 Impact

| 层面 | Change / 拟实施内容 | Impact / 不能越过的边界 |
|---|---|---|
| UX/UI | 保留现有报表入口；区分 Local/GBP，增加按行核对及导出范围确认。 | 所有建议增加的列/弹窗须与 Finance 确认；不能仅修改列名掩盖计算错误。 |
| 后端取数 | 依据授权范围、选择财年和期间生成同一报表数据集；字段语义和行粒度统一。 | 需要明确 Line × Part × Plant × 价格期间/版本是否为行键，防止连接 GR 时重复。 |
| 计算 | 对每个错误列建立“原始输入→口径→独立期望结果”；Local 与 GBP 分离。 | 不能默认 next-current、现汇或最新价格；不得重算覆盖已批准交易。 |
| 数据库 | 核对已有本币价格、币种、GR、汇率和历史版本来源；优先修正查询/映射。 | 尚无证据要求新增表/列；如必须新增，要另列迁移影响。 |
| Excel | 使用同一数据集、筛选及版本输出；保留月度、以前年度等已批准字段。 | 缺 Appendix J 实际工作簿；列序、精度、公式/值、冻结列等尚不能宣称最终一致。 |
| Reserve / 财务 | 与 Finance 给出的同期间 Reserve 支持文件、Retros 和 PPV 样例核对。 | Report 修正不等于 Reserve 引擎应同步改公式；先判断错误发生在数据、计算还是展示。 |
| BPM | 本条是报表纠错，未发现要求修改审批路线或任务流。 | 不引入审批重跑、SAP/WIPS 回写或新的批准状态。 |
| 权限 | BRD：GFS/FBP；Training：GFS manager/officer。 | 最终权限有来源差异；页面用合成 GFS Officer 演示，不新授 FBP 权限。 |

同一历史表 CR29.2（财年/有效日期及月度数量）与 CR29.3（All Months 未含 Prior Years）与该报表有关，但 S1 仅直接追溯 CR29.1。将两项保留为关联回归/范围确认，不能自动全数纳入 NEO-004。Resource calculation 的历史回复称其为新需求，也不能混入本次纠错。[S2]

## 5. 字段与系统/接口关系

| 字段组 | 候选来源及读取链路 | 本轮已知与缺口 |
|---|---|---|
| Line / Part / Plant / Vendor / FY / Effective Date | NEO 已保存的 Claim 及零件关联 | 页面实际物理字段、历史版本及一对多关联需对照 schema/查询确认；不能从列名猜数据库列。 |
| Start / New Price、Currency | NEO 保存的商业/计算版本；SAP 参考价格可能经 MCI_getPartPriceDetails 输入 | S6 Id2 为 SAP / Apigee 价格历史 GET。不能推断报表应每次抓最新价；具体价格字段与单位待契约样例。 |
| 月度 GR Quantity | SAP → Apigee → MCI_getGoodsReceiptDetails → NEO | S6 Id4，物理第10行；含 vendor、日期、material、movementType、分页参数。响应字段、冲销/退货及归属期间尚未确认。 |
| FX / GBP 差额 | 已导入 NEO 的汇率及报表批准口径 | S6 Id19 MFT M Exchange Rate，Monex → BODS → Appian。存在该渠道不证明本报表应使用月度汇率；预算/交易/期间率仍待确认。 |
| Local/GBP 差额、Price Movement | 应用报表计算 | 没有证据证明外部系统直接提供这些报表结果；公式、符号、单位、精度、缺数处理须由 Finance 签收。 |
| Current Reserve GBP | 已确认的 Reserve 期间和版本 | Training 明确 current financial (reserve) impact；现有本地 fixture 数值不是正式 Reserve 算法。 |

现有接口名称是复用线索，不是 payload 契约。暂不新增 SAP、WIPS、S4、Tableau 接口；若 Finance 样例暴露缺字段，再评估现有接口扩展或新增架构。

## 6. 需要业务确认的问题（讲人话＋例子）

| 编号 | 请确认什么 | 举例 | 建议 / 影响 | 建议确认人 |
|---|---|---|---|---|
| Q1 | 到底哪些列错了？请给同一笔报表、输入和正确答案。 | 某行 EUR100→95，现报表 Local 为−4.25，正确应为−5吗？ | 先用两笔 GBP/非GBP 样例锁定错误；没有证据不能直接改公式。 | Helen Jones / DSMITH69（S1 名称，当前责任待确认） |
| Q2 | 差额正负号、价格单位、汇率采用哪套规则？ | 降价用−5还是节省+5？EUR价格按1件还是100件？0.85取哪个月？ | Local/GBP 分列；保留批准口径，不能因刷新改写历史金额。 | Finance + 计算 SME |
| Q3 | 本次是否一起修 CR29.2 / 29.3？ | 以前年度20件、本年度100件，All Months 是否120？旧 FY Claim 是否展示当期月量？ | 单独确认范围，避免把相关问题当已授权公式。 | Helen Jones / Finance |
| Q4 | 报表以哪个版本与期间为准？ | Claim 后来改价，但上月 Reserve 已冻结；重新下载上月报表应取旧价还是新价？ | 按确认快照回读；避免当前数据与冻结 Reserve 混用。 | Finance + 报表负责人 |
| Q5 | “日期范围”过滤什么，且报表每行代表什么？ | 4月筛选按GR过账日、Claim生效日还是创建日？同Part两个Plant/两次改价合并吗？ | 保留源行粒度，确认前不写死日期与聚合规则。 | Finance + 数据 SME |
| Q6 | 缺汇率/GR时能否导出？ | 100行中1行没有GBP汇率，允许99行还是带异常的100行？ | 方案暂阻受影响结果导出；不是已签业务规则。缺失不能写0。 | Finance |
| Q7 | 哪些角色可以下载？ | Training 仅GFS，BRD 又含FBP；FBP Officer 能看全部还是本团队？ | 先核对角色/数据范围，前端隐藏不能代替服务端权限。 | GFS / FBP / 应用Owner |
| Q8 | 请提供现行报表模板及完整金样例。 | BRD Appendix J 指向 PIN 22.09.2023 TVM.xlsx；现在还用它吗？ | 获取实际模板及GBP/非GBP、跨年、冲销、零量、缺汇率样例。 | 现有报表团队 + Finance |

## 7. 开发与验收准备

下面是增量验收建议，不另建执行结果总表。产品测试结果仍应回到既有 FR1–21 QA 权威表；本条独立页面检查只证明设计交互可用。

| 场景 | 应核对什么 | 当前产品结果 |
|---|---|---|
| Local / GBP 分离 | 金样例逐字段核对币种、符号、单位、汇率和舍入，不用被测系统自证。 | NOT RUN |
| 财年 / 日期 / 行粒度 | 选定年份、GR期间、有效日期及多Plant不漏、不重复；覆盖跨年与冲销。 | NOT RUN |
| Excel 一致 | 实际打开 XLSX，对比筛选范围、全量行数、类型、精度、月度/以前年度列及控制合计。 | NOT RUN |
| Reserve 对账 | 同期间、同版本与授权 Reserve 样例一致；展示明细不代表 Reserve 公式验收。 | NOT RUN |
| 缺数与恢复 | 缺汇率不置零；报错后筛选保留，重试不混入上次结果；旧结果失效清楚。 | NOT RUN |
| 权限与隔离 | 未授权角色/跨团队直接请求被拒；导出同样检查权限。 | NOT RUN |
| UX/UI | 桌面/窄屏、表格滚动、数字对齐、错误定位、键盘和弹窗关闭。 | 产品 NOT RUN；独立设计检查见 VALIDATION.json。 |

开发进入条件：Q1/Q2/Q4/Q5 与实际模板、正确金额样例先确认；Q3 划清关联范围。退出条件：实际交付版本上的适用用例、XLSX 对账及 Finance 结果确认均有证据。页面生成或静态算术示例通过，不等于退出。

## 8. Source / Reference

- **S1** `/Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx`，`RTM for Requested Changes!A5:R5`，NEO-004，E5错误描述，F5 CR29.1，L5 Finance Must，P5 HJONES20 / DSMITH69。
- **S2** 同一工作簿，`P1 CR clean!A6:Y6` / CR29.1，C6 Price Change Local，D6 GBP差额回复与业务用途，W6 FR20.4详细设计；第7行CR29.2、第8行CR29.3为关联而非默认纳入范围。
- **S3** `/Volumes/KIOXIA/JLR Appian/6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx`，表6第71行 FR20.4；正文第356段 Appendix J，第357段链接 `PIN 22.09.2023 TVM.xlsx`。表/行/段按从1计数。本轮未获取该SharePoint模板内容，不声称已按模板全列核验。
- **S4** `/Volumes/KIOXIA/JLR Appian/6.技术方案/2 - Tech NEO/NEO User Training.docx`，第1846段 NAF Pin Report，第1848段 GFS manager/officer，第1850段导出，第1852段零件价格变化及当前财务Reserve影响。段落从1计数，未伪造页码。
- **S5** `/Volumes/KIOXIA/JLR Appian/outputs/neo-jira-stories-20261111/v3/story_data.json`，entries ACT-042，FR20.4，Epic CNP-235。是本地映射，不是本轮在线Jira核验。
- **S6** `/Volumes/KIOXIA/JLR Appian/6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv`，Id2 MCI_getPartPriceDetails（物理第8行）、Id4 MCI_getGoodsReceiptDetails（第10行）、Id19 MFT M Exchange Rate（第111行）。登记表不等于已签payload或当前接口运行证据。
- **S7** `/Volumes/KIOXIA/JLR Appian/outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/analysis.json`，trace NEO-004：ACT-042 / FR20.4 / P6.4 / UC-24，引用原Action表行43。其 extra 中另一来源的 NEO-004 是附件条件必填，不能因同号混并本条。
- **S8** `/Volumes/KIOXIA/JLR Appian/NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Reporting/NafPin.tsx`（筛选与下载）、`naf-pin-data.ts`（nafColumns、nafRows、selectNafRows、nafWorkbook）；本轮只读源码，不据此判断正式环境已修复。源码现有字段非正式模板。
- **S9** `/Volumes/KIOXIA/JLR Appian/NEO_FULL_OFFLINE/skills/jlr-frontend-ux/references/NEO_UXUI_PRINCIPLES.md`，布局、表格、留白、错误提示及响应式设计依据。

## 9. 交付物与边界

独立交互 HTML、内嵌五张图的汇总 HTML、可编辑 MD、五张 PNG、本地检查记录、可复现生成/检查脚本及完整 ZIP。界面英文，评审说明中文。所有输出位于 solution-review/NEO-004。

示例角色 Oliver Grant / GFS Officer、两条历史格式 MCI 编号及金额均为独立设计fixture，不是实际用户/单据登记。4月数量100/120及Reserve −300/−400是展示输入，非已签计算值；没有使用它们证明公式。真实 SAP、数据保存、生产导出、Finance 验收全部未执行。
