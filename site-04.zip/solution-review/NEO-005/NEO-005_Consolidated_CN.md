# NEO-005 · 审批前确认供应商余额与结算安排

16 November 2026 · Finance Must · 独立设计修订

[打开可操作设计](NEO-005_Page_Proposal.html) · [返回 Must 导览](../../must-design-guide-20261115-v1/#NEO-005?lang=zh&view=after)

**让审批人在批准正向应收 Lump Sum 前，知道供应商将如何结清这笔钱。** Buyer 提交 Settlement 前查余额并填写约定结算日；不足时将 Manual Invoice 或 GFS PO override 的方案和理由一起送审；GFS 实施前重新检查。Manual Invoice 保留。

这是按用户建议落实的可走查方案，供客户确认；使用合成数据，不代表已签业务规则或 SAP 联调通过。原 NEO prototype、Before 快照及原需求工作簿不变。

## 1. Customer wording

For requirement 005, we propose checking the supplier balance **before the Buyer submits a receivable Lump Sum Settlement Request**. The request will include the balance result, agreed settlement method, supporting agreement and agreed settlement date for FBP and the relevant approvers to review. This date means when the supplier is expected to pay or the offset is expected to take place; it is not proof of receipt and does not replace the existing Payment Release Date.

For example, a **£20,000 Settlement against an eligible £30,000 balance** can proceed through the existing approval route for offset. If the balance is only **£8,000**, the Buyer can propose a Manual Invoice or a Lump Sum PO under an authorised GFS override, explain how the full £20,000 will be settled and record the agreed date. The shortfall alone will not prevent approval of an explicit alternative arrangement. GFS will recheck before implementation; if an approved offset is no longer covered, the request will return for revised arrangements and approval. A failed SAP lookup must be retried rather than treated as zero or a passed check.

**Please confirm this proposed control and routing approach. Manual Invoice remains available; removing it is a separate decision.**

## Before / After 流程说明

[中英切换流程对比](NEO-005_Before_After_Flow.html) · [完整双语说明](NEO-005_Before_After_Flow_CN_EN.md)

- **Before**：Buyer 提交 Settlement → 完成适用审批与 GFS 检查 → 实施阶段检查供应商余额 → 足额走 PO，不足转人工／例外处理 → 保存外部结果并确认应收实施状态。
- **After**：Buyer 送审前检查余额、填写约定日期及结算安排 → 审批人一起审批金额和安排 → GFS 实施前重查 → 按获批 PO／Manual Invoice 路线执行；若原抵扣安排已无法履行，退回修订并重新审批。
- **例子**：£20,000 应收 LSP 只有 £8,000 可用余额。Before 到实施时再处理不足；After 送审时已显示 £12,000 缺口，并将“供应商 30 Nov 全额付款、走 Manual Invoice”的安排一起送审。

上述业务顺序依据 FR11／FR12／FR14。当前冻结 prototype 的不足余额演练分支另外包含 AP override 和 eTracker approval，流程图明确单列；它们不能当成已确认的现网规则，也未改动原 prototype。Manual Invoice 保留，约定日期不等于实际收款日。[R2–R4、R9]

## 2. 页面与操作链路

创建／保存 Claim → Buyer 准备 Settlement 并查余额 → FBP 核对 → 适用 DoA 审批 → GFS 实施前重查 → 获批 PO／Manual Invoice 路线 → 保存外部结果 → GFS 确认应收 Implemented。

| 步骤 | 谁、在哪里 | 怎么操作 | 结果／控制 |
|---|---|---|---|
| 1 | Buyer · Settlement Request | Check SAP balance；填写 Agreed settlement date、结算方式和协议／供应商承诺。 | 记录余额、币种、公司、供应商、时点和版本；草稿仍可先建。查询失败为 Unknown，保留输入并重试。 |
| 2 | Buyer · 同一页面 | Submit Settlement Request。 | 足额可选标准抵扣；不足必须选 Manual Invoice 或 PO override，说明如何结清**全部金额**。锁定送审金额、日期、方式、证据和检查快照。 |
| 3 | FBP → 指定审批人 | Approval Check 核对安排，再按适用 Mandate／DoA 路线处理。 | 不自定金额阈值、级别或统一 AP 审批。独立页面演示最后一个适用 DoA 审批位。 |
| 4 | GFS · 可处理的 GFS task | Recheck SAP balance，确认协议与安排。 | 标准抵扣若不再足额，退回修订并重新审批。PO 例外须有权 GFS 记录 override 及原因；FBP 不能代做。原任务调度不改。 |
| 5a | GFS／SAP · PO 路线 | Create Lump Sum PO → Read SAP outcome。 | 收到编号后是 Data Posted Awaiting Approval，不是实施完成；须回读对应 SAP 结果供 GFS 核对。 |
| 5b | GFS · Manual Invoice task | 记录 Manual Invoice Number 和实施证据。 | 沿用获批人工路线，不靠预计日期确认完成，也不自动调用 SAP。 |
| 6 | GFS · Finance 状态 | 核对批准版本与实际结果，Mark as Implemented。 | 应收实施和收款分开；不自动 Paid／Closed，不自动填 Actual receipt date。 |

### 日期含义

- **Agreed settlement date（新增）**：供应商承诺付款日或约定抵扣日。例如承诺 30 Nov 支付 £20,000，填 30 Nov 并关联承诺／协议。
- **Payment Release Date（原字段）**：保留，GFS 任务继续按 FR11 等待规则生成。新增日期不覆盖它。
- **Actual receipt date**：实际收款／对账产生的事实，不复制上述日期。

### 关键分支

| 场景 | 本设计的处理 |
|---|---|
| 请求 £20,000，余额 £30,000 或刚好 £20,000 | 标准抵扣 → 既有审批 → GFS 重查 → PO 路线。 |
| 请求 £20,000，余额 £8,000 | 显示 £12,000 shortfall；标准抵扣不准送审，改选 Manual Invoice／GFS PO 例外，写清全额结算安排后可送审。不新增“部分抵扣＋部分开票”的拆分规则。 |
| SAP 超时／失败 | Balance 和 Shortfall 为“—”，结果 Unknown；重试，不按0、不当通过。 |
| 审批时 £30,000，实施前只有 £8,000 | 暂停实施，GFS 填原因退回；Buyer 修改安排，新版本重查并重新送审；保留旧审计。 |
| 金额／版本改变 | 旧检查失效，必须重查。只允许在退回后的草稿修改审批依据。 |
| 同一余额被另一笔 Claim 使用 | 重查发现减少时暂停。查询不等于预留；正式版须解决并发重复占用，不能宣称本设计已锁定资金。 |

## 3. ACT／FR／页面及影响

| 项目 | 关联／修改 |
|---|---|
| Epic | 主 CNP-233 授权审批，关联 CNP-234 下游实施。 |
| User stories | ACT-012 Submit Settlement Request；ACT-013 Approval Check；ACT-022 Manage Task。 |
| FR | FR1.2、FR9.1／9.4、FR10.2、FR11、FR12、FR14。FR11.1 是 Trading Division 专用，不套普通 LSP。 |
| UC | 沿用既有分析 UC-18 Settlement、UC-14 审批、UC-21 LSP 检查，补足额、不足、失败、变化及例外场景。 |
| 页面 | P4.3／P9.4 Settlement 录入；P4.1.7 Approval Check 核对；P3.2 Task Detail 承接 GFS 重查和实施。独立页面集中演示这些阶段，不重编页面号。 |
| 类型 | **应用前后端＋BPM＋集成依赖**，包括字段、检查快照、服务端校验、审批版本、退回／override、外部编号和结果关联；不是 UX/UI only。 |
| 接口 | 优先确认复用 MCI_getSupplierBalanceFromSAP：NEO 经 Apigee 查询 SAP。SAP 提供余额；读取余额不是建 PO。 |
| 优先级 | Finance Must；源表建议 Phase 1。契约和权限确认是实际联调的前置，不阻止本独立方案评审。 |

## 4. 收敛为两项确认

| 项目 | 建议采用的答案与例子 | 谁确认 |
|---|---|---|
| 业务控制及路线 | 接受“提交 Settlement 前查＋实施前重查”，独立约定结算日，不足带 Manual Invoice／GFS PO 例外送审。例：£8,000 余额支持不了 £20,000 抵扣，但可以审批供应商承诺全额付款的人工发票方案。按 Receivable 类型识别方向，不只看正号。 | Finance／GFS／流程 Owner，确认整套建议即可。 |
| SAP 契约及授权 GFS | 提供余额含义、币种、时点、正负号和成功／失败样例，以及 override 权限名单。例：两笔各 £20,000，不能各自看到 £30,000 就认为两笔均可全额抵扣。现有 GET 优先复用；不足时再评估接口扩展。 | SAP／Apigee Owner（目录列 Harsh Kumar）及 Finance／GFS。 |

**取消 Manual Invoice 单独决策，不作为本设计默认改动。** 历史 CR7 提及可能需要新 SAP Integration，保留为契约核对背景，不提前承诺新增架构。页面中的余额例子已归一为可结算余额，不能对任意 SAP 原始值直接取绝对值。

## 5. 怎么走查

1. 选 £30,000／£20,000 场景；Alice Morgan 查余额并 Submit Settlement Request。
2. Switch to Ben Taylor → Confirm checks and send for approval；切 Eva Brooks → Approve assigned step。
3. 切 Daniel Foster → Recheck SAP balance → 确认协议安排 → Confirm GFS checks。
4. Create Lump Sum PO → Read SAP outcome → Mark as Implemented。查看外部编号，确认 Collection 仍为 Not confirmed。
5. 选 £8,000 场景，查余额后改选 Manual Invoice，填 “Supplier will pay the full GBP 20,000 on 30 November under agreement v1”；审批后记录发票号和证据。或选 GFS PO override，由 GFS 记录 override 和原因后走 PO。
6. 选 Balance falls… 场景；GFS 重查会发现不足。Return to Buyer 必填原因，原输入保留，版本增加，新版本需重查并重审。

场景和角色切换是评审工具。数据仅在本页会话内，刷新／Restart 重置；不调用 SAP、创建线上单据或发送邮件。生产身份、后台持久化、真实流程与接口需单独实现和验收。

本轮本地结果见 [VALIDATION.json](VALIDATION.json) 和 [PAGE_VISUAL_CHECK.json](PAGE_VISUAL_CHECK.json)。接口、后端权限、持久化、工作流、并发资源预留和 Finance UAT 均不算通过。

## 6. Source / Reference

| Ref | 来源与定位 | 证据边界 |
|---|---|---|
| R1 | NEO Business Requirements (added China requirements) 2(RTM for Requested Changes)_1113 1400 version.xlsx；工作表 NEO Business Requirements (adde；E6、P6、S6、V6、X6。 | 原要求将不足余额纳入审批；取消 Manual Invoice 是问题，不是决定。用户源内容不改。 |
| R2 | Material Cost & Inventory - BRD V3.1.docx；表6第4行 FR1.2、第35行 FR11。 | 原 Payment Release Date 与 GFS 日期等待。未证明新增结算日与原字段同义。 |
| R3 | 同一 BRD；表6第37行 FR12。 | 应收余额检查、不足转人工；PO 返回编号及 Data Posted Awaiting Approval；应收由 GFS 手动更新 Finance Implemented。 |
| R4 | 同一 BRD；表6第39行 FR14。 | Manual Invoice 与 GFS override 转自动 LSP PO；没有统一新增 AP 审批规则。 |
| R5 | Integrations - 2026-11-09_0941(Sheet 1).csv；物理第12行、Id 6、MCI_getSupplierBalanceFromSAP；UpdatedOn 07 MAY 2025。 | Appian→SAP／Apigee GET／JSON；companycode、vendor 参数；120秒；Owner Harsh Kumar。未调用接口。 |
| R6 | NEO Business Requirements (added China requirements) 1.xlsx；P1 CR clean!A13:Y13／CR7，D13、P13、W13。 | 历史性能问题及可能需新 SAP Integration，须对照现行契约。 |
| R7 | outputs/neo-jira-stories-20261111/v3/story_data.json，ACT-012／013／022；new-requirements/analysis.json，NEO-005。 | 既有 Epic／ACT／UC／页面分析关联，不是本轮在线 Jira 核验。 |
| R9 | must-design-guide-20261115-v1/before-source/app.js；SHA-256 `3ff8bc0b158ba08f2302e7404bb6185a553088c78614051451e6b5137a26802e`；P05-B09、P05-B10、ap-override、etracker-approve。 | 冻结 prototype 的本地演练路径；不足分支与 BRD 规则分开记录，不证明现网已验证。 |
| R8 | 用户 16 Nov 2026 指示；项目 jlr-frontend-ux 规则、共享 NEO theme 快照。 | 将建议落实为可走查流程，减少开放问题，保留 Manual Invoice；沿用 NEO／Ant Design 的交互与样式。 |

BRD 和 CSV：`/Volumes/KIOXIA/JLR Appian/6.技术方案/2 - Tech NEO/`。需求工作簿：`/Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/`。表／行按1起算。

Training 补充截图：`/Volumes/KIOXIA/JLR Appian/outputs/NEO_Business_Questions_Source_Review_20261116/evidence/Q010_Manual_Invoice_Override_Training.png`。它支持历史人工发票／Override 操作，不是本轮验收证据。

只更新本独立005设计及导览中的对应条目。旧版保存在 qa/20261116/previous-design.zip；当前源码在 design-source/。验证中检查原 prototype／Before 文件及其它35项条目保持不变。
