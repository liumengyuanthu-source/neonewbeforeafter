# NEO-005 · Before / After process

## NEO-005 · Before / After 流程

关键变化：将供应商余额与结算安排提前到审批阶段，同时保留实施前复核。

### Before · 既有流程

审批与 GFS 检查完成后，进入实施阶段的余额检查和分支处理。

1. **Buyer — 创建／维护应收 LSP**: 准备 Claim、金额和支持文件，提交 Settlement Request。
2. **FBP／适用审批人 → GFS — 完成既有授权与检查**: 按适用 Mandate／DoA 及 GFS 检查规则处理；保留原日期等待和支持文件要求。
3. **NEO／SAP · 实施阶段 — 检查供应商余额**: 拟走自动 PO 的应收 LSP 在此检查余额是否足以覆盖 Claim。已选择 Manual Invoice 的项目走原人工路线。
4. **实施处理人 — 足额／不足分别处理**: 足额进入 PO 建单、审批与结果回读；不足进入已有人工／例外分支，见下方。
5. **GFS／Finance — 记录外部结果与实施状态**: 关联 PO／发票编号和结果；应收 Implemented 与实际到账、关闭分开。

- **BRD 既有规则**: 不足 → GFS Manual Invoice；允许有权 GFS override 转自动 Lump Sum PO。
- **当前 prototype 的本地演练分支**: 不足 → AP override → PO；或 eTracker approval → Invoice → NEO match。它们是冻结原型中的分支，不等于已确认的现网规则。

### After · 005 建议流程

提交 Settlement 前查余额；让审批人看到可执行的结算方式、日期和证据。

1. **Buyer · 提交前 — 查 SAP 余额，准备结算安排**: 选择标准抵扣、Manual Invoice 或 GFS PO override；填写约定结算日并关联协议。
2. **Buyer — 提交同一版本的 Settlement**: 足额可走标准抵扣；不足时需说明全额如何结算。锁定金额、日期、方式、证据和余额快照。
3. **FBP／适用审批人 — 审批金额及结算安排**: 沿用适用审批路线；同时审阅余额、不足原因、承诺日期和替代结算方式。
4. **GFS · 实施前 — 重新查余额并核对获批安排**: 原抵扣不再足额：暂停 → 退回 Buyer 修订 → 重查并重新审批。PO 例外须有权 GFS 确认 override。
5. **GFS／SAP — 按获批方式实施并记录结果**: PO 路线回读 SAP 结果；人工路线记录发票号和证据，再按应收规则确认 Implemented。

- **方案一 · Manual Invoice**: Buyer 提出全额收款安排与日期 → 审批 → GFS 重查并核对 → 记录人工发票和实施证据。
- **方案二 · GFS PO override**: Buyer 提出 PO 例外和理由 → 审批 → 有权 GFS 重查、确认 override → PO 建单及结果回读。

### 同一笔 £20,000 的例子

Before：进入实施时，发现仅 £8,000 余额，再处理不足余额的人工／例外路线。

After：送审前已显示 £12,000 shortfall。Buyer 提出“供应商 30 Nov 全额支付 £20,000，走 Manual Invoice”，审批人先批准这套安排，GFS 再核验并执行。

### 继续保留的控制

- Manual Invoice 不删除；取消它仍是单独决策。
- 既有 DoA／GFS 权限、支持文件和 Payment Release Date 等待规则保留；不新增统一 AP 审批。
- After 的 Agreed settlement date 是约定付款／抵扣日，不替代 Payment Release Date，也不是实际到账日。
- After 查询失败显示 Unknown 并重试；PO 编号、Implemented、实际收款分别确认。

Before 页面仍指本导览冻结的当前 prototype。上方业务顺序依据 BRD；原型分支单独注明，未宣称现网整链已验证。After 是独立建议设计。

### 来源与适用范围

- BRD V3.1 · 表6第35行 FR11：适用授权后 GFS 检查及日期等待。
- BRD V3.1 · 表6第37行 FR12：实施阶段余额检查、不足转人工、PO 编号和应收实施状态。
- BRD V3.1 · 表6第39行 FR14：GFS Manual Invoice 与不足余额时的 GFS override。
- 当前导览 Before bundle app.js（SHA 3ff8bc0b…）：P05-B09、P05-B10、ap-override、etracker-approve；来自本地代码，不是线上执行证据。
- 005 需求工作簿 E6／P6；用户 16 Nov 2026 确认的设计方向；After 页面 NEO-005_Page_Proposal.html。

## NEO-005 · Before / After process

Key change: bring supplier balance and settlement arrangements into approval, while retaining the pre-implementation check.

### Before · Existing process

The balance check and insufficient-balance routing sit in implementation, after the applicable approvals and GFS checks.

1. **Buyer — Create / maintain a receivable LSP**: Prepare the Claim, amount and supporting documents, then submit the Settlement Request.
2. **FBP / applicable approvers → GFS — Complete existing authorisation and checks**: Follow the applicable Mandate / DoA and GFS checks, including existing date-based waits and supporting documents.
3. **NEO / SAP · Implementation — Check the supplier balance**: For receivable LSPs taking the automatic PO route, check whether the balance covers the Claim. Preselected Manual Invoice items follow the existing manual route.
4. **Implementation owner — Follow the sufficient / insufficient branch**: Sufficient balance proceeds to PO creation, approval and readback. Insufficient balance enters the existing manual / exception branch below.
5. **GFS / Finance — Record external outcome and implementation**: Link the PO / invoice reference and result. Receivable Implemented remains separate from collection and closure.

- **Existing BRD rule**: Insufficient balance → GFS Manual Invoice; authorised GFS may override to an automatic Lump Sum PO.
- **Current prototype rehearsal branches**: Insufficient balance → AP override → PO; or eTracker approval → Invoice → NEO match. These are branches in the frozen prototype, not confirmed current-production policy.

### After · Proposed 005 process

Check before Settlement submission so approvers can review the method, agreed date and evidence.

1. **Buyer · Before submission — Check SAP and prepare arrangements**: Select standard offset, Manual Invoice or GFS PO override; record the agreed settlement date and supporting agreement.
2. **Buyer — Submit one version for approval**: Sufficient balance supports offset. Insufficient balance needs an explicit arrangement for the full amount. Lock amount, date, method, evidence and balance snapshot.
3. **FBP / applicable approvers — Approve the amount and arrangements**: Retain the applicable approval route. Review the balance, shortfall, agreed date and alternative settlement method together.
4. **GFS · Before implementation — Recheck and confirm the approved method**: If the approved offset is no longer covered: hold → return to Buyer → revised check and approval. A PO exception also needs an authorised GFS override.
5. **GFS / SAP — Implement the approved method**: Read back the SAP PO outcome, or record the manual invoice and evidence. Then confirm receivable Implemented under the existing rule.

- **Route 1 · Manual Invoice**: Buyer proposes full collection arrangements and date → approval → GFS recheck and confirmation → invoice number and implementation evidence.
- **Route 2 · GFS PO override**: Buyer proposes the PO exception and reason → approval → authorised GFS rechecks and confirms override → PO creation and outcome readback.

### The same £20,000 Settlement

Before: implementation finds only £8,000 available, then follows the insufficient-balance manual / exception route.

After: a £12,000 shortfall is visible before submission. The Buyer proposes “Supplier pays the full £20,000 on 30 Nov via Manual Invoice”. Approvers review that arrangement before GFS confirms and implements it.

### Controls that remain

- Manual Invoice stays; removing it is a separate decision.
- Existing DoA / GFS authority, evidence and Payment Release Date scheduling remain. No universal new AP approval is introduced.
- The proposed Agreed settlement date is the expected payment / offset date. It neither replaces Payment Release Date nor proves receipt.
- A failed After lookup is Unknown and requires retry. A PO number, Implemented and receipt of funds are separate outcomes.

Before pages remain the current prototype frozen in this guide. The business sequence is sourced from the BRD; prototype-only branches are labelled separately. No current-production end-to-end validation is claimed. After is an independent proposal.

### Sources and scope

- BRD V3.1 · Table 6 row 35, FR11: GFS checks after applicable authorisation and date-based waits.
- BRD V3.1 · Table 6 row 37, FR12: implementation balance check, insufficient-balance handling, PO reference and receivable implementation.
- BRD V3.1 · Table 6 row 39, FR14: GFS Manual Invoice and GFS override for insufficient balance.
- Frozen Before app.js (SHA 3ff8bc0b…): P05-B09, P05-B10, ap-override and etracker-approve. Local code evidence, not online execution.
- Requirement 005 workbook E6 / P6; user direction on 16 Nov 2026; independent NEO-005_Page_Proposal.html.

