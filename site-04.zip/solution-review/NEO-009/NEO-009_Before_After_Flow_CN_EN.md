# NEO-009 · Before / After process

Priority: Could (Procurement: Could; Finance: Could)

ACT-001 / ACT-012 / ACT-022 / ACT-025 · FR1.6 / FR14

## RMA 价格与交易自动处理

保留既有审批，先取得可信 RMA 数据，再自动实施；结果未知时先查原单。

### Before · 现有路径

1. **Buyer · 准备 RMA Claim** — 按既有流程维护零件、价格和支持文件，并完成适用的 Settlement 授权。
2. **GFS／指定团队 · 处理人工任务** — BRD FR14 和 Training 包含 RMA 人工实施；当前原型有 Manual Task 表单。
3. **任务处理人 · 记录结果** — 人工确认外部处理结果及凭据，不把打开任务当作已实施。

### After · 建议路径

1. **Buyer／SAP · 读取并复核 RMA 零件与价格** — 保留供应商、工厂、币种、有效期和价格版本；刷新原价不能覆盖 Buyer 已填的新价。
2. **Buyer → 适用审批人 · 提交已复核的商业内容** — 沿用现有授权与 GFS 检查；锁定本次价格和支持文件版本。
3. **NEO／SAP · 按同一请求编号实施** — 按已确认的 RMA 契约发送；保存关联编号，回读外部处理状态。
4. **GFS／NEO · 成功完成，异常分流** — 超时先查原单；确认失败才修正重试或转人工。只有适用明细成功且条件满足，才更新 Implemented。

### 例子

示例：原价从 £20 刷新为 £22，Buyer 新价仍为 £19，差额变为 -£3。提交超时后先按原请求编号查 SAP，不能重新建一笔。

### 保留控制

- Manual Task 保留为受控回退；已成功明细不可重复发送。
- RMA 原在自动更新范围之外；这是扩展建议，不是既有接口已支持的证明。

### 正式实施前补齐

- SAP／Apigee Owner 确认 RMA 读取、写入、状态回查和防重复契约；普通 Parts API 不足以证明可复用。

## Automate RMA price and transaction handling

Retain existing approvals, obtain reliable RMA data, then automate implementation; check the original transaction when the outcome is unknown.

### Before · Existing path

1. **Buyer · Prepare the RMA Claim** — Maintain parts, prices and evidence and complete applicable Settlement authorisation.
2. **GFS / Assigned team · Handle the manual task** — BRD FR14 and Training include manual RMA implementation; the current prototype has a Manual Task form.
3. **Task owner · Record the result** — Record external results and evidence; opening a task does not establish implementation.

### After · Proposed path

1. **Buyer / SAP · Retrieve and review RMA parts and prices** — Retain supplier, plant, currency, effective date and price version. Refreshing the start price must not overwrite the Buyer’s new price.
2. **Buyer → Applicable approvers · Submit the reviewed commercial scope** — Retain existing authorisation and GFS checks; bind the reviewed prices and evidence version.
3. **NEO / SAP · Implement under one submission reference** — Send through the agreed RMA contract, save the correlation reference and read back the external outcome.
4. **GFS / NEO · Complete confirmed success; route exceptions** — On timeout, check the original transaction first. Correct, retry or use the manual route only after a confirmed failure. Set Implemented only after the applicable lines and controls succeed.

### Example

Example: the start price changes from £20 to £22 while the Buyer’s new price stays £19, giving a -£3 difference. If submission times out, query SAP using the original reference before creating anything else.

### Controls retained

- Keep Manual Task as a controlled fallback; never resend successful lines.
- RMA was outside the original automatic-update scope; this proposal does not prove existing API coverage.

### Production dependencies

- SAP / Apigee owners must confirm RMA read, write, status and duplicate-prevention contracts; generic Parts APIs alone do not prove reuse.

## Sources

- **R-1113** NEO Business Requirements (added China requirements) 2(RTM for Requested Changes)_1113 1400 version.xlsx · NEO Business Requirements (adde!E10,N10,P10,Q10; priorities K10:L10
- **S1** NEO Business Requirements (added China requirements) 1.xlsx · RTM for Requested Changes!A10:R10
- **S3-8** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 8
- **S3-39** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 39
- **S3-scope** Material Cost & Inventory - BRD V3.1.docx · Body paragraphs 120-131; 280
- **S4** Integrations - 2026-11-09_0941(Sheet 1).csv · Logical records 7-8; Id1-2
- **S4-inventory** Integrations - 2026-11-09_0941(Sheet 1).csv · All logical CSV records; whole-word RMA search across cells (not substring matches)
- **S6** NEO User Training.docx · Body paragraphs 1191-1200
- **S7** ManualTaskForm.tsx · lines 1-137
- **S2** NEO Business Requirements (added China requirements) 1.xlsx · P1 CR clean!A27:Y27

Before: frozen prototype `3ff8bc0b158ba08f2302e7404bb6185a553088c78614051451e6b5137a26802e`. Historical problems are labelled separately. After is a proposal; numerical examples are illustrative. Production execution: NOT RUN.
