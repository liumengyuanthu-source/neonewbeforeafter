# NEO-009 · RMA 零件、价格与交易自动化

<!-- FLOW-REVIEW-20261116 -->
## 16 Nov 2026 · 流程评审补充

[中英文 Before / After 流程](NEO-009_Before_After_Flow.html) · [流程说明 MD](NEO-009_Before_After_Flow_CN_EN.md)

保留既有审批，先取得可信 RMA 数据，再自动实施；结果未知时先查原单。

本轮为流程说明补充；原交互页面、问题及历史证据保留。正式实施前需补齐：SAP／Apigee Owner 确认 RMA 读取、写入、状态回查和防重复契约；普通 Parts API 不足以证明可复用。
<!-- /FLOW-REVIEW-20261116 -->

## 1. 一句话说明

让 Buyer 直接取得 RMA（SAP ECC）的零件和价格，并把授权后的 RMA 交易送到目标系统，收到实际结果后再更新 NEO。原文要减少人工维护原材料价格；它不是单纯加一个按钮，也不能用现有 WIPS 自动化直接替代。[S1、S2]

本轮交付独立的页面方案和实施评估。没有修改现有 NEO prototype。页面中的人员、供应商、零件号、金额、日期、接口参考号和结果全部为合成评审数据；不是当前 SAP 记录，也不代表接口或流程已验收。

## 2. 分类、优先级与需求关联

| 项目 | 评估 | 依据／限制 |
| --- | --- | --- |
| 主要改动类型 | Application 前后端 + Integration needed | 需要取价、价格版本、交易提交、结果关联、状态控制及异常任务；不属于 UXUI only |
| 对接系统 | RMA（SAP ECC）；现有渠道可能经 Apigee | RMA 属于 SAP ECC 是来源原文；实际 API 提供方、网关和调用方式仍需 SAP 团队确认 |
| 复用现有接口 | 两个 POA 查询接口可先评估；不能直接确认支持 RMA | MCI_getPartDetails、MCI_getPartPriceDetails 是读接口，不证明 RMA 覆盖，也不提供本需求的写入／查重／结果契约 [S4] |
| 新增架构 | 需新增或扩展接口契约及 NEO 编排；是否增加基础设施待评估 | 历史 CR12 明确提到 new SAP Integration；不等于必需另建一个平台 [S2 P27] |
| Epic | 主关联 CNP-234 Implementation；关联 CNP-231 Claims and data、CNP-233 Authorisation | 复用现有 ACT 的本地 Epic 分组；没有新建 Jira Epic，也不是已批准的新增范围 [S5] |
| User story | ACT-001 Create Claim；ACT-025 Complete Task；上游 ACT-012 Submit Settlement Request、ACT-022 Manage Task | ACT-025 可承接手工处理思路，但 RMA 分派必须按 FR14 的 GFS，而非直接照搬其他 CBSL 任务 |
| FR | 直接影响 FR1.6、FR14；关联 FR9.1／FR9.4、FR11、FR16／FR21 | RMA 自动实施及结果处理是对既有手工范围的扩展，不能假装旧 FR 已完整覆盖 |
| UC | 扩展现有 Claim／POA 场景 UC-02、03、09 和实施场景 UC-19、20 | 这是本轮场景关联建议；没有给新自动化场景杜撰已批准的 UC 编号。需补 RMA 成功、未知、部分成功、人工交接子场景 |
| 页面 | P2.6.1 Select Parts、P2.6.2 Part Prices；下游 P3.5 手工实施任务详情的扩展 | 本页合并呈现选件／改价用于评审；正式实现保持既有分步和其余字段。自动结果区尚未分配正式新页面号 |
| 优先级 | 建议 P2；接口与范围确认先做 | RTM Procurement／Finance 均为 Could；高金额风险意味着交付控制严格，不自动把业务优先级改成 Must [S1 K10／L10] |
| 历史记录 | Significant；Pause；No - Backlog；CR12 needs to be backlogged | 这是原表历史状态，不代表当前项目决策。Sam Scott／Denes Hagen 为来源中的确认人，现任责任需重新确认 |

注意：ACT-040 现有定义是查看月度／预算汇率；ACT-051 的列明参考表也没有直接确认 RMA 物料价格。因此本需求的 RMA 主数据维护不能靠这两个 ACT 的名字就认定已覆盖。[S5]

## 3. 来源边界

| 来源 | 可以确认 | 不能据此认定 |
| --- | --- | --- |
| S1 E10 | 要自动取得 RMA parts、prices 和 transactional activity；高金额、当前人工维护 | 原文没有完整的 RMA 对象、字段、审批触发点或交易结果契约 |
| S2 G27／P27 | 原 Phase 2 未确定预算；历史备注认为需 new SAP Integration | 不能认定现有 SAP API 已具备写入能力，也不能把“nothing to do with Appian Dev Team”当作 NEO 无需开发 |
| S3-scope 原 BRD | RMA source-system update 在原始 out-of-scope 列表中 | 这次新增需求需明确变更范围，不应静默写成旧系统已有自动化 |
| S3-8 FR1.6 | 记录 Part／Plant／当前价／新价／币种／价格变化等；WIPS simulation 排除 RMA 等情形 | 不能把 RMA 写入接到 WIPS 建单／审批机器人 |
| S3-39 FR14 | RMA 生成 Line-level 的 GFS 人工更新任务 | 自动化后的人工兜底角色先沿用这一证据；转 CBSL 需明确新决定 |
| S4 查询接口 | SAP 到 NEO 的通用 POA parts／price history GET | 全目录按独立单词 RMA 搜索未找到命名记录；这只表示材料未证明专用契约，不证明 SAP 没有该能力 |
| S6 Training | Complete Task 下列出 Manual Tasks - RMA | 本轮只引用已提取文字；不能把同章节其他任务额外字段直接套到 RMA |
| S7 当前源码 | 通用手工任务有备注、草稿、确认和错误保留 | 仅核读该组件，不构成全产品接口审计，也不证明 RMA 自动写入已实现 |

## 4. 页面方案

### 4.1 Buyer：选件与取价

![Buyer：选择有有效价格的零件，查看来源并维护拟议新价](NEO-009_Page_Parts.png)

沿用 NEO 字体、颜色、间距、表格和操作模式。显示 Supplier、Company／Plant、Currency／Price unit、Source version。当前价只读，新价单独录入；勾选控制本次选择，眼睛图标查看该零件的来源。缺价格行置灰且写明原因，不把缺失值当0。

正式页面要保留 FR1.6 的完整适用字段，包括价格变化原因／符号／百分比、Runout／日期等。本图仅呈现 RMA 新增取价与来源部分，不替代全量 POA 表单。

### 4.2 确认本次选件

![仅核对选中的零件和新旧价差](NEO-009_Page_Review.png)

Review selected parts 只包含已选项。本例20变19，显示 New minus current = -1；这是算术差，不直接定义 Risk／Opportunity、会计或报表的符号。Apply to Claim 保持禁用，因为本包没有产品写入。两位小数仅用于 fixture，正式数量／单位／价格精度需确认。

### 4.3 源价格变化

![刷新后20变22，保留用户输入19，要求重新核对](NEO-009_Page_PriceChange.png)

刷新源价不得悄悄改掉用户已输入的新价。示例重新核对后差额为19−22=-3。是否导致重算、重审或仍使用原批准快照，必须由商业版本和审批规则决定；勾选“已核对”不等于新价格已获批准。

### 4.4 GFS：未知结果与查原单

![请求已发出但结果未知：先查询，禁止立即重发或转手工](NEO-009_Page_Unknown.png)

保留同一个 Submission reference，显示结果未知。Check status 在样例中返回已存在的外部记录，状态仍为 Processing，不会因此标成 Implemented。这里的查询能力是拟议接口要求，不是已有 API 的承诺。

### 4.5 部分成功

![逐项显示成功与拒绝，整条Line仍等待实施](NEO-009_Page_Partial.png)

本例两项中一项成功、一项拒绝；成功项保留外部编号，不整单重发。正式实现要确认 SAP 是否支持逐项结果、独立重试或事务整体回滚；如果接口只支持原子提交，就不能照搬这个分项重试设计。

### 4.6 人工处理

![确认失败后由GFS审阅原因和原批准版本](NEO-009_Page_Manual.png)

只有已确定拒绝、符合授权人工路线的情形才进入人工处理评审；超时不自动转手工。保留原提交参考和 Settlement 版本。备注不能为空；备注本身不代表外部处理已完成。正式完成仍需外部参考与实际完成证据。

另附 Readback、Complete 和390px截图。Complete样例只有全部项确认完成才显示Implemented；付款、月结和Claim关闭是其他业务状态。

## 5. 改动与影响

| 层／责任 | 需要做什么 | 影响 |
| --- | --- | --- |
| UXUI／前端 | RMA范围识别、有效选件、源价／新价分离、版本、结果及异常展示 | Buyer 和 GFS 的日常操作；禁止沿用截图中的假成功 |
| NEO应用服务 | 服务端重新校验授权、对象匹配和价格版本，冻结实施依据 | 前端勾选不能替代后端验证；避免用最新数据覆盖已批准内容 |
| 数据库 | 关联Line、申请版本、源快照、提交参考、外部编号、逐项结果和审计 | 保存模型需结合现有dictionary核对后决定扩表，不在本稿冒定现有字段 |
| BPM | 满足批准／GFS／Complete等实际触发条件后提交；等待、查询、异常路由 | 具体触发点待业务签收，不从本图推断Mark As Complete就是唯一触发 |
| SAP／Apigee | 提供或扩展RMA读写、回执与按提交参考查询能力 | 新SAP接口工作量不能被UI交付掩盖 |
| Finance／计算 | 确认单位、金额、符号、币种、价格日期、对已批准值的影响 | 防止高金额错误以及计算基础与实施基础不一致 |
| 运营 | 未知／失败对账、人工交接、重复检测、可观测性与重放权限 | 防止重试导致二次价格更新；不能把“按钮可点击”当可靠恢复 |

## 6. 接口与数据契约：先要什么

| 能力 | 已有材料 | 需要补齐的字段／规则 |
| --- | --- | --- |
| 取零件 | MCI_getPartDetails，Id1 | 确认RMA覆盖、Vendor／Plant／Material键、分页、失效及权限过滤 |
| 取价格 | MCI_getPartPriceDetails，Id2 | 确认币种、计价单位／换算、有效期、价格版本、缺价／多价处理 |
| 写入RMA交易 | 仅需求及CR12说明 | 目标业务对象、操作类型、批准版本、有效日期、材料行、价格及币种／单位；写入授权、幂等键、返回契约 |
| 查原单／回执 | 未收到专用契约 | 同一提交参考查外部编号、状态及各行结果；回调认证／重试／排序／重复事件处理 |
| 状态与对账 | 原BRD手工任务有依据 | 什么结果证明Implemented；超时多久查询；部分成功是否支持；人工完成需要什么证据 |

以上是待确认的语义字段清单，不是现有接口payload。字段名、路径、类型、必填、精度、枚举、错误码和实际样例都未被本包伪造。通用GET的路径参数只能证明该接口登记内容，不能证明RMA业务写入对象。

## 7. 业务问题：讲人话

| 编号 | 要确认什么 | 例子／影响 | 建议确认方 |
| --- | --- | --- | --- |
| Q01 | 自动化具体改哪个RMA对象：价格主数据、协议、交易申请还是其他？ | 给供应商的某原材料从20改19，是改未来价格，还是补算过去交易？二者接口和批准依据不同 | RMA Buyer／FBP、SAP负责人 |
| Q02 | 一条价格到底靠哪些值唯一匹配？ | 同材料不同Plant、GBP/kg与GBP/ton，不能选到同一价格。需要真实组合与精度样例 | SAP主数据、RMA业务 |
| Q03 | 什么时候才允许发送？ | Settlement批准但还没Complete，能否改价？若GFS检查未完成必须等哪个动作？ | Process Owner、GFS、FBP |
| Q04 | 超时怎么找到已经建好的记录？ | SAP成功但NEO没收到响应，是否能用同一个提交参考查询？如果不能，不能放心重发 | SAP／Apigee、NEO技术 |
| Q05 | 部分成功怎么办？ | 两项中第一项成功、第二项拒绝，是只补第二项，还是必须整体撤回？ | SAP、GFS、Finance |
| Q06 | 人工处理仍由GFS吗，需要什么证据？ | 原BRD是GFS的Line级任务。谁能转手工，外部编号和确认文件是否必填？ | GFS、业务流程负责人 |
| Q07 | 已批准后源价变了，要不要重审？ | 批准时原价20，发送前取价22，用户新价仍19：能继续用原快照还是必须重算／重审？ | FBP、Buyer、审批政策负责人 |
| Q08 | 现有查询接口是否覆盖RMA，谁提供新增写入和状态查询？ | 不要因同为SAP就认定两个POA GET可直接覆盖；提供非生产成功／失败／超时样例 | SAP、Apigee、RMA团队 |
| Q09 | 此次是否正式纳入范围，原确认人是否仍适用？ | 原记录为Could／Pause／Backlog且曾无Phase2预算；Sam Scott、Denes Hagen只是历史联系人 | Sponsor、Product Owner、项目经理 |

## 8. 验证和退出条件

本轮 **64 项本地交互／布局检查通过**。本地验证覆盖选件／缺价禁选、清空新价、刷新后的输入保留与重新核对、选件范围、弹窗回退、未知结果查询、部分结果、人工备注，以及多尺寸和键盘关闭。实际逐项结果在 PAGE_VISUAL_CHECK.json，期望与观测值分开保留。

| 验证层 | 本轮结果 | 不能代替什么 |
| --- | --- | --- |
| 独立页面交互／fixture | 见随包实际检查结果 | 不代替真实API、后端、持久化或金额业务验收 |
| 真实RMA读取／写入／回读 | NOT RUN | 尚无本需求完整接口契约及测试环境 |
| 服务端权限／幂等／并发 | NOT RUN | 页面禁用按钮不等于权限或幂等已实现 |
| 真实批准版本／BPM状态 | NOT RUN | 本页状态切换是评审fixture，不是工作流执行 |
| 金额／精度／Finance对账 | NOT RUN | 20→19只是显示算术，不是签收golden case |
| 产品回归／部署 | NOT RUN | 未修改或部署现有prototype |

进入开发前：确认自动化对象、批准触发、RMA接口及错误／重复处理、数据单位／精度、GFS兜底和范围预算。进入业务验收前：用同一测试Line完成真实读取→批准依据→写入→回读→状态更新，并覆盖超时原单查询、拒绝、价格变化及适用的部分结果。所有外部调用只在授权隔离环境执行。

## 9. Reference

| ID | 原文件／定位 | 使用方式 |
| --- | --- | --- |
| S1 | NEO Business Requirements (added China requirements) 1.xlsx；RTM for Requested Changes!A10:R10 | NEO-009原文、Both、分类、Could、关联CR12 |
| S2 | 同工作簿；P1 CR clean!A27:Y27，重点G／H／M／N／P／T／W27 | 历史范围、复杂度、责任线索、暂停／Backlog和SAP集成备注 |
| S3-8 | Material Cost & Inventory - BRD V3.1.docx；第6个表、第8行FR1.6 | Parts字段及WIPS排除RMA |
| S3-39 | 同BRD；第6个表、第39行FR14 | RMA Line-level GFS手工任务 |
| S3-scope | 同BRD；正文段落120–131、280 | 原始自动更新范围排除及后续自动化方向 |
| S4 | Integrations - 2026-11-09_0941(Sheet 1).csv；逻辑记录7–8、Id1–2 | 通用SAP POA GET；不是RMA写入契约 |
| S5 | outputs/neo-jira-stories-20261111/v3/story_data.json；entries.act 1／12／22／25／40／51 | 现有Epic和ACT范围；本地整理成果，不替代原BRD |
| S6 | NEO User Training.docx；正文段落1191–1200 | Complete Task、Manual Tasks - RMA |
| S7 | app/src/views/Tasks/ManualTaskForm.tsx，1–137行；目录20261106_REACT_ANTD_v1 | 当前通用手工任务只读核验 |
| S8 | app/src/theme/index.ts；同React目录 | 沿用真实主题快照、JLR字体与Ant Design |

Word定位为文档对象中的1-based表／行／正文段落，不冒充打印页码。CSV含多行单元格，使用逻辑记录号和接口Id，不冒充物理文本行。精确路径、引用原文、SHA-256保存在 SOURCE_EVIDENCE.json；主题与依赖版本保存在 design-source/SOURCE_MANIFEST.json。
