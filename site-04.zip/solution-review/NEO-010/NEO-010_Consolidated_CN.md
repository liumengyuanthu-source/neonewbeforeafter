# NEO-010 · Activity Log 与财务影响追踪

<!-- FLOW-REVIEW-20261116 -->
## 16 Nov 2026 · 流程评审补充

[中英文 Before / After 流程](NEO-010_Before_After_Flow.html) · [流程说明 MD](NEO-010_Before_After_Flow_CN_EN.md)

沿用 Activity Log，补齐变化链和前后计算版本，不另造一套审批流程。

本轮为流程说明补充；原交互页面、问题及历史证据保留。正式实施前需补齐：确认需覆盖的事件和留存周期；计算服务提供可比较的前后版本及币种／期间口径。
<!-- /FLOW-REVIEW-20261116 -->

## 1. 一句话说明

日志既要说清“谁在什么时间改了哪个字段”，也要说清“这次修改让全年／期间影响变了多少”。保留现有日志，在一条活动下面查看字段前后值和当时的计算前后值，避免只留下“FTO 已刷新”而不知道金额影响。[S1]

沿用既有 NEO theme、JLR 字体和 Ant Design。本包是独立页面评审，没有修改现有 prototype。所有人员、Line、零件、版本和金额均为合成数据，不是实际业务记录或 Finance 签收样例。

## 2. 改动分类与关联

| 项目 | 结论 | 依据／边界 |
| --- | --- | --- |
| 主要改动类型 | Application 内部前后端、计算快照及审计关联；同时调整UXUI | 仅给页面加列不够，必须捕获每次保存和相应计算的实际结果 |
| Integration needed | 默认不因本需求新增外部系统接口 | 优先用NEO已有业务事件及计算输入。若FTO、价格、FX的来源版本未传入，才评估对应渠道的元数据扩展 |
| 新增架构 | 暂无证据需要新增独立平台 | 可扩展既有审计与计算存储；防篡改、归档、检索规模由实际要求决定 |
| Epic | 主关联 CNP-231 Claims and data；关联 CNP-235 Finance and continuity、CNP-233 Authorisation | 属于跨动作审计能力，本轮只是归属建议，未创建Jira记录 |
| User Story | ACT-004 Update Claim、ACT-054 FTO Refresh；关联ACT-031 Manage FTO Volumes、ACT-006 Edit Finance Data | 这些动作会产生事件；“查看日志”是共用能力，不能只覆盖一个ACT就声称全部修改已覆盖 [S6] |
| FR | 直接FR6、FR8.1相关FTO、FR10.1日志；关联FR6.2／6.3、FR16状态历史 | 原BRD的FR21是Task SLA，不能因为名称叫“审计”就把它误归为FR21 [S3-73] |
| UC场景 | 修改Claim、FTO刷新、Finance修改、审批状态／日期变更的日志子场景 | 当前材料没有确认独立“增强审计”UC编号；复用动作并补子场景，不编造已批准编号 |
| 页面 | P6.8 Activity / Audit Log；P13.5 Activity Log | 沿用既有页面目录 [S11]。先展示Line日志；请求日志复用同一明细模式，但必须保留实际Request身份 |
| 优先级 | 增强部分建议P1；保留现有日志是必保底线 | Finance列为Should，并明确“The current audit log functionality must remain” [S1 L11／N11] |
| 历史状态 | CR30、In backlog、No - Backlog、Wave4/5/6 TBC | 历史表状态。James Norton是来源中的人名，不自动等于当前责任人 [S2] |

## 3. 现有资料与实现：已有的保留，缺的补齐

| 来源 | 已有内容 | 本需求增量／限制 |
| --- | --- | --- |
| S1 E11／N11／P11 | 记录字段及计算变化、人员、日期时间，体现重大金额影响 | 没有定义“重大”的阈值，不能默认过滤小额或用任意百分比标红 |
| S2 CR30 | 需要找业务确认看不到哪些实际例子 | 先核对业务缺口，不能从历史抱怨推断当前所有日志都不准确 |
| S3-14 FR6 | Values或Confidence修改要说明理由并记审计 | 原因应来自真实操作，不在日志页补造 |
| S3-28 FR10.1 | 请求日志含状态、批准日期、Clearing House日期变化 | 这些记录都要保留，新增金额区不能替换原状态日志 |
| S4 Training 726–739 | GFS／FBP执行FTO Refresh，替换原FTO行、后台重新计算并产生日志 | 不能把“已开始刷新”当作“新金额已经计算成功” |
| S5 数据字典 | MCI_ACTIVITY_LOG和字段级日志已有实体、动作、人员时间、旧／新值结构 | 计算事件关联、源版本、金额单位与状态的完整存储契约未由这些字段证明 |
| S7 当前ActivityLog.tsx | 已显示Activity、Field、Old／New Value、Performed By／On、Reason；可按人员筛选及分页 | 原字段列表要保留，新增变化详情和金融对比，不应重做成只有摘要的日志 |
| S8 当前audit.ts | 对保存版本逐次比较，包含Parts、FTO、计算总额、分行结果等；金额等值格式有归一化处理 | 已有基础不等于NEO-010全量覆盖已验证；本轮没有运行当前产品的捕获／保存测试 |
| S9 当前ClaimRecord.tsx | 合并Claim与实施相关活动，并分开Approval Request Activity | 保留对象边界，不能把不同Request或多次计算拼成同一事件 |

## 4. 页面方案

### 4.1 日志列表

![Activity history：人员、时间、字段和本次金额变化](NEO-010_Page_History.png)

保留Claim的横向tabs。Activity history按事件时间显示，列表提供人员和关键字筛选；Search才应用，筛选先于分页。查看图标放在首个Actions列。当前样例6条事件包含FTO、价格、文字、Finance备注、金额字段及状态变化。

此表是增量方案，不删原日志字段；点击事件后可查看原值、新值和原因。时间区明确为UTC，仅为本次展示约定，生产时区需要确认。

### 4.2 FTO刷新：看当时的前后影响

![FTO事件：100000变125000，全年影响增加0.030000 £m](NEO-010_Page_FTO.png)

示例旧量100,000、新量125,000；保存的全年影响从120,000 GBP变150,000 GBP，Change为30,000 GBP，即0.030000 £m。期间影响从60,000变75,000 GBP，变化0.015000 £m。绑定CALC-12→CALC-13，不能拿当前最新CALC-14来覆盖这次历史差异。

本例可用固定单位差额1.20 GBP解释全年数值，但不是定义完整FTO、Runout、FX或期间分配公式。正式金额必须来自已签收计算逻辑的前后快照。

### 4.3 改价格：不重复计入上一次FTO变化

![价格事件：18.80变18.68，全年影响增加0.015000 £m](NEO-010_Page_Price.png)

示例单价20.00 GBP不变，拟议新价18.80→18.68，FTO量125,000不变。本次全年输出150,000→165,000 GBP，差额15,000 GBP；不能把上一笔FTO刷新带来的30,000再算进来。详情展示CALC-13→CALC-14、字段旧新值、理由及来源。

Change固定解释为After−Before。正负本身不是“好／坏”标签，也不代表已付款、已实施或新的批准金额。

### 4.4 已保存，但计算未完成

![Pending：保留字段变化，金额等待对应计算完成](NEO-010_Page_Pending.png)

记录已保存的价格修改和旧计算；After及Change显示“—”。等待同一次修改对应的计算结果，不能用0填补或提前标成功。正式实现还需区分失败、重试和被更新版本取代的计算，并避免乱序回执覆盖历史事件。

### 4.5 历史资料不完整

![历史缺旧快照：不能用最新金额倒推历史差额](NEO-010_Page_Legacy.png)

只有After快照时，旧金额和差额均未知。不得假设Before=0，不拿当前值回填过去。历史日志保持可见；若之后找到真实凭据，采用带来源的补充记录，是否允许补录及审批由审计政策确认。

### 4.6 系统执行与零影响

![系统触发：记录系统执行者及调度来源，不冒充Buyer操作](NEO-010_Page_System.png)

系统任务显示System及触发来源。若是某人发起后台任务，应分别保留发起人和执行服务，不能把当前查看人当操作者。单独的Zero截图展示已确认计算前后相同：这时Change才是0.000000；非计算活动则为Not applicable。

本包另含390px截图。普通业务页没有设计诊断标签；场景选择仅存在页面外部的评审条。访问受限和加载失败各有独立状态，不能混成“没有日志”。

## 5. 字段与存储对应

| 页面／业务信息 | 已有数据字典依据 | 需补核对 |
| --- | --- | --- |
| 业务对象／活动 | MCI_ACTIVITY_LOG：ENTITY_TYPE_ID、ENTITY_ID、ACTIVITY_TYPE_ID、ACTION；字段字典1925–1938行 | Claim／Request实际实体类型值、权限及相互关联 |
| 字段名称和前后值 | MCI_ACTIVITY_FIELD_LEVEL_LOG：FIELD_NAME、FIELD_LABEL、OLD_VALUE、NEW_VALUE；1912–1924行 | 类型和单位不能只靠文本猜；空字符串、null、0及删除要分开 |
| 操作人／时间 | CREATED_BY／CREATED_ON、UPDATED_BY／UPDATED_ON | 谁是业务发起者、谁是系统执行者；记录时间和业务事件时间区别；时区 |
| 同一活动关联 | ACTIVITY_LOG_ID、PARENT_ACTIVITY_LOG_ID | 不能单凭名字假设PARENT_ACTIVITY_LOG_ID一定表示计算链；须核实实际语义 |
| 计算前后金额 | 旧／新值字段可以承载文字；当前应用保存计算结果与版本 | 需要明确事件→输入版本→结果版本的关系，以及Annual／Calendarised、币种、FY、单位和精度 |
| 状态与原因 | ACTION、DESCRIPTION及当前应用Reason | 原因字典字段映射及计算Pending／Failed／Complete状态是否已有专用存储待确认 |
| 历史归档 | MCI_ACTIVITY_LOG_ARCH、MCI_ACTIVITY_FIELD_LEVEL_LOG_ARCH | 保留期限、查询权限、补录、归档后版本关联；IS_ACTIVE不等于允许用户删除审计 |

字典是已整理的结构材料，并非当前数据库DDL或真实接口证据。详细行号及原始单元格见SOURCE_EVIDENCE.json。本轮不擅自建立数据库字段或把金额影响塞进某个不明语义字段。

## 6. 开发影响与依赖

| 层 | 建议修改 | 验收重点 |
| --- | --- | --- |
| UXUI | 保留现有日志；增加按活动查看变化和金额快照 | 数据可读、单位明确、空态／错误／权限区别，旧日志不丢失 |
| 前后端应用 | 业务保存时记录实际字段、操作者、时间、原因及事件身份 | 不以页面当前用户替代实际actor；失败保存不写“成功修改” |
| 计算服务 | 关联本次输入与原／新结果；异步完成后追加关联结果 | 不重写原始变化，不把新一轮计算回填到旧事件 |
| 数据库／审计 | 保持记录与字段级日志，核对计算版本关联模型 | 同一事件重试不重复，撤销／更正保留历史；原值含0和空值 |
| BPM／系统任务 | 为自动导入、审批、任务变化记录来源及真实结果 | System与人分开；父／子活动按实际语义关联 |
| 外部接口 | 优先复用已有输入；如缺source version则扩展元数据 | 未证明需要新SAP／WIPS业务接口，不把审计增强扩大为交易改造 |
| 权限／运营 | 服务端限制历史可见范围、敏感字段和归档查询 | 不能通过日志绕过FR6.3的Reserve权限；页面隐藏不足以证明安全 |

只记录事件标题成本最低，但不解决业务看不清金额的问题；每次打开时用最新数据重算容易改写历史。建议保留当时快照并关联本次计算，代价是版本存储和异步关联要补齐。这是本轮推荐方案，不是Finance已批准的计算政策。

## 7. 业务问题：讲人话

| 编号 | 需要确认 | 例子／影响 | 建议确认方 |
| --- | --- | --- | --- |
| Q01 | “所有变化”和“关键字段”分别怎么定义？ | 描述、附件、FTO、价格、Reserve、系统回执都要记录吗？先给出必保留字段／事件清单，不能只凭开发猜 | Business／Corporate Audit |
| Q02 | 金额影响具体展示哪些口径？ | Annual、Calendarised、Reserve、Buyer Performance并不相同。FTO变了，应看哪几项、哪个FY和币种？ | Finance／FBP |
| Q03 | “重大影响”有没有金额或百分比阈值？ | +£100和+£1m是否不同提示？没有签收阈值前只如实列值，不自动过滤 | Finance／Audit |
| Q04 | 多个输入一起变时，要解释到什么程度？ | 同时改价格和FTO，能可靠展示总差异；要拆出各自贡献，需要单独定义归因方法 | Finance／计算负责人 |
| Q05 | 计算失败或被下一次修改取代，日志显示什么？ | 10:00改价未完成，10:01再改价；10:00的结果晚回来，不能挂到10:01记录 | Product Owner／技术 |
| Q06 | 历史没有旧快照，接受标Unavailable吗？ | 只有当前£150k，不能倒推出上周增加多少。是否补录，凭什么文件、由谁批准？ | Audit／数据迁移负责人 |
| Q07 | 哪些用户能看哪些历史字段？ | Buyer不能看Reserve敏感内容，也不应该从Activity Log看到其旧新值；人员名称和离职用户如何显示？ | Security／Finance |
| Q08 | 时间、留存及更正规则是什么？ | 用UTC还是用户时区；更正错日志是否只能追加；保留多久、归档能否查询／导出？ | Audit／运营／数据负责人 |

## 8. 验证范围与退出条件

本轮 **60 项本地交互／布局检查通过**。本地检查验证合成事件的筛选／分页、事件对应关系、独立预期金额差、空值与0、Pending、历史缺口、系统actor、访问受限及响应式。完整实际结果在PAGE_VISUAL_CHECK.json。

| 层 | 当前结论 |
| --- | --- |
| 独立页面交互／布局 | 以本包实际检查记录为准 |
| 真实保存、失败事务及持久化回读 | NOT RUN |
| 完整事件覆盖／跨对象关联／异步乱序 | NOT RUN |
| 服务端权限、保留、防篡改及归档 | NOT RUN |
| Finance公式、精度及全量对账 | NOT RUN |
| 产品回归／生产部署 | NOT RUN；prototype未修改 |

设计退出：字段、事件、金额口径和责任边界明确，缺口可逐项确认。开发退出：各实际动作都可在同一业务记录上保存并回读正确日志；对应计算版本和真实金额一致；异常、重复、乱序、权限、历史与归档场景通过。不能用本包页面的fixture检查替代这些验收。

## 9. Reference

| ID | 文件／定位 | 用途 |
| --- | --- | --- |
| S1 | NEO Business Requirements (added China requirements) 1.xlsx；RTM for Requested Changes!A11:R11 | NEO-010原文、Should和保留现有日志要求 |
| S2 | 同文件；P1 CR clean!A28:Y28 | CR30历史原因、Backlog、业务例子待确认 |
| S3-14／17 | Material Cost & Inventory - BRD V3.1.docx；表6行14 FR6／行17 FR6.3 | 修改理由及Reserve访问约束 |
| S3-28／41／73 | 同BRD；表6行28 FR10.1、行41 FR16、行73 FR21 | 原有日志、状态与SLA边界 |
| S4 | NEO User Training.docx；正文段落726–739 | FTO Refresh角色、重新计算和产生日志 |
| S5 | NEO_数据字典.xlsx；字段字典1912–1938、1956–1980 | 活动／字段日志及归档结构 |
| S6 | outputs/neo-jira-stories-20261111/v3/story_data.json；ACT-004／006／031／054 | ACT和Epic现有本地映射 |
| S7 | app/src/views/Approvals/ActivityLog.tsx | 当前字段列表、人员筛选与分页 |
| S8 | app/src/domain/claims/audit.ts | 逐保存版本字段与计算值的差异提取 |
| S9 | app/src/views/Claim/sections/ClaimRecord.tsx，活动汇总与activity-log部分 | Claim及Request历史关联 |
| S10 | app/src/theme/index.ts | NEO主题快照 |
| S11 | outputs/NEO_143_Page_Screenshots_20261104/scope.json | P6.8与P13.5既有页面定位 |

源码均来自NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1，只读核验，不声称已测试全部产品。Word按1-based表／行／正文段落定位，不冒充打印页码。完整路径、原文和SHA保存在SOURCE_EVIDENCE.json。
