# NEO-010 · Before / After process

Priority: Should (Procurement: —; Finance: Should)

ACT-004 / ACT-006 / ACT-031 / ACT-054 · FR6 / FR8.1 / FR10.1 / FR16

## 完整记录字段与金额变化

沿用 Activity Log，补齐变化链和前后计算版本，不另造一套审批流程。

### Before · 现有路径

1. **有权用户／系统 · 修改字段或重算** — 当前代码已有字段变化、实际操作人及部分计算差异记录。
2. **用户 · 在 Activity Log 查询** — 按现有筛选和分页查看记录；需求要求补齐覆盖及金额影响，不能描述为原来完全没有日志。

### After · 建议路径

1. **有权用户／系统 · 提交一次有版本的变化** — 记录实际操作人、发起人、时间、来源与原因；自动任务不冒用 Buyer 身份。
2. **应用服务 · 绑定前后字段与计算结果** — 同一事件保留旧版本与新版本。异步重算未完成时金额影响保持 Pending。
3. **用户 · 展开事件，查看金额影响** — 用同口径 After − Before 展示金额变化及输入版本；缺旧值显示不可比较。
4. **审计／Finance · 按事件追溯** — 保留每次变化的独立依据，不用最新总额倒填历史，也不重复累计同一变化。

### 例子

示例：FTO 更新使全年影响从 £120,000 变成 £150,000，日志记录 +£30,000。随后改价变成 £165,000，第二条记录 +£15,000，而非再次记 +£45,000。

### 保留控制

- 日志只读；不替代审批记录、财务对账或权限校验。
- 真正没有变化可显示 0；结果未算完或旧值缺失不可显示 0。

### 正式实施前补齐

- 确认需覆盖的事件和留存周期；计算服务提供可比较的前后版本及币种／期间口径。

## Record field changes and financial impact

Keep Activity Log and complete the change trail and calculation versions; do not add another approval flow.

### Before · Existing path

1. **Authorised user / System · Change a field or recalculate** — Current code already records field changes, actors and some calculation differences.
2. **User · Review Activity Log** — Use existing filters and paging. The requirement extends completeness and financial impact, rather than introducing a previously absent log.

### After · Proposed path

1. **Authorised user / System · Commit a versioned change** — Record the actor, initiator, time, source and reason; an automated task must not impersonate the Buyer.
2. **Application service · Bind before / after fields and calculation results** — Keep the old and new versions for the same event. Financial impact stays Pending until asynchronous recalculation completes.
3. **User · Open the event and review its impact** — Display After minus Before on the same basis with input versions; missing old values remain non-comparable.
4. **Audit / Finance · Trace the individual events** — Retain the evidence for each event; never backfill history with current totals or count the same change twice.

### Example

Example: an FTO update changes annual impact from £120,000 to £150,000, so the event shows +£30,000. A later price edit raises it to £165,000; that event shows +£15,000, not +£45,000.

### Controls retained

- The log is read-only and does not replace approval evidence, reconciliation or access checks.
- Zero is valid for a confirmed unchanged amount, not for pending or missing results.

### Production dependencies

- Confirm event coverage and retention; the calculation service must supply comparable versions, currencies and periods.

## Sources

- **R-1113** NEO Business Requirements (added China requirements) 2(RTM for Requested Changes)_1113 1400 version.xlsx · NEO Business Requirements (adde!E11,N11,P11,Q11; priorities K11:L11
- **S1** NEO Business Requirements (added China requirements) 1.xlsx · RTM for Requested Changes!A11:Y11
- **S3-14** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 14
- **S3-28** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 28
- **S3-41** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 41
- **S4** NEO User Training.docx · Body paragraphs 726-739 (1-based)
- **S7** ActivityLog.tsx · Numbered source lines
- **S8** audit.ts · Numbered source lines
- **S2** NEO Business Requirements (added China requirements) 1.xlsx · P1 CR clean!A28:Y28

Before: frozen prototype `3ff8bc0b158ba08f2302e7404bb6185a553088c78614051451e6b5137a26802e`. Historical problems are labelled separately. After is a proposal; numerical examples are illustrative. Production execution: NOT RUN.
