# NEO-006 · 下一财年 AutoPAM 预测

独立页面方案，沿用 NEO design system。未修改 NEO prototype；没有计算真实预测、发送 GCP/EDW 数据或生成正式报表。页面中的文件、金额和版本都是合成设计例子。

## 1. 分类、Epic、User Story、FR 与优先级

| 项目 | 结论 | Source / Reference |
|---|---|---|
| 原需求 | 新增 AutoPAM CY+1 文件，按每条 ID 展示未来财年的财务影响。 | S1 E7/P7 |
| 原分类 | New functionality；不属于旧功能原样迁移。 | S1 D7/G7 |
| 主要改动类型 | APP：新增预测期间、规则、输入版本、结果及文件查询；包含前端和后端，不能定为 UX/UI only。 | 分析建议，基于 S1/S3 |
| 集成分类 | 条件性 INT：若 ExWorks 生成结果，需确认 NEO 是否消费、消费什么；若 NEO 计算，需取得完整次年输入。现有接口复用尚未证明。 | S1/S2/S4 |
| 新架构 | 未确认需要新平台；先定计算和数据归属，再选扩展现有传输或新增契约。 | 分析建议 |
| Epic | CNP-235 — ACT-050 的现有 Epic 关联。ExWorks 交付归属不因这一映射而转入 NEO。 | S5 |
| 主 User Story | ACT-050 Auto PAM Report；既有 Story 只覆盖查看已有报表文件，需补次年规则、生成和来源验收。 | S5 |
| 主 FR | FR18 Forecast Reporting Calculations and Output。 | S3；S2 W18 |
| UC | 关联 UC-24 的文件回读；新增跨财年、缺输入、规则版本和重复生成情景。关联沿用已有追溯表，不伪造正式新 UC 编号。 | S6 |
| 页面 | P6.7 Auto PAM Report：保留现有 File / Created On，拟增加期间与报表层级筛选和同页预览弹窗；暂不新增一级页面或编造新页面号。 | S5/S6/S7 + 设计建议 |
| 原优先级 | Finance Could；Procurement 未填；R7 为 N。历史 CR24 为 Low / Pause / Backlog。 | S1 L7/K7/R7；S2 H18/N18/T18 |
| 建议优先级 | P2，先做范围和数据可行性确认，再排开发。R7=N 不代表已批准本项目范围或已解决数据依赖。 | 分析建议 |
| 关联需求 | NEO-001 是现有 AutoPAM 规则修正；NEO-002 是未来输入来源问题。本条扩展至下一财年，不能由前两条完成自动推定实现。 | S1 第2、3、7行 |

## 2. 用人话理解：先分清“换财年”与“提前看到明年”

现在看到的是本财年剩余月份的影响。这条希望今天就能看见同一批 Claim 对下一财年的影响。例如 2026年11月查看 2027/28 财年，而不是等到 2027年4月再把当前年度文件改名。

| 证据 | 它说了什么 | 对本方案的影响 |
|---|---|---|
| Finance 新要求 | 需要一套逻辑，为每条 ID 生成未来财年的财务影响。 | 需要次年规则和数据；不能复制本年结果或按比例推算。 |
| 原需求及 CR24 历史说明 | 没有可行数据集，讨论由 ExWorks 另项目承接，称已与 Dan Yielder 确认；历史为暂停/Backlog。 | 这是范围冲突，必须重新确认当前 Owner、交付方与 NEO 边界；历史文字不是本轮签署。 |
| 原 BRD FR18 | 每天向 GCP 提供报告，结合 Line 和 FTO，记录触发规则，提供 Summary 和 PAM Full。 | 可作为报表基础，但没有证明次财年的输入覆盖和完整公式已具备。 |
| 接口 Id18 E2SC | 登记为从今天到未来12个月的动态日期范围。 | 滚动12个月不一定覆盖完整下一财年，不能只因“未来数据”就认为满足。 |

**建议方案：**先由 Finance + ExWorks 确认谁计算、谁维护规则。若 ExWorks 负责，NEO 最多按已批准契约消费或展示结果；若明确由 NEO 负责，再扩展 FR18 计算和调度。当前独立页面仅示意“NEO 保留查询入口”的一种选择，不预先替业务作范围决定。

## 3. 页面与交互

### 3.1 默认：下一财年输入未具备

选择 Forecast period 和 Report level，再点 Apply。默认示意数据未到齐，结果为空并明确说明原因；不是0，不显示伪造的成功文件。财年起止日期采用设计例子，需按 Q2 确认。

![下一财年输入未到齐](NEO-006_Page_Missing.png)

### 3.2 文件已就绪：条件性目标方案

已收到并验证输出时，沿用 File 和 Created On。左侧查看图标打开本文件的预览，不在列表直接修改公式或 Claim。过滤变化后需要 Apply，旧结果不会混在新期间中。

![下一财年文件已就绪](NEO-006_Page_Available.png)

### 3.3 按 Line 查看影响

同页弹窗显示目标财年、生成时间、币种及每条 Line 的预测影响。Summary 展示结果；PAM Full 示例增加规则和输入快照追溯列，最终字段须核对 Appendix M 和实际模板。例子 GBP12,000 与 GBP−8,000 合计 GBP4,000 仅说明显示与合计，不是已验证预测公式。

![Summary 预览](NEO-006_Page_Preview.png)

![PAM Full 预览](NEO-006_Page_Full.png)

最终 Download file 禁用：本包没有正式文件生成、权限服务或可信来源输出，不能用演示表格冒充实际报表。

### 3.4 当前年度继续可查

下一财年缺数据不应清空当前财年的已有文件。页面提供当前财年对照，保持期间明确；当前与次年示例金额相同也不表示存在结转规则。

![当前财年文件查询](NEO-006_Page_Current.png)

### 3.5 读取失败与无文件分开

读取失败保留已选期间，提供 Retry；没有生成匹配文件则显示无文件。二者都不能代表金额为0或传输完成。另设无权限场景，不展示结果。

![读取失败与重试](NEO-006_Page_Failed.png)

## 4. Solution、Change 和 Impact

| 层面 | Change | Impact / 必须保留的边界 |
|---|---|---|
| UX/UI | P6.7 增加期间、报表层级、文件预览及缺数/失败状态。 | 沿用当前 NEO theme、字体、Ant Design 表格/Select/Modal/Button、32/24/16px边距；不恢复 Before 样式，不添加规则编辑页。 |
| 应用后端 | 按授权范围和期间获取可用输出；如承担计算则需新财年规则、输入匹配、版本和完整性校验。 | 前端不能决定使用旧输入；是否计算与是否展示要分开。 |
| 数据 | 区分目标FY、来源期间、源快照、规则版本、生成时间、文件标识、币种、Line关联。 | 这些是逻辑设计项，不宣称字典中已有同名列；需schema和契约逐项确认。 |
| 计算 | 定义每条Line在下一财年的适用日期、POA/LSP处理、价格/量/汇率、正负号、精度和跨年规则。 | 不将本年剩余月份外推、不把缺量当0、不把已支付或一次性LSP重复带入次年。具体排除规则仍待签认。 |
| 流程/调度 | 复用既有日报调度作为候选，按确认方案增生成、校验、失败重跑及发布步骤。 | 这是批处理/报表编排，不新增 DoA 或审批链；重跑同期间不能造成重复累计或悄悄覆盖历史文件。 |
| 集成 | 先确认 ExWorks→NEO 的文件/接口是否存在，或 NEO 计算需要的新输入；输出再核对 GCP/EDW方向。 | 现有 Appian→EDW 的Qlik复制不能直接证明 ExWorks→NEO 可接入。 |
| 现有功能 | 保持当前FY的文件查询、既有访问规则和可追踪的生成记录。 | 本条失败不应破坏当前FY；数据复制成功不等于Finance金额正确。 |
| 性能 | 按确认数据规模批处理，查询已生成结果；设计上不因打开页面立即全量计算。 | 实际批次时长、并发、重跑窗口及完成SLA需要实测，不套用样例数字。 |

## 5. 系统、接口与数据依赖

| 已有材料 | 能确认什么 | 不能据此确认什么 |
|---|---|---|
| S4 Id25 Qlik Replication，CSV逻辑记录29 | Appian MariaDB 的3张 AutoPAM staging 表复制到EDW对应视图。 | 不是 ExWorks→NEO 输入；没有证明接收次年结果或完整输出契约。 |
| S4 Id18 MFT E2SC，CSV逻辑记录24 | GCP Data Lake→Appian，经BODS/MFT获取CSV ZIP；有滚动未来12个月日期描述。 | 不保证下一完整财年、所有零件/供应商/地点覆盖，也不保证当前接口仍适用。 |
| S3 FR18 | 输入组合为Line与FTO；公式Appendix L、输出Appendix M、变更Appendix N。 | 本轮没有获得这些附录对应的已签次年规则与输出样本，不能称公式完整。 |
| S8 Scheduler，Sheet 1第19行 | Auto Pam Scheduler登记每日17:00，典型40分钟；有switch/timer常量。 | 不是本条次年生成SLA，也没有时区、输入就绪门槛或CY+1调度合同。 |
| S8 I19 “3 Days Delete” | 调度表有删除描述。 | 未说明删流程实例、临时记录还是业务文件；不能直接替换Training七天文件保留。 |
| S9 Training ¶1927/1929 | 除Buyer外用户组管理；发往GCP后保存文件副本七天再移除/归档。 | 要核对当前组权限与实际保留设计；不擅自扩大到所有Buyer或执行删除。 |

缺少的关键材料：当前项目归属确认、下一财年输入样本与覆盖清单、Finance golden cases、公式/规则版本、Summary/PAM Full样本、ExWorks接口或文件契约、传输回执和失败/重跑规则、数据保留对象说明。不存在材料时标缺失，不按接口名补写payload。

## 6. 业务问题：人话＋例子

| 编号 | 要确认什么 | 例子 / 为什么影响方案 | 建议谁确认 |
|---|---|---|---|
| Q1 | 下一财年的结果最终谁负责算？NEO只给入口，还是连计算也负责？ | 原文说ExWorks另项目，Finance又要求加入AutoPAM。如果ExWorks已有结果，应避免两边重复算出不同金额。 | Finance Owner + ExWorks Owner + NEO Owner；原文提Dan Yielder，当前责任人待确认 |
| Q2 | CY+1 是下个自然年，还是下个财年？是哪12个月？ | 2026年11月要看2027年1–12月，还是2027年4月–2028年3月？原文CY+1/FY+1混用。 | Finance |
| Q3 | 哪些输入真的覆盖完整下一财年？缺几个月怎么办？ | 今天往后12个月可能只有到2027年11月，无法覆盖到2028年3月。应显示缺数，还是有签认补数规则？ | ExWorks / FTO / E2SC数据Owner + Finance |
| Q4 | 哪些Claim带入次年，按什么规则算？ | 今年一次性支付的LSP是否还影响次年？POA明年才生效，应计哪些月份？不能默认沿用本年金额。 | Finance + Buyer业务代表 |
| Q5 | 次年结果沿用哪个价格、量、汇率和规则版本？ | 11月与12月输入改变时，是生成新的预测版本，还是重写上次结果？哪个用于正式报告？ | Finance + 计算服务Owner |
| Q6 | 文件从谁那里来，NEO怎样知道它已完整、可用？ | 文件名写了FY27但里面有FY26数据怎么办？需要期间、行数、币种、版本和控制总额核对，不只判断上传成功。 | ExWorks / 数据平台 / NEO接口Owner |
| Q7 | Summary / PAM Full具体列什么，多久更新、保留多久？ | 是每天与当前FY一起生成，还是月度生成？“3 Days Delete”删什么，七天规则是否仍适用？ | Finance + 运维 / 数据保留Owner |

## 7. 增量验收与退出条件

| 验收主题 | 必须验证的结果 | 产品当前状态 |
|---|---|---|
| 年度/期间 | 按签认FY定义选择，跨年边界不混淆本年、次年或重复累计。 | NOT RUN |
| 金额与规则 | 用Finance独立golden cases验证POA/LSP、正负号、精度、汇率、月份；逐Line、汇总和Full一致。 | NOT RUN |
| 缺输入 | 缺字段、缺月份、缺组合、重复或过期输入按确认规则处理，不静默补0。 | NOT RUN |
| 版本/重跑 | 同输入重跑不重复，修订保留来源和规则版本；未知传输先核查原输出。 | NOT RUN |
| 权限 | 列表、预览、下载和直接请求都执行同一授权，不泄露跨团队/保密Line。 | NOT RUN |
| 接口/导出 | 实际传输、回执、落库及打开导出文件逐项对账；不能只看按钮。 | NOT RUN |
| 兼容 | 当前财年报表、NEO-001既有规则修正及已确认保留行为不受损。 | NOT RUN |
| UX/UI | 默认缺输入、Apply筛选、Summary/Full预览、取消、错误重试、无权限、窄屏、键盘。 | 仅独立设计检查见 PAGE_VISUAL_CHECK.json；产品 NOT RUN |

开发进入条件：先确认Q1/Q2、输入可行性及Finance规则/样例，才能定接口方案和估算。退出条件：已批准范围的实际版本完成以上适用项，保留同一来源期间、规则、输出及Finance签认。当前不满足产品退出条件。实际产品测试仍维护原有FR1–21 QA总表，本包不是新的业务验收台账。

## 8. Source / Reference

- S1 `8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx`，`RTM for Requested Changes!A7:R7`，特别D7/E7/F7/G7/L7/P7/R7；读取原文，未改原表。
- S2 同文件，`P1 CR clean!A18:Y18`，CR24；D18项目归属/缺数据，G18年初文件切换，H18/N18/T18优先级与历史状态，W18对应FR18。
- S3 `6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx`，表6第51行FR18，Appendix L/M/N为原文指向；不声称本轮已取得完整签认附件。
- S4 `6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv`，按CSV解析的逻辑记录24/Id18与29/Id25，不能用多行单元格的物理行号混代；Id25登记更新时间24 Oct 2025，Id18为12 May 2025。
- S5 `outputs/neo-jira-stories-20261111/v3/story_data.json`，act=50/name=Auto PAM Report，row中Epic CNP-235；本地Story草案，不证明Jira已更新。
- S6 `outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/analysis.json`，trace中NEO-006→ACT-050→FR18→UC-24关联→P6.7，原追溯Action行51；属于派生映射。
- S7 `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Reporting/AutoPam.tsx` 与 `auto-pam-data.ts`，已有File/Created On、权限入口及历史Training样例；只读源码检查，不是现网功能证据。
- S8 `6.技术方案/2 - Tech NEO/Scheduler Processes - 2026-11-09_0944.xlsx`，`Sheet 1!A19:O19`，Auto Pam Scheduler；登记更新时间10 Apr 2025。
- S9 `6.技术方案/2 - Tech NEO/NEO User Training.docx`，正文段落1925–1938，权限¶1927、文件/GCP/保留¶1929；段落序号为python-docx自1计数，不是页码。
- S10 `NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/theme/index.ts`、共享layout/styles及`NEO_FULL_OFFLINE/skills/jlr-frontend-ux/references/NEO_UXUI_PRINCIPLES.md`。当前theme快照SHA见design-source/SOURCE_MANIFEST.json；本页使用真实Ant Design组件。

## 9. 交付物与边界

独立交互HTML、汇总HTML、可编辑MD、业务问题清单、PNG截图、来源摘录和SHA、独立设计检查及ZIP。页面英文，评审中文。不新增产品页面、不部署、不更新Jira、不运行真实财务规则或接口、不修改prototype或共享业务验收结果。
