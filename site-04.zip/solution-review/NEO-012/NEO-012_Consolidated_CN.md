# NEO-012 · Reserve 文件中的已实施 LSP 与发票状态区分

<!-- FLOW-REVIEW-20261116 -->
## 16 Nov 2026 · 流程评审补充

[中英文 Before / After 流程](NEO-012_Before_After_Flow.html) · [流程说明 MD](NEO-012_Before_After_Flow_CN_EN.md)

在现有 Reserve 列表和导出中增加可核对的分组，保留原财务状态与总额。

本轮为流程说明补充；原交互页面、问题及历史证据保留。正式实施前需补齐：SAP／AP 提供按 NEO Line／PO 关联的发票状态、日期及部分开票规则；现有 PO 查询登记不证明这些字段已具备。
<!-- /FLOW-REVIEW-20261116 -->

## 1. 这条需求要解决什么

Finance 下载 Reserve 文件时，要看得出：哪些 Lump Sum 已实施，但供应商发票还没有收到；哪些属于其他 accruals。不能再靠人工逐条拼 PO、实施状态和发票资料。[S1 E13、P13]

这里的 NEO-012 指 **RTM for Requested Changes 第13行**，不是同一个Excel里 RTM - Archive 第15行的 Parent drill-down，也不是 NEO RTM 第16行的建单字段。这三个编号重名，必须带Sheet引用。[S1-ID]

CR20提到这项报表改动曾实施不正确、需要回退，但各列状态并不一致：S1说部分交付后回退，S2同时写“In Dev / Test”“Not deployed”“Needs refinement”。这是历史记录，不能据此确认现在生产已修复或已部署。应索取回退后的现网文件和期望样例。[S1 E13；S2 C32、N32、P32、T32]

## 2. 分类、优先级和关联

| 项目 | 评估 | Reference／边界 |
| --- | --- | --- |
| 原始分类 | Finance → Finance Reserves；Existing functionality - Update/correct logic | S1 B13:D13 |
| 主要改动类型 | Application内部前后端：报表读取、分组、筛选、导出和期间快照；附带UXUI | 不只是加一列文字，必须有可确认的发票状态来源 |
| UXUI only？ | 否；除非现网数据和分类已正确，缺口确实只剩显示，才可缩小为展示修正 | 当前证据尚不能支持这个前提 |
| Integration needed | 条件性需要：先查已有源能否提供与Line／PO匹配的发票状态及截止时点 | SAP／Apigee接口或SAP/AP维护的现行数据文件；最终owner及渠道待确认 |
| 现有接口能否复用 | MCI_getPurchaseOrderDetails可支持PO批准／实施证据；登记表没有给发票字段payload，不能确认它能供发票状态 | S6；PO批准不等于发票收到 |
| 新架构 | 暂无证据要求新平台或中间件；先评估扩展现有读取／文件渠道 | 如确需新接口，独立评审契约、权限、调度、回补和版本 |
| Priority | 原始Must；建议P0确认原版样例和发票证据来源，P1实施报表及对账 | S1 L13；S2为历史优先信息，不替代本轮排期 |
| Epic | CNP-235 Finance and continuity | S8，本地Story映射；未写入Jira |
| User Story | 主ACT-029 Generate Reserve、ACT-039 Actual Reserves - Customer Filters；关联ACT-052 Team Level View、ACT-047 Data Checks | 本需求是既有Reserve查看／导出子场景，不新造“已批准UC编号” |
| FR | 主FR17、FR17.1、FR17.5；关联FR17.3／17.6／17.7，实施证据关联FR6.2／FR16 | Journal FR17.8只做兼容性核查，不自动扩成过账规则变更 |
| 既有页面 | P16月度Reserve入口 → P16.1月度明细／Claims；关联P16.2 Teams、P16.3生成，以目录原名为准 | S13；本包是月度明细与弹窗方案，不新增一级入口 |
| 独立交付边界 | 页面使用合成数据；没有改prototype、真实业务数据、共享QA或生产 | 本包测试只验证设计交互，不更新产品验收结果 |

## 3. 已有证据和真正缺口

| 项目 | 已有资料能说明什么 | 不能据此认定什么 |
| --- | --- | --- |
| Reserve明细与下载 | BRD FR17.5已要求Workflow Status、交易类型、Accrual／Provision等分类、当期／前期／Movement及Excel下载，输入应在生成时快照 | 新增报表分组不应替换这些已有列 |
| 原始财务分类 | FR17.1内嵌图第16条显示Finance Status = Implemented → Accrual；前面有Prepayment特殊规则 | 没有可见发票收到条件；部分下拉内容被截断，不能还原成完整可执行政策 |
| Implemented含义 | FR6.2／FR16描述实施状态及自动／人工路径；FR17.3另有System Reserve Status | Workflow Status、Finance Status、Reserve Finance Status、System Reserve Status不是同一个字段 |
| SAP批准回读 | MCI_getPurchaseOrderDetails通过Apigee GET读取PO详情；Scheduler Id5每天00:00检查Data Posted的PO批准并标Complete | Complete和Implemented具体映射仍需确认；不能把批准回读当作发票回读；时区未提供 |
| PO Payments | 培训PDF第1–4页说明SAP报表文件上传、Ingested状态、按Purchasing Document关联NEO ID并在Reserve查付款行 | 没有付款记录不等于没有发票；上传失败／未覆盖全部期间时也不能判“未收到” |
| 当前本地页面 | TrainingReserveClaims.tsx已有分类、实施状态、金额、筛选及下载；MonthlyList已有Accrual汇总 | 本次查看的列定义没有显式Invoice Status at Cutoff和新的Accrual Reporting Group；不等于审计了全应用所有入口 |
| 数据字典 | 已有Reserve分类、状态、金额、PO关联和手工发票编号 | 手工发票号不等于通用供应商发票状态；缺少已确认的一对多／部分发票关联契约 |

来源对应S3-16／41／42／43／45／47，S6、S7、S9–S11、S14。FR17.1图保存在source-images，不能作为完整规则表直接编码。

## 4. 页面方案与操作

采用当前NEO主题、JLR Emeric和Ant Design。报表分组作为独立显示维度，保留原Reserve Finance Status；不通过新标签自动改金额、科目、支付或业务流程状态。主界面不放来源诊断说明，References及评审文档承载这些信息。

### 4.1 月度Reserve：先看整体，再筛选Line

Ben Taylor／FBP Officer打开October 2026的Reserve Claims。上方显示期间、快照版本和截止时点；四组汇总覆盖本样例的全部accrual Lines。分组是本轮建议，具体名称和是否拆成四组由Finance确认。

![月度Reserve与Accrual分组](NEO-012_Page_Overview.png)

建议判断顺序：先沿用已核准规则判断记录是否属于Accrual；在这个人口里，对明确未实施的记录单列；对于已实施LSP，只有明确的截止时点发票证据才分到“未收到”或其他；缺失／失败／不完整证据放入待确认。其他已确认记录归到Other accruals。未知实施状态、部分发票、冲销或矛盾证据也需要独立核对，不能自动套入“未实施”或“其他”。这些异常尚待业务样例，不宣称本页全部模拟完成。

### 4.2 筛选“已实施且未收发票”

选择Accrual reporting group → Implemented LSP · invoice not received → Apply filters。下拉选择本身不提交筛选。MCI-00057是样例中唯一匹配行。Reset恢复全部；搜索支持Line ID、Description或PO。空结果禁用下载。

![已实施但未收发票的筛选结果](NEO-012_Page_Filtered.png)

筛选后的金额只对应明细结果；顶部All accruals保留完整样例人口的金额，两者明确区分。正式实现必须先对有权限的完整结果集筛选，再分页和导出。

### 4.3 核对证据

点行前的眼睛图标，查看截止时点状态、PO关联和证据。示例中的“Finance-confirmed”是假设输入，**不是已批准的人工确认功能**；本包没有新增人工改单入口。需要业务确认是否允许Finance确认，以及角色、理由和证据要求。

![目标LSP的证据明细](NEO-012_Page_Detail.png)

实施并不等于已经收到发票，也不等于已付清。收到发票后Reserve金额是否减少，应由独立的已确认金额规则和付款／发票对账决定。本方案没有将收到发票的行自动清零。

### 4.4 下载要与屏幕筛选一致

点Download Reserve file → 查看期间、版本、行数、当期／前期／Movement → Download Excel。实际生成.xlsx，包含筛选行及Export Scope。取消不下载，失败保留筛选。本包已读取实际生成文件核对内容，非只检查按钮。

![下载范围确认](NEO-012_Page_Export.png)

文件示例只有本次变化所需的15列，**不是替代现网完整Reserve模板**。正式开发必须保留现网原列、顺序、类型和下游依赖，新增列位置须经Finance确认。包内两个导出文件分别为目标筛选和未确认筛选；都明确标为Synthetic，不能作为会计golden case。

### 4.5 数据缺失时不下结论

MCI-00060显示Unknown。切到Invoice data unavailable评审场景后，所有已实施LSP的发票状态都为Unknown，目标“未收到”分组为空，而原有金额保持不变。

![缺少发票证据](NEO-012_Page_Unknown.png)

### 4.6 历史快照与后来收到的发票分开

Final snapshot comparison场景保留10月31日截止状态。MCI-00057的11月4日发票证据单独显示，不能静默改写10月Final。更正／重发历史报表、后续期间何时采用新证据仍需Finance确认。

![历史快照与后续发票证据](NEO-012_Page_History.png)

评审场景之间切换会重置本地状态；场景切换不是业务状态流转。Buyer权限场景不显示Reserve内容和下载；这只是本地界面限制，正式服务端鉴权仍须验证。

## 5. 字段、系统与接口映射

| 页面／输出字段 | 已有字段或来源 | Gap／需要补齐 |
| --- | --- | --- |
| Line、期间 | MCI_RESERVE_RISK_OPPORTUNITY.RISK_OPPORTUNITY_ID、RESERVE_ID，第1386–1387行；报表LINE_ID第2591行 | 按同一期间及快照关联；不能仅按供应商汇总匹配 |
| Workflow／Finance Status | 报表WORKFLOW_STATUS、FINANCE_STATUS，第2604–2605行；ACTUAL_IMPLEMENTATION_DATE第2646行 | 具体状态枚举、Complete与Implemented的映射和时点待确认 |
| Reserve Finance Status | RESERVE_FINANCE_STATUS_ID第1389行，参考表第426–434行，报表第2607行 | 复用既有会计分类；本次Reporting Group建议独立，不覆盖此字段 |
| System Reserve Status | 报表SYSTEM_RESERVE_STATUS第2615行；BRD FR17.3 | 不用此状态单独判断发票是否收到 |
| 当期／前期／Movement | 主表第1394–1396行；报表第2617–2619行 | 保留原公式、精度和符号，拆组前后总额必须对上 |
| 交易类型／PO | 报表TRANSACTION_TYPE第2612行，PURCHASING_DOCUMENT第2642行；PO Payments PDF第3–4页 | 公司、财年、PO行及Line匹配粒度需契约确认，不能保证一个PO只对应一个Line |
| Invoice Status at Cutoff | 本次建议新增的报表字段 | 本字典和所查接口登记中未找到足以确认的通用存储／payload映射。Unknown不是No |
| Invoice Reference／Evidence | MANUAL_INVOICE_NUMBER第723行仅为已有手工字段；报表DOCUMENT_NUMBER第2641行语义需确认 | 不自动等同供应商发票号；一对多、部分、取消和贷项规则待提供 |
| Accrual Reporting Group | 本次建议派生字段 | 明确输入、条件、优先级及版本；标签不是新的会计状态 |
| 截止时点／快照／源版本 | FR17.5已要求输入快照；具体新增证据元数据待设计 | 页面中的时区、日期、版本均为合成例子，不是现网调度或签收政策 |

S5保存全列及逐行定位。实现建议链路：既有Reserve快照 + 已确认实施证据 + 已匹配的发票证据 → 独立报表分组 → 页面／Excel同一读取模型 → 总额对账。不要把PO批准接口、PO Payments文件和发票状态混为一条已成立的接口链。

## 6. Change与Impact

| 层 | 修改建议 | 影响与验证重点 |
| --- | --- | --- |
| 页面 | 在月度明细增加报表分组、发票状态与证据查看，保留原分类和金额 | 桌面／窄屏、原筛选、权限、未知数据、下载范围 |
| 后端／读取模型 | 同一授权人口下生成分类、汇总及导出，记录截止及源版本 | 不能第一页计算汇总、全部数据导出却只校验屏幕权限 |
| 数据关系 | 明确Line → PO／PO行 → 发票／调整记录，多条输入避免重复计数 | 不因join到两张发票，把一条Reserve金额算两遍 |
| 接口或文件 | 核对现有SAP／AP发票数据是否够用，再决定复用或扩展 | 部分／失败／重跑／超时／回补不得视作“未收到” |
| 计算与财务 | 先做分类可见性；若实际要求更改计提公式／科目，单独批准并给golden cases | 不复刻历史错误CR；与NEO-011 Deposits类别独立兼容 |
| 历史／报告 | 保存当期证据，后来事件单独显示；新增列保留兼容性 | 历史Final不静默重算，Teams及其他消费方对账 |
| BPM | 本需求本身不要求新审批流程；读取实施状态不触发实施 | 如引入人工确认，另确认角色、提交和审计边界 |

建议顺序：先取得原版和回退版Reserve文件 → 明确期望标签及条件 → 核对发票数据源和关联 → 实现读取及导出 → 用同期间全量样例对账。页面评审可以先进行，真实分类不能在证据不足时伪装完成。

## 7. 讲人话的问题清单

| 编号 | 需要业务确认 | 举例／影响 | 建议提供方 |
| --- | --- | --- | --- |
| Q01 | “恢复原设计”具体是哪份Reserve文件，最后想看几类、叫什么？ | 请给改前、错误版、回退版及期望版。我们暂用四组，不代表已确认名称 | Linda Dawson或现任Finance报告负责人；来源S2 |
| Q02 | “收到发票”指哪一刻、在哪个系统登记？ | 邮箱收到PDF、AP登记、SAP过账不是同一天；以哪一个作为月底依据？ | AP／SAP SME／Finance |
| Q03 | 一条LSP部分开票或多张发票怎么分？ | £50k只收到£10k发票，整行、剩余额还是拆分显示？不能擅自按金额分摊 | Finance／AP |
| Q04 | Complete／Implemented以哪个字段、哪次回读为准？ | PO已经批准，定时任务还没回写；报表按SAP事实还是NEO状态？ | NEO／SAP维护团队 |
| Q05 | 新分组只改报告，还是也要改Reserve金额／科目？ | 已实施未收票仍留£50k，还是根据其他规则调整？需完整期望样例 | Finance／GFS |
| Q06 | 发票关联和数据完整性如何证明？ | 一个PO两条Line、跨公司重复PO、接口失败或延迟到达，怎样不漏算／重复算？ | SAP／集成团队 |
| Q07 | 允许Finance人工确认“没有发票”吗？ | 如接口不提供状态，谁能确认、有效期多长、需要什么证据？本包仅演示假设输入 | Finance控制负责人 |
| Q08 | 跨期、冲销、贷项与历史Final怎么处理？ | 11月4日才收到10月业务发票，10月文件是否重发？旧版如何保留？ | Finance／月结负责人 |
| Q09 | Excel列序和下游还有谁在用？ | 新增两列是否会破坏现有宏、Teams汇总或外部报表？请提供现网模板和使用者 | Reporting Owner |

## 8. 验证、样例与退出条件

56项本地检查实际通过，预期和实际逐项记录于PAGE_VISUAL_CHECK.json。包括筛选提交边界、目标行、未知与失败场景、历史证据、采购限制、实际.xlsx下载回读、六种宽度及200% CSS缩放。浏览器截图和导出均由这个独立页面产生。

| 样例检查 | 预先定义的预期 | 实际 |
| --- | --- | --- |
| 全部5行 | 当期120,000，前期110,000，Movement10,000 GBP | 相等 |
| 目标未收票LSP | 仅MCI-00057，当期50,000、前期45,000、Movement5,000 | 页面与导出相等 |
| 缺发票数据 | 3条已实施LSP均Unknown，不能进入“未收到”组 | 页面与导出相等 |
| 历史证据 | 截止Not received；后来Received单独显示 | 两者同时保留 |
| 导出失败 | 无下载，原筛选MCI-00057保留 | 相等 |

这些金额是人工定义的合成fixture，用于验证分组和导出，不是按真实Finance公式算出的golden case。部分发票、冲销、跨公司匹配、完整Reserve字段、数据库保存、服务端权限、源系统接口和整期财务对账均未执行。Native Excel打开／关闭测试未执行；已用独立读取器检查下载文件的工作表和单元格。

设计评审退出：本条需求、来源、现有功能、缺口、页面和问题可清楚评审。正式实现退出：Finance签收原版与期望文件及分类规则；取得发票证据契约；同一期间全人口不漏不重、拆分前后金额一致；筛选／导出／权限及历史处理通过；真实接口和业务验收留证。没有这些证据，不能标记业务PASS。

## 9. Reference

| ID | 来源定位 | 用途 |
| --- | --- | --- |
| S1／S1-ID | 新需求Workbook，RTM for Requested Changes第13行；其他Sheet重名记录 | 精确锁定本条需求 |
| S2 | 同Workbook，P1 CR clean第32行，CR20／APPIAN-17168 | 历史回退描述及报告需求；未访问Jira |
| S3-16／41 | Material Cost & Inventory - BRD V3.1.docx，表6行16 FR6.2／行41 FR16 | 实施状态语义 |
| S3-42／43／45 | 同BRD，FR17／17.1嵌图／17.3 | 汇总、财务分类、System Reserve Status |
| S3-47／48／49／50 | 同BRD，FR17.5–17.8 | 明细、Excel、检查、筛选、Journal边界 |
| S4 | NEO User Training.docx，正文段落1376–1387、1739–1783 | FBP/GFS查看、过滤及生成 |
| S5 | NEO_数据字典.xlsx，字段字典逐行号见第5节及JSON | 字段映射和未确认数据 |
| S6 | Integrations - 2026-11-09_0941(Sheet 1).csv，第11物理记录，Id5 | SAP PO详情接口；登记仅写Output JSON，没有结构 |
| S7 | Scheduler Processes - 2026-11-09_0944.xlsx，Sheet 1第8行，Id5 | SAP批准定时回读；不含发票状态说明 |
| S8 | neo-jira-stories-20261111/v3/story_data.json，ACT-029／039／047／052 | Epic及User Story关联 |
| S9–S11 | 当前React源码TrainingReserveClaims.tsx、training-sample.ts、MonthlyList.tsx | 已有页面列和下载入口，仅源代码核对 |
| S12 | 当前React src/theme/index.ts | 原样复用NEO主题 |
| S13 | NEO_143_Page_Screenshots_20261104/scope.json | 已有P16页面编号 |
| S14 | PO Payments in NEO 1.pdf，物理第1–4页 | 文件导入、付款行和Purchasing Document关联 |

SOURCE_EVIDENCE.json包含23条来源记录、原文、定位及SHA；附录规则图可直接回看。所有新增标签／分组／状态提示均是本轮页面建议，不是对原BRD业务规则的静默修改。
