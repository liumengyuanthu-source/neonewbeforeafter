# NEO-012 · Before / After process

Priority: Must (Procurement: —; Finance: Must)

ACT-029 / ACT-039 / ACT-052 / ACT-047 · FR6.2 / FR16 / FR17 / FR17.5

## 区分已实施但未收发票的 LSP

在现有 Reserve 列表和导出中增加可核对的分组，保留原财务状态与总额。

### Before · 现有路径

1. **Finance · 打开期间 Reserve** — 当前列表已有财务状态、金额、筛选及导出；不能凭缺少付款记录认定未收发票。
2. **Finance · 另行核对实施与收票** — 新需求要求在 Reserve File 中直接区分已实施但未收票的 LSP。

### After · 建议路径

1. **Finance／数据服务 · 固定期间与数据范围** — 按期间截止点读取 LSP 类型、实施结果、发票状态和数据版本。
2. **应用服务 · 按证据分组** — 已实施＋明确未收发票进入目标组；尚未实施、其他情况及状态未知分别显示。
3. **Finance · 筛选、查看并导出** — 保留原分类与金额；导出与筛选一致的全部授权记录，不仅当前页。
4. **Finance · 对账并保留历史** — 新分组汇总与原总额一致；后续收到发票不会修改上期 Final 快照。

### 例子

示例：10 月 31 日已实施的 LSP £50,000，收票状态明确为“未收到”，进入目标组；11 月 4 日收到发票，只影响相应新期间／版本，不改 10 月 Final。

### 保留控制

- Implemented、PO 已批准、发票已收到、已付款不能互相替代。
- 发票来源未接通时显示 Unknown；不能把所有空值归成未收票。

### 正式实施前补齐

- SAP／AP 提供按 NEO Line／PO 关联的发票状态、日期及部分开票规则；现有 PO 查询登记不证明这些字段已具备。

## Separate implemented LSPs awaiting invoices

Add an evidence-based group to existing Reserve views and exports, while preserving financial status and totals.

### Before · Existing path

1. **Finance · Open the period Reserve** — The current list has financial status, amounts, filters and export; no payment record does not establish that an invoice is missing.
2. **Finance · Reconcile implementation and invoice receipt** — The request asks for implemented LSPs awaiting supplier invoices to be identifiable directly in the Reserve File.

### After · Proposed path

1. **Finance / Data service · Fix the reporting period and population** — Read LSP type, implementation outcome, invoice status and source version as of the period cutoff.
2. **Application service · Group from evidence** — Implemented plus confirmed no invoice enters the target group. Keep not implemented, other cases and unknown evidence distinct.
3. **Finance · Filter, inspect and export** — Keep original classifications and amounts; export all authorised matching records, not just the visible page.
4. **Finance · Reconcile and retain history** — Group subtotals reconcile to the original total; a later invoice does not rewrite the previous Final snapshot.

### Example

Example: a £50,000 LSP is implemented with confirmed no invoice on 31 October, so it enters the target group. Receipt on 4 November affects the relevant new period / version, not the October Final.

### Controls retained

- Implemented, PO approval, invoice receipt and payment are distinct facts.
- Show Unknown when the invoice source is unavailable; do not classify every blank as no invoice.

### Production dependencies

- SAP / AP must supply invoice state, date and partial-invoice rules linked to the NEO Line / PO; a registered PO query does not prove these fields exist.

## Sources

- **R-1113** NEO Business Requirements (added China requirements) 2(RTM for Requested Changes)_1113 1400 version.xlsx · NEO Business Requirements (adde!E13,N13,P13,Q13; priorities K13:L13
- **S1** NEO Business Requirements (added China requirements) 1.xlsx · RTM for Requested Changes!A13:Y13
- **S3-16** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 16 (1-based)
- **S3-41** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 41 (1-based)
- **S3-42** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 42 (1-based)
- **S3-47** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 47 (1-based)
- **S4** NEO User Training.docx · Body paragraphs 1376-1387, 1739-1783 (1-based)
- **S6** Integrations - 2026-11-09_0941(Sheet 1).csv · CSV physical record 11; Integration Id 5
- **S7** Scheduler Processes - 2026-11-09_0944.xlsx · Sheet 1 row 8; Scheduler Id 5
- **S2** NEO Business Requirements (added China requirements) 1.xlsx · P1 CR clean!A32:Y32

Before: frozen prototype `3ff8bc0b158ba08f2302e7404bb6185a553088c78614051451e6b5137a26802e`. Historical problems are labelled separately. After is a proposal; numerical examples are illustrative. Production execution: NOT RUN.
