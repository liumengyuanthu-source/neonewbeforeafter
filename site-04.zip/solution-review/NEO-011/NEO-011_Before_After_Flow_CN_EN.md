# NEO-011 · Before / After process

Priority: Must (Procurement: —; Finance: Must)

ACT-030 / ACT-029 · FR6.3 / FR17.1 / FR17.5

## Deposit 分类与准备金处理

Deposits 已是现有选项；重点修正它进入准备金和账务的规则，不新增同义字段。

### Before · 现有路径

1. **FBP · 维护非标准会计分类** — FR6.3 及当前页面已有 Prepayment、Loans、Deposits；仍由有权 Finance 用户维护。
2. **GFS／Finance · 生成、审阅 Reserve** — 当前原型有 Draft／Final 明细。历史需求指出 Deposit 分类／账务需修正，并非本轮验证当前引擎有同样错误。

### After · 建议路径

1. **FBP · 在现有字段选择 Deposits** — 保存修改理由和 Claim 版本；不通过 Generate Reserve 临时改分类。
2. **GFS／计算服务 · 按 Deposit 规则生成 Draft** — 读取已确认的分类、账户映射和金额口径；不能把 Claim 金额直接当 Reserve 金额。
3. **Finance · 核对分类、金额与账务去向** — 在现有 Reserve 明细核对；缺映射时该行明确待处理，不按普通类别悄悄计算。
4. **Finance · 按既有控制形成 Final** — 完成对账后沿用 Final 权限；历史 Final 不回写，本改动不自动生成 SAP posting。

### 例子

示例：一条 £50,000 Claim 被 FBP 确认为 Deposit。系统应采用 Deposit 规则，而不是因为金额是 £50,000 就自动生成同额准备金；未给定规则时金额为待确认。

### 保留控制

- 保留 FR6.3 其他字段及现有 Finance 权限；不扩大 Buyer 可见范围。
- 分类保存、Reserve 计算、Journal／SAP 处理是不同动作。

### 正式实施前补齐

- 需求表仍写需 Finance 确认；请提供 Deposit 分类／账户映射及一笔金样后启用正式计算。

## Deposit classification and Reserve treatment

Deposits is already an option. Correct how it drives Reserve and accounting treatment without adding a duplicate field.

### Before · Existing path

1. **FBP · Maintain non-standard accounting** — FR6.3 and the current page already include Prepayment, Loans and Deposits, maintained by authorised Finance users.
2. **GFS / Finance · Generate and review the Reserve** — The prototype has Draft / Final details. The historical request calls for corrected Deposit treatment; it is not a fresh finding against the current engine.

### After · Proposed path

1. **FBP · Select Deposits in the existing field** — Save the reason and Claim version; do not change classification ad hoc during Generate Reserve.
2. **GFS / Calculation service · Generate the Draft under the Deposit rule** — Use the confirmed classification, account mapping and amount basis; the Claim value is not automatically the Reserve value.
3. **Finance · Review classification, amount and accounting destination** — Review existing Reserve details; mark an affected row unresolved when mapping is missing instead of silently applying an ordinary category.
4. **Finance · Finalise under existing controls** — Retain Final authority after reconciliation; do not rewrite historical Finals or automatically create an SAP posting.

### Example

Example: FBP classifies a £50,000 Claim as a Deposit. Apply the Deposit rule rather than automatically creating a £50,000 Reserve. The Reserve amount remains unresolved until that rule is supplied.

### Controls retained

- Retain the other FR6.3 fields and Finance permissions; do not expand Buyer visibility.
- Saving classification, calculating Reserve and processing Journal / SAP are separate actions.

### Production dependencies

- The workbook still calls for Finance confirmation; obtain the Deposit classification, account mapping and one golden case before enabling the production calculation.

## Sources

- **R-1113** NEO Business Requirements (added China requirements) 2(RTM for Requested Changes)_1113 1400 version.xlsx · NEO Business Requirements (adde!E12,N12,P12,Q12; priorities K12:L12
- **S1** NEO Business Requirements (added China requirements) 1.xlsx · RTM for Requested Changes!A12:Y12
- **S3-17** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 17
- **S3-42** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 42
- **S3-43** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 43
- **S3-47** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 47
- **S4-edit** NEO User Training.docx · Body paragraphs 664-676 (1-based)
- **S4-generate** NEO User Training.docx · Body paragraphs 1739-1769 (1-based)
- **S7** ClaimReserve.tsx · Numbered source lines
- **S2** NEO Business Requirements (added China requirements) 1.xlsx · P1 CR clean!A31:Y31

Before: frozen prototype `3ff8bc0b158ba08f2302e7404bb6185a553088c78614051451e6b5137a26802e`. Historical problems are labelled separately. After is a proposal; numerical examples are illustrative. Production execution: NOT RUN.
