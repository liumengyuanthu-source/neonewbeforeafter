# NEO-011 · Deposits 非标准交易与准备金处理

<!-- FLOW-REVIEW-20261116 -->
## 16 Nov 2026 · 流程评审补充

[中英文 Before / After 流程](NEO-011_Before_After_Flow.html) · [流程说明 MD](NEO-011_Before_After_Flow_CN_EN.md)

Deposits 已是现有选项；重点修正它进入准备金和账务的规则，不新增同义字段。

本轮为流程说明补充；原交互页面、问题及历史证据保留。正式实施前需补齐：需求表仍写需 Finance 确认；请提供 Deposit 分类／账户映射及一笔金样后启用正式计算。
<!-- /FLOW-REVIEW-20261116 -->

## 1. 一句话说明

让 Deposits 能被正确识别，并进入 Finance 确认的准备金和资产负债表处理，减少月结时人工把 Provision 改回正确科目的工作。[S1]

本需求不只是增加一个下拉选项。原BRD FR6.3已经写了“Prepayment、Loans、Deposits”，当前代码也包含这三个选项；需要核对的是选项、保存字段、准备金分类、科目及后续输出是否真正连通。原始需求没有提供完整会计规则或科目号，不能把“Deposits”直接等同于“Prepayment”，也不能默认归为Provision。

本包为独立评审，使用NEO主题、JLR字体和Ant Design。数据、金额、人员及版本均为合成样例。现有prototype未修改。

## 2. 分类、优先级与关联

| 项目 | 评估 | 依据及边界 |
| --- | --- | --- |
| 需求类型 | Existing functionality - Update/correct logic | 原始分类 [S1 D12] |
| 主要改动类型 | Application内部前后端／参考数据／准备金计算和输出映射；附带UXUI调整 | 仅加选项无法改变错误的会计分类 |
| UXUI | 核对Claim非标准标记、Reserve的Deposits选择、月度准备金分类与异常提示 | 保留现有FR6.3字段；新增提示和核对步骤为本轮方案 |
| Integration needed | 取决于现行Journal／报表输出如何消费分类与科目 | 若现有渠道已经支持所需科目、公司、金额等字段，可先复用；契约尚未证明，不宣称接口已满足 |
| 对接对象 | Finance负责会计规则；SAP／接口团队确认实际过账或文件渠道；报表负责人确认输出 | MCI_raiseLumpSumPO是建PO接口，不是Reserve Journal过账接口 [S14] |
| 新增架构 | 当前没有证据要求新平台或新中间件 | 优先扩展已有参考数据、规则及快照；若契约缺字段再评估扩展 |
| Priority | 建议P0业务／数据规则澄清，P1实现和回归；原始要求Must | 与NEO-010的Should不同；这里会影响月结分类 [S1 L12] |
| Epic | CNP-235 Finance and continuity；关联CNP-231 Claims and data | 本地Story映射，未写入Jira [S6] |
| User Story | 主ACT-030 Edit Reserve Data；下游ACT-029 Generate Reserve | 关联ACT-001／004建单及更新；ACT-058／059／060仅涉及历史人工Memo核对，不能自动把Memo当最终解决方案 |
| FR | 主FR6.3、FR17.1、FR17.5；关联FR1.2、FR17及实际适用FR20报表 | FR1.2是非标准交易标记，FR6.3是会计分类，两者不能混为一个字段 |
| UC场景 | 非标准LSP录入→FBP选择Deposits→月度准备金核对→适用输出及回执 | 没有找到已签收的独立Deposits UC编号，先作为既有ACT的子场景，不编造编号 |
| 页面 | P2.2 Supplier Claim Details；P9 Edit Reserve Data／P6.7 Reserves；P16.1月度明细／P16.3生成 | 复用既有目录，不新增一级菜单 [S13] |

S1 P12写“HJONES20 / DSMITH69 to confirm story”。E12提到Kristy Louise Roberts或Kish Galliara。CR26历史记录还包括Linda Dawson及Needs refinement／Backlog。这些是原文线索，不代表上述人员已接受当前责任或签收。[S1／S2]

## 3. 现有证据与真正缺口

| 来源 | 能确认的内容 | 不能据此确认的内容 |
| --- | --- | --- |
| 新需求NEO-011 | Deposits需正确处理；目前描述为当作Provision后人工纠正B/S | 哪类Deposit、借贷方向、科目、期间及何时生效 |
| BRD FR1.2 | Lump Sum包含Non-Standard Transaction Flag，举例Loan／Prepayment | Buyer是否应选择最终会计类别，以及与FBP分类冲突时谁决定 |
| BRD FR6.3 | Purchasing FBP可编辑Reserve；有标记时显示Prepayment／Loans／Deposits；Purchasing不得查看该Reserve信息 | 全部GFS与FBP层级的实际配置和例外 |
| BRD FR17.1内嵌规则图 | 可见Prepayment条件及其他状态分类，未见明确Deposits分支 | 图中部分下拉文字截断，不能由此还原完整可执行规则；不能直接套用Prepayment分支 |
| BRD FR17／17.5 | 月度Draft／Final、逐Line分类、B/S与I/S字段及快照 | Deposit如何汇总、是否独立类别、是否计入现有总额 |
| Training | Edit Reserve Data限FBP组；Generate Reserve列GFS和FBP组 | 与BRD“GFS生成、FBP查看”存在角色差异，仍须确认 [S4] |
| 数据字典 | Claim、非标准会计参考表、Reserve分类和科目已有字段 | 实际Deposits枚举ID、生产行、完整规则和接口payload |
| 当前代码 | ClaimReserve已渲染Non-standard accounting；source-choices和Claim输入均含Deposits | 选项存在不证明Finance分类、Journal及报表已正确。未执行现有产品验收 |

原BRD FR17.1规则图片已保存在source-images内，保持原图；该图是历史证据，不是本次新UI。Word来源用1-based表／行或正文段落定位，不冒充打印页码。

## 4. 页面与交互

### 4.1 FBP编辑Reserve

![Edit Reserve data：保留全部FR6.3字段](NEO-011_Page_Edit.png)

Ben Taylor（FBP Officer）进入MCI-00057的Reserve。保留Historical precedence、Volume adjust reserve、Non-standard accounting、Commentary、Dates correct、Unusual accounting treatment和Reason。LSP样例的Volume adjust为No。非标准标记为No时，不出现会计类型选择。

当前样例存的是Prepayment；将其改为Deposits并填写原因。这里使用现有三项选项，并不生成新的枚举数字。

### 4.2 保存前核对变化

![Review：Saved与Proposed并列](NEO-011_Page_Review.png)

Review changes显示六项字段的保存值与拟议值、操作者及原因。Back to edit保留输入，尚未保存；Save Reserve data才更新本页内存中的保存版本。Reason必填是沿用当前应用的审计行为，不把字典nullable当作免填依据。

提示说明：保存字段不改变既有Final快照，也不代表已向SAP过账。Deposits规则未确认时，需要Finance核对。这是拟议控制，不是已签收的全局冻结或审批规则。

### 4.3 保存后的状态

![Saved：字段已保存，会计处理仍需核对](NEO-011_Page_Saved.png)

保存后版本3→4，View saved values可回读本页保存的Deposits及Commentary。Discard changes恢复最后保存值。保存失败保留输入及旧版本，不显示成功。

样例只在本页面内存中工作，刷新会恢复初始状态。没有真实持久化、服务端授权、并发校验或审计存储；不能把页面回读当作产品验收。

### 4.4 月度Draft核对

![Draft：异常行保留在完整清单中](NEO-011_Page_Draft.png)

Oliver Grant（GFS Officer）查看November 2026 Draft。Deposits行保留在明细中，类别、科目未定时显示“—”和Finance review required；普通行继续保留。受影响的总额不能显示为0，也不能把过滤后的可计算行当成完整总额。

建议在受影响规则和科目缺失时阻止该Reserve Finalise；不擅自规定必须阻止所有其他期间、所有Claim或所有业务操作。具体阻断范围请Finance确认。

### 4.5 Deposits处理明细

![Treatment：保留已知Claim金额，未知Reserve金额不推算](NEO-011_Page_Treatment.png)

Claim value 50,000 GBP是已知样例输入，不等于Current month reserve，也不等于支付金额。Reserve类别、B/S科目、当月金额、过账编号都未确认，分别保持未知。不显示“自动Provision”，不伪造科目号或SAP成功回执。

确认时至少需要Company、收款／付款方向、付款状态、期间、适用规则及来源版本。本轮没有给出任何会计分录建议。

### 4.6 已Final的历史期间

![Final：旧期间快照保留，不随新选择回写](NEO-011_Page_Final.png)

October 2026 Final version 2仍展示历史Prepayment分类，保持只读。它仅是“历史保留”样例，并非声明过去分类正确或月结已验收。该样例没有原科目／金额／回执，详情明确显示缺失。

实际旧期间是否需要纠正、通过重开还是当前期调整，应由Finance决定并保留原版本与更正记录；不能在下拉框保存时静默改历史。

## 5. 字段、计算与系统链路

| 信息 | 已有映射 | 缺口／开发注意点 |
| --- | --- | --- |
| 非标准会计类型 | MCI_REF_NON_STANDARD_ACCOUNTING，字段字典301–309；Claim.NON_STANDARD_ACCOUNTING_ID，第742行 | 查实际Deposits行ID、启用／生效状态；显示文字不能直接充当FK |
| Buyer标记与类型 | BRD FR1.2；当前Claim的nonStandardTransaction／nonStandardTransactionKind | 与FBP Reserve分类如何同步、冲突如何处理尚未确认，不能随意覆盖 |
| 月度分类 | MCI_RESERVE_RISK_OPPORTUNITY.RESERVE_FINANCE_STATUS_ID，第1389行 | Deposits对应什么分类、规则优先级、有效期间待确认 |
| B/S与I/S | BALANCE_SHEET_ACCOUNT第1412行；INCOME_STATEMENT_ACCOUNT第1410行 | 具体科目、Company／Team／方向／期间映射由Finance提供 |
| Memo | MCI_RESERVE_RISK_OPPORTUNITY_MEMO.NON_STANDARD_ACCOUNTING_ID，第1454行 | 历史人工纠正是否已入账；自动化后不能再与旧Memo重复计入 |
| Auto PAM／报表 | REF_AUTO_PAM_RULE第92行；STG_REPORT_EXTRACT.NON_STANDARD_ACOOUNTING第2527行；STG_RESERVE_RISK_REPORT.NON_STANDARD_TRANSACTION_FLAG第2636行 | 保留源字段拼写；类型与flag不同，逐输出核对，不能同名近似就当同义 |
| 已有Prepayment字段 | TOTAL_PREPAYMENT_GBP、SHORT_TERM_PREPAYMENT_GBP、LONG_TERM_PREPAYMENT_GBP | 不能因字段现成，就将Deposit无条件塞入Prepayment金额 |
| Journal／外部处理 | 当前journal.ts已有映射版本、模板、科目、公司、借贷、期间和receipt结构 | 本地结构不是实际SAP契约；现有MCI_raiseLumpSumPO不证明Journal接口可复用 |

建议链路：Claim标记与FBP分类 → 已核准参考值和会计规则 → 同期间完整Reserve快照 → Journal／报表输出 → 实际结果回读与对账。某环节缺资料，要定位到该环节，不因为下拉已完成就宣称端到端完成。

## 6. Change、Impact与实施拆分

| 层 | Change | Impact／验收 |
| --- | --- | --- |
| 前端 | 复用现有字段；清楚显示选择、保存、待核对及只读历史 | 不改POA／LSP其他字段；Buyer不可借此看到Reserve信息 |
| 后端 | 统一非标准类型与角色校验；保存原因和版本；返回明确的未核准处理状态 | 不接受无效枚举；并发不覆盖；失败不记成功 |
| 规则／数据库 | 核对已有FK及参考行；补Deposit适用条件、分类、科目、生效版本 | 不默认Prepayment或Provision；不覆盖历史Final |
| 准备金／对账 | 同期间完整人口、当前／前期与Movement、Memo去重及汇总 | Deposit金额和普通行共同对账，缺失值不能默认为0 |
| 工作流 | 按确认的权限和月结控制处理待核对项 | 不把GFS／FBP角色差异用mock决定，不新增未批准的全局审批链 |
| 外部渠道／报表 | 逐项核对现有输出能否传分类、科目和回执 | 可复用的先复用；需新增字段／契约时单独列变更与系统owner |

建议先收齐会计样例及规则，再改计算和输出；页面与输入验证可以独立推进。应覆盖普通LSP、Prepayment、Loans、Deposits及未标记Claim的回归。

## 7. 讲人话的问题清单

| 编号 | 要确认什么 | 例子／为什么影响开发 | 建议确认方 |
| --- | --- | --- | --- |
| Q01 | 这里的Deposit具体是哪类款项，是否既有付出也有收到？ | JLR付给供应商的保证金与供应商付给JLR的款项，不能只凭同一个词用相同分录 | Kristy Louise Roberts／Kish Galliara或现任Finance SME |
| Q02 | 正确类别、科目及适用条件是什么？ | GB01的一笔£50k在未付／已付、不同期间分别怎样处理？请给可复算的实际样例和期望分录 | Finance／GFS |
| Q03 | Buyer标记、Buyer类型和FBP分类谁是最终依据？ | Buyer填Prepayment，FBP改Deposits，是否回写Claim，是否需要另一次审批？ | Business／FBP |
| Q04 | 缺规则时哪里必须停？ | 只阻止受影响的Final或Journal，还是整个期间？其他Draft是否可继续？ | Finance控制负责人 |
| Q05 | 已Final或已经用Memo纠正的旧单怎么处理？ | 上月已经人工调整，本月新增自动逻辑不能再计一次。用当前期调整还是重开？ | GFS／月结负责人 |
| Q06 | 哪些报表及总额要单列／合并Deposits？ | 总Provision、Prepayments、Reserve和Auto PAM分别怎样呈现，谁签收对账？ | Reporting／Finance |
| Q07 | 谁能编辑、谁能生成与Finalise？ | BRD限制Purchasing查看Reserve；Training列出的生成角色比BRD广，需核对现网配置 | Business Owner／权限管理员 |
| Q08 | 实际Journal走文件还是接口？现有模板／payload能否承载所需数据？ | 建PO接口不等于Journal过账；需要字段、方向、回执与失败样例 | SAP／集成团队／GFS |

原记录中待确认Story的账号HJONES20／DSMITH69保留为来源信息，需核对其当前身份与责任。[S1 P12]

## 8. 本地验证与正式退出条件

本轮 **50 项本地交互／布局检查通过**。本地设计检查覆盖字段保留、必填原因、修改预览、取消／回读／失败输入保留、Draft缺口、Final只读、角色场景和响应式；逐项预期与实际保存在PAGE_VISUAL_CHECK.json。

| 验证层 | 状态 |
| --- | --- |
| 独立页面交互与布局 | 以本包实际检查记录为准 |
| 当前NEO产品、API、数据库持久化与服务端权限 | NOT RUN |
| Deposit分类／科目／期间规则及Finance golden cases | BLOCKED：规则与样例未签收 |
| SAP／Journal／报表／全期间对账 | NOT RUN |
| 生产发布 | NOT RUN；本包没有部署 |

设计退出：页面与影响明确、未知字段和规则可逐项确认、原始证据可定位。业务实现退出：Finance签收样例；所有类型与正常／异常／历史更正分支通过；数据库回读、权限、期间及Memo对账一致；实际输出／回执匹配同一版本。不能用本包的保存提示代替正式验收。

## 9. Reference

| ID | 来源与定位 | 用途 |
| --- | --- | --- |
| S1 | NEO Business Requirements (added China requirements) 1.xlsx；RTM for Requested Changes!A12:R12 | NEO-011原文、Must、责任线索 |
| S2 | 同Workbook；P1 CR clean!A31:Y31，CR26 | 历史问题及Needs refinement |
| S3-4／17 | Material Cost & Inventory - BRD V3.1.docx；表6行4 FR1.2／行17 FR6.3 | 标记、选择、字段与权限 |
| S3-42／43／47 | 同BRD；表6行42 FR17／行43 FR17.1内嵌图／行47 FR17.5 | 月度分类与明细、快照 |
| S4-edit／generate | NEO User Training.docx；正文段落664–676／1739–1769 | 编辑与生成角色 |
| S5 | NEO_数据字典.xlsx；字段字典，逐行编号见证据文件 | FK、Reserve分类、科目、Memo与报表 |
| S6 | outputs/neo-jira-stories-20261111/v3/story_data.json；ACT-001／004／029／030／058–060 | 现有Epic及Action关联 |
| S7／8／9 | src/views/Claim/sections/ClaimReserve.tsx；src/domain/access/source-choices.ts；management.ts | 已有UI、选项与保存契约 |
| S10／11 | src/domain/p02/fr1-presentation.ts；src/domain/p05/journal.ts | Claim输入与本地Journal结构 |
| S12 | src/theme/index.ts | 未修改的NEO主题快照 |
| S13 | outputs/NEO_143_Page_Screenshots_20261104/scope.json | 既有页面编号 |
| S14 | Integrations - 2026-11-09_0941(Sheet 1).csv；第16条物理记录MCI_raiseLumpSumPO | 证明已有建PO入口，不能证明Reserve过账接口 |

代码路径前缀为NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app。完整绝对路径、SHA及来源原文保存在SOURCE_EVIDENCE.json。来源分析、页面样例与真实产品验收分别记录。
