# NEO-003 汇总版 · 批准前刷新 SAP 起始价

版本 V1 · 2026-11-12 · 第 3 / 68 条 · 独立方案评审，未修改 NEO prototype。

## 本轮界面修订：NEO design system

按用户 12 Nov 2026 确认的项目默认规则，页面已统一使用当前 NEO React theme、JLR Emeric 字体及真实 Ant Design 6.7.0 组件。桌面边距32px、中屏24px、手机16px；表格横向滚动、黑色主按钮、蓝色链接、状态色、下拉、弹窗和校验沿用 NEO。仅展示本条涉及的交互，未连接的导航与最终业务提交禁用。

Reference：`NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/theme/index.ts`、`src/layouts/BasicLayout/`、`src/styles/` 和 `NEO_FULL_OFFLINE/skills/jlr-frontend-ux/references/NEO_UXUI_PRINCIPLES.md`。theme 原文件与只读快照 SHA 一致，详见交付包 `design-source/SOURCE_MANIFEST.json`。配套布局是独立评审页的适配，不是新增产品 design system。

当前本地页面检查见 `PAGE_VISUAL_CHECK.json`；接口、后台、流程、权限和业务验收仍为 NOT RUN。旧截图及旧检查数不作为本版验收依据。此修订没有改写业务范围或原 prototype。

## 1. 结论与追溯

Buyer 编辑 POA Claim 时，可以主动检查 SAP 起始价；有变化的零件要提示 Buyer 复核结束价，再重新计算及按适用规则提交。**这不是只加一个按钮，也不是把 SAP 价格写回 SAP。** [S1]

建议：在现有 Part Prices 页增加 Refresh SAP prices；先展示本次读取的差异，再由 Buyer 应用并复核。本方案建议暂时保留已输入的结束价供复核，避免静默改掉谈判结果；此取舍仍需业务确认。

| 项目 | 汇总结果 |
|---|---|
| 原需求 | RTM for Requested Changes / NEO-003，第 4 行；原追溯 P1 CR Clean CR8。[S1] |
| 原表分类 | **Minor Change - UI/UX**，如实保留。 |
| 实施分类建议 | **APP — 应用前后端修改 + INT-REUSE — 现有 SAP 读接口候选复用**。只有接口不能满足有效价、完整性或时效要求时，才升级为 INT-CHANGE。 |
| Epic | **CNP-231**；本地范围 Claims and data，正式 Epic 标题在当前登记中为空，不补造名称。[S4] |
| 主 User Story | **ACT-004 — Update Claim**。入口是 Buyer 编辑已有 Claim。[S1、S4] |
| 关联 User Story | **ACT-001 — Create Claim**：共用零件价格组件，属于兼容回归；新建阶段是否开放按钮待确认。**ACT-005 — Submit Claim**：检查复核与计算是否完成。若批准入口另有独立 request，需同步确认其提交控制，不把 Submit Claim 自动等同审批提交。 |
| 直接影响 FR | **FR6 — Edit Risk/Opportunity；FR1.6 — POA Part Level Data**。历史 CR 明确写 Yes - FR6。[S2、S5] |
| 回归关联 FR | **FR7 / FR8 / FR8.1**：价格变化后的计算；**FR16**：适用状态与锁；**FR18**：NEO-001 对刷新后的 Claim 计算存在条件依赖。不是全部已批准修改范围。 |
| 映射纠正 | **FR6.1 是 Lump Sum，不作为本次 POA 刷新主 FR；ACT-026 Bulk Upload Parts 也不是新增刷新入口。** 原粗映射只保留为历史，不直接复制到开发清单。[S5、S6] |
| UC | 沿用 ACT-004 的 UC-05/09/10 编辑场景、UC-15 退回更正关联；增加刷新差异、结束价复核、并发与失败恢复场景。旧编号关系来自本地追溯表，新增测试不代表已有 UC 已验证。[S6] |
| 页面 | **P1.1.21 — Update Claim / Parts Data for POA / Part Prices**（主要修改）；**P1.1.22 — Update Claim / Calculation**（重算）。**P2.6.2 / P2.6.3** 为新建流程共用组件的回归关联，不擅自新增入口。 |
| Priority | 原表 Procurement = **Must**、Finance = **Must**。建议 **P0：价格准确性与下游失败风险前置**；详细排期需先核实接口和规则。 |
| 状态 | 已制作独立页面交互样例；真实 SAP、持久化、审批、计算及业务验收均 **NOT RUN**。 |

## 2. 用人话理解：旧的起始价会让后面的金额不对

例如 Buyer 已加入零件：起始价 £100，谈好的结束价 £95。期间 SAP 起始价变成 £104。若还用 £100 计算，差额是 £5；按 £104 和原结束价 £95 算，差额变成 £9。

但若 Buyer 原来想表达“降价 5%”，新起始价 £104 的 95% 是 £98.80。**保留结束价 £95、保留降价金额 £5（得到 £99）、保留降价 5%（得到 £98.80）是三个不同决定。** 系统不能悄悄替 Buyer 选择。[业务例子，不是签收公式]

原需求明确：按钮供 Buyer 在审批前编辑时使用；变更后应提示检查结束价。它没有明确刷新时按什么规则维护金额/百分比，以及哪些审批状态禁止操作。[S1:N4/Q4]

## 3. 页面与操作设计

所有图均为独立设计数据。页面保持 After 的顶栏、编辑分区、Part Prices 表格和后续 Calculation 入口。顶部中文场景切换仅用于评审，不进入正式业务页面。

### 3.1 入口：现有 Part Prices 页

![刷新按钮入口](NEO-003_Page_Entry.png)

新增 **Refresh SAP prices**，建议作用于本条 Claim 已加入的零件，不受批量改价勾选影响；范围需要业务确认。新建/编辑权限沿用原规则，本条默认只明确 Buyer，不自动扩展 PM / SPM 权限。

### 3.2 读取后先看差异

![SAP 价格差异确认](NEO-003_Page_Preview.png)

独立弹窗展示 Part / Plant、Saved start price、SAP start price、Current end price、Currency。Cancel 不改变 Claim；Apply and review end prices 才将本次有效读取结果应用到编辑中的 Claim。弹窗属于该页面的交互状态，**不新编一个正式页面编号**。

“先预览再应用”是本轮可评审建议，不是原 BRD 已有交互。读取本身不产生 SAP 修改、WIPS 建单或审批请求。

### 3.3 更新后复核结束价

![起始价更新后复核结束价](NEO-003_Page_Review.png)

变化行明确显示 Review end price。示例中 £100 → £104，原结束价 £95 暂时保留；差额重新显示 £9，百分比为示例精度。Buyer 复核后才可继续 Calculation；如果要调整结束价，正式实现继续使用当前允许的金额/百分比或直接价格编辑方式，不能绕过原 Resource / Currency 等限制。

本次独立样例只演示“保留 £95 并确认”的路径，其他改价、保存、提交和计算未接入。Submit / Save as Draft 保持不连接，不能作为测试成功证据。

### 3.4 无变化、读取失败、已批准

- **无变化**：提示起始价未变，保留结束价；不制造价格变更记录或要求无意义的重新审批。是否仍记读取日志由审计规则决定。
- **读取失败**：提示 No prices have changed，保留原输入，可再次检查。不把超时当零价或已成功刷新。
- **已批准**：刷新禁用并说明原因；服务端也必须拒绝不允许的刷新。具体是哪种批准和处理中状态须确认。

![读取失败：保留原始数据](NEO-003_Page_Failed.png)

![已批准：禁止刷新](NEO-003_Page_Approved.png)

## 4. Solution、Change、Impact

| 层面 | 建议怎么改 | 影响与限制 |
|---|---|---|
| 前端 | 新增刷新按钮、变化对比、变化行提示及结束价复核。 | 不改正常字段含义；价格控件原权限与限制继续有效。 |
| 应用服务 | 校验 Buyer 对 Claim 的权限及状态，按已有零件键请求价格，整理差异和失败行。 | 不能仅按零件号匹配；Vendor / Plant / Material 等组合及价格有效期必须核实。 |
| 读取与应用分离 | 预览保存本次读取版本；应用时再次检查 Claim 修订与审批状态。 | 预览后另一用户修改或进入锁定状态，应拒绝旧预览并要求重新检查。 |
| 结束价处理 | 建议保留原谈判结束价供人工复核，明确重新计算差额；不默认保持百分比。 | 该建议待业务确认；改变币种、价格单位或计价条件时不自动覆盖。 |
| 计算 | 已应用的起始价变化使旧结果失效；复核后重新计算，并回读新版本。 | FR7 / FR8 / FR8.1 需回归；独立页面未执行真实计算。 |
| 数据与审计 | 记录何人、何时、哪条零件、旧/新起始价、来源有效期、复核及后续计算版本。 | 现有数据字段是否足够待核验，未臆造新增数据库列。 |
| 审批控制 | 不刷新已锁定依据；前端和后端同时执行许可检查。 | FR6 原有“active 或 approved Settlement 不可编辑”与新需求“before approval”不是完全相同条件，须形成明确状态表。 |
| Integration | 候选复用 MCI_getPartPriceDetails，经 NEO 应用后端调用 Apigee / SAP。 | 浏览器不直接调用 SAP、不暴露凭据；只读价格，不写 SAP。接口契约不足才新开修改项。 |
| 下游影响 | 起始价准确可降低后续处理的价格不一致风险。 | 不能承诺单靠本功能修复所有 Robot 失败，也不自动更改或重建已有 WIPS Claim。 |
| 架构 | 当前无需提出新增平台。 | ECC / S4 / 非 SAP 场景覆盖要按接口与路由确认，不能默认一条接口覆盖所有工厂。 |

## 5. 接口与数据映射：目前有证据的部分

接口登记 Id 2 / MCI_getPartPriceDetails：**GET**，Appian 经 **Apigee** 请求 **SAP**；描述是取零件价格用于 POA Claim。[S3] 表中 Source / Target 表示调用方向；返回的价格业务数据来自 SAP，不代表 Appian 是价格来源。

| 契约线索 | 已知 | 仍需确认 |
|---|---|---|
| Endpoint | material-cost-inventory-service/material-price-history/VAR_VENDOR_CODE | 名称是 price history，不能仅凭名称认定会返回唯一“最新有效价”。 |
| 查询参数 | plant=VAR_PLANT_CODES；materialNumber=VAR_MATERIAL_CODES；offset=VAR_START_INDEX；limit=VAR_BATCH_SIZE | 多工厂/多物料编码格式、最大批量、分页完整性及匹配键。 |
| 输入 / 输出 | 无 request body；JSON response。 | 实际 JSON 字段名、价格、币种、价格单位、有效期、返回错误结构；当前登记未给出。 |
| 价格选择 | 新需求要求 latest pricing information | 按今天有效价、Claim Effective Date，还是最新一条记录？存在未来价格时如何选？ |
| 现行配置线索 | Timeout (Seconds) = 300；记录为未废弃，更新日期 07 May 2025。 | 300 是登记值，不是用户应等待的目标，也不是当前可用性或性能证明。 |
| 使用边界 | 本次只读 SAP 后更新 NEO Claim | 不调用 WIPS 建单/审批，不执行 SAP 写入；已有 WIPS 草稿是否同步另行确认。 |

**价格单位例子：**返回 £100 / 100 件，单件是 £1，不能直接覆盖为 £100 / 件。只有取得正式单位和转换规则才能应用。GBP / EUR 不一致也不能靠显示名称相同就覆盖。

## 6. 业务确认问题（背景、例子、决定与影响）

| 问题 | 人话背景与例子 | 要确认什么 / 影响哪里 | 建议回答人 |
|---|---|---|---|
| Q1：到底什么时候不允许刷新？ | Mandate 已批准但还没做 Settlement，算“已批准不能改”吗？正在审批或退回后可不可以？ | 给出每类 Request / Claim 状态的许可表；影响 FR6、FR16 和审批快照。 | Buyer 流程负责人 + Finance / FBP |
| Q2：起始价变了，原来谈好的结束价要不要保留？ | £100 → £104；原结束价 £95。保留结束价得 £95，保留降价 £5 得 £99，保留 5% 得 £98.80。 | 选择默认处理和必须人工复核的情况；影响前端、公式和申请金额。 | 采购 + Finance |
| Q3：“最新价”是今天的价，还是单据生效日的价？ | 今天 £104，下月价格 £106，而 Claim 生效日是下月。 | 选择有效日期与匹配规则；否则同一接口也会选错价格。 | SAP 价格负责人 + 采购 |
| Q4：按钮刷全部已加入零件，还是只刷勾选的？ | Claim 有 100 个零件，Buyer 当前勾选 2 个准备批量改价；是否误以为刷新也只有 2 个？ | 建议刷新范围独立且明确；决定是否需要选择范围及提示。 | Buyer 代表 |
| Q5：100 个零件只有 99 个取价成功，怎么处理？ | 一条找不到价格或币种/单位不一致，其余 99 条有效。 | 整批保留原值，还是允许部分应用并阻止失败行继续？不能自行静默混合。 | 采购 + Finance + 接口团队 |
| Q6：以前的 WIPS 草稿和计算结果要怎么处理？ | WIPS 已按 £100 建过草稿，现在 NEO 起始价变 £104。 | 哪些需重算、同步、重新确认；不能自动新建一张 WIPS 单解决。 | CBSL / WIPS 负责人 + 采购 |
| Q7：是不是只有 Buyer 能刷新？新建时也要吗？ | 原 FR6 还允许关联 PM / SPM 编辑，但新增按钮描述只明确 Buyer 编辑。 | 不自动扩权限；确认 PM / SPM、新建阶段是否适用。 | 业务权限负责人 |
| Q8：如何才算“检查过结束价”？ | Buyer 只看到了黄色提示，还是必须逐行确认？有 50 条变价怎么办？ | 明确逐行/批量复核及留痕，哪些提交必须拦截；样例采用变化行确认，待业务签收。 | Buyer 代表 + Finance |

历史 CR 写 “Harsh 认为已存在，需 Dan 再核对”，同时又标 Pause / Backlog；最新表写 No。应请现有团队展示实际入口和行为，再决定复用还是补做。不能由文档冲突推出当前功能一定存在或不存在。[S2]

## 7. 验收要点与退出条件

下表为后续产品验收，不把独立设计脚本通过当业务通过。

| 场景 | 预期结果 | 实际结果 / 状态 |
|---|---|---|
| 起始价变化 | 按正式 SAP 返回应用到正确 Vendor / Plant / Part；只对变化行要求复核，记录来源和版本。 | 未执行 / NOT RUN |
| 无变化 | 原起始价、结束价和有效计算不被无意义修改；读取日志按确认策略处理。 | 未执行 / NOT RUN |
| Cancel / 并发修改 | 取消不改变输入；过期预览不得覆盖后来编辑或已锁定版本。 | 未执行 / NOT RUN |
| 结束价及计算 | 按 Q2 / Q8 的规则复核和改价；新金额用独立 Finance 标准样例验算。 | 未执行 / NOT RUN |
| 已批准 / 审批中 / Settlement 锁 | 按签收状态表在服务端拒绝不允许的刷新，不能绕过 UI 调接口。 | 未执行 / NOT RUN |
| 超时 / 部分失败 / 分页缺失 | 不写零价、不漏行、不伪报成功；重试及部分应用遵守确认策略。 | 未执行 / NOT RUN |
| 单位 / 币种 / 有效期 | 不按错误单位或过期价格覆盖；不可转换时保留输入并说明。 | 未执行 / NOT RUN |
| 保存、重开及提交 | 应用后的价格、复核和计算版本持久化一致；提交服务执行相同校验。 | 未执行 / NOT RUN |
| 既有 WIPS / AutoPAM | 按确认策略关联旧外部编号并回归报告，不重复建单或覆盖审批依据。 | 未执行 / NOT RUN |
| UX/UI | 变化行清楚，提示针对具体 Part / Plant；失败保留输入，窄屏表格可访问，按钮及焦点可用。 | 产品未执行 / NOT RUN；独立页面检查另见 VALIDATION.json。 |

进入开发条件：确定 Q1/Q2/Q3/Q5/Q8、取得接口样例和权限、有效价及单位规则，确认是否有可复用实现。功能退出条件：上述适用场景在实际指定版本执行并留存 API 回读、持久化、审批边界和金额证据。

## 8. Source / Reference

- **S1** `/Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx`，`RTM for Requested Changes!A4:R4`；D4 原分类、E4 描述、K4/L4 Must、M4 痛点、N4/Q4 按钮及结束价复核要求。
- **S2** 同一工作簿，`P1 CR clean!A5:Y5` / CR8；P5 “functionality is already in place” 待交叉核对；N5 Pause；T5 No - Backlog；W5 Yes - FR6。历史联系人不是已确认当前责任人。
- **S3** `/Volumes/KIOXIA/JLR Appian/6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv`，物理第 8 行 / Id 2 MCI_getPartPriceDetails；第 6 行表头。GET 路径、Apigee、JSON 和 300 秒来自该登记；本轮未调用接口。
- **S4** `/Volumes/KIOXIA/JLR Appian/outputs/neo-jira-stories-20261111/v3/story_data.json`，ACT-001/004/005/026 及 Epic CNP-231。本轮未读线上 Jira；正式 Epic 名称不补造。
- **S5** `/Volumes/KIOXIA/JLR Appian/6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx`，第 6 表第 14 行 FR6（编辑角色、值/信心变更原因、Settlement 锁）、第 15 行 FR6.1（Lump Sum）、第 8 行 FR1.6（零件与价格）。表/行从 1 开始，无伪造页码。
- **S6** `/Volumes/KIOXIA/JLR Appian/outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/analysis.json`，NEO-003 trace 的既有 ACT / UC / 页面登记。本轮明确收窄主线为 ACT-004、FR6/FR1.6，FR6.1 与 ACT-026 不直接纳入；未静默覆盖旧表。
- **S7** `/Volumes/KIOXIA/JLR Appian/NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Parts/PartPrices.tsx`，原批量改价、Preview / Apply、过期预览校验、Resource / Currency 直接改价限制、Calculation 入口；`SelectParts.tsx` 的 Current Price 来源展示。只读对照，不证明现网刷新按钮有无。
- **S8** `/Volumes/KIOXIA/JLR Appian/NEO_FULL_OFFLINE/skills/jlr-frontend-ux/references/NEO_UXUI_PRINCIPLES.md`，独立页面视觉依据；所有图只用于本次设计评审。

## 9. 交付范围

- NEO-003_Consolidated_CN.html：单文件汇总，内嵌主要页面图，作为统一阅读入口。
- NEO-003_Consolidated_CN.md：可编辑汇总，含分类、Epic / ACT / FR / UC、Change / Impact、问题例子和来源。
- NEO-003_Page_Proposal.html：独立交互方案，支持有变化、无变化、失败、已批准场景；不会访问 SAP 或写业务数据。
- 五张页面图：Entry、Preview、Review、Failed、Approved。
- VALIDATION.json：文件及独立页面检查，不是产品验收。

所有文件放在 solution-review/NEO-003，原 prototype、业务数据、QA 权威表和线上系统均未修改。
