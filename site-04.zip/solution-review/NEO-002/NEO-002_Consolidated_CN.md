# NEO-002 汇总版 · 生产计划数据来源变更

版本 V1 · 2026-11-12 · 第 2 / 68 条 · 独立方案评审，未修改 NEO prototype。

## 本轮界面修订：NEO design system

按用户 12 Nov 2026 确认的项目默认规则，页面已统一使用当前 NEO React theme、JLR Emeric 字体及真实 Ant Design 6.7.0 组件。桌面边距32px、中屏24px、手机16px；表格横向滚动、黑色主按钮、蓝色链接、状态色、下拉、弹窗和校验沿用 NEO。仅展示本条涉及的交互，未连接的导航与最终业务提交禁用。

Reference：`NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/theme/index.ts`、`src/layouts/BasicLayout/`、`src/styles/` 和 `NEO_FULL_OFFLINE/skills/jlr-frontend-ux/references/NEO_UXUI_PRINCIPLES.md`。theme 原文件与只读快照 SHA 一致，详见交付包 `design-source/SOURCE_MANIFEST.json`。配套布局是独立评审页的适配，不是新增产品 design system。

当前本地页面检查见 `PAGE_VISUAL_CHECK.json`；接口、后台、流程、权限和业务验收仍为 NOT RUN。旧截图及旧检查数不作为本版验收依据。此修订没有改写业务范围或原 prototype。

## 1. 结论与追溯

旧的未来收货计划数据已经不可用，不能继续把旧数据当成有效预测。业务需要先决定：**A 接入新来源，保留原来的预测能力；或 B 批准取消这项输入，并修改依赖它的计算。** 本轮展示两种页面方案，不代业务选定规则。[S1]

建议先确定新数据能否提供及时间；能提供且需保留原功能时优先 A。若必须先上线且业务接受能力变化，再批准 B。Finance 标为 Not Now 不代表可以静默沿用失效数据。

| 项目 | 汇总结果 |
|---|---|
| 原需求 | RTM for Requested Changes / NEO-002，第 3 行；原追溯 P1 CR Clean CR28。[S1] |
| 主要改动类型 | **待方案选择。A：INT-CHANGE — 外部数据契约/来源修改 + APP 应用适配；B：APP — 内部计算修改 + 停用既有输入。** |
| 接口复用 | A 可评估复用 BODS / MFT / SFTP 传输链路，但新资产及字段契约尚未确认，不能写“已有接口直接可用”。B 也需安排停用接收、调度及运维清理。 |
| 新架构 | 当前没有证据必需新增平台；若新资产只能通过不同协议/平台提供，再单独评估。 |
| 主 Epic | **CNP-235 — NEO Epic 4 - Finance and continuity**，对应 ACT-050 / FR18。[S4] |
| 关联 Epic | **CNP-231 — Claims and data 范围**，对应 ACT-001 / ACT-004；该 Epic 正式标题在本地登记中为空，不补造名称。[S4] |
| User Story | **ACT-050 Auto PAM Report**：输出预测；**ACT-001 Create Claim / ACT-004 Update Claim**：POA 计算的消费场景。此为变更关联建议，不宣称这些故事现已覆盖新数据源。[S4] |
| 直接影响 FR | **FR8**：实际及剩余财年财务影响；**FR18**：预测报表计算及输出。[S2] |
| 关联 FR | **FR1.6、FR6/6.1**：录入/更新后重算；**FR9.1/9.4、ACT-012 Submit Settlement Request**：若授权边界比较使用这些金额，需回归，比较口径待确认。 |
| 不直接等同 | **ACT-054 FTO Refresh、FR8.1、FR19.12** 不直接等于本需求。FTO 和预计收货计划是两种数据；只有选 B 并确认改用 FTO 金额时，才进一步核对这些关联。[S2、S4] |
| UC | 现有 UC-24 文件回读仅覆盖输出一部分；原粗映射的 ACT-054 / UC-07 不能证明生产计划链路覆盖。需补“新源导入→POA Finance impact→AutoPAM”或“停用后替代口径”场景，编号待正式登记。[S6] |
| 页面 | **P1.1.2 — Line Detail / Calculations**（沿用既有登记，主要页面）；**P6.7 — Auto PAM Report**（输出消费页面）。创建向导 P2.6.3 Calculation 需检查同一结果组件，页面号沿用已有 ACT-001 登记。 |
| Priority | 原表 Finance = **Not Now**，Procurement 空白。建议 **P0 决策、P2 接源候选**；若继续保留该能力且无有效来源，接源是相应上线场景的前置。P2 不是可带错数据上线的许可。 |
| 状态 | 两种独立页面方案可评审；未连接接口、未修改产品、功能验收全部 **NOT RUN**。 |

## 2. 用人话理解：缺的是“以后会收到多少零件”

NEO 有两种不同的问题：

- 已经收了多少货？FR8 的 Actual Financial Impact 使用实际收货记录。
- 后面还会收多少货？FR8 的 Remaining Financial Year Impact 使用未来收货计划，再乘价格变化，形成剩余影响；与实际影响合并为 Calendarized Financial Impact。[S2]

**FTO 的全年/期间 Buyer Forecast 不是同一个数。** 不能因为页面都写 Forecast，就把两者替换或叠加。

原需求提出按零件、工厂、月份取得新预计收货量；原 BRD 使用周计划；现有接口 SQL 则列出日期和数量。这三种粒度要先约定如何对应，不能直接复制现有周计算逻辑。[S1、S2、S3]

## 3. 页面方案：Calculations

页面继续沿用现有 After 的顶栏、记录页横向 Tabs、Buyer Forecast Calculations 和 Finance impact 分区。**业务界面不提供“选 A / B”开关**；独立 HTML 顶部的开关仅供本次设计评审。

### A：新数据源有效，保留原字段

![A：新来源有效时的计算页面](NEO-002_Page_A.png)

| 页面元素 | 处理 |
|---|---|
| Buyer Forecast Calculations、Full Fiscal / Calendarised FTO 结果 | 保留。不要把生产计划接源变更误做成 FTO 上传/刷新变更。 |
| Finance impact → Actuals by fiscal year | 使用确认的实际收货口径，本条不改变其来源。 |
| Remaining forecast | 使用新来源经校验的预计收货量，按批准的期间及价格变化计算。 |
| Calendarised impact | 按确认口径合并实际与剩余影响，保留对应计算版本。 |
| 新增控件 | 不新增业务人员手工选择数据源、编辑接口或调整计算公式的控件。 |

### A：数据缺失时的状态

![A：未来计划缺失时的页面](NEO-002_Page_Missing.png)

建议：缺少未来计划时，Remaining forecast 和依赖它的合计显示 **—**，说明无法计算；保留仍有效的实际值和 FTO 结果。**缺数据不等于零。** 是否禁止某类申请或只阻止相关金额校验，需要业务确认，不在本方案中擅自规定。[设计建议]

### B：经批准取消该输入

![B：取消输入后的计算页面方案](NEO-002_Page_B.png)

本图展示 B 的“移除依赖字段”分支：保留 Actuals 和独立的 FTO 结果，移除依赖生产计划的 Remaining forecast / Calendarised finance impact。**只有业务批准降低这项能力后才能实施。**

原需求也提出 B 的另一种做法：改用页面已有 annualised / calendarised 金额。这需要确认选哪个金额、字段名称是否变化、能否与 actuals 相加及审批如何比较；本轮不把未知的替代公式画成已确定字段。[S1:P3]

图中 NEO-L-00001、Alice Morgan、P2001 / PL02 及金额仅为独立设计数据，不代表当前用户记录或 Finance 标准样例。以 £10 的成本增加举例：FTO 1,000 件对应负向 £10,000；示例实际 200 件对应负向 £2,000；新计划 300 件对应负向 £3,000，财务合计为负向 £5,000。期间 FTO £5,000 另设为演示值，数字相同不表示两种指标等价；实际符号、期间分配及精度须由 Finance 确认。

P6.7 Auto PAM Report 的 File / Created On 页面结构沿用 NEO-001；文件内计算口径与 Summary / PAM Full 需要同步回归，不再新增报表管理页面。

## 4. Solution、Change 和 Impact

| 层面 | A：接新源 | B：取消输入 |
|---|---|---|
| 数据来源 | 确认新资产 JLR_DL_EDW_RDY_DP0015_SUPPLIER_SCHEDULES_ACCESS 的真实表、字段、授权及交付方式。它只是资产名，不是已确认 API endpoint。 | 停止使用旧生产计划数据；FTO 和 GR 不随之删除。 |
| 应用处理 | 校验零件、工厂、供应商、日期/月份、数量及提取版本；按确认规则聚合，计算 POA 和 AutoPAM。 | 修改依赖项；移除或明确改名后的替代计算，联动 NEO-001。不能把实际金额伪装成实际+未来合计。 |
| 前端 | 主体字段保留；增加必要的缺数据提示，不暴露接口诊断文字。 | 按确认方案移除依赖字段，或显示经批准且名称准确的替代指标。 |
| 后端 / 数据库 | 适配数据粒度、去重、增量/替换、有效期与回读。当前字段能否复用需核对，不能直接复制旧表结构。 | 停用依赖的计算读取；历史版本/追溯保留范围待确认。 |
| 调度 / BPM | 核验原日调度、传输成功/失败、补跑与重算触发；无依据新增审批链。 | 取消原输入调度及错误告警是否仍有其他消费者，须先查清；报表生成调度仍需保留。 |
| 财务 / 审批 | 影响剩余财年预测、合计及使用这些金额的授权比较。 | 原比较依据可能失效，不能只删两列就算完成；需 Finance 和采购批准控制替代方式。 |
| Integration | 原 EDW / GCP → BODS / MFT → NEO 接收链路可作为候选；新契约必须核验。 | 停用现有链路，仍需接口团队协调；不是“无任何集成工作”。 |
| 历史结果 | 新源切换不得静默重算已批准或冻结结果。 | 停用也不得抹去旧计算证据。 |

## 5. 接口、字段与来源：目前能确认到哪里

原接口登记 **Id 18 / MFT E2SC** 写明：GCP Data Lake → Appian，BODS 为中间系统，通过 MFT / SFTP 获取 CSV ZIP。将来由新 NEO 替换 Appian 的接收处理；新资产的数据提供接口由谁实现尚待确认。[S3]

| 当前登记字段 / 传输 | 对应作用 | 本次还缺什么 |
|---|---|---|
| LOCATION_ID | 地点标识；候选映射到 Plant | 地点与 NEO Plant Code 的正式对应，不直接认定同码。 |
| ITEM_ID AS SUPPLIER_ITEM_ID | 供应商零件标识；候选关联 Part | JLR Part 与 Supplier Part 的转换、后缀及重复情况。 |
| SUPPLIER_ID | 供应商标识 | 与 Vendor / GSDB 的对应和适用粒度。原需求的 Part/Plant/Month 不能据此丢掉供应商维度。 |
| DCI_DATE AS FORECAST_DATE | 预计收货日期 | 新源月数据与原周/日期数据如何分摊；当前周、财年边界如何算。 |
| DCI_QTY AS FORECAST_QTY | 预计数量 | 单位、零值、负值、取消计划、同键多行如何处理。原 SQL 的 DCI_QTY >= 1 不自动成为新源规则。 |
| CREATION_DATE / EXTRACT_DATE | 创建/提取时间 | 新源快照版本、过期判定与切换规则。 |
| /outbound/NEO_Part_Forecast_data.zip | 原文件路径 | 新源是否继续此路径、文件名/CSV header、压缩格式、失败回执及重传方式。 |
| 原 SQL：当日至未来 12 个月 | 原提取窗口 | 新源覆盖窗口是否满足整个适用财年；不能把历史 SQL 日期硬编码到新方案。 |

调度登记 Sheet 1 第 15 行 / Id 6：Fetch Future Forecast data，进程 MCI Update MFT E2SC Data Scheduler，Daily、09:30，记录耗时 4 minutes、1 Day Delete。[S7] **09:30 时区、4 minutes 的含义及清理范围仍需确认，不能当作 SLA 或当前运行证明。**

资料另有命名差异：最新 Finance 描述写 E2SE，原 BRD 和接口登记写 E2SC。应确认是否为同一旧来源，不自行合并名称。

## 6. 业务确认问题（人话 + 例子）

| 问题 | 背景 / 例子 | 需要确认什么、影响哪里 | 建议回答人 |
|---|---|---|---|
| Q1：我们还要不要“未来还会收多少货”这项预测？ | 旧数据已失效。选 A 要接新源；选 B 会改变原来的预测能力。 | 选择 A，或批准 B 的移除/替代方案；影响 FR8、FR18 及排期。 | Finance + 采购业务负责人 |
| Q2：如果不用未来计划，页面已有哪个金额可以代替？ | 已收货影响 £2,000，全年 FTO 预测 £10,000；不能直接认为剩余是 £8,000，两者依据可能不同。 | 指定字段、公式、名称和能否与实际值合并；不确认就只展示方案，不实施替换。 | Finance |
| Q3：新源只有每月数量，遇到月中生效或当前周怎么算？ | 11 月计划 300 件，价格 15 日生效：按实际计划分布、按天分摊，还是别的规则？不能自行取 150 件。 | 时间粒度及期间分配；影响 POA 金额与 AutoPAM。 | Finance + 数据负责人 |
| Q4：今天没收到文件，这笔单还能继续吗？ | 页面有已收货影响，但没有未来计划；这不代表未来数量为 0。 | 等待、仅提示、阻止哪类金额比较/提交，以及是否允许有版本标识的历史值；确定边界而非一律阻断。 | Finance + 采购流程负责人 |
| Q5：新数据来了，已批准的单是否重算？ | 昨天批准时预测 £5,000，今天新计划变成 £7,000。 | 区分最新预测与已批准依据；是否重审、历史保留、重算时点。 | Finance + 审批政策负责人 |
| Q6：Settlement 是否还用这个数判断超出 Mandate？ | 若删掉 Remaining forecast，原来“实际+未来”比较所需金额可能不完整。 | 指定继续采用的比较字段、币种、版本和容差；影响 ACT-012、FR9.1/9.4 的回归。 | Finance + 采购审批负责人 |
| Q7：FTO Refresh 是否应该顺便更新生产计划？ | GFS/FBP 现在刷新 FTO，未必代表也要重新拉未来收货计划。 | 明确是否需要联动；未确认前不扩展 ACT-054 权限或行为。 | Finance + 现有 NEO 团队 |

技术材料需同步取得：新资产 schema / 样例、数据提供团队、权限开通、字段映射、月/周口径、调度时区、回执及补跑说明、Finance 标准金额。不是让业务用户填写接口 endpoint。

## 7. 验收要点与退出条件

| 场景 | 预期 | 实际结果 / 状态 |
|---|---|---|
| 新源键与数量（A） | 按批准的 Part / Plant / Vendor / Period 映射回读；重复或无法匹配的数据有明确处理。 | 未执行 / NOT RUN |
| 月、周、财年边界（A） | 按签收规则分配；与 Finance 标准样例一致。 | 未执行 / NOT RUN |
| 缺文件、空结果、迟到与重复文件 | 缺数据不作零；重跑不重复累加；过期判定和恢复遵守确认规则。 | 未执行 / NOT RUN |
| 实际 + 剩余影响 | 期间不重叠、不漏算，POA 明细与合计可对账。 | 未执行 / NOT RUN |
| 取消输入（B） | 不再读取失效数据；移除/替代字段、AutoPAM 及授权比较按批准方案一致更新。 | 未执行 / NOT RUN |
| FTO 独立性 | 未批准联动时，FTO Refresh、FTO 上传及其金额不被本条误改。 | 未执行 / NOT RUN |
| 历史、批准与重算 | 保存原审批依据，按确认范围使用新版本；不能用新金额覆盖历史批准证据。 | 未执行 / NOT RUN |
| 报表及输出 | POA 与 AutoPAM 使用各自已确认计算版本；文件内容、格式和 GCP 输出回归。 | 未执行 / NOT RUN |
| 页面 / 权限 | 明确缺失状态、保留必要业务信息；不出现业务用户切换 A/B 的控件或无授权新增操作。 | 未执行 / NOT RUN |

进入开发：先批准 A/B，取得相应的数据契约或替代规则，以及 Finance 样例。完成验收：在指定环境执行适用场景，保存版本、记录、实际金额、接口回读和页面证据。当前独立页面检查不代表接口、计算或业务通过。

## 8. Reference 与本轮映射纠正

- **S1** `/Volumes/KIOXIA/JLR Appian/8.需求文档/1112 NEO 新需求/NEO Business Requirements (added China requirements) 1.xlsx`，`RTM for Requested Changes!A3:R3`，重点 E3、L3、N3、P3；关联 NEO-001 的 P2。来源声称数据停用，本轮未访问源系统实测。
- **S2** `/Volumes/KIOXIA/JLR Appian/6.技术方案/2 - Tech NEO/Material Cost & Inventory - BRD V3.1.docx`，第 6 表第 19 行 FR8（E2SC 周计划、GR、剩余及合计）；第 20 行 FR8.1（FTO）；第 64 行 FR19.12（FTO 上传）；第 51 行 FR18（报表）；第 8 行 FR1.6（Parts）。表/行从 1 开始，不虚构 Word 页码。
- **S3** `/Volumes/KIOXIA/JLR Appian/6.技术方案/2 - Tech NEO/Integrations - 2026-11-09_0941(Sheet 1).csv`，物理第 24 行，Id 18 MFT E2SC；第 6 行为表头。描述、来源/目标/中间系统、路径及 Additional Details 的 SQL。不是新资产的完整契约。
- **S4** `/Volumes/KIOXIA/JLR Appian/outputs/neo-jira-stories-20261111/v3/story_data.json`，entries ACT-001、004、012、050、054；Epic CNP-231、233、235。编号为既有本地映射，本轮未查线上 Jira。ACT-054 指 FTO，不能据此证明新源流程已覆盖。
- **S5** `/Volumes/KIOXIA/JLR Appian/NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Parts/CalculationResults.tsx`，Buyer Forecast、Finance impact 字段；`src/views/Claim/sections/SavedCalculation.tsx`，已保存结果及过期提示；`src/domain/p03/calculation.ts`，CalculationPolicy / sources.weekly / remainingGbp / financialImpactGbp。只读源码对照，不是现网验收。
- **S6** `/Volumes/KIOXIA/JLR Appian/outputs/01a0bcc6-9999-7af1-b627-6be523cbcea0/new-requirements/analysis.json`，NEO-002 trace 登记。**本轮纠正：原粗映射 ACT-054、FR19.12、FR8.1 不足；应直接关联 FR8、FR18，FTO 只保留条件关联。** 原文件不静默覆盖，此汇总明确记录差异。P1.1.2 和 P6.7 继承登记；P2.6.3 来自前序 ACT-001 页面核对记录，非新建编号。
- **S7** `/Volumes/KIOXIA/JLR Appian/6.技术方案/2 - Tech NEO/Scheduler Processes - 2026-11-09_0944.xlsx`，Sheet 1 第 15 行 / Id 6，Fetch Future Forecast data。
- **S8** `/Volumes/KIOXIA/JLR Appian/NEO_FULL_OFFLINE/skills/jlr-frontend-ux/references/NEO_UXUI_PRINCIPLES.md`，页面排版依据；独立方案只借用视觉原则，未改产品组件。

## 9. 交付范围

NEO-002_Consolidated_CN.html 为统一阅读入口，内嵌三张页面状态图；NEO-002_Consolidated_CN.md 为可编辑文本；NEO-002_Page_Proposal.html 为独立交互评审页。方案选择控件只用于设计评审，正式业务页面不含该控件。

所有输出只写入 solution-review/NEO-002；未修改 NEO prototype、原需求工作簿、QA 权威表、Jira 或部署。下一条为 NEO-003：刷新 SAP 价格。
