# NEO-008 · Before / After process

Priority: Must (Procurement: —; Finance: Must)

ACT-029 / ACT-030 · FR6.3 / FR17 / FR17.5

## 预付款固定实施月汇率

沿用 Reserve 页面和审批；修改非 GBP 预付款的换算基础，后续余额仍可随摊销变化。

### Before · 现有路径

1. **FBP · 维护预付款分类** — 在现有 Edit Reserve Data 中维护会计分类。
2. **GFS／Finance · 按最新月汇率重算剩余余额** — 按需求原文描述的旧逻辑，USD 剩余余额 × 最新月汇率。例：12 月 USD 50,000 × 0.72 = GBP 36,000；尚未计入抵消重估的 Memo。
3. **历史需求记录 · 人工抵消汇率重估** — 需求表记载使用最新月汇率重估后，GFS 需通过 Memo 抵消；这不是本轮对现网的测试结果。

### After · 建议路径

1. **FBP → 计算服务 · 识别预付款与实施版本** — 读取已保存的分类、原币金额及实施证据，不在生成 Reserve 时让用户随意改分类。
2. **计算服务 · 固定实施月 GBP 基础** — 在实施时固定基础：USD 100,000 × 0.80 = GBP 80,000，保留实施月及汇率版本。后续不能被最新月 0.72 或 0.85 覆盖。
3. **GFS／Finance · 按期间余额计算并核对** — 本例剩余 50%：GBP 80,000 × 50% = GBP 40,000。剩余余额变化时准备金仍会变化；固定的不是每月总额。
4. **Finance · 沿用 Final 审核与历史快照** — 缺历史汇率时该行标为待处理；更正汇率生成新版本，不覆盖原 Final。

### 例子

同一笔 USD 100,000 预付款：实施时固定 GBP 80,000；下面逐期对比旧、新算法和实际影响。

同一笔已实施、标记为 Prepayment 的非 GBP NEO ID，原金额 USD 100,000，10 月实施。汇率统一为 GBP per USD：1 USD = GBP 0.80。各期剩余比例仅用于说明；假设没有新增金额、退款、历史更正或 Memo。

- Before：本期外币剩余余额 × 最新月汇率。每个月重新换算，余额和汇率都可能使 GBP 准备金变化。
- After：实施时保存 GBP 基础 = USD 100,000 × 0.80 = GBP 80,000；本期准备金 = 固定 GBP 基础 × 本期剩余比例。本例也等于 USD 剩余余额 × 0.80。

| 时点／场景 | 原币剩余余额 | 该月汇率 | Before：按该月汇率 | After：按固定 GBP 基础 | After − Before |
| --- | --- | --- | --- | --- | --- |
| 10 月实施 · 剩余 100% | USD 100,000 | 0.80 | 100,000 × 0.80 = GBP 80,000 | GBP 80,000 × 100% = GBP 80,000 | GBP 0 |
| 11 月 · 剩余 60% | USD 60,000 | 0.75 | 60,000 × 0.75 = GBP 45,000 | GBP 80,000 × 60% = GBP 48,000 | +GBP 3,000 |
| 12 月 · 剩余 50% | USD 50,000 | 0.72 | 50,000 × 0.72 = GBP 36,000 | GBP 80,000 × 50% = GBP 40,000 | +GBP 4,000 |
| 次年 1 月 · 仍剩余 50% | USD 50,000 | 0.85 | 50,000 × 0.85 = GBP 42,500 | GBP 80,000 × 50% = GBP 40,000 | −GBP 2,500 |
| 后续全部摊销 · 剩余 0% | USD 0 | 0.85 | 0 × 0.85 = GBP 0 | GBP 80,000 × 0% = GBP 0 | GBP 0 |

#### 影响是什么

- 金额：12 月 Before 为 GBP 36,000，After 为 GBP 40,000，差 GBP 4,000。这是同一期的估值差，不是新增 Claim、节省或收付款。各期差额不可直接累计。
- 跨月变化：After 从 11 月 GBP 48,000 降到 12 月 GBP 40,000，减少 GBP 8,000 来自剩余比例 60% → 50%。次年 1 月余额不变，即使汇率升至 0.85，After 仍为 GBP 40,000；Before 却升至 GBP 42,500。
- 人工调整：原需求记载 GFS 需要 Memo 抵消汇率重估。新计算应消除这一项抵消需求；上线时逐 ID／期间核对旧 Memo，避免已经得到 GBP 40,000 后又叠加旧 GBP 4,000 调整。不是取消全部 Memo，也不自动删除旧记录。
- 受影响位置：ACT-030／FR6.3 的 Prepayment 分类决定是否适用；ACT-029／FR17 的生成、明细、预付款汇总及使用这些金额的导出要一致。相关账务输出需按已确认映射对账，不能仅凭 GBP 4,000 指定借贷或自动过账。
- 实现与范围：保存实际实施月、原币金额、币种、采用汇率及版本、固定 GBP 基础；后续生成读取同一基础。保留现有页面入口及审批。这里只改非 GBP Prepayment；Loans、Deposits、Buyer Forecast、DoA 不随之改变。

固定的是汇率基础，不是每月准备金金额。60%、50%、0% 不是新业务规则；实际摊销、部分实施、退款和更正按 Finance 确认的规则。Before 算式依据需求表 E9／P9 描述的旧问题，未作为当前 prototype 或现网实测。

Reference: R-1113 E9 / P9; S3-17 FR6.3; S3-42 / S3-47 FR17 / FR17.5.


### 保留控制

- 不改变 Loans、Deposits、Buyer Forecast 或 DoA；旧 Memo 需核对，不能自动删除。
- 查询失败或缺汇率显示未知，不能当作 0、1 或回退到最新月。

### 正式实施前补齐

- Finance 提供实施时间定义、适用汇率和两期金样；Monex／BODS 团队提供历史汇率及更正版本。

## Fix prepayment FX at implementation

Keep the Reserve pages and approvals. Change the FX basis for non-GBP prepayments; remaining balances can still change through amortisation.

### Before · Existing path

1. **FBP · Maintain the prepayment classification** — Maintain the accounting classification in existing Edit Reserve Data.
2. **GFS / Finance · Reconvert the remaining balance at the latest monthly rate** — Under the old logic described in the request, remaining USD × latest monthly FX. Example: December USD 50,000 × 0.72 = GBP 36,000, before any Memo offset.
3. **Historical requirement · Manually offset FX revaluation** — The request records latest-month FX revaluation and GFS Memo offsets. This is a reported historical problem, not a fresh production test.

### After · Proposed path

1. **FBP → Calculation service · Identify the prepayment and implementation version** — Read the saved classification, source-currency amount and implementation evidence; do not change classification ad hoc during generation.
2. **Calculation service · Fix the implementation-month GBP basis** — Fix the basis at implementation: USD 100,000 × 0.80 = GBP 80,000, retaining the implementation month and rate version. Later rates of 0.72 or 0.85 must not replace it.
3. **GFS / Finance · Calculate and review the period balance** — With 50% remaining in this example: GBP 80,000 × 50% = GBP 40,000. Reserve still changes as the balance changes; the monthly amount is not frozen.
4. **Finance · Retain Final review and historical snapshots** — Flag an affected row when its historical rate is missing. Rate corrections create a new version without overwriting the original Final.

### Example

One USD 100,000 prepayment fixes GBP 80,000 at implementation. Compare each period, the two formulas and their effects below.

One implemented non-GBP NEO ID is flagged Prepayment: USD 100,000, implemented in October. Rates are GBP per USD: USD 1 = GBP 0.80. Remaining percentages are illustrative; assume no additions, refunds, historical corrections or Memos.

- Before: remaining foreign-currency balance × the latest monthly rate. Both the outstanding balance and FX can change the GBP Reserve each month.
- After: store the implementation GBP basis = USD 100,000 × 0.80 = GBP 80,000; period Reserve = fixed GBP basis × the remaining proportion. In this example this also equals the remaining USD balance × 0.80.

| Period / scenario | Remaining source balance | Monthly FX | Before: monthly FX | After: fixed GBP basis | After − Before |
| --- | --- | --- | --- | --- | --- |
| October implementation · 100% remains | USD 100,000 | 0.80 | 100,000 × 0.80 = GBP 80,000 | GBP 80,000 × 100% = GBP 80,000 | GBP 0 |
| November · 60% remains | USD 60,000 | 0.75 | 60,000 × 0.75 = GBP 45,000 | GBP 80,000 × 60% = GBP 48,000 | +GBP 3,000 |
| December · 50% remains | USD 50,000 | 0.72 | 50,000 × 0.72 = GBP 36,000 | GBP 80,000 × 50% = GBP 40,000 | +GBP 4,000 |
| Following January · still 50% | USD 50,000 | 0.85 | 50,000 × 0.85 = GBP 42,500 | GBP 80,000 × 50% = GBP 40,000 | −GBP 2,500 |
| Later fully amortised · 0% remains | USD 0 | 0.85 | 0 × 0.85 = GBP 0 | GBP 80,000 × 0% = GBP 0 | GBP 0 |

#### What changes

- Amounts: December is GBP 36,000 Before and GBP 40,000 After, a GBP 4,000 valuation difference for that period. It is not a new Claim, a saving or a cash movement. Do not add differences across periods.
- Period movement: After falls from GBP 48,000 in November to GBP 40,000 in December because the remaining proportion falls from 60% to 50%. In January the balance is unchanged, so After stays GBP 40,000 even at FX 0.85; Before rises to GBP 42,500.
- Manual adjustments: the request reports GFS Memos reversing FX revaluation. The corrected calculation should remove that specific offset need. Reconcile existing Memos by ID and period so the GBP 40,000 result does not receive the old GBP 4,000 adjustment again. Do not cancel all Memos or delete historical records automatically.
- Affected locations: ACT-030 / FR6.3 Prepayment classification determines eligibility; ACT-029 / FR17 generation, details, prepayment totals and exports consuming those amounts must agree. Reconcile related accounting outputs to agreed mappings; the GBP 4,000 difference alone does not define debit / credit entries or authorise posting.
- Implementation and scope: retain the actual implementation month, original amount, currency, rate and version, and fixed GBP basis; reuse that basis for later periods. Keep existing page entry points and approvals. Only non-GBP Prepayments change here; Loans, Deposits, Buyer Forecast and DoA are unchanged.

The FX basis is fixed, not the monthly Reserve amount. The 60%, 50% and 0% figures are not new policy: Finance must confirm amortisation, partial implementation, refunds and corrections. The Before formula illustrates the historical problem described in E9 / P9; it is not a fresh test of the current prototype or production.

Reference: R-1113 E9 / P9; S3-17 FR6.3; S3-42 / S3-47 FR17 / FR17.5.


### Controls retained

- Do not change Loans, Deposits, Buyer Forecast or DoA; reconcile existing Memos rather than deleting them automatically.
- An unavailable rate stays unknown; never use zero, one or the latest month as a silent fallback.

### Production dependencies

- Finance supplies the implementation-date definition, rate basis and two-period golden cases; Monex / BODS supplies historical and corrected rate versions.

## Sources

- **R-1113** NEO Business Requirements (added China requirements) 2(RTM for Requested Changes)_1113 1400 version.xlsx · NEO Business Requirements (adde!E9,N9,P9,Q9; priorities K9:L9
- **S1** NEO Business Requirements (added China requirements) 1.xlsx · RTM for Requested Changes!A9:R9
- **S3-17** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 17
- **S3-42** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 42
- **S3-47** Material Cost & Inventory - BRD V3.1.docx · Table 6 row 47
- **S4** Integrations - 2026-11-09_0941(Sheet 1).csv · CSV parsed logical record 25; Id19
- **S6a** ClaimReserve.tsx · lines 1-35
- **S6b** MonthlyList.tsx · lines 1-125
- **S2** NEO Business Requirements (added China requirements) 1.xlsx · P1 CR clean!A25:Y25

Before: frozen prototype `3ff8bc0b158ba08f2302e7404bb6185a553088c78614051451e6b5137a26802e`. Historical problems are labelled separately. After is a proposal; numerical examples are illustrative. Production execution: NOT RUN.
