# NEO-008 · 预付款固定实施月汇率

<!-- FLOW-REVIEW-20261116 -->
## 16 Nov 2026 · 流程评审补充

[中英文 Before / After 流程](NEO-008_Before_After_Flow.html) · [流程说明 MD](NEO-008_Before_After_Flow_CN_EN.md)

沿用 Reserve 页面和审批；修改非 GBP 预付款的换算基础，后续余额仍可随摊销变化。

本轮为流程说明补充；原交互页面、问题及历史证据保留。正式实施前需补齐：Finance 提供实施时间定义、适用汇率和两期金样；Monex／BODS 团队提供历史汇率及更正版本。
<!-- /FLOW-REVIEW-20261116 -->

## 1. 一句话说明

非 GBP 的预付款，在实施时记录实施月份汇率及 GBP 换算基础。后续生成 Reserve 时，不因为每个月汇率变了就重新换算这笔已固定的基础；但实际剩余余额、摊销或其他业务变化仍需要正常反映。[S1]

这不是“从实施起 Reserve 永远是一个数字”。本例用 USD100,000 × 0.8 得到 GBP80,000 的原始基础；11月剩余60%为 GBP48,000，12月剩余50%为 GBP40,000。0.8保持不变，余额仍变化。这个比例示例用于解释页面，不是 Finance 已签收的摊销公式。

独立设计包沿用 NEO theme、JLR 字体和 Ant Design。未修改现有 prototype、API、数据库、流程或业务台账；所有示例金额、日期和版本均为合成评审数据。

## 2. 主要改动类型、优先级及关联

| 项目 | 结论 | 依据与边界 |
| --- | --- | --- |
| 主要改动类型 | Application 内部前后端、Reserve 计算及版本存储 | 不只是 UXUI；后端必须保留实施月换算基础 |
| Integration | 优先复用现有 Monex → BODS／MFT → NEO 月汇率渠道 | 已有通道，但历史月份、汇率方向、覆盖范围和更正版本仍需确认 [S4] |
| 新增架构 | 当前无证据要求新增平台或对接系统 | 优先复用现有汇率导入和 Reserve 计算，只有历史数据／契约不满足时再评估扩展 |
| Epic | CNP-235 | ACT-029、ACT-030 的现有本地 Epic 映射 [S5] |
| User Story | ACT-029 Generate Reserve；ACT-030 Edit Reserve Data | 前者使用新计算基础，后者维护分类；不能由 Generate Reserve 页面随意改分类 |
| FR | FR17、FR17.5；关联 FR6.3 | 原 BRD 的普通 Reserve 逻辑与预付款例外需明确区分 |
| UC | UC-23 的生成、审阅、跨月重跑与调整场景 | 扩展既有 UC，不新增已批准 UC 编号 |
| 页面 | P5 Reserve；P5.8 Generate Reserve；P1.1.26 Edit Reserve Data | 本页为 Reserve 明细的增量评审视图，不给既有目录擅自新增编号 |
| 优先级 | 建议 P0 | Finance 原文 Must／Accounting requirement；否则需人工 Memo 抵消重估。P0是实施建议 |
| 历史状态 | CR14：In backlog；No - Backlog；Needs refinement | 历史登记，不代表今天部署状态 [S2] |

## 3. 来源告诉了我们什么

| 来源 | 已确认的材料内容 | 不能自动推出的结论 |
| --- | --- | --- |
| S1 P9 | 非 GBP、标为 Prepayment 的 NEO ID，使用实施月份汇率；固定实施时 GBP 基础，后续 Reserve 基于它计算 | 没有完整规定部分实施、摊销、历史更正或已关闭期间如何处理 |
| S1 E9／S2 D25 | GFS 当前用 Memo line 抵消 FX 重估 | 不能上线时自动删除所有旧 Memo，可能重复抵消或影响已关闭期间 |
| S3 FR6.3 | Non-Standard Accounting 包括 Prepayment、Loans、Deposits；编辑由 purchasing FBP 处理，Purchasing 可见性有约束 | RTM写的是 Non-standard transaction flag，不能直接假定它与该会计分类字段是同一个存储值 |
| S3 FR17 | 按月份生成 Draft／Final，提供预付款及其他 Reserve 总额 | 单条预付款设计不等于完整期间已对账 |
| S3 FR17.5 | 生成 Line 明细、当前／上月金额及 Movement；支持源数据下钻和生成时快照 | 不可用最新汇率重写历史 Final，也不能把本例当全部 Reserve 公式 |
| S4 Id19 | MFT M Exchange Rate，Monex来源，经BODS／MFT取得月汇率ZIP | 接口目录没有完整文件字段、历史保留和修正契约 |
| S6 当前实现 | Claim Reserve 已有 Non-standard accounting；Reserve 列表已有期间、Draft／Final和生成确认 | 本轮只读检查相关组件，不声称整个现有计算引擎已通过或确定缺失 |

## 4. 页面设计

### 4.1 November Reserve

![11月：固定实施月基础，显示本月余额及期间变动](NEO-008_Page_November.png)

沿用 Reserve 页面布局，顶部显示 Line、描述、供应商、会计分类和实施状态。Reserve period 改动后先隐藏旧金额，Apply 后显示对应期间结果。表格保留原币、汇率方向和原币余额，避免把0.8的方向看反。

此视图仅展示本需求受影响的一条预付款。正式集成时仍保留完整 Reserve 的其他列、筛选、账户、分类、权限及各项总额，不以此精简评审页替换整张业务表。

### 4.2 查看固定基础

![估值依据：实施月汇率与本月未采用汇率分开展示](NEO-008_Page_Basis.png)

View valuation basis 显示实施日期、原币金额、实施月汇率版本、固定 GBP 基础及当前余额分配。本月最新汇率仅作为对账参考，明确不参与该固定基础的重估。GBP 本币场景不依赖外币汇率。

### 4.3 跨月余额变化

![12月：基础仍是80,000 GBP，余额变为40,000 GBP](NEO-008_Page_December.png)

本例12月最新汇率为0.72，但预付款仍使用固定基础。假设剩余比例50%，结果是40,000 GBP，而不是50,000 USD × 0.72 = 36,000 GBP。比例来源、摊销安排、精度及冲销规则都要由 Finance 签收；本包仅展示指定fixture的算术。

### 4.4 缺实施月汇率

![缺历史汇率：不自动采用当前月，也不显示零金额](NEO-008_Page_Missing.png)

实施月份汇率未取得时，金额显示“—”，不能继续当前行的 Reserve review。不得悄悄回退到预算汇率、最新月汇率或1。整期是否必须阻断还是允许带异常生成 Draft，列为业务确认问题，不由本页决定。

### 4.5 历史汇率更正

![历史更正：保留原换算基础，新版本单独等待Finance处理](NEO-008_Page_Correction.png)

原基础使用 October V1=0.8；收到 V2=0.82 后，历史基础仍显示80,000 GBP，新版本单独列出。该页面保护原快照，但不替 Finance 决定是否重开期间、调整余额或生成 Memo。

### 4.6 Final 快照

![Final Reserve：期间和金额只读](NEO-008_Page_Final.png)

Final 只能查看原记录，本页不提供再次确认或修改期间。Draft 的 Review Reserve 只预览该 Line；确认按钮禁用，未生成真实 Reserve、Journal、Memo 或 SAP posting。

## 5. Change 与 Impact

| 层面 | 修改内容 | 必须保护什么 |
| --- | --- | --- |
| 分类识别 | 使用已确认的 Prepayment 分类触发例外计算 | 不把 Loans、Deposits、普通Accrual或Provision一并改成固定汇率 |
| 实施事件 | 记录实施日期对应的汇率月份、版本和 GBP 基础 | Implemented 不自动等于支付日、Settlement批准日或 SAP PO创建日；真实日期来源待确认 |
| Reserve 计算 | 后续余额以已固定GBP基础及已确认余额分配规则计算 | 不再次按每月spot换算；余额变化和FX变化分开；保留精度与币种 |
| 数据 | 保存原币金额、固定GBP基础、汇率方向、实施日期、来源及版本 | 不覆盖原值；存量缺历史基础不得凭当前值补造 |
| 前端 | 预付款明细显示来源、固定基础、期间余额、缺失／更正／只读状态 | 同步原有主表和明细，保持原有NEO UXUI；账户未知显示“—” |
| Memo与月结 | 新算法和旧抵消Memo按Line及期间对账 | 不重复抵消，不自动删历史Memo，不改已批准Journal或关闭期间 |
| 报告与导出 | Reserve明细、总额及正式导出引用同一期间快照 | 不能页面是固定基础而导出仍用最新汇率；本包未实现导出 |
| 权限 | GFS生成／核对，FBP依既有权限维护会计信息 | Training与BRD的生成及Purchasing可见性差异仍待确认，不通过页面扩大权限 |

建议内部契约需要明确 originalAmount、sourceCurrency、implementedAt、fxMonth、fxVersion、rateDirection、lockedGbpBasis、remainingAllocation、reservePeriod、calculationVersion。它们是逻辑数据项，不是已确认的 API 字段或数据库列；正式开发应先与现有数据字典匹配。

影响范围是预付款 Reserve 和相关对账，不自动变更 Buyer Forecast、DoA、Mandate 或 Settlement 的原批准金额。

## 6. 接口和依赖判断

| 依赖 | 已有证据 | 需要补什么 | 是否新增 |
| --- | --- | --- | --- |
| 月汇率 | S4 Id19：MFT M Exchange Rate；来源Monex，目标Appian，经BODS；路径 /PROD/Outbound/NEO_Monex_Monthly_Exchange.zip | 文件字段、rate类型、方向、货币对、月份、版本、更正、历史保留、缺失与重跑机制 | 优先复用；未确认新接口 |
| 实施结果 | NEO实施状态是冻结基础的业务触发条件 | 各交易路径真实实施日期来源；延迟回执、部分实施和更正时采用哪一天 | 不等于要直接增加SAP接口，先核对已有结果契约 |
| 已实施存量 | 需要原始金额、实施月份及历史汇率才能补齐基础 | 能否追溯原始换算、是否已被Memo抵消、如何对账与切换 | 存量修复／初始化方案待确认，不自动执行迁移 |
| Reserve服务 | 现有期间、生成、明细和Memo能力 | 固定基础读取、余额分配、快照、重跑和Final保护 | 应用内部扩展 |

## 7. 业务问题：讲人话并给例子

| ID | 问题 | 例子／影响 |
| --- | --- | --- |
| NEO008-Q1 | Prepayment 到底由哪个字段判定？ | 页面 Non-standard accounting=Prepayment，还是主表的 Non-standard transaction flag？两个值不一致时不能自行选一个 |
| NEO008-Q2 | 哪个时间叫“implemented”？部分实施怎么处理？ | 10月批准、11月SAP完成、12月NEO收到回执，固定哪一个月份？若分两批实施，是否各有基础？ |
| NEO008-Q3 | 实施月用哪一种汇率、方向和版本？ | USD→GBP的0.8不能当成GBP→USD；是月末spot还是月均？预算汇率不能自动替代 |
| NEO008-Q4 | 后续余额怎么减少？ | 原基础80,000 GBP，剩余60%是否就是48,000？若有不同批次、退款、摊销或余额更正，需要Finance给golden cases |
| NEO008-Q5 | 缺实施月历史汇率时，一行阻断还是整期阻断？ | 100条中只有1条缺10月汇率，是否可生成带异常Draft？不能当0或直接取11月汇率 |
| NEO008-Q6 | 历史汇率更正或从Loans改成Prepayment，已生成的期间怎样处理？ | 0.8更正为0.82、11月已Final：补差、Memo还是重开？由谁批准？ |
| NEO008-Q7 | 原来为抵消FX重估建的Memo，切换新算法时如何处理？ | 新算法已不重估，但旧Memo仍在，可能再次抵消。需按Line／期间核对，不自动删除 |
| NEO008-Q8 | 适用范围和过渡日是什么？ | 只对上线后实施的非GBP预付款生效，还是包括历史存量？Loans／Deposits暂沿原规则，除非另有确认 |

Finance／GFS确认Q1–Q8；Monex／BODS团队与应用团队补Q2–Q5数据来源和契约。原文提到Dan Smith及历史联系人Helen Jones，不把这些名字当作已确认的当前负责人。

## 8. 检查和验收

本包 51 项本地页面检查通过，记录在 PAGE_VISUAL_CHECK.json，验证页面内的指定fixture：11月与12月余额变化、固定换算基础、GBP不换汇、缺历史数据、未实施、历史修正、非预付款、Final只读、返回保留选择、移动端及桌面布局。

本次没有真实汇率文件、Reserve生成、持久化、权限服务、Journal或Finance验收。以上均为 NOT RUN；本地fixture算术通过不能证明正式会计公式正确。

| 正式退出条件 | 状态 |
| --- | --- |
| 分类字段、实施时间、汇率种类和余额计算已签收 | 待确认 |
| 取得历史月汇率、源金额及完整更正样例，核对存量来源 | 待确认 |
| 同一Line跨两个月，含余额变化、无变化、退款／部分实施等Finance golden cases | NOT RUN |
| 重跑不重复生成／不覆盖Final，未知提交结果先回读 | NOT RUN |
| 旧Memo、新算法、Reserve总额和Journal逐期对账 | NOT RUN |
| 权限、页面、明细和正式导出全部一致并经Finance验收 | NOT RUN |

下一步先签收实施时点及余额分配规则，再补固定GBP基础的数据契约；随后在现有Reserve服务上开发，用完整期间和旧Memo共同对账。本独立评审不会修改 prototype，也不会自动执行存量修复。

## 9. Source／Reference

| Source | 文件与位置 | 用途 |
| --- | --- | --- |
| S1 | NEO Business Requirements (added China requirements) 1.xlsx；RTM for Requested Changes!A9:R9，重点E9、P9 | NEO-008原文、实施月汇率及固定GBP基础 |
| S2 | 同工作簿；P1 CR clean!A25:Y25，CR14 | 历史痛点、Memo抵消、原状态与联系人 |
| S3 | Material Cost & Inventory - BRD V3.1.docx；表6第17、42、47行；FR6.3、FR17、FR17.5 | 会计分类、Reserve生成、明细与快照 |
| S4 | Integrations - 2026-11-09_0941(Sheet 1).csv；解析后第25条逻辑记录；Id19 | Monex月汇率BODS／MFT通道，不是完整payload |
| S5 | outputs/neo-jira-stories-20261111/v3/story_data.json；entries.act=29、30 | ACT／Epic／FR本地映射与已有权限疑问 |
| S6 | app/src/views/Claim/sections/ClaimReserve.tsx；app/src/views/Reserve/MonthlyList.tsx | 当前组件只读参考；完整路径、行号和哈希见证据JSON |
| S7 | app/src/theme/index.ts及项目jlr-frontend-ux设计原则 | 现有NEO样式，不另立设计系统 |

SOURCE_EVIDENCE.json 保留完整路径、准确摘录及SHA-256。Word“表6第47行”是结构行，不是文档页码；CSV按逻辑记录计数。原始资料没给出的内容保持待确认。
