# NEO-007 · FTO／GR 较高影响值与 Settlement DoA 复核

## 1. 一句话说明

审批不能只看一套金额。先确认 FTO 和 GR 的金额是在可比较口径下计算的，再根据确认的较高值规则判断 DoA；到了 Settlement，再对照原 Mandate 的批准范围和金额，判断是否需要补批。不是换一个金额标签，也不是金额没超就自动放行。[S1、S2、S3]

本包是独立页面方案。使用 NEO 的实际 React theme、JLR 字体及 Ant Design 组件，未修改现有 prototype、后台、数据库、流程或线上配置。截图中的金额、人员、期间和版本均为评审用合成场景，不代表签收的 DoA 规则或真实已批准记录。

## 2. 分类、优先级与关联

| 项目 | 结论 | 依据与边界 |
| --- | --- | --- |
| 主要改动类型 | Application 内部前后端、计算、数据快照及审批流程修改 | 不属于 UX/UI only；页面必须使用服务端的同一评估结果 |
| Integration | 现有 SAP／Apigee GR 查询为复用候选；可能需要补字段或扩展契约 | 已有 MCI_getGoodsReceiptDetails；尚未证明它提供本次所需完整口径 [S4] |
| 新增架构 | 当前资料不能证明需要新增平台 | 优先扩展现有估值、审批评估和版本存储；不另造审批引擎 |
| Epic | CNP-233 · 现有 ACT-010／012／013／032 所属 Epic | 本地 story_data 中的映射，非本次 Jira 写入 [S5] |
| 主 User Stories | ACT-010 Request For Mandate；ACT-012 Submit Settlement Request；ACT-013 Approval Check | Mandate 评估、Settlement 重评、FBP 决策 |
| 配置关联 | ACT-032 Edit DOA Rules | 只说明需消费已签收政策，不擅自新增阈值或扩权 |
| FR | FR9、FR9.1、FR9.4、FR9.5；关联 FR10.6 | CR9 原文称 Added to FR10.6；旧 BRD FR10.6 描述审批及完成，不能假装已有完整 FTO／GR 算法 [S2、S3] |
| UC | 关联 UC-11／12／18；扩展 UC-14 审批检查；UC-13 为关联路由 | 沿用既有映射建议，不新增已批准 UC 编号；本次补增量场景 |
| 页面 | P4.2／P9.3 Mandate；P4.3／P9.4 Settlement；P4.1.7 Approval Check；P7.2 Manage DoA | 沿用旧目录双入口编号；它们不是本次新增四套独立页面 |
| 优先级 | 建议 P0，先于新的自动审批路由上线 | Finance 原始优先级 Must；选错金额会少批或错批。P0 是本次实施建议，不替代原 CR 历史排期 |
| 历史状态 | CR9：In refinement and design；Partially developed but not deployed | 是历史登记文字，不能证明今天仍如此或已上线 [S2] |

## 3. 原文和已有能力

| 来源 | 原文或已观察事实 | 对设计的影响 |
| --- | --- | --- |
| S1 E8 | DOA approval based on higher of FTO or GR value. Subsequent DOA check in settlement to ensure DOA fully discharged | 两套金额比较与 Settlement 第二次检查都需保留 |
| S2 D21／V21 | 金额判断错误会造成审计不合规；新信息使金额增加时应提示重新审批 | 不能沿用过期金额或把金额更新当作显示刷新 |
| S3 FR9／FR9.1 | Request total – Risks 与 Request total – Opportunities 分开汇总 | 不允许用风险和机会简单抵销后决定审批级别 |
| S3 FR9.4 | Settlement 未超过原 Mandate 时仍由 FBP 决定是否进一步审批；选择不再审批则引用原 Mandate，并生成 GFS 检查任务 | “金额被覆盖”不等于“自动批准”，不直接跳到外部实施 |
| S3 FR9.5／FR10.6 | 可配置 DoA、实际审批人、批准人及时间记录 | 界面展示结果，实际级别和人选由当前签收政策及授权配置确定 |
| S6 当前组件 | Approval Check 已有 Yes／No、必填评论、确认边界；Settlement 引用前次申请并显示风险／机会总额 | 复用这些交互，只增加金额依据和复核信息；本轮未完成产品全链路审计，不能据此断言所有逻辑缺失 |

关键未决：原文没有说清“higher”是带符号数字比较，还是风险／机会分别按敞口绝对值比较；也没有确认先逐 Line 选高再汇总，还是先分别汇总 FTO／GR 再选高。页面先用单条、同币种、同期间的正数敞口作示例，不能将示例的 Math.max 实现直接搬成业务算法。

## 4. 页面方案与交互

### 4.1 Settlement 金额增加

![Settlement：FTO 80,000、GR 120,000，对比原批准 90,000](NEO-007_Page_Increased.png)

保留 NEO 顶栏、面包屑、页面边距和表格样式。Approval Check 内新增 DoA assessment 区域：逐 Line 显示 FTO、GR、评估金额和选用依据，下方对照原 Mandate 编号、版本、金额和范围。本例增加 30,000 GBP，提示需要进一步审批；审批级别标为等待政策评估，不根据样例金额猜 LL5／LL6。

### 4.2 查看金额来源

![金额依据：两套来源、计算版本、期间和币种](NEO-007_Page_Basis.png)

“View amount basis” 打开弹窗，显示 FTO／GR 来源快照及计算引用。正式数据模型应保存源币、评估币、汇率类型与版本、期间、匹配键和计算版本。当前同币 GBP 示例不触发换汇；不能解释为所有审批一律用 GBP。

### 4.3 未超原批准金额

![原批准范围内：仍由 FBP 决定是否补批](NEO-007_Page_Covered.png)

本例评估金额 90,000，原批准 100,000。FBP 必须明确选择是否仍需审批，并留下评论。字段未填时不能预览下一步。评论暂沿用当前组件 4,000 字符上限，这是实现兼容性，不是新增 BRD 规则。

![下一步确认预览：保留前次批准引用，或进入补批](NEO-007_Page_Review.png)

选择“不需进一步审批”时，预览保留 Mandate 46 V2 的引用并转适用 GFS 检查；选择“仍需审批”时，预览重新评估所需路线。本包 Confirm and continue 禁用，不写业务数据或制造已完成审批。

### 4.4 缺数据或不可比较

![GR 缺失：显示未取得，阻止给出审批结论](NEO-007_Page_Missing.png)

GR 缺失不替换为零；期间不一致、符号规则未确认、评估后计算版本变化均显示具体原因。过期场景提供 Reload valuation 后重评，本地仅模拟刷新，不表示真实接口回读成功。

### 4.5 Mandate 阶段

![Mandate：FTO 更高时保留 FTO 作为示例评估依据](NEO-007_Page_Mandate.png)

Mandate 阶段使用同一套金额依据展示，不冒用前次批准。正式设计将此面板嵌入现有 Mandate 申请及审阅页；独立 HTML 的场景切换不是正式产品导航。

## 5. Change 与 Impact

| 层面 | 要改什么 | 影响与保护 |
| --- | --- | --- |
| 前端 | Mandate、Settlement、Approval Check 共用金额依据及差异面板；关联原批准；缺失与过期提示 | 保留现有表单、附件、风险／机会字段及必填校验；不以本页代替完整申请表 |
| 后端评估 | 依据签收公式生成 FTO／GR 可比值、采用结果及所需政策版本 | 金额非客户端权威；输入缺失返回未完成，不默认 0 |
| 数据 | 保留每次估值、源版本、币种／汇率、批准范围、批准版本与本次复核结果 | 不覆盖历史批准快照；不以最新配置重写历史结论 |
| 流程 | Mandate 提交时评估；Settlement 复核；FBP 判断及补批；并发时重新确认 | 金额增加不自动转 GFS 或外部实施；被旧版本认可的请求不得静默套用新金额 |
| 权限 | Buyer 查看／提交，FBP 在有权处理的任务中决定，管理员维护授权配置 | 角色名称不等于可访问所有记录；FA 边界仍以既有待确认项处理 |
| 审计 | 记录原值／新值、采用依据、前次批准、实际决定人、评论、时间与结果 | 保留退回、重新计算和重新审批历史；旧证据不被新值替换 |
| 测试 | 金额选取、单条／多条汇总、正负值、阈值边界、缺数、并发及原批准复用 | 计算预期应来自 Finance golden cases，不能从本页面反推 |

建议契约字段如 assessmentId、inputVersion、ftoImpact、grImpact、selectedBasis、assessedValue、currency、policyVersion、priorApprovalReference、reviewOutcome 属于本方案的逻辑字段，不是已确认数据库列或 API payload。先对照现有数据字典和实际 API，再决定复用／扩展；本轮未虚构存储列名。

## 6. 系统与接口

| 对接点 | 已有资料 | 复用判断 | 还缺什么 |
| --- | --- | --- | --- |
| SAP GR → NEO | S4：MCI_getGoodsReceiptDetails；GET，经 Apigee；Vendor、日期范围、Material、Movement Type、offset／limit；JSON 响应 | 已有入口，可评估复用；接口登记不等于完整契约 | 响应样例、数量／金额／币种粒度、退货／冲销、期间与工厂归属、分页完整性、超时与重试规则 |
| FTO 输入 → NEO | 原需求明确需要 FTO value，当前代码有 FTO／计算能力 | 优先消费已导入且版本明确的 FTO／计算结果 | 本次采用的 FTO 版本、匹配关系、缺失与刷新规则，及 Finance 确认的影响公式 |
| NEO 计算／审批服务 | 当前 Approval Check、Settlement 和 DoA 管理已有组件 | 内部前后端及版本控制扩展 | 服务端评估契约、DoA 有效期与金额边界、来源更新后的冻结与重评规则 |
| 外部实施 | 本变更不直接创建 WIPS／SAP 单据 | 保留已有下游实施前置 | 必须在审批、GFS及既有完成条件满足后才能实施，本页不扩大范围 |

## 7. 需要业务确认的问题

| ID | 用人话问什么 | 例子与影响 |
| --- | --- | --- |
| NEO007-Q1 | “较高”到底比较什么：带正负号的数，还是同一风险／机会方向的敞口大小？ | -80,000 与 -120,000，数值较大是前者，但敞口较大是后者；会决定审批级别。请 Finance 给成对 golden cases |
| NEO007-Q2 | 先每条 Line 选较高值再相加，还是先把两套值各自相加再比较？ | A 的 FTO／GR 为 80／120，B 为 150／50。逐条选高总和270，分别汇总后选高230；风险／机会仍必须分开 |
| NEO007-Q3 | FTO、GR 比较哪个期间，采用哪种汇率？缺 GR 与真实零收货如何区分？ | 全年预测和仅半年收货不天然可比；本币相同也不能解决期间差异 |
| NEO007-Q4 | 这套规则适用哪些交易？POA、RMA、LSP 都适用吗？ | LSP 不一定有零件 GR；不能为了共用页面给它伪造 GR=0 |
| NEO007-Q5 | 金额增加但还在同一 DoA 档内，是否必须重批？原 Mandate 仅部分批准时如何计算可用范围？ | 原批90,000，新值95,000；不能把“档位没变”当作“批准金额足够” |
| NEO007-Q6 | Settlement 在原批准金额内，哪些条款或范围变化仍需补批？FBP 的决定权覆盖哪些情况？ | 价格总额不变但替换了 Line、供应商或付款条款；BRD 要求 FBP 判断，不是自动沿用 |
| NEO007-Q7 | GR 在提交、审批中或批准后更新时，何时刷新，何时冻结，谁发起重评？ | 昨天按90,000批，今天收货数据算出120,000；不能后台覆盖旧批准金额 |

建议由 Finance／DoA policy owner 回答 Q1–Q6，SAP／Apigee 与应用团队补 Q3／Q7 的数据契约。CR9 提及的 Linda Dawson 是历史联系人，不当作当前已确认责任人。

## 8. 本地检查与正式验收边界

本次 51 项本地设计检查通过。PAGE_VISUAL_CHECK.json 记录实际执行的独立 UI 检查，包括 FTO 高、GR 高、两者相等、原批准范围内的 FBP 两种决定、缺数、期间冲突、符号未确认、过期重评、受限视图、弹窗返回及多尺寸布局。实际结果以该文件为准。

产品权限、持久化、SAP／Apigee、真实 DoA 匹配、流程转移、Finance 对账及线上验收均为 NOT RUN。受限场景只是页面示例，不能证明服务端权限已实现。正式交付需把用例和执行结果合入现有统一 QA 表，不新建一套业务验收主表。

| 正式退出条件 | 当前状态 |
| --- | --- |
| Q1–Q7 已签收，公式／期间／币种／范围有成对预期结果 | 待确认 |
| FTO／GR 数据契约、缺失和冲销处理已核对 | 待确认 |
| 单条和多条、风险与机会、LSP适用性、阈值上下及相等点全部验证 | NOT RUN |
| 同一记录走 Mandate → 原批准 → Settlement 重评 → FBP／补批 → GFS，保留每版快照 | NOT RUN |
| 无权限、重复提交、数据变化和未知回执的恢复路径通过 | NOT RUN |
| 页面与已签收服务端结果一致，Finance及业务验收完成 | NOT RUN |

下一步：业务先确认比较和汇总口径；开发在批准后复用现有 Approval Check、Settlement、DoA 管理组件，落地服务端评估及快照契约，再用 Finance golden cases 验证。独立页面评审可继续下一需求，不代表本条获得生产开发或上线批准。

## 9. Source／Reference

| Source | 文件与精确定位 | 使用范围 |
| --- | --- | --- |
| S1 | NEO Business Requirements (added China requirements) 1.xlsx；RTM for Requested Changes!A8:R8 | NEO-007 原始需求、Finance Must、CR9引用 |
| S2 | 同工作簿；P1 CR clean!A21:Y21 | CR9 原文、历史状态、APPIAN-16465 原始登记、FR10.6引用；未访问或验证 Jira 当前状态 |
| S3 | Material Cost & Inventory - BRD V3.1.docx；表6 第21、22、25、26、33行，FR9／9.1／9.4／9.5／10.6 | 申请、风险／机会分别汇总、FBP复核、DoA配置及审批记录 |
| S4 | Integrations - 2026-11-09_0941(Sheet 1).csv；解析后的第10条逻辑记录，Id=4 | SAP GR接口入口及参数；不是响应payload全规格 |
| S5 | outputs/neo-jira-stories-20261111/v3/story_data.json；entries.act=10、12、13、32 | ACT、Epic及FR现有本地映射 |
| S6 | NEO_FULL_OFFLINE/20261106_REACT_ANTD_v1/app/src/views/Approvals/RequestApprovalCheck.tsx；src/views/Settlement/index.tsx | 当前组件只读检查；准确摘录／行号／哈希见 SOURCE_EVIDENCE.json |
| S7 | 同 app/src/theme/index.ts；项目 jlr-frontend-ux/references/NEO_UXUI_PRINCIPLES.md | 当前 NEO theme及页面设计标准 |

原文件完整路径、抽取内容和 SHA-256 保存在 SOURCE_EVIDENCE.json。表格行是 Word 结构行，不是页面页码；CSV 按逻辑记录计数，因为单元格可能跨物理行。资料未证明的地方明确保持待确认。
